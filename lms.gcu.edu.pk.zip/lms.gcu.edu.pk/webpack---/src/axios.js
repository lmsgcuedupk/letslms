export const baseUrl = 'https://lms.gcu.edu.pk';
 export const wsUrl = 'ws://111.68.103.118:10016';


//   export const baseUrl = 'http://localhost:2004';;
//   export const wsUrl = 'ws://localhost:2004/';


