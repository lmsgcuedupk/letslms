export class AssignmentModal {
  constructor(public title: string) {
  }
}
