export class StNameModel {
  constructor(public rollNo: string, public rn: number) {
  }
}
