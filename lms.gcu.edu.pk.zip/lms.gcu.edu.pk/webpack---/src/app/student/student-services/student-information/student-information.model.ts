export class StudentInformationModel {
    constructor(public registrationNo: string,public studentName: string,public fatherName: string,
        public cnic: string,public phoneNumber: string,
        public rollNumber: string, public dob: string,public address: string,
       public gender: string,public religion: string,
       public phto:any,public email: string,public deptName:string) {
  }
}