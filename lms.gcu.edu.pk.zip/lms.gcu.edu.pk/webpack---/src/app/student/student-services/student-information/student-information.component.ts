import {Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import * as fromApp from '../../../store/app.reducers';
import {Store} from '@ngrx/store';
import {SlideInFromLeft} from '../../../transitions';
import {HttpClient} from '@angular/common/http';
import {ToastrService} from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import {StudentInformationService} from './student-information.service';
import { StudentInformationModel } from './student-information.model';
import { AuthenticationService } from 'src/app/auth/_services/authentication.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';


@Component({
  selector: 'app-student-information',
  templateUrl: './student-information.component.html',
  styleUrls: ['./student-information.component.css'],
  animations: [
    SlideInFromLeft()
  ]
})

export class StudentInformationComponent implements OnInit {

  public studentInformation: StudentInformationModel;
  editPhoneNum: boolean=false;
  editEmailBoolean:boolean=false;

  imageUrl: SafeUrl | null = null;
  private usr = this.authenticationService.getUser();

  isModalVisible = false;
  user_ClassCode = 0;
  c_codes: any[] = [];
  Fall2024Data: any = {};

  // imgbyUser=null;
  constructor(private store: Store<fromApp.AppState>, 
    private studentInformationService: StudentInformationService,
    private authenticationService: AuthenticationService,
    private toastr: ToastrService,
    private http: HttpClient,
    private sanitizer: DomSanitizer
  ) {
      this.studentInformation = new StudentInformationModel("","","", "", "","" , "", "","", "","", "", "");
     }
  @Output() close = new EventEmitter<void>();
  @ViewChild('f')  formref : NgForm;

  ngOnInit(): void {
    this.getFall2024Data();
    const usr =  this.authenticationService.getUser();
    // this.imgbyUser=`http://111.68.103.118:10081/get-file/${this.authenticationService.getUser()?.C_CODE}/${this.authenticationService.getUser()?.SE_ID}/${this.authenticationService.getUser()?.MAJ_ID}/${this.authenticationService.getUser()?.ROLNO}`;
    this.getPicture();
    this.studentInformationService.getStudentInformation(usr.ROLNO).subscribe((res:{
      REG_NO: string,NM: string, F_NM: string, NIC: string, PH1: string, ROLNO: string,  DOB: string, ADD1: string,
      GENDER: string, RELIG: string, PHTO:any,  EMAIL: string,D_NM:string})=>{
      this.studentInformation = new StudentInformationModel(res.REG_NO, res.NM,res.F_NM,res.NIC,res.PH1, res.ROLNO,res.DOB,res.ADD1,res.GENDER,res.RELIG,res.PHTO,res.EMAIL,res.D_NM);
    });
  }

  getFall2024Data(){
    this.Fall2024Data = [];
    this.c_codes = [];
    this.user_ClassCode = this.usr.C_CODE;
    // console.log(this.usr, "USER");
    this.studentInformationService.S_GetFall2024Data({c_code:this.usr.C_CODE, se_id: this.usr.SE_ID, maj_id: this.usr.MAJ_ID, rn: this.usr.RN}).subscribe((res: any) => {
      // console.log(res);
      this.c_codes = res[0][0];
      this.c_codes = Object.values(res[0][0]);
      this.Fall2024Data = res[1][0];
      // console.log(this.c_codes)
      if (this.c_codes.includes(this.usr.C_CODE) && this.usr.YEAR == 2024) {
        this.showModal();
      }
    });
  }

  showModal(): void {
    this.isModalVisible = true;
  }

  hideModal(): void {
    this.isModalVisible = false;
  }

  Update(){

    const {obt, tot, brd_rn, brd_nm, pass_year, division, grd} = this.formref.value;
    if (!obt || !tot || !brd_rn) {
      this.toastr.warning("Fill all the Fields!")
      return;
    }
    this.studentInformationService.S_UpdateFall2024Data({c_code:this.usr.C_CODE, se_id: this.usr.SE_ID, maj_id: this.usr.MAJ_ID, rn: this.usr.RN, obt: obt, tot: tot, brd_rn: brd_rn, brd_nm: brd_nm, pass_year: pass_year, division: division, grd: grd}).subscribe((res :any) => {
      // console.log(res);
      if (res[0][0].msg) {
        // this.hideModal();
        this.toastr.success(res[0][0].msg);
        this.getFall2024Data();
      
      }else{
        this.toastr.error("Could Not Update");

      }
    });
  }

  editEml(rn){
    var params = {
      RolNo: this.studentInformation.rollNumber,
      Email:rn.value
    }
    if(params.Email == ''){
      this.toastr.warning('Fields Must Be Filled.');
    }
    else{
      this.studentInformationService.editEmail(params).subscribe(response => {
        this.toastr.success('Successfully updated.');
        this.editEmailBoolean=false;
        },
        error =>{
          this.toastr.warning(' Error Occured.');
          this.editEmailBoolean=false;
        });
        this.studentInformation.email=rn.value;
    }
  }

  editPhone(form:NgForm)
  {
    var params = {
      RolNo: this.studentInformation.rollNumber,
      PH1:form.value.phone
    }
    if(params.PH1==''){
      this.toastr.warning('Fields Must Be Filled.');
    }
    else{
      this.studentInformationService.editPhone(params).subscribe(res => {
        this.toastr.success('Successfully updated.');
        this.editPhoneNum=false;
        },
        error =>{
        this.toastr.warning(' Error Occured.')
           this.editPhoneNum=false;
        });
        this.studentInformation.phoneNumber=form.value.phone;
    } 
  }
  onPhoneChange(){
    this.editPhoneNum=true;
  }
  onEmailChange(){
    this.editEmailBoolean=true;
  }

  // by Shoaib Abbas

  getPicture(){

    this.studentInformationService.S_getStdtPicture(this.usr.C_CODE, this.usr.SE_ID, this.usr.MAJ_ID, this.usr.ROLNO).subscribe(
      response => {
        const objectURL = URL.createObjectURL(response);
        this.imageUrl = this.sanitizer.bypassSecurityTrustUrl(objectURL);
        // console.log("Image", this.imageUrl);
      },
      error => {
        console.error('Error retrieving student picture', error);
      }
    );
 
  }
}