import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { baseUrl } from 'src/axios.js';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentInformationService {

  private apiUrl = 'https://sfc.gcu.edu.pk/get-lms-img';

  constructor(private http: HttpClient) {
  }

//ZAIN AHMAD, made
  getStudentInformation(rolNo: string) {
    return this.http.get(`${baseUrl}/api/student/getStudentInformation/${rolNo}`);
  }
  editEmail(params) {
    return this.http.post(`${baseUrl}/api/student/editEmailstd`, params);
  }
  editPhone(params) {
    return this.http.post(`${baseUrl}/api/student/editPhonestd`, params);
  }

  // By Shoaib Abbas

  S_getStdtDetail_tm(ROLNO: string) {
    return this.http.post(`${baseUrl}/api/student/S_getStdtDetail_tm`, {ROLNO});
  }

  S_StdtAssignmentDetail(ROLNO: string) {
    return this.http.post(`${baseUrl}/api/student/S_StdtAssignmentDetail`, {ROLNO});
  }

  // S_getStdtPicture(c_code: any, se_id: any, maj_id: any, rolno: any) {
    
  //   return this.http.post(`${baseUrl}/api/student/S_getStdtPicture`, {c_code, se_id, maj_id, rolno});
  // }

  S_getStdtPicture(C_CODE: string, SE_ID: string, MAJ_ID: string, ROLNO: string): Observable<Blob> {
    const token = localStorage.getItem('gcuid'); // Retrieve the token from local storage

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });

    const url = `${this.apiUrl}/${C_CODE}/${SE_ID}/${MAJ_ID}/${ROLNO}`;

    return this.http.get(url, { headers, responseType: 'blob' });
  }

  S_GetFall2024Data(param) {
    return this.http.post(`${baseUrl}/util/S_GetFall2024Data`, {param});
  }

  S_UpdateFall2024Data(param) {
    return this.http.post(`${baseUrl}/util/S_UpdateFall2024Data`, {param});
  }
}