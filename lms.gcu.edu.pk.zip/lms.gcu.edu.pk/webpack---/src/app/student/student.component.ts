import { Component, OnChanges, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CourseModal } from './course/course.modal';
import { AppComponentEventEmitterService } from './event-emmiter.service';
import { User } from '../auth/_models';
import { AuthenticationService } from '../auth/_services';
import { FadeIn } from '../transitions';
import {SRMService} from '../auth/_services/srm.service';
import { FeeService } from '../main/shared/services/Fee.service';
declare var $: any;

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css'],
  animations: [
    FadeIn()
  ]
})
export class StudentComponent implements OnInit {
  public studentName: string;
  public rollNumber: string;
  public cgpa: string;
  // from the role based authentication
  loading = false;
  currentUser: User;
  userFromApi: User;
  imgbyUser;
  icon;
  IsUserLoggedIn = false;
  public semesterCourses: CourseModal[] = new Array<CourseModal>();
  showResetForm = false;
  showChangePassword = false;
  showMessage: boolean;
  msg: string;
  usr = null;


  constructor(
    private SRM:SRMService,
    private router: Router,
    private route: ActivatedRoute,
    private clickEvent: AppComponentEventEmitterService,
    private authenticationService: AuthenticationService,
    private feeService: FeeService) {
    this.currentUser = this.authenticationService.currentUserValue;
    this.showMessage = false;
    this.usr = this.authenticationService.getUser();
    this.feeAnnouncement();
  }

  storage(){    
    window.localStorage.setItem("name","waqas")
    window.localStorage.setItem("id","1234")
    window.localStorage.setItem("location","Lahore")
  }

  navigate(path){
    this.router.navigate([path], { relativeTo: this.route });
  }
  OnStudentInformationClicked() {
    this.router.navigate(['studentInformation'], { relativeTo: this.route });
  }

  onHomeClicked() {
    this.router.navigate(['home'], { relativeTo: this.route });
  }

  OnFeeStructureClicked() {
    this.router.navigate(['feeStructure'], { relativeTo: this.route });
  }

  OnSemesterTranscriptClicked() {
    this.router.navigate(['semesterTranscript'], { relativeTo: this.route });
  }

  OnCompleteTranscriptClicked() {
    this.router.navigate(['completeTranscript'], { relativeTo: this.route });
  }

  OnDateSheetClicked() {
    this.router.navigate(['dateSheet'], { relativeTo: this.route });
  }

  OnTeacherAssesmentClicked() {
    this.router.navigate(['teacherAssessment'], { relativeTo: this.route });
  }

  OnCompliantClicked() {
    this.router.navigate(['complaints'], { relativeTo: this.route });
  }
  OnTimeTableClicked() {
    this.router.navigate(['timeTable'], { relativeTo: this.route });
  }
  
  navigateToAttendence(){
    this.router.navigate(['attendance'], { relativeTo: this.route });

  }
  OnProgressReportClicked() {
    this.router.navigate(['progressReport'], {relativeTo: this.route});
  }
  
  onGradesClicked() {
    this.router.navigate(['grades'], {relativeTo: this.route});
  }
  navigateToAllCourses(){
    this.router.navigate(['teacherEvaluation'],{relativeTo:this.route})
  }
  OnShowMenuListItem(id: string) {
    /*const menu = document.getElementById(id);
    const ul = menu.getElementsByTagName('ul')[0];
    if (ul.classList.contains('mm-show')) {
      ul.classList.remove('mm-show');
      menu.classList.remove('mm-active');
    } else {
      ul.classList.add('mm-show');
      menu.classList.add('mm-active');
    }*/
  }

  OnnavBarHamBtnClicked() {
    const HamButton = document.getElementById('navBarHamBtn');
    const mainDivContainingNav = document.getElementById('main-container');
    if (HamButton.classList.contains('is-active')) {
      HamButton.classList.remove('is-active');
      mainDivContainingNav.classList.remove('sidebar-mobile-open');
    } else {
      HamButton.classList.add('is-active');
      mainDivContainingNav.classList.add('sidebar-mobile-open');
    }
  }
  onClickSRMS(){
    let authuserdata2;
  let authuserdata1=this.authenticationService.getUser();
  this.SRM.fmdetails(authuserdata1.FM_ID).subscribe(res=>{
   
   window.open("http://111.68.103.118:10107?id="+res,"SRM");
  })
  }
  OnnavBarHamBtn_lgClicked() {
    const hamButtonLg = document.getElementById('navBarHamBtn-lg');
    const mainDivContainingNav = document.getElementById('main-container');
    if (hamButtonLg.classList.contains('is-active')) {
      hamButtonLg.classList.remove('is-active');
      mainDivContainingNav.classList.remove('closed-sidebar');
      this.clickEvent.announceClick(false);
    } else {
      hamButtonLg.classList.add('is-active');
      mainDivContainingNav.classList.add('closed-sidebar');
      this.clickEvent.announceClick(true);
    }
  }

  OnAppHeaderMobileMenu() {
    const mobileMenu = document.getElementById('app-header-mobile-menu');
    const buttonContent = document.getElementById('content_mobile');
    const buttonActivated = mobileMenu.classList.contains('active');
    if (buttonActivated) {
      mobileMenu.classList.remove('active');
      buttonContent.classList.remove('header-mobile-open');
    } else {
      mobileMenu.classList.add('active');
      buttonContent.classList.add('header-mobile-open');
    }
  }

  ngOnInit(): void {
    this.studentName = this.usr?.NM;
    this.rollNumber = this.usr?.ROLNO;
    this.cgpa = this.usr?.CGPA;
    this.icon=`../../assets/images/avatars/1.png`;
    this.imgbyUser=`http://111.68.103.118:10081/get-file/${this.authenticationService.getUser()?.C_CODE}/${this.authenticationService.getUser()?.SE_ID}/${this.authenticationService.getUser()?.MAJ_ID}/${this.authenticationService.getUser()?.ROLNO}`;
    // this.HomeAnnouncementService.getEnrollSubByStd(this.usr?.YEAR, this.usr?.C_CODE, this.usr?.MAJ_ID,
    //   this.usr?.RN).pipe().subscribe(
    //     session => {
    //       // @ts-ignore
    //       for (const i in session) {
    //         this.semesterCourses.push(new CourseModal(session[i].sub_nm, session[i].sub_code, session[i].t_no, session[i].section));
    //       }
    //       if (this.semesterCourses.length > 0) {
    //         this.selectedCourse.announceSelectedCourse(this.semesterCourses[0]);

    //       }
    //     },
    //     error => {
    //       console.log(error);
    //     }

    //   );
      
    this.loading = true;

    $('.menu-list ul').on('click', () => {
      if (window.innerWidth < 992) {
        $('#navBarHamBtn').removeClass('is-active');
        $('#main-container').removeClass('sidebar-mobile-open');
      }
    });
    $('ul.vertical-nav-menu > li:not(.menu-list):not(.app-sidebar__heading)').on('click', () => {
      if (window.innerWidth < 992) {
        $('#navBarHamBtn').removeClass('is-active');
        $('#main-container').removeClass('sidebar-mobile-open');
      }
    });


    this.clickEvent.message.subscribe(
      value => {
        this.showMessage = true;
      }
    );
  }

  onCloseResetForm() {
    this.showResetForm = false;
  }

  onShowResetForm() {
    this.showResetForm = true;
  }

  onLogout() {
    this.authenticationService.logout();
  }

  OnChangePasswordClicked() {
    this.showChangePassword = true;
  }

  onCloseChangePasswordForm() {
    this.showChangePassword = false;
  }

  onCloseMessage() {
    this.showMessage = false;
  }

  feeAnnouncement() {
    this.feeService.feeAnnouncement(this.currentUser["C_CODE"], this.currentUser["YEAR"], this.currentUser["MAJ_ID"], this.currentUser["INST_NO"], this.currentUser["RN"]).subscribe((res: any)=>{
      this.msg = res[0][0].msg;
      console.log(res[0])
    })
  }
}