import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { SlideInFromLeft } from '../../transitions';
import { TimetableService, Team } from 'src/app/main/shared/services/Timetable.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from './../../auth/_services/authentication.service';
import { announement } from '../course/annoucement/annoucement.component';
import { AnnouncementService } from './../../main/shared/services/Announcement.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  animations: [
    SlideInFromLeft()
  ]
})
export class HomeComponent implements OnInit {
  @ViewChild('chart') pieChart: ElementRef;
  @ViewChild('c') selectCourse: ElementRef;


  announcement: announement[];
  
  Total = 0;

  user_ClassCode = 0;
  user_Year = 0;
  
  termNo = 0;
  check;
  
 


  lineChartData: ChartDataSets[] = [
    { data: [2.95, 3.14, 3.30, 3.75, 1.9, 3.1, 3.3, 3.6], label: 'Performance' },
  ];
  lineChartLabels: Label[] = ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4', 'Sem 5',
    'Sem 6', 'Sem 7', 'Sem 8'];
  lineChartOptions = {
    responsive: true,
    suggestedMin: 0.0,
    suggestedMax: 4.0
  };
  lineChartColors: Color[] = [
    {
      backgroundColor: 'rgba(103, 58, 183, .1)',
      borderColor: 'rgb(103, 58, 183)',
      pointBackgroundColor: 'rgb(103, 58, 183)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(103, 58, 183, .8)'
      // borderColor: 'rgba(94,79,208,1)',
      // backgroundColor: 'rgba(255,255,0,0.28)'
    },
  ];
  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType = 'line';
  loading = true;


  teams: Team[];


  private usr = null;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private announcementService: AnnouncementService,
    private TimetableService: TimetableService,
    private authenticationService: AuthenticationService) {
      this.usr = this.authenticationService.getUser();
  }

  ngOnInit(): void {
    this.teams = this.TimetableService.getTeam(this.usr?.C_CODE);

    this.loadAnnouncements();

    this.user_ClassCode = this.usr.C_CODE;
    this.user_Year = this.usr.YEAR;
  }


  loadAnnouncements(){
    this.announcementService.getAnnouncements({}).subscribe((res:announement[])=>{
      this.announcement = res;
    });
  }


  navigateToCourse(course: string) {
    this.router.navigate(['../Courses', course], { relativeTo: this.route });
  }




 


}
