import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacher-assesment',
  templateUrl: './teacher-assesment.component.html',
  styleUrls: ['./teacher-assesment.component.css']
})
export class TeacherAssesmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

  }

}
