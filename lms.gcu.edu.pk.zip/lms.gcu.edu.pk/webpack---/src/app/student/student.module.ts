import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {StudentComponent} from './student.component';
import {ComplaintsComponent} from './complaints/complaints.component';
import {HomeComponent} from './home/home.component';
import {PreviousCoursesComponent} from './previous-courses/previous-courses.component';
import {TeacherAssesmentComponent} from './teacher-assesment/teacher-assesment.component';
import {TimeTableComponent} from './time-table/time-table.component';
import {CompleteTranscriptComponent} from './examination/complete-transcript/complete-transcript.component';
import {SemesterTranscriptComponent} from './examination/semester-transcript/semester-transcript.component';
import {DateSheetComponent} from './examination/date-sheet/date-sheet.component';
import {FeeStructureComponent} from './student-services/fee-structure/fee-structure.component';
import {StudentInformationComponent} from './student-services/student-information/student-information.component';
import {StudentRoutingModule} from './student-routing.module';
import {AutoCloseDirective} from './auto.close.directive';
import {AppComponentEventEmitterService} from './event-emmiter.service';
import {ChartsModule} from 'ng2-charts';
import {FormsModule} from '@angular/forms';
import {ChangePasswordComponent} from './change-password/change-password.component';
import { OrderByPipe } from './shared/order-by.pipe';
import { AttendanceComponent } from './attendance/attendance.component';
import { ProgressReportComponent } from './progress-report/progress-report.component';
import { TeacherEvaluationComponent } from './teacher-evaluation/teacher-evaluation.component';

@NgModule({
  declarations: [
    StudentComponent,
    ComplaintsComponent,
    HomeComponent,
    PreviousCoursesComponent,
    TeacherAssesmentComponent,
    TimeTableComponent,
    FeeStructureComponent,
    StudentInformationComponent,
    CompleteTranscriptComponent,
    SemesterTranscriptComponent,
    DateSheetComponent,
    AutoCloseDirective,
    ChangePasswordComponent,
    OrderByPipe,
    AttendanceComponent,
    ProgressReportComponent,
    TeacherEvaluationComponent
  ],
  imports: [
    CommonModule,
    StudentRoutingModule,
    ChartsModule,
    FormsModule
  ],
  providers: [AppComponentEventEmitterService]
})
export class StudentModule { }
