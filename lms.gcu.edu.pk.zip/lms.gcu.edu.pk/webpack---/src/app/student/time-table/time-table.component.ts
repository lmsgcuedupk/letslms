import { Component, ElementRef, OnInit, ViewChild , HostListener} from '@angular/core';
import { SlideInFromLeft } from '../../transitions';
import { Timetable, TimetableService } from '../../main/shared/services/Timetable.service';
import { DatePipe } from '@angular/common';
import { jsPDF } from "jspdf";
import autoTable, { UserOptions } from 'jspdf-autotable';
import * as moment from 'moment';
import 'jspdf-autotable';
import { AuthenticationService } from 'src/app/auth/_services';
import { ToastrService } from 'ngx-toastr';
import { MajorService } from 'src/app/main/shared/services/Major.service';
import { StudentInformationService } from '../student-services/student-information/student-information.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
interface jsPDFWithPlugin extends jsPDF {
  autoTable: (options: UserOptions) => jsPDF;
}

interface StudentDetails {
  c_code: string;
  class_nm: string;
  maj_id: string;
  nm: string;
  se_id: string;
  t_no: string;
}

@Component({
  selector: 'app-time-table',
  templateUrl: './time-table.component.html',
  styleUrls: ['./time-table.component.css'],
  animations: [
    SlideInFromLeft()
  ]
})
export class TimeTableComponent implements OnInit {
  isMobile: boolean = false;
  uniqueSubjects: string[] = [];
  // Mapping of subjects to colors
  subjectColorMap: { [subject: string]: string } = {};


  stdentdetails : StudentDetails;
  imageUrl: SafeUrl | null = null;
  stdt_picture : any;
  stdt_rol: string = "";
  //for calander
  currentMonthName: string;
  currentYear: number;
  weekDays: string[] = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  calendarDates: number[] = [];
  calendar: { date: number | null; isCurrentMonth: boolean }[][] = [];

  public timetable: [Timetable[], Timetable[], Timetable[], Timetable[], Timetable[]];
  public cls: string;
  private se: string;
  private nm: string;
  private sub_comb:string;
  section;
  private rolno: string;
  private f_nm: string;
  private semester;
  days: Array<string>;
  btnHide: boolean = false;
  private usr = this.authenticationService.getUser();
  @ViewChild('convert') data: ElementRef;
  constructor(private TimetableService: TimetableService, private toastr: ToastrService,
    private datePipe: DatePipe, private authenticationService: AuthenticationService,
    private majserve: MajorService,
    private studentService: StudentInformationService,
    private router: Router,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer
  ) {
    this.days = new Array<string>();
  }

  ngOnInit() {
    // if (window.innerWidth <= 575) {
    //   this.isMobile = true; // Set to true if screen width is less than or equal to 575 pixels (adjust the value as needed)
    // }
    this.StudentDetail_tm();
    // this.getCalendar();
    // this.AssignmentDetail();
    this.getPicture();
    this.timetable = this.TimetableService.getTimetable();
    this.rolno = this.usr.ROLNO;
    this.stdt_rol = this.rolno;
    this.majserve.std_PDF(this.rolno).subscribe(
      (res: { F_NM: string, SE_NM: string, M_ID: string,T_NO:number,SUB_COMB:string }) => {
        this.usr = { ...this.usr, F_NM: res[0].f_nm, SE_NM: res[0].SE_NM, M_ID: res[0].M_ID,T_NO:res[0].T_NO,SUB_COMB:res[0].SUB_COMB };
        this.cls = this.usr.M_ID;
        this.se = this.usr.SE_NM;
        this.sub_comb=this.usr.SUB_COMB;
        this.nm = this.usr.NM;
        this.f_nm = this.usr.F_NM;
      }
    );
    this.sortByStartTimeTable();
    this.getDaysFromTM();

    this.extractUniqueSubjects();
  }

  @HostListener('window:resize', ['$event'])
  onWindowResize(event:any){

    if (window.innerWidth <= 575) {
      this.isMobile = true; // Set to true if screen width is less than or equal to 575 pixels (adjust the value as needed)
    }
    else{
      this.isMobile = false;
    }

  }

  StudentDetail_tm(){
    this.studentService.S_getStdtDetail_tm(this.usr.ROLNO).subscribe((res:any)=>{
      this.stdentdetails = res[0][0];
    });
  }

  AssignmentDetail(){
    this.studentService.S_StdtAssignmentDetail(this.usr.ROLNO).subscribe((res:any)=>{
    });
  }

  getPicture(){
    // this.stdt_picture = "";
    // this.studentService.S_getStdtPicture(this.usr.C_CODE, this.usr.SE_ID, this.usr.MAJ_ID, this.usr.ROLNO).subscribe((res: any) => {
    //  this.stdt_picture = res.url;
    // });

    this.studentService.S_getStdtPicture(this.usr.C_CODE, this.usr.SE_ID, this.usr.MAJ_ID, this.usr.ROLNO).subscribe(
      response => {
        const objectURL = URL.createObjectURL(response);
        this.imageUrl = this.sanitizer.bypassSecurityTrustUrl(objectURL);
        console.log("Image", this.imageUrl);
      },
      error => {
        console.error('Error retrieving student picture', error);
      }
    );
 
  }

  getCalendar() {
    const today = new Date();
    this.currentMonthName = this.getMonthName(today.getMonth());
    this.currentYear = today.getFullYear();
    // Create a new date for the first day of the current month
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    // Calculate the day of the week for the first day of the month (0 = Sunday, 1 = Monday, etc.)
    const startDayOfWeek = firstDay.getDay();
    // Initialize the calendar array
    this.calendar = [];
    // Initialize day counter and the week array
    let dayCounter = 1;
    let currentWeek = [];
    // Fill in leading empty slots in the calendar before the first day of the month
    for (let i = 0; i < startDayOfWeek; i++) {
      currentWeek.push({ date: null, isCurrentMonth: false });
    }
    // Fill in the days of the current month
    while (dayCounter <= this.getDaysInMonth(today.getMonth(), today.getFullYear())) {
      currentWeek.push({ date: dayCounter, isCurrentMonth: true });
      // If we've reached the end of the week (Saturday), push the currentWeek to the calendar
      if (currentWeek.length === 7) {
        this.calendar.push([...currentWeek]);
        currentWeek = [];
      }

      dayCounter++;
    }

    // Fill in any remaining empty slots in the last week
    while (currentWeek.length < 7) {
      currentWeek.push({ date: null, isCurrentMonth: false });
    }

    // Push the last week to the calendar
    this.calendar.push([...currentWeek]);
  }

  getMonthName(month: number): string {
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return monthNames[month];
  }

  getDaysInMonth(month: number, year: number): number {
    return new Date(year, month + 1, 0).getDate();
  }

  OnStudentInformationClicked() {
    this.router.navigate(['../studentInformation'], { relativeTo: this.route });
    // this.router.navigateByUrl('/studentInformation');
  }

  private extractUniqueSubjects(): void {
    if (this.timetable) {
      this.timetable.forEach((day) => {
        day.forEach((lecture) => {
          if (!this.uniqueSubjects.includes(lecture.SUB_CODE)) {
            this.uniqueSubjects.push(lecture.SUB_CODE);
          }
        });
      });

      this.ColortoEachSub();
    }
  }

  private getColorByIndex(index: number): string {
    const colors = ['red','blue', 'green', 'orange', 'purple', 'pink', 'brown', 'teal', 'gray', 'magenta', 'cyan', 'lime', 'indigo',
    ];
    return colors[index % colors.length]; // Cycle through the colors
  }

  private ColortoEachSub(){

    this.uniqueSubjects.forEach((subject, index) => {
      // Assign a color based on the index (you can customize this logic)
      const color = this.getColorByIndex(index);
      this.subjectColorMap[subject] = color;
    });

  }

  getColorForSubject(subject: string): string {
    // Use the subjectColorMap to get the color for the subject
    return this.subjectColorMap[subject] || 'gray'; // Default to gray if no color is found
  }
  


  private async sortByStartTimeTable() {
    for (var i = 0; i < this.timetable.length; i++) {
      this.timetable[i]?.sort((a, b) =>
        a.START_TIME < b.START_TIME ? -1 :
         a.START_TIME > b.START_TIME ? 1 : 0
      )
    }
  }
  private getDaysFromTM() {
    for (var i = 0; i < this.timetable.length; i++) {
      var d: string = '';
      for (var j = 0; j < this.timetable[i].length; j++) {
        d = this.timetable[i][j]?.DAY.toString();
        if (!this.days.includes(d)) {
          this.days.push(d);
        }
        this.section = this.timetable[i][j]?.SECTION;
        this.semester = this.timetable[i][j]?.T_NO;
      }
    }
    if (this.days.length != 0) {
      this.btnHide = true;
    }
  }
  initCap(words) {
    var separateWord = words.toLowerCase().split(' ');
    for (var i = 0; i < separateWord.length; i++) {
      separateWord[i] = separateWord[i].charAt(0).toUpperCase() +
        separateWord[i].substring(1);
    }
    return separateWord.join(' ');
  }

  CreatePdf() {
    var body = [];
    var header = [];
    if (this.days.length == 0) {
      this.toastr.warning('Time Table Not Exist.')
      return;
    }
    var pa = (this.usr.ROLNO).substr(5, 1);
    var SEMYE;
    if (parseInt(pa) === 1)
    {
      SEMYE = 'Year';
    }
    else {
      SEMYE = 'Semester'; 
      }
    this.toastr.info("Downloading TimeTable");
    var image = new Image();
    image.src = '../../../assets/images/logo3.png';
    const doc = new jsPDF('p', 'mm', [297, 210]);
    doc.addImage(image, 15, 1, 20, 20);
    var exportDate = this.datePipe.transform(new Date(), 'MMM d,y')
    doc.setFontSize(7);
    doc.text(`${exportDate}`, 18, 24);
    doc.setFontSize(13);
    doc.setFont('Arial', 'bold');
    doc.text("GC UNIVERSITY LAHORE", 40, 8);
    doc.text("Time Table", 40, 14);
    doc.setFontSize(11);

    let clas = this.cls;
    let sess = this.se;
    let nam = this.initCap(this.nm);
    let fnam = this.initCap(this.f_nm);
    let rol = this.rolno;
    let t = this.semester;
let SUB_COMB=this.sub_comb;
    doc.text(clas, 40, 19);
    doc.setFont('Arial', 'normal');
    doc.text('Session: '+sess, 40, 24);
    doc.text(SEMYE+" : "+t, 80, 24);
    doc.text("Subject Combination: "+SUB_COMB, 40, 29);
    doc.setFont('Arial', 'bold');
    doc.setFontSize(10);
    doc.text("Roll No: "+rol, 135, 8);
    doc.text("Name: "+nam, 135, 13);
    doc.text("Father Name: "+fnam, 135, 18);
    var y_val = 0;
    for (var i = 0; i < this.days.length; i++) {//DAYS
      header.push(
        [
          { content: this.days[i], colSpan: 7,styles: {halign: 'left',textColor: [0, 0, 0], fontSize: 8,lineColor:[0,0,0], fillColor: [256, 256, 256] } }
        ], ['Time', 'Block', 'Room', 'SubCode', 'Subject Name', 'Teacher Name', 'Sec']
      );
      y_val = this.timetable[i].length + 2;

      for (var j = 0; j < this.timetable.length; j++) {//MAJOR ARRAY
        for (var k = 0; k < this.timetable[j].length; k++) {//INNER ARRAY

          if (this.days[i] == this.timetable[j][k]?.DAY) {
            var obj = this.timetable[j][k];
            var tt = moment(obj?.START_TIME, 'h:mmA').format('hh:mmA') + '-' + moment(obj?.END_TIME, 'h:mmA').format('hh:mmA');

            body.push([tt, obj?.BLK_NM, obj?.ROOM_NM, obj?.SUB_CODE,
              obj?.SUB_NM, obj?.FM_NAME, obj?.SECTION]);
          }
        }
      }
      autoTable(doc, {
        styles: {
          fontSize: 6,
          minCellHeight: 4,
          cellPadding: 1,
          textColor: [0, 0, 0],
        },
        columnStyles: {
          // 0: { fontStyle: 'bold', fontSize: 9 }
        },
        theme: 'grid',
        margin: { top: 30, bottom: 0 },
        head: header,
        body: body,
      });
      body = [];
      header = [];
    }


    var y_Axis =265;
    // var y_Axis = (y_val * 9.5) + 35;
    var x_axis = 14;

    doc.text("Note :", x_axis, y_Axis);
    doc.setFontSize(8).setFont('Times-Roman', 'Bold');
    doc.setTextColor(255, 0, 0);
    doc.text("1.Dars-e-Quran/Tutorial Group Meeting on Friday from 10:30 am to 11:00 am. There will be no Theory/Practical Class on Friday from 10:30 am to 11:10 am", x_axis, y_Axis + 4);
    doc.setTextColor(0, 0, 0);
    doc.text("2.The Duration of each class can be different for different subject depending upon their credit hours.", x_axis, y_Axis + 8);
    doc.text("3.Consult Concerned Chairperson if Teacher is not in class room ", x_axis, y_Axis + 12);
    doc.text("4.In case any query, contact Prof. Inam ul Haq(Incharge General Time Table) in Statistics Department PGB-313 from 09:00 am to 10:30 am.", x_axis, y_Axis + 16);
    doc.text("5.Always keep a photocopy of time table in your possession during academic year, as no duplicate time table will be issued.", x_axis, y_Axis + 20);
    doc.text("* University reserves the right to amend Time Table at any time according to availability of faculty,space and combination.", x_axis, y_Axis + 24);


    doc.setFontSize(7).setFont('Times-Roman');
    doc.setFont('Arial', 'normal');
    doc.text("By:Directorate of Information Technology", 15, 295);
    doc.text('Note: Errors and Omissions are Excepted', 155, 295);


    var a = this.toastr;
    setTimeout(function () {
      a.success("Downloaded");
    }, 1000);

    doc.save('Time Table ' + this.rolno);
  }
}
