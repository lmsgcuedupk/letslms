import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {StudentComponent} from './student.component';
import {ComplaintsComponent} from './complaints/complaints.component';
import {HomeComponent} from './home/home.component';
import {PreviousCoursesComponent} from './previous-courses/previous-courses.component';
import {TeacherAssesmentComponent} from './teacher-assesment/teacher-assesment.component';
import {TimeTableComponent} from './time-table/time-table.component';
import {CompleteTranscriptComponent} from './examination/complete-transcript/complete-transcript.component';
import {SemesterTranscriptComponent} from './examination/semester-transcript/semester-transcript.component';
import {DateSheetComponent} from './examination/date-sheet/date-sheet.component';
import {FeeStructureComponent} from './student-services/fee-structure/fee-structure.component';
import {StudentInformationComponent} from './student-services/student-information/student-information.component';
import {AttendanceComponent } from './attendance/attendance.component';
import {ProgressReportComponent } from './progress-report/progress-report.component';
import {TeacherEvaluationComponent } from './teacher-evaluation/teacher-evaluation.component';
// import {StdPreviousMarksComponent } from './std-previous-marks/std-previous-marks.component';

const routes: Routes = [
  {
    path: '', component: StudentComponent, children: [
      { path: 'complaints', component: ComplaintsComponent },
      { path: 'Courses/:sub_code', loadChildren: () => import(`./course/course.module`).then(m => m.CourseModule) },
      { path: 'completeTranscript', component: CompleteTranscriptComponent },
      { path: 'attendance', component: AttendanceComponent },
      { path: 'semesterTranscript', component: SemesterTranscriptComponent },
      { path: 'dateSheet', component: DateSheetComponent },
      { path: 'home', component: HomeComponent },
      { path: 'previousCourses', component: PreviousCoursesComponent },
      { path: 'feeStructure', component: FeeStructureComponent },
      { path: 'studentInformation', component: StudentInformationComponent },
      { path: 'teacherAssessment', component: TeacherAssesmentComponent },
      { path: 'timeTable', component: TimeTableComponent },
      { path: 'teacherEvaluation',component:TeacherEvaluationComponent},
      { path: 'progressReport', component: ProgressReportComponent },

      { path: 'grades', loadChildren: () => import(`./std-grades/StdGrades.module`).then(m => m.StdGradesModule) },
      
      {path: 'Challans',loadChildren: () => import(`./chalans/chalan.module`).then(m => m.ChalanModule) },
      
      { path: '', redirectTo: 'home', pathMatch: 'full' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentRoutingModule { }
