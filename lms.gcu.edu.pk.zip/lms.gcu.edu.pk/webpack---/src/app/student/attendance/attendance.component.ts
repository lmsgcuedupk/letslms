import { Component, OnInit } from '@angular/core';
import { SlideInFromLeft } from 'src/app/transitions';
import { Team, TimetableService } from './../../main/shared/services/Timetable.service';
import { AuthenticationService } from 'src/app/auth/_services/authentication.service';
import { Color, Label } from 'ng2-charts';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { AttendanceService } from './../../main/attendance/attendance-services/attendance.service';
import { ToastrService } from 'ngx-toastr';
import { filter } from 'src/app/shared/functions/tableSearch';

interface att {
  DA_DATE: string;
  ATTEND: string;
  MONTH_NM: string;
  MONTH: string;
}

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css'],
  animations: [
    SlideInFromLeft()
  ]
})
export class AttendanceComponent implements OnInit {

  private months = ['Jan', 'Feb', 'March', 'April', 'May', 'June', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  private usr;
  teams: Team[];
  subCode = '';
  attendance: att[];
  attendanceLoading = false;

  presents = 0;
  absents = 0;
  leaves = 0;
  per=0;
  // pie chart data
  pieChartLabels: Label[] = ['ABSENTS', 'PRESENTS', 'LEAVES'];
  pieChartData: number[] = [this.presents, this.absents, this.leaves];
  pieChartType: ChartType = 'pie';
  pieChartLegend = true;
  pieChartPlugins = [];

  public pieChartOptions: ChartOptions = {
    responsive: true,
  };



  lineChartLabels: Label[] = [];
  lineChartData: ChartDataSets[] = [
    { data: [], label: 'Absent' },
    { data: [], label: 'Presents' },
    { data: [], label: 'leaves' },
  ];

  lineChartOptions = {
    responsive: true,
    suggestedMin: 0,
    suggestedMax: 100
  };
  lineChartColors: Color[] = [
    {
      backgroundColor: 'rgba(103, 58, 183, .1)',
      borderColor: 'rgb(103, 58, 183)',
      pointBackgroundColor: 'rgb(103, 58, 183)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(103, 58, 183, .8)',
    },
  ];
  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType = 'line';

  constructor(private timetableService: TimetableService,
    private authenticationService: AuthenticationService,
    private attendanceService: AttendanceService,
    private toastrService: ToastrService) {
    this.usr = this.authenticationService.getUser();
    this.attendance = [];
  }

  ngOnInit(): void {
    this.teams = this.timetableService.getWorkingTeams(this.usr.C_CODE);
    
    if(this.teams?.length>0){
      this.OnCourseChangeOnInit(this.teams[0])
    }
  }


  OnCourseChangeOnInit(c) {
    this.getAttendanace(this.teams.find(x => x.SUB_CODE === c.SUB_CODE));


    this.subCode = '';
    this.subCode = c.value;
  }

  OnCourseChange(c: HTMLSelectElement) {
    this.getAttendanace(this.teams.find(x => x.SUB_CODE === c.value));


    this.subCode = '';
    this.subCode = c.value;
  }
  getAttendanace(team) {
    this.attendance=[];
    this.absents=0;
    this.presents=0;
    this.leaves=0;
    this.per=0;
    this.attendanceLoading = true;
    this.attendanceService.getStdAttendance(team).subscribe((res:att[]) => {
      this.attendance=res;
      this.attendanceLoading = false;

      this.presents = (res?.filter(x => x.ATTEND === 'p'))?.length;
      this.absents = (res?.filter(x => x.ATTEND === 'a'))?.length;
      this.leaves = (res?.filter(x => (x.ATTEND === 'd'||x.ATTEND === 'l')))?.length;
      this.pieChartData = [this.absents, this.presents, this.leaves];


      //for line chart
      let months: Set<string> = new Set<string>();
      res?.forEach(entry => {
        entry.MONTH = this.getMonthName(parseInt(entry.MONTH_NM));
        months.add(entry.MONTH);
      });


      let present: number[] = [];
      let absent: number[] = [];
      let leaves: number[] = [];
      let total: number[] = [];

      months.forEach(mon => {
        present.push(res?.filter(x => x.MONTH === mon && x.ATTEND === 'p')?.length);
        absent.push(res?.filter(x => x.MONTH === mon && x.ATTEND === 'a')?.length);
        leaves.push(res?.filter(x => x.MONTH === mon && (x.ATTEND === 'd'||x.ATTEND === 'l'))?.length);
        total.push()
      });

      this.lineChartLabels = Array.from(months);
      this.lineChartData = [
        { data: absent, label: 'Absent' },
        { data: present, label: 'Present' },
        { data: leaves, label: 'Leaves' }
      ];
      if(this.attendance?.length===0){
        this.presents=0;
        this.absents=0;
        this.leaves=0;
        this.per=0;
      }

    }, err => {
      console.log(err);
      this.attendanceLoading = false;
      this.toastrService.error("Unknown Error");
    });
  }

  getMonthName(monthId: number) {
    return this.months[monthId - 1];
  }

  Filter()
    {
      filter();
    }
}
