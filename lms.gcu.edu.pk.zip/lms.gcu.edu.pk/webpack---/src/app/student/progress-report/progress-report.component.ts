import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { SlideInFromLeft } from 'src/app/transitions';
import { ProgressServices } from 'src/app/main/progress-report/progress-services';
import { ToastrService } from 'ngx-toastr';
import 'jspdf-autotable';
import { jsPDF } from "jspdf";
import { DatePipe } from '@angular/common';
import autoTable, { UserOptions } from 'jspdf-autotable'
import { AuthenticationService } from 'src/app/auth/_services/authentication.service';
import * as moment from 'moment';
interface jsPDFWithPlugin extends jsPDF {
  autoTable: (options: UserOptions) => jsPDF;
}
export interface subjectInformation {
  Father_name: string;
  GP_PER: number;
  Name: string;
  Roll_number: string;
  SUB_CODE: string;
  c_class: string;
  grd: string;
  reg_no: null
  req_cr_hr: number
  session: string;
  subject_name: string;
  t_no: number;
}
export interface studentNamesInformation {
  DES: string,
  F_NM: string,
  NM: string,
  REG_NO: string,
  ROLNO: string,
  SE_ID: string,
  MAJTITLE: string
}

export interface studentCgpaInformation {
  ROLNO: string,
  cr_h: number,
  earn: number,
  gp: number,
  sgpa: number,
  t_no: number,
  cgpa:number
}

@Component({
  selector: 'app-progress-report',
  templateUrl: './progress-report.component.html',
  styleUrls: ['./progress-report.component.css'],
  animations: [
    SlideInFromLeft()
  ]
})

export class ProgressReportComponent implements OnInit {
  transcript: Map<number, subjectInformation[]>;
  repeat:Map<string,number>;
  improve: Map<number, subjectInformation[]>;
  stdNamesInfo: Map<string, studentNamesInformation[]>;
  stdCgpaInfo: Array<studentCgpaInformation>;
  extra:Map<number,{earn:number,cr_h:number}>;
  public num: any;
  private usr;
  public sbInfo: any;
  // earn_h=0;
  public total_cr_h;
  public total_grade_point;
  public total_cgpa;
  public today: any = new Date();
  btnHide:boolean=false;

  constructor(private proSer: ProgressServices,
    private authenticationService: AuthenticationService,
    private toaster: ToastrService, private datePipe: DatePipe) {
   this.repeat=new Map<string,number>();
   this.improve= new Map<number, subjectInformation[]>();
    this.transcript = new Map<number, subjectInformation[]>();
    this.stdNamesInfo = new Map<string, studentNamesInformation[]>();
    this.stdCgpaInfo = new Array<studentCgpaInformation>();
    this.extra=new Map();
    this.usr = this.authenticationService.getUser();
    this.total_cr_h = 0.0;
    this.total_cgpa = 0.0;
    this.total_grade_point = 0.0;
    this.today = moment(this.today).format('DD-MMM-YYYY');
  }
  ngOnInit(): void {
    this.OnSubmit();
  }
  OnSubmit() {
    this.transcript.clear();
    this.stdCgpaInfo = [];
    this.stdNamesInfo.clear();
    //called by services of tchr panel progress report component.
    this.proSer.getExamRslt(this.usr?.C_CODE, this.usr?.SE_ID, this.usr?.RN,
      this.usr?.RN, this.usr?.YEAR, this.usr?.MAJ_ID).subscribe((res: [studentNamesInformation[], subjectInformation[], studentCgpaInformation[]]) => {
      this.btnHide=true;
        res[0]?.forEach(entry => {
          if (this.stdNamesInfo.has(entry.ROLNO)) {
            this.stdNamesInfo.get(entry.ROLNO).push(entry);
          }
          else {
            this.stdNamesInfo.set(entry.ROLNO, new Array<studentNamesInformation>(entry));
          }
        });
        res[1]?.forEach(entry => {
          if(this.repeat.has(entry.SUB_CODE)){
        //  this.extra+=entry.req_cr_hr;
        this.extra.get(this.repeat.get(entry.SUB_CODE)).earn+=entry.req_cr_hr;
            if(this.improve.has(this.repeat.get(entry.SUB_CODE))){
              this.improve.get(this.repeat.get(entry.SUB_CODE)).push(entry);
            }
            else
          this.improve.set(this.repeat.get(entry.SUB_CODE), new Array<subjectInformation>(entry));
          }else
          {
        //  this.earn_h+=entry.req_cr_hr;
          this.repeat.set(entry.SUB_CODE,entry.t_no);
          if (this.transcript.has(entry.t_no)) {
            this.transcript.get(entry.t_no).push(entry);
            if(entry.grd!="F" && entry.grd!="f" && entry.grd!="In" && entry.grd!="in")
            this.extra.get(entry.t_no).earn+=entry.req_cr_hr;
            this.extra.get(entry.t_no).cr_h+=entry.req_cr_hr;
          }
          else {
            this.extra.set(entry.t_no,{earn:entry.req_cr_hr,cr_h:entry.req_cr_hr})
            this.transcript.set(entry.t_no, new Array<subjectInformation>(entry));
          }
        }
        });
        res[2]?.forEach((entry,index) => {
          this.stdCgpaInfo.push(entry);
          this.stdCgpaInfo[index].cr_h
          =this.extra.get(index+1)?.cr_h;
          this.stdCgpaInfo[index].earn=
          Math.min(this.extra.get(index+1)?.earn,this.extra.get(index+1)?.cr_h)
          this.total_cr_h += this.stdCgpaInfo[index].cr_h;
          this.total_grade_point += this.stdCgpaInfo[index].gp;
        });
        this.total_cgpa=Math.floor(this.stdCgpaInfo[this.stdCgpaInfo.length-1].cgpa*100)/100;
        this.num = this.stdNamesInfo.get(this.usr?.ROLNO);

      });
  }
  public sgp: any;
  public number1;
}