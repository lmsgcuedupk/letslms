import { Component, OnInit, ViewChild } from '@angular/core';
import { TimetableService, Team } from 'src/app/main/shared/services/Timetable.service';
import { SlideInFromLeft } from 'src/app/transitions';
import { AuthenticationService } from './../../auth/_services/authentication.service';
import { TeacherEvaluationServices } from './teacherEvaluation-Services';
import { ToastrService } from 'ngx-toastr';
import { SelectList } from 'src/app/main/shared/model/SelectList.model';
import { NgForm } from '@angular/forms';
export interface Pattern{
  PT_ID:number,
  PD_ID: number,
  PD_OPT: string
}
export interface FormQuestions{
  C_CODE:string,
  D_ID:string,
  MAJ_ID:string,
  RESPONSE_ID:string
  QUES_ID:string,
  QUESTION:string,
  FRM_ID:string,
  T_NO:string,
  YEAR:string,
  SE_ID:string,
  RN:string,
  SECTION:string,
  SUB_CODE:string,
  SUBMISSION_DT:Date,
  CUR_YEAR:number
}
@Component({
  selector: 'app-teacher-evaluation',
  templateUrl: './teacher-evaluation.component.html',
  styleUrls: ['./teacher-evaluation.component.css'],
  animations:[
    SlideInFromLeft()
  ]
})
export class TeacherEvaluationComponent implements OnInit {
  @ViewChild('f') formRef:NgForm;
  teams: Team[];
  private usr = null;
  val:string;
  formQues:Array<FormQuestions>;
  pat:Array<Pattern>;
  sub:string;
  obj:any;
  teacher:Array<SelectList>;
  showDetail:boolean=false;
  hideBtn:boolean=true;

  submitted:boolean=false;
  dueDate:boolean=false;
  info:boolean=false;
  showComment:boolean = true;
  
  ans: Array<{ question_id: string, response_id:string }>;
    constructor(private TimetableService: TimetableService,
      private authenticationService: AuthenticationService,
      private tchrEvalSer:TeacherEvaluationServices,private toaster:ToastrService) { 
      this.usr = this.authenticationService.getUser();
      this.pat = new Array<Pattern>();
      this.formQues=new Array<FormQuestions>();
      this.sub='';
      this.obj='';
      this.teacher=[];
      this.ans = new Array<{ question_id: string,response_id:string }>();
      }
  ngOnInit(): void {
    this.teams = this.TimetableService.getTeam(this.usr?.C_CODE);
    // this.teams = this.TimetableService.getAllteam(this.usr?.C_CODE);
    this.navigateToSingleCourse(this.teams[0]?.SUB_CODE,0);
  }
  navigateToSingleCourse(sub_code:string,i){
    
    this.info=false;
    this.submitted=false;
    this.dueDate=false;

    this.sub = sub_code;
    this.obj = '';
    this.pat=[];
    this.formQues=[];
    this.val=sub_code;
    this.showDetail=true;
    this.hideBtn=true;
    this.ans = [];
    this.getTeacherName(this.sub,this.usr.C_CODE,this.usr.SE_ID,this.teams[0].T_NO, this.teams[0].SECTION);
    this.obj=this.teams[i];
    this.tchrEvalSer.getEvaluationForm(this.usr.C_CODE,this.usr.SE_ID,this.teams[0].T_NO,this.usr.RN,this.teams[0].SECTION,sub_code,
      this.usr.YEAR,this.usr.MAJ_ID).subscribe((res:{msg:string}) =>{
      if(res?.msg === 'Submit'){
        this.hideBtn=false;
        this.submitted=true;
        this.info=false;
        this.dueDate=false;
        return;
      }
      if(res?.msg === '2'){
        this.hideBtn=false;
        this.dueDate=true;
        this.submitted=false;
        this.info=false;
        return;
      }
      res[0]?.forEach(e=>{
        this.formQues.push(e);
      });
      res[1]?.forEach(e =>{
        this.pat.push(e);
      });
      if(this.formQues.length==0){
        this.info=true;
        this.submitted=false;
        this.dueDate=false;
        this.hideBtn=false;
        return;
      }
      else{
        this.info=false;
        return;
      }   
    })
  }
  getTeacherName(sc:string,cc:string,seid:string,tNo:string,sec:string,){
    this.teacher=[];
    this.tchrEvalSer.getTeacherName(sc,cc,seid,tNo,sec).subscribe((res:{NM:string,FM_ID:number}[]) =>{
      res?.forEach(e =>{
        this.teacher.push({nm:e.NM,id:e.FM_ID});
      })
    })
  }
  
  updateSelection(q_id,pd_id){
    this.formQues[q_id].RESPONSE_ID = pd_id;
    let objIndex:number=-1;
     objIndex= this.ans.findIndex((obj => obj.question_id==q_id));
    if(objIndex != -1){
      this.ans[objIndex].response_id=pd_id;
    }
    else{
      this.ans.push({question_id:q_id, response_id:pd_id});
    }
  }
  onSubmitForm(){
    if(this.ans.length != this.formQues.length){
      this.toaster.warning('Fill Form Properly');
      return;
    }
    // this.hideBtn=true;
    this.tchrEvalSer.updateEvalFormSelection({
    year:this.usr.YEAR, c_code:this.usr.C_CODE,se_id:this.usr.SE_ID,
    maj_id:this.usr.MAJ_ID,t_no:this.teams[0].T_NO,sub_code:this.sub,
    section:this.teams[0].SECTION,rn:this.usr.RN, frm_id:this.formQues[0].FRM_ID,
    fm_id:this.teacher[0]?.id, array:this.ans
    }).subscribe(res =>{
      this.commentSubmit();
      // this.formQues=[];
      this.hideBtn=false;
      this.submitted=true;
      this.toaster.success('Form Submit Successfully.');
      this.ans = [];
    })
  }


  private commentSubmit(){
    // if(!this.formRef.value.comment) return;
    let param = {
        year:this.usr?.YEAR, c_code:this.usr?.C_CODE,se_id:this.usr?.SE_ID,
        maj_id:this.usr?.MAJ_ID,t_no:this.teams[0]?.T_NO,sub_code:this.sub,
        section:this.teams[0]?.SECTION,rn:this.usr?.RN, frm_id:this.formQues[0]?.FRM_ID,
        fm_id:this.teacher[0]?.id, comment:this.formRef.value.comment,cur_year:this.formQues[0]?.CUR_YEAR
    }
    this.tchrEvalSer.EV_F_insertEvaluationFormComment(param).subscribe((res:{affectedRows:number}) =>{
      if(res?.affectedRows!=0){
        this.formQues=[];
      }
    })

  }

}