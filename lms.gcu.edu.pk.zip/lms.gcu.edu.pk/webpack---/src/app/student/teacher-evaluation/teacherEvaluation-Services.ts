import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { baseUrl } from '../../../axios';
@Injectable({
    providedIn: 'root'
})

export class TeacherEvaluationServices {

    constructor(private http: HttpClient) {
    }
    getEvaluationForm(c_code:string,se_id:string,t_no:string,rn:string,section:string,subCode:string,year:string,maj_id:string){
        return this.http.get(`${baseUrl}/api/forms/getEvaluationForm/${c_code}/${se_id}/${t_no}/${rn}/${section}/${subCode}/${year}/${maj_id}`);
    }
    updateEvalFormSelection(params){
        return this.http.post(`${baseUrl}/api/forms/updateEvalFormSelection`,params);
    }
    getTeacherName(sub_code:string,c_code:string,se_id:string,t_no:string,section:string){
        return this.http.get(`${baseUrl}/api/forms/getTeacherName/${sub_code}/${c_code}/${se_id}/${t_no}/${section}`);
    }
    EV_F_insertEvaluationFormComment(params){
        return this.http.post(`${baseUrl}/api/forms/EV_F_insertEvaluationFormComment`,params);
    }
}