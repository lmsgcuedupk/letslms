import { Injectable } from '@angular/core';
import {
    Router,
    CanActivate,
    Route,
    UrlSegment,
    ActivatedRouteSnapshot,
    RouterStateSnapshot,
    UrlTree
} from '@angular/router';
import { Observable } from 'rxjs';

import { AuthenticationService } from '../_services';

@Injectable({ providedIn: 'root' })
export class AccessGuard implements CanActivate {
    constructor(private authenticationService: AuthenticationService,
        private router: Router) {
    }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        return this.authenticationService.isAdmin();
    }
}
