import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
    constructor() { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // Modify the request to include the custom header
        request = request.clone({
            setHeaders: {
                Authorization: `Bearer ${JSON.parse(localStorage.getItem("gcuid"))}` 
//             'x-secret-key': '0333666224403096681544',

            }
        });

        return next.handle(request);
    }
}

