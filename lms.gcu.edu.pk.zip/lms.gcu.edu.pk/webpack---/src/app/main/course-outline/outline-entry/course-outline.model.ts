export class CourseOutlineModel {
    constructor(public sub_nm: string, public cr_h: number, public nm: string, public content: string,
        public week_no: number, public t_no: number, public methodology: string,
        public sub_code: string, public se_id: number, public section: string,
        public plagirism: string, public out_id: number, public outcome: string,
        public objective: string, public material: string, public maj_id: number,
        public fm_id: number, public d_id: number, public c_code: number,
        public attendance: string, public assessment: string, public support: string) {
    }
}