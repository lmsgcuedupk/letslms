export class SubjectModel {
    constructor(public subId: string, public SUB_CODE: string, public SUB_NM: string, public nickName: string, public subDept: string, public subClass: string,
        public cr_h:string, public nat_id:string) {
    }
}