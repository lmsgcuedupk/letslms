import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { baseUrl } from 'src/axios.js';
@Injectable({
    providedIn: 'root'
})

export class AnnouncementService {

    constructor(private http: HttpClient) {
    }


    getAnnouncements(params) {
        return this.http.post(`${baseUrl}/api/announcement/getAnnoucements`, params);
    }

     // for record add screen
     UploadDailyRecord(params){
        return this.http.post(`${baseUrl}/api/systemUpdates/uploadDailyRecord`,params);
    }

    getRecord(params){
        return this.http.post(`${baseUrl}/api/systemUpdates/getRecord`,params);
    }

}