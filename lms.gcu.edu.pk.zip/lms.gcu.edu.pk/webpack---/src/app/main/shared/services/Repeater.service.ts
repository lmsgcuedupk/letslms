import { Injectable } from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';
import { baseUrl } from 'src/axios.js';
@Injectable({
    providedIn: 'root'
})

export class RepeaterService {

    constructor(private http: HttpClient) {
    }

    getSectionCountandName(grp:string,se_id: string, t_no: string, c_code: string, sub_code: string) {
        return this.http.get(`${baseUrl}/api/repeater/getSectionCountandName/${grp}/${se_id}/${t_no}/${c_code}/${sub_code}`);
    }  



    getRepeaterAttAssignData(year: string, c_code: string, rn: string, t_no: string, maj_id: string, sub_code: string, se_id: string, sec: string) {
        return this.http.get(`${baseUrl}/api/repeater/getRepeaterAttAssignData/${year}/${c_code}/${rn}/${t_no}/${maj_id}/${sub_code}/${se_id}/${sec}`);
    }






    DeleteRepeaterEnrollment(year: string, c_code: string, rn: string, t_no: string, maj_id: string, sub_code: string, se_id: string, sec: string) {
        return this.http.post(`${baseUrl}/api/repeater/DeleteRepeaterEnrollment`,{year:year,c_code:c_code,rn:rn,t_no:t_no,maj_id:maj_id,sub_code:sub_code,se_id:se_id,sec:sec} );
    }
    
    RepeaterEnrollment(year: string, c_code: string, rn: string, t_no: string, maj_id: string, sub_code: string, se_id: string, sec: string) {
        let params = new HttpParams().set('year', year.valueOf()).set('c_code', c_code.valueOf()).set('rn', rn.valueOf()).set('t_no', t_no.valueOf()).set('maj_id', maj_id.valueOf()).set('sub_code', sub_code.valueOf()).set('se_id', se_id.valueOf()).set('sec', sec.valueOf());
        return this.http.post(`${baseUrl}/api/repeater/RepeaterEnrollment`, params);
    }
    GetSubjectNatureId(c_code:number, sub_code:string){
            return this.http.get(`${baseUrl}/api/repeater/GetSubjectNatureId/${c_code}/${sub_code}`);
    }

    SearchRepeater(c_code: string, se_id: string, t_no: string, rn: string, year: string) {
        return this.http.get(`${baseUrl}/api/repeater/SearchRepeater/${c_code}/${se_id}/${t_no}/${rn}/${year}`);
    }
   
    viewAllRepeater(c_code: string, maj_id: string, se_id: string, t_no: string, sub_code: string) {
        return this.http.get(`${baseUrl}/api/repeater/viewAllRepeater/${c_code}/${maj_id || 0}/${se_id || 0}/${t_no || 0}/${sub_code || null}`);
    }
    getSubjectRepeaterStudents(c_code: string, se_id: string, t_no: string){
        return this.http.get(`${baseUrl}/api/repeater/getSubjectRepeaterStudents/${c_code}/${se_id}/${t_no}`);

    }
}

