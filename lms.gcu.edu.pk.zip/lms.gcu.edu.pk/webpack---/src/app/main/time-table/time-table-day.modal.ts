export class TimeTableDay {
  constructor(public isLecture: boolean,
              public teacher: string,
              public roomNo: string,
              public lecture: string) {
  }
}
