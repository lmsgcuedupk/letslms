import {TimeTableDay} from './time-table-day.modal';

export class TimeTableModal {

  constructor(public timetable: [TimeTableDay[], TimeTableDay[], TimeTableDay[], TimeTableDay[], TimeTableDay[]]) {
  }
}
