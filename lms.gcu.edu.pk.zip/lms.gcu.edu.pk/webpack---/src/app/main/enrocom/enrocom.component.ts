import { Component, OnInit } from '@angular/core';
import { SlideInFromLeft } from 'src/app/transitions';
@Component({
  selector: 'app-enrocom',
  templateUrl: './enrocom.component.html',
  styleUrls: ['./enrocom.component.css'],
  animations: [
    SlideInFromLeft()
  ]
})
export class EnrocomComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
