export class StudentRollNumberModel {
    constructor(public studentRN: number) {
    }
}