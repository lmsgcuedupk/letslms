export class SubjectModel {
    constructor(public subCode: string, public subName: string) {
    }
}