export class StudentNameModel {
    constructor(public StudentName: string) {
    }
}