import { Component, OnInit } from '@angular/core';
import { SlideInFromLeft } from 'src/app/transitions';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css'],
  animations: [
    SlideInFromLeft()
  ]
})
export class CalendarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
