export class SubjectModel {
    constructor(public subCode: string, public subName: string,public CR_H:number,public NAT_ID:number) {
    }
}