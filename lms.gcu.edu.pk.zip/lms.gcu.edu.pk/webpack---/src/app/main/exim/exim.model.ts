
export class tableCollection{
    public tb_id;
    // public tb_nm;
constructor(tb_id:string/*,tb_nm:string*/){
this.tb_id=tb_id;
// this.tb_nm=tb_nm;
}

}