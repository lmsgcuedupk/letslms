export class TimetableModel {
    constructor(public sub_code:string,public grp: number,public tmId: string, public dId: number, public deptNm: string, public cNm: string, public se: number, public tNo: number, public section: string, public subject: string, public fmId: string, public fm: string, public day: string, public sTime: string, public eTime: string,  public blkId: string,public blkNm:string, public rmId:string, public rmNm: string, public status: number) {
    }
}