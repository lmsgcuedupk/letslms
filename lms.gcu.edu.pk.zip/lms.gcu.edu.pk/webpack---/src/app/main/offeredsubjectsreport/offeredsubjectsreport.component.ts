import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offeredsubjectsreport',
  templateUrl: './offeredsubjectsreport.component.html',
  styleUrls: ['./offeredsubjectsreport.component.css']
})
export class OfferedsubjectsreportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
