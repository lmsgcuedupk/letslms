export class SubjectModel {
  // tslint:disable-next-line:variable-name
  constructor(public sub_code: string, public sub_nm: string ) {}

}
