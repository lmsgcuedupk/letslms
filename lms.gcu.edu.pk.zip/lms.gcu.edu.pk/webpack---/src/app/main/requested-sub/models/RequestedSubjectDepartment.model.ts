export class RequestedSubjectDepartmentModel {
    constructor(public c_code: number, public c_nm: string, public maj_id: number, public maj_nm: string, public se_id: number, public se: string, public t_no: number, public status: number) {
    }
}