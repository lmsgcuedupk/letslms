"use strict";
(self["webpackChunklmsv3"] = self["webpackChunklmsv3"] || []).push([["src_app_student_student_module_ts"],{

/***/ 8422:
/*!************************************************************!*\
  !*** ./src/app/student/attendance/attendance.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendanceComponent": () => (/* binding */ AttendanceComponent)
/* harmony export */ });
/* harmony import */ var src_app_transitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/transitions */ 71629);
/* harmony import */ var src_app_shared_functions_tableSearch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/functions/tableSearch */ 7535);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _main_shared_services_Timetable_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../main/shared/services/Timetable.service */ 3651);
/* harmony import */ var src_app_auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/auth/_services/authentication.service */ 7893);
/* harmony import */ var _main_attendance_attendance_services_attendance_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../main/attendance/attendance-services/attendance.service */ 35640);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-toastr */ 94817);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ng2-charts */ 53808);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 2508);










function AttendanceComponent_span_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "span", 26);
  }
}
function AttendanceComponent_option_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const t_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpropertyInterpolate"]("value", t_r6.SUB_CODE);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate2"](" ", t_r6.SUB_CODE, "-", t_r6.SUB_NM, "");
  }
}
function AttendanceComponent_div_39_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 28)(1, "input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("keydown", function AttendanceComponent_div_39_Template_input_keydown_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r8.Filter());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
}
const _c0 = function (a0, a1) {
  return {
    "text-danger": a0,
    "text-success": a1
  };
};
function AttendanceComponent_tr_50_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr", 30)(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](5, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const a_r10 = ctx.$implicit;
    const i_r11 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction2"](7, _c0, a_r10.ATTEND === "a" || a_r10.ATTEND === "A", a_r10.ATTEND === "p" || a_r10.ATTEND === "P"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](i_r11 + 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](5, 4, a_r10.DA_DATE, " dd MMM, y"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", a_r10.ATTEND === "p" || a_r10.ATTEND === "P" ? "Present" : a_r10.ATTEND === "a" || a_r10.ATTEND === "A" ? "Absent" : "Leave", " ");
  }
}
class AttendanceComponent {
  constructor(timetableService, authenticationService, attendanceService, toastrService) {
    this.timetableService = timetableService;
    this.authenticationService = authenticationService;
    this.attendanceService = attendanceService;
    this.toastrService = toastrService;
    this.months = ['Jan', 'Feb', 'March', 'April', 'May', 'June', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    this.subCode = '';
    this.attendanceLoading = false;
    this.presents = 0;
    this.absents = 0;
    this.leaves = 0;
    this.per = 0;
    // pie chart data
    this.pieChartLabels = ['ABSENTS', 'PRESENTS', 'LEAVES'];
    this.pieChartData = [this.presents, this.absents, this.leaves];
    this.pieChartType = 'pie';
    this.pieChartLegend = true;
    this.pieChartPlugins = [];
    this.pieChartOptions = {
      responsive: true
    };
    this.lineChartLabels = [];
    this.lineChartData = [{
      data: [],
      label: 'Absent'
    }, {
      data: [],
      label: 'Presents'
    }, {
      data: [],
      label: 'leaves'
    }];
    this.lineChartOptions = {
      responsive: true,
      suggestedMin: 0,
      suggestedMax: 100
    };
    this.lineChartColors = [{
      backgroundColor: 'rgba(103, 58, 183, .1)',
      borderColor: 'rgb(103, 58, 183)',
      pointBackgroundColor: 'rgb(103, 58, 183)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(103, 58, 183, .8)'
    }];
    this.lineChartLegend = true;
    this.lineChartPlugins = [];
    this.lineChartType = 'line';
    this.usr = this.authenticationService.getUser();
    this.attendance = [];
  }
  ngOnInit() {
    this.teams = this.timetableService.getWorkingTeams(this.usr.C_CODE);
    if (this.teams?.length > 0) {
      this.OnCourseChangeOnInit(this.teams[0]);
    }
  }
  OnCourseChangeOnInit(c) {
    this.getAttendanace(this.teams.find(x => x.SUB_CODE === c.SUB_CODE));
    this.subCode = '';
    this.subCode = c.value;
  }
  OnCourseChange(c) {
    this.getAttendanace(this.teams.find(x => x.SUB_CODE === c.value));
    this.subCode = '';
    this.subCode = c.value;
  }
  getAttendanace(team) {
    this.attendance = [];
    this.absents = 0;
    this.presents = 0;
    this.leaves = 0;
    this.per = 0;
    this.attendanceLoading = true;
    this.attendanceService.getStdAttendance(team).subscribe(res => {
      this.attendance = res;
      this.attendanceLoading = false;
      this.presents = res?.filter(x => x.ATTEND === 'p')?.length;
      this.absents = res?.filter(x => x.ATTEND === 'a')?.length;
      this.leaves = res?.filter(x => x.ATTEND === 'd' || x.ATTEND === 'l')?.length;
      this.pieChartData = [this.absents, this.presents, this.leaves];
      //for line chart
      let months = new Set();
      res?.forEach(entry => {
        entry.MONTH = this.getMonthName(parseInt(entry.MONTH_NM));
        months.add(entry.MONTH);
      });
      let present = [];
      let absent = [];
      let leaves = [];
      let total = [];
      months.forEach(mon => {
        present.push(res?.filter(x => x.MONTH === mon && x.ATTEND === 'p')?.length);
        absent.push(res?.filter(x => x.MONTH === mon && x.ATTEND === 'a')?.length);
        leaves.push(res?.filter(x => x.MONTH === mon && (x.ATTEND === 'd' || x.ATTEND === 'l'))?.length);
        total.push();
      });
      this.lineChartLabels = Array.from(months);
      this.lineChartData = [{
        data: absent,
        label: 'Absent'
      }, {
        data: present,
        label: 'Present'
      }, {
        data: leaves,
        label: 'Leaves'
      }];
      if (this.attendance?.length === 0) {
        this.presents = 0;
        this.absents = 0;
        this.leaves = 0;
        this.per = 0;
      }
    }, err => {
      console.log(err);
      this.attendanceLoading = false;
      this.toastrService.error("Unknown Error");
    });
  }
  getMonthName(monthId) {
    return this.months[monthId - 1];
  }
  Filter() {
    (0,src_app_shared_functions_tableSearch__WEBPACK_IMPORTED_MODULE_1__.filter)();
  }
  static #_ = this.ɵfac = function AttendanceComponent_Factory(t) {
    return new (t || AttendanceComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_main_shared_services_Timetable_service__WEBPACK_IMPORTED_MODULE_2__.TimetableService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_3__.AuthenticationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_main_attendance_attendance_services_attendance_service__WEBPACK_IMPORTED_MODULE_4__.AttendanceService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](ngx_toastr__WEBPACK_IMPORTED_MODULE_6__.ToastrService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: AttendanceComponent,
    selectors: [["app-attendance"]],
    decls: 51,
    vars: 22,
    consts: [[1, "card", "mb-3"], [1, "card-header"], [1, "row", "mt-4", "mb-2", "card-body"], [1, "col-md-12", "col-lg-5"], [1, "card"], ["class", "spinner-border  spinner-border-sm mr-1", 4, "ngIf"], [1, "card-body"], [1, "form-group", "mt-2"], ["name", "input_attendence_course", "id", "input_attendence_course", 1, "form-control", 3, "change"], ["c", ""], [3, "value", 4, "ngFor", "ngForOf"], [1, "chart-wrapper"], ["baseChart", "", 3, "data", "labels", "chartType", "options", "plugins", "legend"], ["chart", ""], [1, "card-footer"], [1, "row", "pb-2"], [1, "col-sm-4", "m-auto"], [1, "col-sm-6", "m-auto"], [1, "col-md-12", "col-lg-7"], ["baseChart", "", 3, "datasets", "labels", "options", "colors", "legend", "chartType", "plugins"], ["class", "col-lg-12 col-md-6 form-group px-0 mt-0 pt-1", 4, "ngIf"], ["id", "table", 1, "table", "table-striped", "table-bordered"], [1, "thead-dark"], ["scope", "col", 2, "width", "5vw"], ["scope", "col"], ["id", "values", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "spinner-border", "spinner-border-sm", "mr-1"], [3, "value"], [1, "col-lg-12", "col-md-6", "form-group", "px-0", "mt-0", "pt-1"], ["type", "text", "name", "Search", "placeholder", "Search", "id", "myInput", 1, "form-control", "col-lg-4", 3, "keydown"], ["id", "values", 3, "ngClass"]],
    template: function AttendanceComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div")(1, "div", 0)(2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " Courses ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "div", 2)(5, "div", 3)(6, "div", 4)(7, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](8, AttendanceComponent_span_8_Template, 1, 0, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9, " Overall Attendance Report with Detail ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 6)(11, "div", 7)(12, "select", 8, 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function AttendanceComponent_Template_select_change_12_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r12);
          const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](13);
          return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx.OnCourseChange(_r1));
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](14, AttendanceComponent_option_14_Template, 2, 3, "option", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](16, "canvas", 12, 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "div", 14)(19, "div", 15)(20, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](24, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "div", 15)(27, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "div", 18)(30, "div", 4)(31, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](32, "Monthly Report");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](33, "div", 6)(34, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](35, "canvas", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](36, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](37, " Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](38, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](39, AttendanceComponent_div_39_Template, 2, 0, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](40, "table", 21)(41, "thead", 22)(42, "tr")(43, "th", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](44, "Sr No");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](45, "th", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](46, "Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](47, "th", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](48, "Status");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](49, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](50, AttendanceComponent_tr_50_Template, 8, 10, "tr", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.attendanceLoading);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.teams);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("data", ctx.pieChartData)("labels", ctx.pieChartLabels)("chartType", ctx.pieChartType)("options", ctx.pieChartOptions)("plugins", ctx.pieChartPlugins)("legend", ctx.pieChartLegend);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("Presents: ", ctx.presents, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("Absents: ", ctx.absents, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("Leaves: ", ctx.leaves, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("Percentage: ", ctx.presents + ctx.absents + ctx.leaves > 1 ? ((ctx.presents + ctx.leaves) / (ctx.presents + ctx.absents + ctx.leaves) * 100).toFixed(2) + "%" : 0, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("datasets", ctx.lineChartData)("labels", ctx.lineChartLabels)("options", ctx.lineChartOptions)("colors", ctx.lineChartColors)("legend", ctx.lineChartLegend)("chartType", ctx.lineChartType)("plugins", ctx.lineChartPlugins);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.attendance.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.attendance);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, ng2_charts__WEBPACK_IMPORTED_MODULE_8__.BaseChartDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgSelectMultipleOption"], _angular_common__WEBPACK_IMPORTED_MODULE_7__.DatePipe],
    styles: [".text-center[_ngcontent-%COMP%] {\n    text-align: center;\n    font-weight: bold;\n  }\n  \n  table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n    vertical-align: middle !important;\n    font-weight: bold;\n    font-size: 12.5px;\n    text-align: center;\n  }\n  \n  .center[_ngcontent-%COMP%] {\n    align-items: center;\n    justify-content: center;\n    display: flex;\n  }\n  \n  table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n    text-align: center;\n    font-size: 13px;\n  }\n  \n  table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n    width: 100%;\n    font-size: 13px;\n  }\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9hdHRlbmRhbmNlL2F0dGVuZGFuY2UuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGtCQUFrQjtJQUNsQixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxpQ0FBaUM7SUFDakMsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxtQkFBbUI7SUFDbkIsdUJBQXVCO0lBQ3ZCLGFBQWE7RUFDZjs7RUFFQTtJQUNFLGtCQUFrQjtJQUNsQixlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsV0FBVztJQUNYLGVBQWU7RUFDakIiLCJzb3VyY2VzQ29udGVudCI6WyIudGV4dC1jZW50ZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgfVxuICBcbiAgdGFibGUgdGQge1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGUgIWltcG9ydGFudDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXNpemU6IDEyLjVweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbiAgXG4gIC5jZW50ZXIge1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgZGlzcGxheTogZmxleDtcbiAgfVxuICBcbiAgdGFibGUgdGgge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDEzcHg7XG4gIH1cbiAgXG4gIHRhYmxlIHRkIGlucHV0IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBmb250LXNpemU6IDEzcHg7XG4gIH0iXSwic291cmNlUm9vdCI6IiJ9 */"],
    data: {
      animation: [(0,src_app_transitions__WEBPACK_IMPORTED_MODULE_0__.SlideInFromLeft)()]
    }
  });
}

/***/ }),

/***/ 47144:
/*!*************************************************!*\
  !*** ./src/app/student/auto.close.directive.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AutoCloseDirective": () => (/* binding */ AutoCloseDirective)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class AutoCloseDirective {
  constructor(elRef) {
    this.elRef = elRef;
    this.isActive = false;
  }
  toggleOpen() {
    this.isActive = !this.isActive;
    this.elRef.nativeElement.children[1].classList.toggle('mm-show');
  }
  onBlur() {
    setTimeout(() => {
      this.isActive = false;
      this.elRef.nativeElement.children[1].classList.remove('mm-show');
    }, 100);
  }
  ngOnInit() {}
  static #_ = this.ɵfac = function AutoCloseDirective_Factory(t) {
    return new (t || AutoCloseDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef));
  };
  static #_2 = this.ɵdir = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
    type: AutoCloseDirective,
    selectors: [["", "autoCloseItem", ""]],
    hostVars: 2,
    hostBindings: function AutoCloseDirective_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AutoCloseDirective_click_HostBindingHandler() {
          return ctx.toggleOpen();
        })("blur", function AutoCloseDirective_blur_HostBindingHandler() {
          return ctx.onBlur();
        });
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("mm-active", ctx.isActive);
      }
    }
  });
}

/***/ }),

/***/ 98867:
/*!**********************************************************************!*\
  !*** ./src/app/student/change-password/change-password.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePasswordComponent": () => (/* binding */ ChangePasswordComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/auth/_services/authentication.service */ 7893);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-toastr */ 94817);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);






const _c0 = ["f"];
function ChangePasswordComponent_div_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 25)(1, "div")(2, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Password is Mismatched");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
  }
}
const _c1 = function (a0, a1) {
  return {
    "is-invalid": a0,
    "is-valid": a1
  };
};
const _c2 = function (a0, a1) {
  return {
    "text-danger": a0,
    "text-success": a1
  };
};
const _c3 = function (a0) {
  return {
    "is-invalid": a0
  };
};
class ChangePasswordComponent {
  constructor(authService, toastr) {
    this.authService = authService;
    this.toastr = toastr;
    this.submitted = false;
    this.user = this.authService.getUser();
    this.rolno = "";
    this.hasUpperCase = false;
    this.hasLowerCase = false;
    this.hasNumber = false;
    this.hasSpecialChar = false;
    this.isMinLength = false;
    this.showPassword = {
      oldpass: false,
      newpass: false,
      confirmpass: false
    };
    // tslint:disable-next-line:no-output-native
    this.close = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
  }
  onClose() {
    this.close.emit();
  }
  ngOnInit() {
    setTimeout(() => {
      $(".backdrop").css("opacity", "1");
    }, 50);
    this.rolno = this.user.ROLNO;
  }
  OnChangeClicked(form) {
    this.submitted = true;
    if (form.value.cnic === "" || form.value.oldpass === "" || form.value.newpass === "" || form.value.newpass !== form.value.confirmpass) {
      this.submitted = false;
      return;
    }
    this.authService.changePassword(form.value).subscribe(res => {
      this.submitted = false;
      if (res.status == 1) {
        this.toastr.success("Password Changed Successfully");
        setTimeout(() => {
          this.close.emit();
        }, 1000);
      } else {
        this.toastr.warning("Incorrect Previous Password");
      }
    }, error => {
      this.submitted = false;
      this.toastr.error("Some Error Occured");
    });
  }
  checkPasswordStrength(password) {
    this.hasUpperCase = /[A-Z]/.test(password);
    this.hasLowerCase = /[a-z]/.test(password);
    this.hasNumber = /\d/.test(password);
    this.hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    this.isMinLength = password.length >= 8;
  }
  togglePasswordVisibility(field) {
    this.showPassword[field] = !this.showPassword[field];
  }
  isPasswordStrong() {
    return this.hasUpperCase && this.hasLowerCase && this.hasNumber && this.hasSpecialChar && this.isMinLength;
  }
  static #_ = this.ɵfac = function ChangePasswordComponent_Factory(t) {
    return new (t || ChangePasswordComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_0__.AuthenticationService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](ngx_toastr__WEBPACK_IMPORTED_MODULE_2__.ToastrService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: ChangePasswordComponent,
    selectors: [["app-change-password"]],
    viewQuery: function ChangePasswordComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.formRef = _t.first);
      }
    },
    outputs: {
      close: "close"
    },
    decls: 41,
    vars: 20,
    consts: [[1, "backdrop"], [1, "row"], [1, "col-sm-6", "offset-sm-3", "ml-2", "mr-2", "ml-sm-auto", "mr-sm-auto"], [1, "alert-box"], ["action", "", 1, "clearfix", 3, "ngSubmit"], ["form", "ngForm"], [1, "form-group", "mb-4"], ["for", "usnm"], ["type", "text", "name", "usnm", "id", "usnm", "readonly", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "inputOldPassword"], [1, "position-relative"], ["ngModel", "", "name", "oldpass", "id", "inputOldPassword", "required", "", 1, "form-control", 3, "type"], [1, "show-password", 3, "click"], [1, "fa", 2, "color", "darkgray", 3, "ngClass"], ["for", "inputNewPassword"], ["ngModel", "", "name", "newpass", "id", "inputNewPassword", "required", "", 1, "form-control", 3, "type", "ngClass", "input"], [1, "password-guidelines"], [3, "ngClass"], [1, "position-relative", "form-group"], ["for", "confirmpass"], ["name", "confirmpass", "id", "confirmpass", "ngModel", "", "required", "", 1, "form-control", 3, "type", "ngClass"], ["confirmpass", ""], ["class", "invalid-feedback", 4, "ngIf"], ["type", "submit", 1, "btn", "btn-danger", "float-right", 3, "disabled"], [1, "btn", "btn-outline-secondary", "float-right", "mr-2", 3, "click"], [1, "invalid-feedback"]],
    template: function ChangePasswordComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "form", 4, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngSubmit", function ChangePasswordComponent_Template_form_ngSubmit_4_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r3);
          const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](5);
          return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx.OnChangeClicked(_r0));
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 6)(7, "label", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8, "Username");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function ChangePasswordComponent_Template_input_ngModelChange_9_listener($event) {
          return ctx.rolno = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "div", 6)(11, "label", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12, "Old Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](14, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "i", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ChangePasswordComponent_Template_i_click_15_listener() {
          return ctx.togglePasswordVisibility("oldpass");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div", 6)(18, "label", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19, "New Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "div", 10)(21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("input", function ChangePasswordComponent_Template_input_input_21_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r3);
          const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](5);
          return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx.checkPasswordStrength(_r0.value.newpass));
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "i", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ChangePasswordComponent_Template_i_click_22_listener() {
          return ctx.togglePasswordVisibility("newpass");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](23, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "div", 16)(25, "p", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](26, " Use at least one uppercase letter, one lowercase letter, one number, one special character, and minimum 8 characters ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "div", 18)(28, "label", 19)(29, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30, "Confirm Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](31, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](32, "input", 20, 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](34, "i", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ChangePasswordComponent_Template_i_click_34_listener() {
          return ctx.togglePasswordVisibility("confirmpass");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](35, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](36, ChangePasswordComponent_div_36_Template, 4, 0, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](37, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](38, " Change ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](39, "button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ChangePasswordComponent_Template_button_click_39_listener() {
          return ctx.onClose();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](40, " Close ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](5);
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](33);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.rolno);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("type", ctx.showPassword["oldpass"] ? "text" : "password");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", ctx.showPassword["oldpass"] ? "fa-eye-slash" : "fa-eye");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("type", ctx.showPassword["newpass"] ? "text" : "password")("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](12, _c1, !ctx.isPasswordStrong(), ctx.isPasswordStrong()));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", ctx.showPassword["newpass"] ? "fa-eye-slash" : "fa-eye");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](15, _c2, !ctx.hasUpperCase || !ctx.hasLowerCase || !ctx.hasNumber || !ctx.hasSpecialChar || !ctx.isMinLength, ctx.hasUpperCase && ctx.hasLowerCase && ctx.hasNumber && ctx.hasSpecialChar && ctx.isMinLength));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("type", ctx.showPassword["confirmpass"] ? "text" : "password")("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction1"](18, _c3, ctx.submitted && _r0.value.newpass !== _r0.value.confirmpass));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", ctx.showPassword["confirmpass"] ? "fa-eye-slash" : "fa-eye");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", _r0.value.newpass !== _r0.value.confirmpass && _r1.value !== "");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", !_r0.valid);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgForm],
    styles: [".backdrop[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  background: rgba(0, 0, 0, 0.75);\n  z-index: 80;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  opacity: 0;\n  transition: opacity 0.4s;\n}\n\n.alert-box[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 800px; \n  border-radius: 5px;\n  padding: 24px;\n  background: white;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.26);\n  z-index: 100;\n  box-sizing: border-box;\n}\n\n.form-group[_ngcontent-%COMP%] {\n  margin-bottom: 1rem;\n}\n\n.position-relative[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.form-control[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 600%;\n  padding: 12px;\n  font-size: 16px; \n}\n\n.password-guidelines[_ngcontent-%COMP%] {\n  margin-top: 5px;\n}\n\n.password-guidelines[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 14px;\n  margin: 0;\n}\n\n.password-guidelines[_ngcontent-%COMP%]   .text-danger[_ngcontent-%COMP%] {\n  color: red;\n}\n\n.password-guidelines[_ngcontent-%COMP%]   .text-success[_ngcontent-%COMP%] {\n  color: green;\n}\n\n.invalid-feedback[_ngcontent-%COMP%] {\n  display: block;\n  color: red;\n}\n\n.is-invalid[_ngcontent-%COMP%] {\n  border-color: red;\n}\n\n.btn[_ngcontent-%COMP%] {\n  margin-top: 10px;\n}\n\n.btn.float-right[_ngcontent-%COMP%] {\n  margin-left: 10px;\n}\n\n.show-password[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 10px;\n  top: 50%;\n  transform: translateY(-50%);\n  cursor: pointer;\n  z-index: 101;\n}\n\n.show-password[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 20px;\n  color: #007bff;\n}\n\n.invalid-feedback[_ngcontent-%COMP%] {\n  display: block;\n  color: red;\n  margin-top: 5px;\n  font-weight: bold; \n}\n\n.is-invalid[_ngcontent-%COMP%] {\n  border-color: red;\n}\n.form-control.is-valid[_ngcontent-%COMP%] {\n  border-color: green;\n  background-image: none;\n  border-width: revert;\n}\n\n.form-control.is-invalid[_ngcontent-%COMP%] {\n  border-color: red;\n  background-image: none;\n  border-width: revert;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9jaGFuZ2UtcGFzc3dvcmQvY2hhbmdlLXBhc3N3b3JkLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQWU7RUFDZixNQUFNO0VBQ04sT0FBTztFQUNQLFdBQVc7RUFDWCxZQUFZO0VBQ1osK0JBQStCO0VBQy9CLFdBQVc7RUFDWCxhQUFhO0VBQ2IsdUJBQXVCO0VBQ3ZCLG1CQUFtQjtFQUNuQixVQUFVO0VBQ1Ysd0JBQXdCO0FBQzFCOztBQUVBO0VBQ0UsV0FBVztFQUNYLGdCQUFnQjtFQUNoQixrQkFBa0I7RUFDbEIsYUFBYTtFQUNiLGlCQUFpQjtFQUNqQix5Q0FBeUM7RUFDekMsWUFBWTtFQUNaLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxlQUFlO0VBQ2YsYUFBYTtFQUNiLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsZUFBZTtFQUNmLFNBQVM7QUFDWDs7QUFFQTtFQUNFLFVBQVU7QUFDWjs7QUFFQTtFQUNFLFlBQVk7QUFDZDs7QUFFQTtFQUNFLGNBQWM7RUFDZCxVQUFVO0FBQ1o7O0FBRUE7RUFDRSxpQkFBaUI7QUFDbkI7O0FBRUE7RUFDRSxnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxpQkFBaUI7QUFDbkI7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFFBQVE7RUFDUiwyQkFBMkI7RUFDM0IsZUFBZTtFQUNmLFlBQVk7QUFDZDs7QUFFQTtFQUNFLGVBQWU7RUFDZixjQUFjO0FBQ2hCOztBQUVBO0VBQ0UsY0FBYztFQUNkLFVBQVU7RUFDVixlQUFlO0VBQ2YsaUJBQWlCO0FBQ25COztBQUVBO0VBQ0UsaUJBQWlCO0FBQ25CO0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsc0JBQXNCO0VBQ3RCLG9CQUFvQjtBQUN0Qjs7QUFFQTtFQUNFLGlCQUFpQjtFQUNqQixzQkFBc0I7RUFDdEIsb0JBQW9CO0FBQ3RCIiwic291cmNlc0NvbnRlbnQiOlsiLmJhY2tkcm9wIHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC43NSk7XG4gIHotaW5kZXg6IDgwO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgb3BhY2l0eTogMDtcbiAgdHJhbnNpdGlvbjogb3BhY2l0eSAwLjRzO1xufVxuXG4uYWxlcnQtYm94IHtcbiAgd2lkdGg6IDEwMCU7XG4gIG1heC13aWR0aDogODAwcHg7IFxuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIHBhZGRpbmc6IDI0cHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBib3gtc2hhZG93OiAwIDJweCA4cHggcmdiYSgwLCAwLCAwLCAwLjI2KTtcbiAgei1pbmRleDogMTAwO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xufVxuXG4uZm9ybS1ncm91cCB7XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG59XG5cbi5wb3NpdGlvbi1yZWxhdGl2ZSB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLmZvcm0tY29udHJvbCB7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXgtd2lkdGg6IDYwMCU7XG4gIHBhZGRpbmc6IDEycHg7XG4gIGZvbnQtc2l6ZTogMTZweDsgXG59XG5cbi5wYXNzd29yZC1ndWlkZWxpbmVzIHtcbiAgbWFyZ2luLXRvcDogNXB4O1xufVxuXG4ucGFzc3dvcmQtZ3VpZGVsaW5lcyBwIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBtYXJnaW46IDA7XG59XG5cbi5wYXNzd29yZC1ndWlkZWxpbmVzIC50ZXh0LWRhbmdlciB7XG4gIGNvbG9yOiByZWQ7XG59XG5cbi5wYXNzd29yZC1ndWlkZWxpbmVzIC50ZXh0LXN1Y2Nlc3Mge1xuICBjb2xvcjogZ3JlZW47XG59XG5cbi5pbnZhbGlkLWZlZWRiYWNrIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGNvbG9yOiByZWQ7XG59XG5cbi5pcy1pbnZhbGlkIHtcbiAgYm9yZGVyLWNvbG9yOiByZWQ7XG59XG5cbi5idG4ge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4uYnRuLmZsb2F0LXJpZ2h0IHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5cbi5zaG93LXBhc3N3b3JkIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMTBweDtcbiAgdG9wOiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICB6LWluZGV4OiAxMDE7XG59XG5cbi5zaG93LXBhc3N3b3JkIGkge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGNvbG9yOiAjMDA3YmZmO1xufVxuXG4uaW52YWxpZC1mZWVkYmFjayB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBjb2xvcjogcmVkO1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkOyBcbn1cblxuLmlzLWludmFsaWQge1xuICBib3JkZXItY29sb3I6IHJlZDtcbn1cbi5mb3JtLWNvbnRyb2wuaXMtdmFsaWQge1xuICBib3JkZXItY29sb3I6IGdyZWVuO1xuICBiYWNrZ3JvdW5kLWltYWdlOiBub25lO1xuICBib3JkZXItd2lkdGg6IHJldmVydDtcbn1cblxuLmZvcm0tY29udHJvbC5pcy1pbnZhbGlkIHtcbiAgYm9yZGVyLWNvbG9yOiByZWQ7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmU7XG4gIGJvcmRlci13aWR0aDogcmV2ZXJ0O1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 92277:
/*!*******************************************************!*\
  !*** ./src/app/student/complaints/complaint.model.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComplaintModel": () => (/* binding */ ComplaintModel)
/* harmony export */ });
/*export interface ComplaintModel {
  regNo: string;
  studentName: string;
  contactNo: string;
  email: string;
  complaintRelatedTo: string;
  complaintDetails: string;
  complaintDocument: string;
  revealIdentity: boolean;
  termAndConditionAgreement: boolean;
}*/
class ComplaintModel {
  constructor(regNo, studentName, contactNo, email, complaintRelatedTo, complaintDetails, complaintDocument, revealIdentity, termAndConditionAgreement) {
    this.regNo = regNo;
    this.studentName = studentName;
    this.contactNo = contactNo;
    this.email = email;
    this.complaintRelatedTo = complaintRelatedTo;
    this.complaintDetails = complaintDetails;
    this.complaintDocument = complaintDocument;
    this.revealIdentity = revealIdentity;
    this.termAndConditionAgreement = termAndConditionAgreement;
  }
}

/***/ }),

/***/ 62687:
/*!************************************************************!*\
  !*** ./src/app/student/complaints/complaints.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComplaintsComponent": () => (/* binding */ ComplaintsComponent)
/* harmony export */ });
/* harmony import */ var _complaint_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./complaint.model */ 92277);
/* harmony import */ var _store_complaints_component_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./store/complaints.component.actions */ 5341);
/* harmony import */ var _transitions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../transitions */ 71629);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ 23488);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);







function ComplaintsComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ComplaintsComponent_div_3_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r3);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r2.onClose());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Invalid Input ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "button", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3, "Close");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
}
class ComplaintsComponent {
  constructor(store) {
    this.store = store;
    this.show = false;
  }
  ngOnInit() {
    $('input[type="file"]').change(e => {
      const fileName = e.target.files[0].name;
      $('.custom-file-label').html(fileName);
    });
  }
  onSubmit(form) {
    this.show = !form.valid && form.touched;
    this.data = new _complaint_model__WEBPACK_IMPORTED_MODULE_0__.ComplaintModel(form.value.InputRegistration, form.value.InputStudentName, form.value.InputContactNo, form.value.InputEmail, form.value.inputComplaint, form.value.inputComplaintDetails, form.value.inputComplaintDocument, form.value.inputRevealIdentity, form.value.inputAgreement);
    this.store.dispatch(new _store_complaints_component_actions__WEBPACK_IMPORTED_MODULE_1__.StoreInformation(this.data));
    setTimeout(() => {}, 3000);
  }
  onClose() {
    this.show = false;
  }
  static #_ = this.ɵfac = function ComplaintsComponent_Factory(t) {
    return new (t || ComplaintsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_4__.Store));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: ComplaintsComponent,
    selectors: [["app-complaints"]],
    decls: 65,
    vars: 3,
    consts: [[1, "p-lg-5", "mt-5", "p-sm-3"], [3, "ngSubmit"], ["form", "ngForm"], ["class", "alert alert-danger d-flex justify-content-between", 3, "click", 4, "ngIf"], [1, "row"], [1, "col-sm-12", "col-lg-6"], [1, "form-group"], ["for", "InputRegistration", 1, "text-bold"], ["type", "text", "name", "InputRegistration", "id", "InputRegistration", "ngModel", "", "required", "", "placeholder", "", 1, "form-control", "shadow-sm"], ["for", "InputStudentName", 1, "text-bold"], ["type", "text", "name", "InputStudentName", "id", "InputStudentName", "ngModel", "", "required", "", "placeholder", "", 1, "form-control", "shadow-sm"], ["for", "InputContactNo", 1, "text-bold"], ["type", "tel", "name", "InputContactNo", "id", "InputContactNo", "required", "", "ngModel", "", "placeholder", "+92-XXX-XXXXXXX", 1, "form-control", "shadow-sm"], ["for", "InputEmail", 1, "text-bold"], ["type", "email", "name", "InputEmail", "id", "InputEmail", "ngModel", "", "placeholder", "", 1, "form-control", "shadow-sm"], [1, "col-sm-12", "col-lg-6", 2, "margin-bottom", "50px"], ["for", "inputComplaint", 1, "text-bold"], ["name", "inputComplaint", "id", "inputComplaint", "ngModel", "", 1, "form-control", "shadow-sm"], ["for", "inputComplaintDetails", 1, "text-bold"], ["name", "inputComplaintDetails", "id", "inputComplaintDetails", "ngModel", "", "required", "", "rows", "5", 1, "form-control", "shadow-sm"], [1, "text-bold", "mt-2"], [1, "input-group"], [1, "custom-file"], ["type", "file", "id", "inputGroupFile01", "name", "inputComplaintDocument", "ngModel", "", "aria-describedby", "inputGroupFileAddon01", 1, "custom-file-input"], ["for", "inputGroupFile01", 1, "custom-file-label", "shadow-sm"], [1, "mt-5", "custom-control", "custom-switch", "form-group"], ["type", "checkbox", "ngModel", "", "name", "inputRevealIdentity", "id", "customSwitch1", 1, "custom-control-input"], ["for", "customSwitch1", 1, "custom-control-label"], [1, "p", "mt-1"], [1, "custom-control", "custom-checkbox", "form-group"], ["type", "checkbox", "name", "inputAgreement", "ngModel", "", "id", "customCheck1", 1, "custom-control-input"], ["for", "customCheck1", 1, "custom-control-label", "text-bold"], ["type", "submit", 1, "btn", "btn-primary", "lift-animation", "mt-4", "float-right", 3, "disabled"], [1, "alert", "alert-danger", "d-flex", "justify-content-between", 3, "click"], [1, "btn", "btn-danger"]],
    template: function ComplaintsComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "form", 1, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngSubmit", function ComplaintsComponent_Template_form_ngSubmit_1_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r4);
          const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](2);
          return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx.onSubmit(_r0));
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, ComplaintsComponent_div_3_Template, 4, 0, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "label", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](8, "Registration#");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 6)(11, "label", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12, "Student Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](13, "input", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "div", 6)(15, "label", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](16, "Contact-No");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](17, "input", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 6)(19, "label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Email");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](22, "div", 15)(23, "div", 6)(24, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](25, "Complaint related to");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "select", 17)(27, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](28, "Faculty");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](29, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](30, "Department");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](32, "Staff");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](33, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](34, "Harassment");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](35, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](36, "Other");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](37, "div", 6)(38, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](39, "Complaint Details");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](40, "textarea", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](41, "div", 6)(42, "label", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](43, "Complaint Document");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](44, "div", 21)(45, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](46, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](47, "label", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](48, "Choose file");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](49, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](50, "input", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](51, "label", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](52, "Reveal Identity");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](53, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](54, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](55, "Terms of use");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](56, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](57, "p", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](58, "I hereby accept that all provided information is true and can be use for any further investigation as per the GCU Code of conduct.");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](59, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](60, "input", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](61, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](62, "I agree to terms and conditions");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](63, "button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](64, "Upload");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()();
      }
      if (rf & 2) {
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.show);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](60);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !_r0.valid);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgForm],
    styles: [".text-bold[_ngcontent-%COMP%]{\n  \n  font-weight: bold;\n}\n\n.lift-animation[_ngcontent-%COMP%]{\n  box-shadow: 3px 3px 10px grey;\n  transition: .4s;\n}\n.lift-animation[_ngcontent-%COMP%]:hover{\n  box-shadow: 6px 6px 20px grey;\n  transform: translate(0,-3px);\n}\n.lift-animation[_ngcontent-%COMP%]:focus{\n  transform: translate(0,3px);\n}\nlabel.text-bold[_ngcontent-%COMP%]{\n  font-size: 1rem;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9jb21wbGFpbnRzL2NvbXBsYWludHMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG9DQUFvQztFQUNwQyxpQkFBaUI7QUFDbkI7O0FBRUE7RUFDRSw2QkFBNkI7RUFDN0IsZUFBZTtBQUNqQjtBQUNBO0VBQ0UsNkJBQTZCO0VBQzdCLDRCQUE0QjtBQUM5QjtBQUNBO0VBQ0UsMkJBQTJCO0FBQzdCO0FBQ0E7RUFDRSxlQUFlO0FBQ2pCIiwic291cmNlc0NvbnRlbnQiOlsiLnRleHQtYm9sZHtcbiAgLyp0ZXh0LXNoYWRvdzogMXB4IDFweCAwcHggI2IzYjNiMzsqL1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLmxpZnQtYW5pbWF0aW9ue1xuICBib3gtc2hhZG93OiAzcHggM3B4IDEwcHggZ3JleTtcbiAgdHJhbnNpdGlvbjogLjRzO1xufVxuLmxpZnQtYW5pbWF0aW9uOmhvdmVye1xuICBib3gtc2hhZG93OiA2cHggNnB4IDIwcHggZ3JleTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCwtM3B4KTtcbn1cbi5saWZ0LWFuaW1hdGlvbjpmb2N1c3tcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCwzcHgpO1xufVxubGFiZWwudGV4dC1ib2xke1xuICBmb250LXNpemU6IDFyZW07XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
    data: {
      animation: [(0,_transitions__WEBPACK_IMPORTED_MODULE_2__.SlideInFromLeft)()]
    }
  });
}

/***/ }),

/***/ 5341:
/*!**************************************************************************!*\
  !*** ./src/app/student/complaints/store/complaints.component.actions.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "STORE_INFORMATION": () => (/* binding */ STORE_INFORMATION),
/* harmony export */   "StoreInformation": () => (/* binding */ StoreInformation)
/* harmony export */ });
const STORE_INFORMATION = 'STORE_INFORMATION';
class StoreInformation {
  constructor(payload) {
    this.payload = payload;
    this.type = STORE_INFORMATION;
  }
}

/***/ }),

/***/ 8938:
/*!**************************************************!*\
  !*** ./src/app/student/event-emmiter.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponentEventEmitterService": () => (/* binding */ AppComponentEventEmitterService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 93135);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);


class AppComponentEventEmitterService {
  constructor() {
    // Observable string sources
    this.buttonClicked = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    this.message = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
  }
  // Service message commands
  announceClick(message) {
    this.buttonClicked.next(message);
  }
  static #_ = this.ɵfac = function AppComponentEventEmitterService_Factory(t) {
    return new (t || AppComponentEventEmitterService)();
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: AppComponentEventEmitterService,
    factory: AppComponentEventEmitterService.ɵfac
  });
}

/***/ }),

/***/ 75393:
/*!******************************************************************************************!*\
  !*** ./src/app/student/examination/complete-transcript/complete-transcript.component.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompleteTranscriptComponent": () => (/* binding */ CompleteTranscriptComponent)
/* harmony export */ });
/* harmony import */ var _transitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../transitions */ 71629);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ 23488);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);




function CompleteTranscriptComponent_div_24_tr_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "tr")(1, "td", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const subjectTranscript_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectTranscript_r3.courseCode);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectTranscript_r3.courseTitle);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectTranscript_r3.creditHour);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectTranscript_r3.gradePoints);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectTranscript_r3.grade);
  }
}
function CompleteTranscriptComponent_div_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 6)(3, "div", 7)(4, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "table", 8)(7, "thead", 3)(8, "tr")(9, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, "Course-Code");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12, "Course-Title");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14, "Credit-Hour");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, "Grade-Pts");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](18, "Grade");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](20, CompleteTranscriptComponent_div_24_tr_20_Template, 11, 5, "tr", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "div", 10)(22, "div", 11)(23, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](25, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](28);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](29, "br")(30, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const semesterTranscript_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("Semester-", semesterTranscript_r1.semesterNo, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", semesterTranscript_r1.semesterSubjects);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("Cr.Hr. For GPA = ", semesterTranscript_r1.creditHoursForCGPA, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("Grade Pts = ", semesterTranscript_r1.semesterGradePoints, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("SGPA= ", semesterTranscript_r1.SGPA, "");
  }
}
class CompleteTranscriptComponent {
  constructor(store) {
    this.store = store;
  }
  ngOnInit() {
    // this.store.select('fromExamination').subscribe(
    //   state => {
    //     this.completeTranscript = state.completeTranscript;
    //   }
    // );
  }
  static #_ = this.ɵfac = function CompleteTranscriptComponent_Factory(t) {
    return new (t || CompleteTranscriptComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_2__.Store));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: CompleteTranscriptComponent,
    selectors: [["app-complete-transcript"]],
    decls: 25,
    vars: 6,
    consts: [[1, "row"], [1, "col-sm-12"], [1, "table", "table-bordered"], [1, "bg-light"], ["scope", "row"], ["class", "row", 4, "ngFor", "ngForOf"], [1, "card"], [1, "card-header"], [1, "table", "m-0", "table-bordered"], [4, "ngFor", "ngForOf"], [1, "card-footer"], [1, "row", "pb-2"], [1, "col-sm-3", "text-center", "m-auto"]],
    template: function CompleteTranscriptComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "div", 0)(2, "div", 1)(3, "table", 2)(4, "thead", 3)(5, "tr")(6, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7, "Credits Attempts");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Credits Accepted Towards Degree");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11, "Credits Earned");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, "CGPA");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "tbody")(15, "tr")(16, "td", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](23);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](24, CompleteTranscriptComponent_div_24_Template, 31, 5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.completeTranscript.creditAttempts);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.completeTranscript.creditAcceptedTowardsDegree);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.completeTranscript.creditEarned);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.completeTranscript.CGPA);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.completeTranscript.semestersTranscript);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf],
    styles: ["tbody.custom-hover[_ngcontent-%COMP%]    > tr[_ngcontent-%COMP%]:hover {\n  background-color: #E0F3FF;\n  transition: .2s;\n}\n\n.card[_ngcontent-%COMP%] {\n  border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0;\n  font-size: .8rem;\n}\n\n.card-header[_ngcontent-%COMP%] {\n  text-transform: uppercase;\n  color: rgba(13, 27, 62, 0.7);\n  font-weight: bold;\n  background-color: white;\n\n  display: flex;\n  align-items: center;\n  border-bottom-width: 1px;\n  padding-top: 0;\n  padding-bottom: 0;\n  padding-right: .625rem;\n  height: 3.5rem;\n}\n\n.card-body[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n  padding: 1.25rem;\n  -ms-flex: 1 1 auto;\n  min-height: 1px;\n}\n.card-footer[_ngcontent-%COMP%] {\n  background-color: white;\n\n  text-transform: uppercase;\n  color: rgba(13, 27, 62, 0.7);\n  font-weight: bold;\n}\n\n\n@media (max-width: 768px) {\n  .table[_ngcontent-%COMP%]{\n    font-size: .7rem;\n  }\n  .card-footer[_ngcontent-%COMP%]{\n    font-size: .7rem;\n  }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9leGFtaW5hdGlvbi9jb21wbGV0ZS10cmFuc2NyaXB0L2NvbXBsZXRlLXRyYW5zY3JpcHQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUF5QjtFQUN6QixlQUFlO0FBQ2pCOztBQUVBO0VBQ0Usd0RBQXdEO0VBQ3hELGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6Qiw0QkFBNEI7RUFDNUIsaUJBQWlCO0VBQ2pCLHVCQUF1Qjs7RUFFdkIsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQix3QkFBd0I7RUFDeEIsY0FBYztFQUNkLGlCQUFpQjtFQUNqQixzQkFBc0I7RUFDdEIsY0FBYztBQUNoQjs7QUFFQTtFQUNFLGNBQWM7RUFDZCxnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLGVBQWU7QUFDakI7QUFDQTtFQUNFLHVCQUF1Qjs7RUFFdkIseUJBQXlCO0VBQ3pCLDRCQUE0QjtFQUM1QixpQkFBaUI7QUFDbkI7O0FBRUEscUJBQXFCO0FBQ3JCO0VBQ0U7SUFDRSxnQkFBZ0I7RUFDbEI7RUFDQTtJQUNFLGdCQUFnQjtFQUNsQjtBQUNGIiwic291cmNlc0NvbnRlbnQiOlsidGJvZHkuY3VzdG9tLWhvdmVyID4gdHI6aG92ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTBGM0ZGO1xuICB0cmFuc2l0aW9uOiAuMnM7XG59XG5cbi5jYXJkIHtcbiAgYm9yZGVyLXJhZGl1czogY2FsYyguMjVyZW0gLSAxcHgpIGNhbGMoLjI1cmVtIC0gMXB4KSAwIDA7XG4gIGZvbnQtc2l6ZTogLjhyZW07XG59XG5cbi5jYXJkLWhlYWRlciB7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGNvbG9yOiByZ2JhKDEzLCAyNywgNjIsIDAuNyk7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcblxuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAxcHg7XG4gIHBhZGRpbmctdG9wOiAwO1xuICBwYWRkaW5nLWJvdHRvbTogMDtcbiAgcGFkZGluZy1yaWdodDogLjYyNXJlbTtcbiAgaGVpZ2h0OiAzLjVyZW07XG59XG5cbi5jYXJkLWJvZHkge1xuICBmbGV4OiAxIDEgYXV0bztcbiAgcGFkZGluZzogMS4yNXJlbTtcbiAgLW1zLWZsZXg6IDEgMSBhdXRvO1xuICBtaW4taGVpZ2h0OiAxcHg7XG59XG4uY2FyZC1mb290ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcblxuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBjb2xvcjogcmdiYSgxMywgMjcsIDYyLCAwLjcpO1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLypBZGRlZCBpbiBteSBDaGFuZ2UqL1xuQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XG4gIC50YWJsZXtcbiAgICBmb250LXNpemU6IC43cmVtO1xuICB9XG4gIC5jYXJkLWZvb3RlcntcbiAgICBmb250LXNpemU6IC43cmVtO1xuICB9XG59XG5cblxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
    data: {
      animation: [(0,_transitions__WEBPACK_IMPORTED_MODULE_0__.SlideInFromLeft)()]
    }
  });
}

/***/ }),

/***/ 21261:
/*!************************************************************************!*\
  !*** ./src/app/student/examination/date-sheet/date-sheet.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DateSheetComponent": () => (/* binding */ DateSheetComponent)
/* harmony export */ });
/* harmony import */ var _transitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../transitions */ 71629);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ 23488);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);




function DateSheetComponent_tr_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "tr")(1, "td", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const subjectDateSheet_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectDateSheet_r1.date);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectDateSheet_r1.day);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectDateSheet_r1.time);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectDateSheet_r1.courseName);
  }
}
class DateSheetComponent {
  constructor(store) {
    this.store = store;
  }
  ngOnInit() {
    // this.store.select('fromExamination').subscribe(
    //   state => {
    //     this.subjects = state.semesterDateSheet;
    //   }
    // );
  }
  static #_ = this.ɵfac = function DateSheetComponent_Factory(t) {
    return new (t || DateSheetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_2__.Store));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: DateSheetComponent,
    selectors: [["app-date-sheet"]],
    decls: 19,
    vars: 2,
    consts: [[1, "row"], [1, "col-sm-12"], [1, "card", "shadow"], [1, "card-header"], [1, "card-body"], [1, "table", "table-bordered"], [1, "bg-light"], [4, "ngFor", "ngForOf"], ["scope", "row"]],
    template: function DateSheetComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, " Date-Sheet ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 4)(6, "table", 5)(7, "thead", 6)(8, "tr")(9, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, "Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12, "Day");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14, "Time");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, "Semester");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](18, DateSheetComponent_tr_18_Template, 9, 4, "tr", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.subjects.subjects);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf],
    styles: ["tbody.custom-hover[_ngcontent-%COMP%]    > tr[_ngcontent-%COMP%]:hover {\n  background-color: #E0F3FF;\n  transition: .2s;\n}\n\n\n.card[_ngcontent-%COMP%] {\n  border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0;\n  font-size: .8rem;\n}\n\n\n.card-header[_ngcontent-%COMP%] {\n  text-transform: uppercase;\n  color: rgba(13, 27, 62, 0.7);\n  font-weight: bold;\n  background-color: white;\n\n  display: flex;\n  align-items: center;\n  border-bottom-width: 1px;\n  padding-top: 0;\n  padding-bottom: 0;\n  padding-right: .625rem;\n  height: 3.5rem;\n}\n\n.card-body[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n  padding: 1.25rem;\n  -ms-flex: 1 1 auto;\n  min-height: 1px;\n  overflow: hidden;\n  overflow-x: scroll;\n}\n\n\n.card-footer[_ngcontent-%COMP%] {\n  background-color: white;\n\n  text-transform: uppercase;\n  color: rgba(13, 27, 62, 0.7);\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9leGFtaW5hdGlvbi9kYXRlLXNoZWV0L2RhdGUtc2hlZXQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUF5QjtFQUN6QixlQUFlO0FBQ2pCOztBQUVBLGdCQUFnQjtBQUNoQjtFQUNFLHdEQUF3RDtFQUN4RCxnQkFBZ0I7QUFDbEI7O0FBRUEsNkJBQTZCO0FBQzdCO0VBQ0UseUJBQXlCO0VBQ3pCLDRCQUE0QjtFQUM1QixpQkFBaUI7RUFDakIsdUJBQXVCOztFQUV2QixhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLHdCQUF3QjtFQUN4QixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixjQUFjO0FBQ2hCOztBQUVBO0VBQ0UsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixrQkFBa0I7RUFDbEIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixrQkFBa0I7QUFDcEI7O0FBRUEsOEJBQThCO0FBQzlCO0VBQ0UsdUJBQXVCOztFQUV2Qix5QkFBeUI7RUFDekIsNEJBQTRCO0VBQzVCLGlCQUFpQjtBQUNuQiIsInNvdXJjZXNDb250ZW50IjpbInRib2R5LmN1c3RvbS1ob3ZlciA+IHRyOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0UwRjNGRjtcbiAgdHJhbnNpdGlvbjogLjJzO1xufVxuXG4vKkFkZGVkIGluIHRoaXMqL1xuLmNhcmQge1xuICBib3JkZXItcmFkaXVzOiBjYWxjKC4yNXJlbSAtIDFweCkgY2FsYyguMjVyZW0gLSAxcHgpIDAgMDtcbiAgZm9udC1zaXplOiAuOHJlbTtcbn1cblxuLypyZW1vdmVkIGZvbnRzaXplIGZyb20gdGhpcyovXG4uY2FyZC1oZWFkZXIge1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBjb2xvcjogcmdiYSgxMywgMjcsIDYyLCAwLjcpO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG5cbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYm9yZGVyLWJvdHRvbS13aWR0aDogMXB4O1xuICBwYWRkaW5nLXRvcDogMDtcbiAgcGFkZGluZy1ib3R0b206IDA7XG4gIHBhZGRpbmctcmlnaHQ6IC42MjVyZW07XG4gIGhlaWdodDogMy41cmVtO1xufVxuXG4uY2FyZC1ib2R5IHtcbiAgZmxleDogMSAxIGF1dG87XG4gIHBhZGRpbmc6IDEuMjVyZW07XG4gIC1tcy1mbGV4OiAxIDEgYXV0bztcbiAgbWluLWhlaWdodDogMXB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBvdmVyZmxvdy14OiBzY3JvbGw7XG59XG5cbi8qcmVtb3ZlZCBmb250IHNpemUgZnJvbSB0aGlzKi9cbi5jYXJkLWZvb3RlciB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGNvbG9yOiByZ2JhKDEzLCAyNywgNjIsIDAuNyk7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
    data: {
      animation: [(0,_transitions__WEBPACK_IMPORTED_MODULE_0__.SlideInFromLeft)()]
    }
  });
}

/***/ }),

/***/ 60855:
/*!******************************************************************************************!*\
  !*** ./src/app/student/examination/semester-transcript/semester-transcript.component.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SemesterTranscriptComponent": () => (/* binding */ SemesterTranscriptComponent)
/* harmony export */ });
/* harmony import */ var _transitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../transitions */ 71629);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ 23488);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);




function SemesterTranscriptComponent_tr_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "tr")(1, "td", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const subjectTranscript_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectTranscript_r1.courseCode);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectTranscript_r1.courseTitle);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectTranscript_r1.creditHour);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectTranscript_r1.gradePoints);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](subjectTranscript_r1.grade);
  }
}
class SemesterTranscriptComponent {
  constructor(store) {
    this.store = store;
  }
  ngOnInit() {
    // this.store.select('fromExamination').subscribe(
    //   state => {
    //     this.semesterTranscript = state.semesterTranscript;
    //   }
    // );
  }
  static #_ = this.ɵfac = function SemesterTranscriptComponent_Factory(t) {
    return new (t || SemesterTranscriptComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_2__.Store));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: SemesterTranscriptComponent,
    selectors: [["app-semester-transcript"]],
    decls: 29,
    vars: 6,
    consts: [[1, "row"], [1, "col-sm-12"], [1, "card"], [1, "card-header"], [1, "table", "m-0", "table-bordered"], [1, "bg-light"], [4, "ngFor", "ngForOf"], [1, "card-footer"], [1, "row", "pb-2"], [1, "col-sm-3", "text-center", "m-auto"], ["scope", "row"]],
    template: function SemesterTranscriptComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "table", 4)(7, "thead", 5)(8, "tr")(9, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, "Course-Code");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12, "Course-Title");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14, "Credit-Hour");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, "Grade-Pts");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](18, "Grade");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](20, SemesterTranscriptComponent_tr_20_Template, 11, 5, "tr", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "div", 7)(22, "div", 8)(23, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](25, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](28);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("Semester ", ctx.semesterTranscript.semesterNo, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.semesterTranscript.semesterSubjects);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("Cr.Hr. For GPA = ", ctx.semesterTranscript.creditHoursForCGPA, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("Grade Pts = ", ctx.semesterTranscript.semesterGradePoints, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("SGPA= ", ctx.semesterTranscript.SGPA, "");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf],
    styles: ["tbody.custom-hover[_ngcontent-%COMP%]    > tr[_ngcontent-%COMP%]:hover {\n  background-color: #E0F3FF;\n  transition: .2s;\n}\n.card[_ngcontent-%COMP%] {\n  border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0;\n  font-size: .8rem;\n}\n\n.card-header[_ngcontent-%COMP%] {\n  text-transform: uppercase;\n  color: rgba(13, 27, 62, 0.7);\n  font-weight: bold;\n  background-color: white;\n\n  display: flex;\n  align-items: center;\n  border-bottom-width: 1px;\n  padding-top: 0;\n  padding-bottom: 0;\n  padding-right: .625rem;\n  height: 3.5rem;\n}\n\n.card-body[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n  padding: 1.25rem;\n  -ms-flex: 1 1 auto;\n  min-height: 1px;\n}\n.card-footer[_ngcontent-%COMP%] {\n  background-color: white;\n  text-transform: uppercase;\n  color: rgba(13, 27, 62, 0.7);\n  font-weight: bold;\n}\n@media (max-width: 768px) {\n  .table[_ngcontent-%COMP%]{\n    font-size: .7rem;\n  }\n  .card-footer[_ngcontent-%COMP%]{\n    font-size: .7rem;\n  }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9leGFtaW5hdGlvbi9zZW1lc3Rlci10cmFuc2NyaXB0L3NlbWVzdGVyLXRyYW5zY3JpcHQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUF5QjtFQUN6QixlQUFlO0FBQ2pCO0FBQ0E7RUFDRSx3REFBd0Q7RUFDeEQsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLDRCQUE0QjtFQUM1QixpQkFBaUI7RUFDakIsdUJBQXVCOztFQUV2QixhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLHdCQUF3QjtFQUN4QixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixjQUFjO0FBQ2hCOztBQUVBO0VBQ0UsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixrQkFBa0I7RUFDbEIsZUFBZTtBQUNqQjtBQUNBO0VBQ0UsdUJBQXVCO0VBQ3ZCLHlCQUF5QjtFQUN6Qiw0QkFBNEI7RUFDNUIsaUJBQWlCO0FBQ25CO0FBQ0E7RUFDRTtJQUNFLGdCQUFnQjtFQUNsQjtFQUNBO0lBQ0UsZ0JBQWdCO0VBQ2xCO0FBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJ0Ym9keS5jdXN0b20taG92ZXIgPiB0cjpob3ZlciB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFMEYzRkY7XG4gIHRyYW5zaXRpb246IC4ycztcbn1cbi5jYXJkIHtcbiAgYm9yZGVyLXJhZGl1czogY2FsYyguMjVyZW0gLSAxcHgpIGNhbGMoLjI1cmVtIC0gMXB4KSAwIDA7XG4gIGZvbnQtc2l6ZTogLjhyZW07XG59XG5cbi5jYXJkLWhlYWRlciB7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGNvbG9yOiByZ2JhKDEzLCAyNywgNjIsIDAuNyk7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcblxuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAxcHg7XG4gIHBhZGRpbmctdG9wOiAwO1xuICBwYWRkaW5nLWJvdHRvbTogMDtcbiAgcGFkZGluZy1yaWdodDogLjYyNXJlbTtcbiAgaGVpZ2h0OiAzLjVyZW07XG59XG5cbi5jYXJkLWJvZHkge1xuICBmbGV4OiAxIDEgYXV0bztcbiAgcGFkZGluZzogMS4yNXJlbTtcbiAgLW1zLWZsZXg6IDEgMSBhdXRvO1xuICBtaW4taGVpZ2h0OiAxcHg7XG59XG4uY2FyZC1mb290ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgY29sb3I6IHJnYmEoMTMsIDI3LCA2MiwgMC43KTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5AbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcbiAgLnRhYmxle1xuICAgIGZvbnQtc2l6ZTogLjdyZW07XG4gIH1cbiAgLmNhcmQtZm9vdGVye1xuICAgIGZvbnQtc2l6ZTogLjdyZW07XG4gIH1cbn1cblxuXG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
    data: {
      animation: [(0,_transitions__WEBPACK_IMPORTED_MODULE_0__.SlideInFromLeft)()]
    }
  });
}

/***/ }),

/***/ 93106:
/*!************************************************!*\
  !*** ./src/app/student/home/home.component.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeComponent": () => (/* binding */ HomeComponent)
/* harmony export */ });
/* harmony import */ var _transitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../transitions */ 71629);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _main_shared_services_Announcement_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../main/shared/services/Announcement.service */ 61335);
/* harmony import */ var src_app_main_shared_services_Timetable_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/main/shared/services/Timetable.service */ 3651);
/* harmony import */ var _auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../auth/_services/authentication.service */ 7893);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);







const _c0 = ["chart"];
const _c1 = ["c"];
function HomeComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 19)(1, "a", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "\u00D7");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "h6")(4, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "Important Notice for BS Program Students (Admitted in 2024 FALL)");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6, " The Students who were admitted in the ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "fall of 2024");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, " in BS Program are instructed to enter their ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Intermediate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, " obtained marks, Total Marks and Board Roll Number by ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14, "Wednesday, January 15, 2025");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15, ". ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](16, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, " Please update your information in ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](19, "Profile Screen");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](20, " (TimeTable --> View Profile). ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function HomeComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 19)(1, "a", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "\u00D7");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "h6")(4, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "Important Notice for Intermediate Students (Admitted in 2024 FALL)");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6, " The Students who were admitted in the ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "fall of 2024");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, " in Intermediate are instructed to enter their ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Matric");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, " obtained marks, Total Marks and Board Roll Number by ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14, "Wednesday, February 12, 2025");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15, ". ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](16, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, " Please update your information in ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](19, "Profile Screen");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](20, " (TimeTable --> View Profile). ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function HomeComponent_div_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 21)(1, "div", 22)(2, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function HomeComponent_div_10_Template_div_click_2_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r6);
      const s_r4 = restoredCtx.$implicit;
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r5.navigateToCourse(s_r4.SUB_CODE));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "h5", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const s_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"]("", s_r4.SUB_CODE, " (", s_r4.SECTION, ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](s_r4.SUB_NM);
  }
}
function HomeComponent_tr_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const s_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](s_r7.ANN_TITLE);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](5, 3, s_r7.ANN_DATE, " d, MMM , y, h:mm a"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](s_r7.ANN_DESC);
  }
}
const _c2 = function () {
  return [2, 3, 11, 20, 21, 27, 30, 31, 36, 40, 48, 49, 58, 116];
};
const _c3 = function () {
  return [1, 111];
};
class HomeComponent {
  constructor(router, route, announcementService, TimetableService, authenticationService) {
    this.router = router;
    this.route = route;
    this.announcementService = announcementService;
    this.TimetableService = TimetableService;
    this.authenticationService = authenticationService;
    this.Total = 0;
    this.user_ClassCode = 0;
    this.user_Year = 0;
    this.termNo = 0;
    this.lineChartData = [{
      data: [2.95, 3.14, 3.30, 3.75, 1.9, 3.1, 3.3, 3.6],
      label: 'Performance'
    }];
    this.lineChartLabels = ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4', 'Sem 5', 'Sem 6', 'Sem 7', 'Sem 8'];
    this.lineChartOptions = {
      responsive: true,
      suggestedMin: 0.0,
      suggestedMax: 4.0
    };
    this.lineChartColors = [{
      backgroundColor: 'rgba(103, 58, 183, .1)',
      borderColor: 'rgb(103, 58, 183)',
      pointBackgroundColor: 'rgb(103, 58, 183)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(103, 58, 183, .8)'
      // borderColor: 'rgba(94,79,208,1)',
      // backgroundColor: 'rgba(255,255,0,0.28)'
    }];

    this.lineChartLegend = true;
    this.lineChartPlugins = [];
    this.lineChartType = 'line';
    this.loading = true;
    this.usr = null;
    this.usr = this.authenticationService.getUser();
  }
  ngOnInit() {
    this.teams = this.TimetableService.getTeam(this.usr?.C_CODE);
    this.loadAnnouncements();
    this.user_ClassCode = this.usr.C_CODE;
    this.user_Year = this.usr.YEAR;
  }
  loadAnnouncements() {
    this.announcementService.getAnnouncements({}).subscribe(res => {
      this.announcement = res;
    });
  }
  navigateToCourse(course) {
    this.router.navigate(['../Courses', course], {
      relativeTo: this.route
    });
  }
  static #_ = this.ɵfac = function HomeComponent_Factory(t) {
    return new (t || HomeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_main_shared_services_Announcement_service__WEBPACK_IMPORTED_MODULE_1__.AnnouncementService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_main_shared_services_Timetable_service__WEBPACK_IMPORTED_MODULE_2__.TimetableService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_3__.AuthenticationService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: HomeComponent,
    selectors: [["app-home"]],
    viewQuery: function HomeComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.pieChart = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.selectCourse = _t.first);
      }
    },
    decls: 33,
    vars: 7,
    consts: [["class", "alert alert-info alert-dismissible", 4, "ngIf"], [1, "card", "mb-3"], [1, "card-header"], [1, "ml-3"], ["src", "../../../assets/books.png", "alt", "", 1, "collapse-arrow", 2, "width", "3rem"], [1, "ml-3", "mt-4"], [1, "card-body", "row", 2, "min-height", "50vh"], ["class", "col-lg-4 col-md-6 col-sm-12 p-2", 4, "ngFor", "ngForOf"], [1, "row"], [1, "col-sm-12"], [1, "card"], [1, "card-header", "d-flex", "justify-content-between"], [1, "ml-2"], ["src", "../../../assets/email.png", "alt", "", 1, "collapse-arrow", 2, "width", "3rem"], [1, "badge", "badge-pill", "badge-primary", "p-2"], [1, "card-body", "mb-3"], [1, "table", "table-hover"], ["scope", "col"], [4, "ngFor", "ngForOf"], [1, "alert", "alert-info", "alert-dismissible"], ["href", "#", "data-dismiss", "alert", "aria-label", "close", 1, "close"], [1, "col-lg-4", "col-md-6", "col-sm-12", "p-2"], [1, "card", "course-grid"], [1, "card-body", "course-box", 3, "click"], [2, "color", "darkslategrey"]],
    template: function HomeComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, HomeComponent_div_1_Template, 21, 0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, HomeComponent_div_2_Template, 21, 0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 1)(4, "div", 2)(5, "i", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "h3", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "Courses");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, HomeComponent_div_10_Template, 7, 3, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 8)(12, "div", 9)(13, "div", 10)(14, "div", 11)(15, "div", 2)(16, "i", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](17, "img", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "h3", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](19, "Announcements");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](20, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div", 15)(22, "table", 16)(23, "thead")(24, "tr")(25, "th", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26, "Title");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "th", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28, "Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](29, "th", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](30, "Details");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](32, HomeComponent_tr_32_Template, 8, 6, "tr", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](5, _c2).includes(ctx.user_ClassCode) && ctx.user_Year == 2024);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](6, _c3).includes(ctx.user_ClassCode) && ctx.user_Year == 2024);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.teams);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](22);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.announcement);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.DatePipe],
    styles: ["tbody.custom-hover[_ngcontent-%COMP%] > tr[_ngcontent-%COMP%]:hover {\n  background-color: cadetblue;\n  transition: .2s;\n}\n\n.card-header[_ngcontent-%COMP%] {\n  padding: .75rem 1.25rem;\n  margin-bottom: 0;\n  border-bottom: none;\n}\n\ndiv.custom-height[_ngcontent-%COMP%] {\n  height: 30rem;\n}\n\n.spinner-border[_ngcontent-%COMP%] {\n  color: blue !important;\n}\n\n.course-grid[_ngcontent-%COMP%] {\n  display: grid;\n  \n  grid-template-rows: repeat(3, 1fr);\n  grid-gap: 2px;\n  justify-content: center;\n  align-items: center;\n  background-color: #e9ecef;\n  transition: 0.4;\n  -webkit-transition: 0.4;\n  -moz-transition: 0.4;\n  -ms-transition: 0.4;\n  -o-transition: 0.4;\n  border-radius: .3rem;\n}\n\n.course-box[_ngcontent-%COMP%] {\n  height: 70px;\n  text-align: center;\n}\n\n.team[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:hover {\n  background-color: #acacac;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9ob21lL2hvbWUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDJCQUEyQjtFQUMzQixlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsdUJBQXVCO0VBQ3ZCLGdCQUFnQjtFQUNoQixtQkFBbUI7QUFDckI7O0FBRUE7RUFDRSxhQUFhO0FBQ2Y7O0FBRUE7RUFDRSxzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsMkNBQTJDO0VBQzNDLGtDQUFrQztFQUNsQyxhQUFhO0VBQ2IsdUJBQXVCO0VBQ3ZCLG1CQUFtQjtFQUNuQix5QkFBeUI7RUFDekIsZUFBZTtFQUNmLHVCQUF1QjtFQUN2QixvQkFBb0I7RUFDcEIsbUJBQW1CO0VBQ25CLGtCQUFrQjtFQUNsQixvQkFBb0I7QUFDdEI7O0FBRUE7RUFDRSxZQUFZO0VBQ1osa0JBQWtCO0FBQ3BCOztBQUVBO0VBQ0UseUJBQXlCO0FBQzNCIiwic291cmNlc0NvbnRlbnQiOlsidGJvZHkuY3VzdG9tLWhvdmVyPnRyOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogY2FkZXRibHVlO1xuICB0cmFuc2l0aW9uOiAuMnM7XG59XG5cbi5jYXJkLWhlYWRlciB7XG4gIHBhZGRpbmc6IC43NXJlbSAxLjI1cmVtO1xuICBtYXJnaW4tYm90dG9tOiAwO1xuICBib3JkZXItYm90dG9tOiBub25lO1xufVxuXG5kaXYuY3VzdG9tLWhlaWdodCB7XG4gIGhlaWdodDogMzByZW07XG59XG5cbi5zcGlubmVyLWJvcmRlciB7XG4gIGNvbG9yOiBibHVlICFpbXBvcnRhbnQ7XG59XG5cbi5jb3Vyc2UtZ3JpZCB7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIC8qIGdyaWQtdGVtcGxhdGUtY29sdW1uczogcmVwZWF0KDMsIDFmcik7ICovXG4gIGdyaWQtdGVtcGxhdGUtcm93czogcmVwZWF0KDMsIDFmcik7XG4gIGdyaWQtZ2FwOiAycHg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTllY2VmO1xuICB0cmFuc2l0aW9uOiAwLjQ7XG4gIC13ZWJraXQtdHJhbnNpdGlvbjogMC40O1xuICAtbW96LXRyYW5zaXRpb246IDAuNDtcbiAgLW1zLXRyYW5zaXRpb246IDAuNDtcbiAgLW8tdHJhbnNpdGlvbjogMC40O1xuICBib3JkZXItcmFkaXVzOiAuM3JlbTtcbn1cblxuLmNvdXJzZS1ib3gge1xuICBoZWlnaHQ6IDcwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLnRlYW0gOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2FjYWNhYztcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"],
    data: {
      animation: [(0,_transitions__WEBPACK_IMPORTED_MODULE_0__.SlideInFromLeft)()]
    }
  });
}

/***/ }),

/***/ 565:
/*!************************************************************************!*\
  !*** ./src/app/student/previous-courses/previous-courses.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PreviousCoursesComponent": () => (/* binding */ PreviousCoursesComponent)
/* harmony export */ });
/* harmony import */ var _transitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../transitions */ 71629);
/* harmony import */ var _axios_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../axios.js */ 46491);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ 23488);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-toastr */ 94817);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);








function PreviousCoursesComponent_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "span", 7);
  }
}
function PreviousCoursesComponent_div_7_tr_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "tr")(1, "td")(2, "a", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function PreviousCoursesComponent_div_7_tr_12_Template_a_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r6.OnCourseClicked());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "td")(5, "a", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function PreviousCoursesComponent_div_7_tr_12_Template_a_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r7);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r8.OnCourseClicked());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const semesterCourse_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](semesterCourse_r5.SUB_NM);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](semesterCourse_r5.SUB_CODE);
  }
}
function PreviousCoursesComponent_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div")(1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 9)(4, "table", 10)(5, "thead", 11)(6, "tr")(7, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](8, "Courses");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, "Course-Code");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](12, PreviousCoursesComponent_div_7_tr_12_Template, 7, 2, "tr", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const semPreviousCourses_r2 = ctx.$implicit;
    const i_r3 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" Semester-", i_r3 + 1, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", semPreviousCourses_r2);
  }
}
class PreviousCoursesComponent {
  constructor(store, http, toastr, router) {
    this.store = store;
    this.http = http;
    this.toastr = toastr;
    this.router = router;
    this.loading = true;
  }
  ngOnInit() {
    const std = JSON.parse(localStorage.getItem('currentUser'));
    this.http.get(`${_axios_js__WEBPACK_IMPORTED_MODULE_1__.baseUrl}/api/StudentPreviousCourses/getStudentPreviousCourses`, {
      params: {
        year: std.YEAR,
        c_code: std.C_CODE,
        d_id: std.D_ID,
        maj_id: std.MAJ_ID,
        rn: std.RN
      }
    }).subscribe(data => {
      this.loading = false;
      const thi = this;
      // @ts-ignore
      const groupBy = key => data.reduce((r, a, i) => {
        if (!i || r[r.length - 1][0][key] !== a[key]) {
          return r.concat([[a]]);
        }
        r[r.length - 1].push(a);
        return r;
      }, []);
      this.prevCourses = groupBy('T_NO');
    }, error => {
      this.loading = false;
      this.toastr.error('Error Fetching Data');
    });
  }
  OnCourseClicked() {
    this.router.navigate(['/course']);
  }
  static #_ = this.ɵfac = function PreviousCoursesComponent_Factory(t) {
    return new (t || PreviousCoursesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_3__.Store), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](ngx_toastr__WEBPACK_IMPORTED_MODULE_5__.ToastrService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: PreviousCoursesComponent,
    selectors: [["app-previous-courses"]],
    decls: 8,
    vars: 3,
    consts: [[1, "container", "p-2"], [1, "card", "shadow"], [1, "card-header", "text-responsive"], ["class", "spinner-border spinner-border-sm mr-1", 4, "ngIf"], [1, "card-body", "pt-0"], [1, "table-responsive"], [4, "ngFor", "ngForOf"], [1, "spinner-border", "spinner-border-sm", "mr-1"], [1, "card-header", "p-0"], [1, "card-body", "p-0"], [1, "table", "table-bordered"], [1, "bg-light"], [3, "click"]],
    template: function PreviousCoursesComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, PreviousCoursesComponent_span_3_Template, 1, 0, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4, " Previous Courses ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 4)(6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](7, PreviousCoursesComponent_div_7_Template, 13, 2, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.loading);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.prevCourses);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf],
    styles: [".card[_ngcontent-%COMP%] {\n  border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0;\n}\n\n.card-header[_ngcontent-%COMP%] {\n  text-transform: uppercase;\n  color: rgba(13, 27, 62, 0.7);\n  font-weight: bold;\n  font-size: .7rem;\n  background-color: white;\n\n  display: flex;\n  align-items: center;\n  border-bottom-width: 1px;\n  padding-top: 0;\n  padding-bottom: 0;\n  padding-right: .625rem;\n  height: 3.5rem;\n}\n\n.card-body[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n  padding: 1.25rem;\n  -ms-flex: 1 1 auto;\n  min-height: 1px;\n  font-size: .8rem;\n}\n\n.table[_ngcontent-%COMP%] {\n  width: 100%;\n  margin-bottom: 1rem;\n  color: #212529;\n}\n\n.table-bordered[_ngcontent-%COMP%] {\n  border: 1px solid #adafb2;\n}\n\n.card-footer[_ngcontent-%COMP%] {\n  background-color: white;\n}\n\ntbody.custom-hover[_ngcontent-%COMP%]    > tr[_ngcontent-%COMP%]:hover {\n  background-color: #E0F3FF;\n  transition: .2s;\n}\n\n\na.collapsed[_ngcontent-%COMP%]    > img.collapse-arrow[_ngcontent-%COMP%] {\n  transition: .3s transform ease-in-out;\n  transform: rotate(0deg);\n}\n\na[_ngcontent-%COMP%]    > img.collapse-arrow[_ngcontent-%COMP%] {\n  transition: .3s transform ease-in-out;\n  transform: rotate(-180deg);\n}\n\ndiv.card-body[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]    > a.text-dark[_ngcontent-%COMP%]{\n  text-decoration: none;\n}\n\n@media (max-width: 992px) {\n  .card-header[_ngcontent-%COMP%]{\n    font-size: .7rem;\n  }\n  .card-body[_ngcontent-%COMP%] {\n    font-size: .6rem;\n  }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9wcmV2aW91cy1jb3Vyc2VzL3ByZXZpb3VzLWNvdXJzZXMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQ0E7RUFDRSx3REFBd0Q7QUFDMUQ7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsNEJBQTRCO0VBQzVCLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsdUJBQXVCOztFQUV2QixhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLHdCQUF3QjtFQUN4QixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixjQUFjO0FBQ2hCOztBQUVBO0VBQ0UsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixrQkFBa0I7RUFDbEIsZUFBZTtFQUNmLGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkIsY0FBYztBQUNoQjs7QUFFQTtFQUNFLHlCQUF5QjtBQUMzQjs7QUFFQTtFQUNFLHVCQUF1QjtBQUN6Qjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6QixlQUFlO0FBQ2pCOztBQUVBLGlEQUFpRDtBQUNqRDtFQUNFLHFDQUFxQztFQUNyQyx1QkFBdUI7QUFDekI7O0FBRUE7RUFDRSxxQ0FBcUM7RUFDckMsMEJBQTBCO0FBQzVCOztBQUVBO0VBQ0UscUJBQXFCO0FBQ3ZCOztBQUVBO0VBQ0U7SUFDRSxnQkFBZ0I7RUFDbEI7RUFDQTtJQUNFLGdCQUFnQjtFQUNsQjtBQUNGIiwic291cmNlc0NvbnRlbnQiOlsiXG4uY2FyZCB7XG4gIGJvcmRlci1yYWRpdXM6IGNhbGMoLjI1cmVtIC0gMXB4KSBjYWxjKC4yNXJlbSAtIDFweCkgMCAwO1xufVxuXG4uY2FyZC1oZWFkZXIge1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBjb2xvcjogcmdiYSgxMywgMjcsIDYyLCAwLjcpO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiAuN3JlbTtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG5cbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYm9yZGVyLWJvdHRvbS13aWR0aDogMXB4O1xuICBwYWRkaW5nLXRvcDogMDtcbiAgcGFkZGluZy1ib3R0b206IDA7XG4gIHBhZGRpbmctcmlnaHQ6IC42MjVyZW07XG4gIGhlaWdodDogMy41cmVtO1xufVxuXG4uY2FyZC1ib2R5IHtcbiAgZmxleDogMSAxIGF1dG87XG4gIHBhZGRpbmc6IDEuMjVyZW07XG4gIC1tcy1mbGV4OiAxIDEgYXV0bztcbiAgbWluLWhlaWdodDogMXB4O1xuICBmb250LXNpemU6IC44cmVtO1xufVxuXG4udGFibGUge1xuICB3aWR0aDogMTAwJTtcbiAgbWFyZ2luLWJvdHRvbTogMXJlbTtcbiAgY29sb3I6ICMyMTI1Mjk7XG59XG5cbi50YWJsZS1ib3JkZXJlZCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNhZGFmYjI7XG59XG5cbi5jYXJkLWZvb3RlciB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xufVxuXG50Ym9keS5jdXN0b20taG92ZXIgPiB0cjpob3ZlciB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFMEYzRkY7XG4gIHRyYW5zaXRpb246IC4ycztcbn1cblxuLypGb3IgYXJyb3cgaWNvbiByb3RhdGlvbiB3aGVuIGxpbmtzIGFyZSBjbGlja2VkKi9cbmEuY29sbGFwc2VkID4gaW1nLmNvbGxhcHNlLWFycm93IHtcbiAgdHJhbnNpdGlvbjogLjNzIHRyYW5zZm9ybSBlYXNlLWluLW91dDtcbiAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XG59XG5cbmEgPiBpbWcuY29sbGFwc2UtYXJyb3cge1xuICB0cmFuc2l0aW9uOiAuM3MgdHJhbnNmb3JtIGVhc2UtaW4tb3V0O1xuICB0cmFuc2Zvcm06IHJvdGF0ZSgtMTgwZGVnKTtcbn1cblxuZGl2LmNhcmQtYm9keSA+IGRpdiA+IGEudGV4dC1kYXJre1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG5cbkBtZWRpYSAobWF4LXdpZHRoOiA5OTJweCkge1xuICAuY2FyZC1oZWFkZXJ7XG4gICAgZm9udC1zaXplOiAuN3JlbTtcbiAgfVxuICAuY2FyZC1ib2R5IHtcbiAgICBmb250LXNpemU6IC42cmVtO1xuICB9XG59XG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
    data: {
      animation: [(0,_transitions__WEBPACK_IMPORTED_MODULE_0__.SlideInFromLeft)()]
    }
  });
}

/***/ }),

/***/ 17975:
/*!**********************************************************************!*\
  !*** ./src/app/student/progress-report/progress-report.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProgressReportComponent": () => (/* binding */ ProgressReportComponent)
/* harmony export */ });
/* harmony import */ var src_app_transitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/transitions */ 71629);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jspdf-autotable */ 43015);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ 56908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_main_progress_report_progress_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/main/progress-report/progress-services */ 85744);
/* harmony import */ var src_app_auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/auth/_services/authentication.service */ 7893);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-toastr */ 94817);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);








function ProgressReportComponent_div_4_div_32_tr_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const x_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", x_r6.SUB_CODE.toUpperCase(), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", x_r6.subject_name, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", x_r6.req_cr_hr, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", x_r6.GP_PER, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", x_r6.grd, " ");
  }
}
function ProgressReportComponent_div_4_div_32_div_18_tr_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const x_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", x_r8.SUB_CODE.toUpperCase(), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", x_r8.subject_name, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", x_r8.req_cr_hr, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", x_r8.GP_PER, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", x_r8.grd, " ");
  }
}
function ProgressReportComponent_div_4_div_32_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div")(1, "p", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, " Repeated/Improved ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "table", 11)(4, "thead", 12)(5, "tr", 13)(6, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7, "Course Code");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9, "Title");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](11, "Cr.Hr.");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, "Grd.Pts.");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15, "Grade");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](16, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, ProgressReportComponent_div_4_div_32_div_18_tr_17_Template, 11, 5, "tr", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const t_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r5.improve.get(t_r3.key));
  }
}
function ProgressReportComponent_div_4_div_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div")(1, "h6", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "table", 11)(4, "thead", 12)(5, "tr", 13)(6, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7, "Course Code");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9, "Title");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](11, "Cr.Hr.");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, "Grd.Pts.");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15, "Grade");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](16, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, ProgressReportComponent_div_4_div_32_tr_17_Template, 11, 5, "tr", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](18, ProgressReportComponent_div_4_div_32_div_18_Template, 18, 1, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](19, "div", 15)(20, "div")(21, "h6");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](22);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "div")(24, "h6");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](25);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "div")(27, "h6");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "div")(30, "h6");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const t_r3 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" Semester-", t_r3.key, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", t_r3.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.improve.get(t_r3.key) != null);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("Cr.Hr.Earned = ", ctx_r2.stdCgpaInfo[t_r3.key - 1] == null ? null : ctx_r2.stdCgpaInfo[t_r3.key - 1].earn, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("Cr.Hr.For GPA = ", ctx_r2.stdCgpaInfo[t_r3.key - 1] == null ? null : ctx_r2.stdCgpaInfo[t_r3.key - 1].cr_h, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("Grade Points = ", ctx_r2.stdCgpaInfo[t_r3.key - 1] == null ? null : ctx_r2.stdCgpaInfo[t_r3.key - 1].gp == null ? null : ctx_r2.stdCgpaInfo[t_r3.key - 1].gp.toFixed(2), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("SGPA = ", ctx_r2.stdCgpaInfo[t_r3.key - 1] == null ? null : ctx_r2.stdCgpaInfo[t_r3.key - 1].sgpa == null ? null : ctx_r2.stdCgpaInfo[t_r3.key - 1].sgpa.toFixed(2), "");
  }
}
function ProgressReportComponent_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 4)(1, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, "Government College University Lahore");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "h4");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "h4");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "h4");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8, "Progress Report");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "div", 5)(10, "div", 6)(11, "div")(12, "h5")(13, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](14, "Name: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](16, "div")(17, "h5")(18, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](19, "Father Name: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "div", 6)(22, "div")(23, "h5")(24, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](25, "Roll Number: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](27, "div")(28, "h5")(29, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](30, "Registration No: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](32, ProgressReportComponent_div_4_div_32_Template, 32, 7, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](33, "keyvalue");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](34, "hr", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](35, "div", 9)(36, "div")(37, "h6");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](38);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](39, "div")(40, "h6");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](41);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](42, "div")(43, "h6");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](44);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const data_r1 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](data_r1.MAJTITLE);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](data_r1.SE_ID);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", data_r1.NM, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", data_r1.F_NM, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", data_r1.ROLNO, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", data_r1.REG_NO, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](33, 10, ctx_r0.transcript));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("Total Cr.Hr.For CGPA= ", ctx_r0.total_cr_h, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("Total Grade Points= ", ctx_r0.total_grade_point == null ? null : ctx_r0.total_grade_point.toFixed(2), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("CGPA= ", ctx_r0.stdCgpaInfo[(ctx_r0.stdCgpaInfo == null ? null : ctx_r0.stdCgpaInfo.length) - 1] == null ? null : ctx_r0.stdCgpaInfo[(ctx_r0.stdCgpaInfo == null ? null : ctx_r0.stdCgpaInfo.length) - 1].cgpa, "");
  }
}
class ProgressReportComponent {
  constructor(proSer, authenticationService, toaster, datePipe) {
    this.proSer = proSer;
    this.authenticationService = authenticationService;
    this.toaster = toaster;
    this.datePipe = datePipe;
    this.today = new Date();
    this.btnHide = false;
    this.repeat = new Map();
    this.improve = new Map();
    this.transcript = new Map();
    this.stdNamesInfo = new Map();
    this.stdCgpaInfo = new Array();
    this.extra = new Map();
    this.usr = this.authenticationService.getUser();
    this.total_cr_h = 0.0;
    this.total_cgpa = 0.0;
    this.total_grade_point = 0.0;
    this.today = moment__WEBPACK_IMPORTED_MODULE_2__(this.today).format('DD-MMM-YYYY');
  }
  ngOnInit() {
    this.OnSubmit();
  }
  OnSubmit() {
    this.transcript.clear();
    this.stdCgpaInfo = [];
    this.stdNamesInfo.clear();
    //called by services of tchr panel progress report component.
    this.proSer.getExamRslt(this.usr?.C_CODE, this.usr?.SE_ID, this.usr?.RN, this.usr?.RN, this.usr?.YEAR, this.usr?.MAJ_ID).subscribe(res => {
      this.btnHide = true;
      res[0]?.forEach(entry => {
        if (this.stdNamesInfo.has(entry.ROLNO)) {
          this.stdNamesInfo.get(entry.ROLNO).push(entry);
        } else {
          this.stdNamesInfo.set(entry.ROLNO, new Array(entry));
        }
      });
      res[1]?.forEach(entry => {
        if (this.repeat.has(entry.SUB_CODE)) {
          //  this.extra+=entry.req_cr_hr;
          this.extra.get(this.repeat.get(entry.SUB_CODE)).earn += entry.req_cr_hr;
          if (this.improve.has(this.repeat.get(entry.SUB_CODE))) {
            this.improve.get(this.repeat.get(entry.SUB_CODE)).push(entry);
          } else this.improve.set(this.repeat.get(entry.SUB_CODE), new Array(entry));
        } else {
          //  this.earn_h+=entry.req_cr_hr;
          this.repeat.set(entry.SUB_CODE, entry.t_no);
          if (this.transcript.has(entry.t_no)) {
            this.transcript.get(entry.t_no).push(entry);
            if (entry.grd != "F" && entry.grd != "f" && entry.grd != "In" && entry.grd != "in") this.extra.get(entry.t_no).earn += entry.req_cr_hr;
            this.extra.get(entry.t_no).cr_h += entry.req_cr_hr;
          } else {
            this.extra.set(entry.t_no, {
              earn: entry.req_cr_hr,
              cr_h: entry.req_cr_hr
            });
            this.transcript.set(entry.t_no, new Array(entry));
          }
        }
      });
      res[2]?.forEach((entry, index) => {
        this.stdCgpaInfo.push(entry);
        this.stdCgpaInfo[index].cr_h = this.extra.get(index + 1)?.cr_h;
        this.stdCgpaInfo[index].earn = Math.min(this.extra.get(index + 1)?.earn, this.extra.get(index + 1)?.cr_h);
        this.total_cr_h += this.stdCgpaInfo[index].cr_h;
        this.total_grade_point += this.stdCgpaInfo[index].gp;
      });
      this.total_cgpa = Math.floor(this.stdCgpaInfo[this.stdCgpaInfo.length - 1].cgpa * 100) / 100;
      this.num = this.stdNamesInfo.get(this.usr?.ROLNO);
    });
  }
  static #_ = this.ɵfac = function ProgressReportComponent_Factory(t) {
    return new (t || ProgressReportComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_main_progress_report_progress_services__WEBPACK_IMPORTED_MODULE_3__.ProgressServices), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_4__.AuthenticationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](ngx_toastr__WEBPACK_IMPORTED_MODULE_6__.ToastrService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_7__.DatePipe));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: ProgressReportComponent,
    selectors: [["app-progress-report"]],
    decls: 5,
    vars: 2,
    consts: [[1, "tabber"], [1, "container-fluid", "card", "shadow"], [1, "row", "card-body", 2, "margin-top", "-10px"], ["id", "checkTable", "class", "ri8", 4, "ngFor", "ngForOf"], ["id", "checkTable", 1, "ri8"], [2, "display", "flex", "flex-flow", "row nowrap", "justify-content", "space-between"], [2, "display", "flex", "flex-flow", "column nowrap", "text-align", "left"], [4, "ngFor", "ngForOf"], [2, "border", "1px solid black"], [1, "d-flex", "row", "justify-content-around"], ["id", "tst"], [1, "table", "table-bordered", "table-striped", "m-0", "p-0"], [1, "thead-dark"], [1, "table-active"], [4, "ngIf"], [1, "mt-2", "d-flex", "row", "justify-content-around"], ["id", "ts"]],
    template: function ProgressReportComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](4, ProgressReportComponent_div_4_Template, 45, 12, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.num);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.KeyValuePipe],
    styles: [".ri8[_ngcontent-%COMP%]{\n    width: 1000px;\n    text-align: center;\n    margin: 0 auto;\n}\n#tst[_ngcontent-%COMP%]{\n    text-align: left;\n    font-weight: 800;\n}\n\n#ts[_ngcontent-%COMP%]{\n    text-align: left;\n    font-size: medium;\n    font-weight: 600;\n}\n\n.text-center[_ngcontent-%COMP%] {\n    text-align: center;\n    font-weight: bold;\n  }\n  \n  table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n    vertical-align: middle !important;\n    font-weight: bold;\n    font-size: 12.5px;\n    text-align: center;\n  }\n  \n  .center[_ngcontent-%COMP%] {\n    align-items: center;\n    justify-content: center;\n    display: flex;\n  }\n  \n  table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n    text-align: center;\n    font-size: 13px;\n  }\n  \n  table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n    width: 100%;\n    font-size: 13px;\n  }\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9wcm9ncmVzcy1yZXBvcnQvcHJvZ3Jlc3MtcmVwb3J0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxhQUFhO0lBQ2Isa0JBQWtCO0lBQ2xCLGNBQWM7QUFDbEI7QUFDQTtJQUNJLGdCQUFnQjtJQUNoQixnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsaUJBQWlCO0lBQ2pCLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxpQ0FBaUM7SUFDakMsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxtQkFBbUI7SUFDbkIsdUJBQXVCO0lBQ3ZCLGFBQWE7RUFDZjs7RUFFQTtJQUNFLGtCQUFrQjtJQUNsQixlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsV0FBVztJQUNYLGVBQWU7RUFDakIiLCJzb3VyY2VzQ29udGVudCI6WyIucmk4e1xuICAgIHdpZHRoOiAxMDAwcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbjogMCBhdXRvO1xufVxuI3RzdHtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtd2VpZ2h0OiA4MDA7XG59XG5cbiN0c3tcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGZvbnQtc2l6ZTogbWVkaXVtO1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5cbi50ZXh0LWNlbnRlciB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB9XG4gIFxuICB0YWJsZSB0ZCB7XG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZSAhaW1wb3J0YW50O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc2l6ZTogMTIuNXB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxuICBcbiAgLmNlbnRlciB7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICB9XG4gIFxuICB0YWJsZSB0aCB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgfVxuICBcbiAgdGFibGUgdGQgaW5wdXQge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgfSJdLCJzb3VyY2VSb290IjoiIn0= */"],
    data: {
      animation: [(0,src_app_transitions__WEBPACK_IMPORTED_MODULE_0__.SlideInFromLeft)()]
    }
  });
}

/***/ }),

/***/ 30636:
/*!*************************************************!*\
  !*** ./src/app/student/shared/order-by.pipe.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderByPipe": () => (/* binding */ OrderByPipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class OrderByPipe {
  transform(value, ...args) {
    return null;
  }
  static #_ = this.ɵfac = function OrderByPipe_Factory(t) {
    return new (t || OrderByPipe)();
  };
  static #_2 = this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({
    name: "orderBy",
    type: OrderByPipe,
    pure: true
  });
}

/***/ }),

/***/ 97852:
/*!***************************************************!*\
  !*** ./src/app/student/student-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudentRoutingModule": () => (/* binding */ StudentRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _student_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./student.component */ 52667);
/* harmony import */ var _complaints_complaints_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./complaints/complaints.component */ 62687);
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home/home.component */ 93106);
/* harmony import */ var _previous_courses_previous_courses_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./previous-courses/previous-courses.component */ 565);
/* harmony import */ var _teacher_assesment_teacher_assesment_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./teacher-assesment/teacher-assesment.component */ 11125);
/* harmony import */ var _time_table_time_table_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./time-table/time-table.component */ 63014);
/* harmony import */ var _examination_complete_transcript_complete_transcript_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./examination/complete-transcript/complete-transcript.component */ 75393);
/* harmony import */ var _examination_semester_transcript_semester_transcript_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./examination/semester-transcript/semester-transcript.component */ 60855);
/* harmony import */ var _examination_date_sheet_date_sheet_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./examination/date-sheet/date-sheet.component */ 21261);
/* harmony import */ var _student_services_fee_structure_fee_structure_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./student-services/fee-structure/fee-structure.component */ 72689);
/* harmony import */ var _student_services_student_information_student_information_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./student-services/student-information/student-information.component */ 6281);
/* harmony import */ var _attendance_attendance_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./attendance/attendance.component */ 8422);
/* harmony import */ var _progress_report_progress_report_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./progress-report/progress-report.component */ 17975);
/* harmony import */ var _teacher_evaluation_teacher_evaluation_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./teacher-evaluation/teacher-evaluation.component */ 9479);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 22560);

















// import {StdPreviousMarksComponent } from './std-previous-marks/std-previous-marks.component';
const routes = [{
  path: '',
  component: _student_component__WEBPACK_IMPORTED_MODULE_0__.StudentComponent,
  children: [{
    path: 'complaints',
    component: _complaints_complaints_component__WEBPACK_IMPORTED_MODULE_1__.ComplaintsComponent
  }, {
    path: 'Courses/:sub_code',
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_student_course_course_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./course/course.module */ 76603)).then(m => m.CourseModule)
  }, {
    path: 'completeTranscript',
    component: _examination_complete_transcript_complete_transcript_component__WEBPACK_IMPORTED_MODULE_6__.CompleteTranscriptComponent
  }, {
    path: 'attendance',
    component: _attendance_attendance_component__WEBPACK_IMPORTED_MODULE_11__.AttendanceComponent
  }, {
    path: 'semesterTranscript',
    component: _examination_semester_transcript_semester_transcript_component__WEBPACK_IMPORTED_MODULE_7__.SemesterTranscriptComponent
  }, {
    path: 'dateSheet',
    component: _examination_date_sheet_date_sheet_component__WEBPACK_IMPORTED_MODULE_8__.DateSheetComponent
  }, {
    path: 'home',
    component: _home_home_component__WEBPACK_IMPORTED_MODULE_2__.HomeComponent
  }, {
    path: 'previousCourses',
    component: _previous_courses_previous_courses_component__WEBPACK_IMPORTED_MODULE_3__.PreviousCoursesComponent
  }, {
    path: 'feeStructure',
    component: _student_services_fee_structure_fee_structure_component__WEBPACK_IMPORTED_MODULE_9__.FeeStructureComponent
  }, {
    path: 'studentInformation',
    component: _student_services_student_information_student_information_component__WEBPACK_IMPORTED_MODULE_10__.StudentInformationComponent
  }, {
    path: 'teacherAssessment',
    component: _teacher_assesment_teacher_assesment_component__WEBPACK_IMPORTED_MODULE_4__.TeacherAssesmentComponent
  }, {
    path: 'timeTable',
    component: _time_table_time_table_component__WEBPACK_IMPORTED_MODULE_5__.TimeTableComponent
  }, {
    path: 'teacherEvaluation',
    component: _teacher_evaluation_teacher_evaluation_component__WEBPACK_IMPORTED_MODULE_13__.TeacherEvaluationComponent
  }, {
    path: 'progressReport',
    component: _progress_report_progress_report_component__WEBPACK_IMPORTED_MODULE_12__.ProgressReportComponent
  }, {
    path: 'grades',
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_student_std-grades_StdGrades_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./std-grades/StdGrades.module */ 31844)).then(m => m.StdGradesModule)
  }, {
    path: 'Challans',
    loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_student_chalans_chalan_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./chalans/chalan.module */ 79010)).then(m => m.ChalanModule)
  }, {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  }]
}];
class StudentRoutingModule {
  static #_ = this.ɵfac = function StudentRoutingModule_Factory(t) {
    return new (t || StudentRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineNgModule"]({
    type: StudentRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_15__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_15__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵsetNgModuleScope"](StudentRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_15__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_15__.RouterModule]
  });
})();

/***/ }),

/***/ 72689:
/*!***********************************************************************************!*\
  !*** ./src/app/student/student-services/fee-structure/fee-structure.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeeStructureComponent": () => (/* binding */ FeeStructureComponent)
/* harmony export */ });
/* harmony import */ var _transitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../transitions */ 71629);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngrx/store */ 23488);



class FeeStructureComponent {
  constructor(store) {
    this.store = store;
  }
  ngOnInit() {
    // this.store.select('fromStudentService').subscribe(
    //   state => {
    //     this.semestersFee = state.semestersFee;
    //   }
    // );
  }
  static #_ = this.ɵfac = function FeeStructureComponent_Factory(t) {
    return new (t || FeeStructureComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_2__.Store));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: FeeStructureComponent,
    selectors: [["app-fee-structure"]],
    decls: 35,
    vars: 1,
    consts: [[1, "main-card", "mb-3", "card"], [1, "card-body", 2, "overflow", "hidden", "overflow-x", "scroll"], [1, "card-title"], [1, "mb-0", "table", "table-bordered"], [1, "bg-light"], [1, "text-center", "d-block", "p-3", "card-footer"], [1, "btn-shadow", "btn-wide", "fsize-1", "btn", "btn-primary", "float-right"], [1, "mr-2", "opacity-7"], [1, "fa", "fa-download"], [1, "mr-1"]],
    template: function FeeStructureComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "h5", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Semester x");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "table", 3)(6, "thead", 4)(7, "tr")(8, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "No");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11, "Challan-No");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, "ScholarShip-%");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Admission-Fee");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](17, "Tuition-Fee");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19, "Fine");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](21, "Tax");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](23, "Payable Fee");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25, "Due-Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](26, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27, "Paid-Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](28, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](29, "div", 5)(30, "button", 6)(31, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](32, "i", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](33, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](34, "Download Challan");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("@SlideInFromLeft", undefined);
      }
    },
    styles: ["tbody.custom-hover[_ngcontent-%COMP%]    > tr[_ngcontent-%COMP%]:hover {\n  background-color: #E0F3FF;\n  transition: .2s;\n}\n.card[_ngcontent-%COMP%] {\n  border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0;\n  font-size: .8rem;\n}\n\n.card-header[_ngcontent-%COMP%] {\n  text-transform: uppercase;\n  color: rgba(13, 27, 62, 0.7);\n  font-weight: bold;\n  background-color: white;\n\n  display: flex;\n  align-items: center;\n  border-bottom-width: 1px;\n  padding-top: 0;\n  padding-bottom: 0;\n  padding-right: .625rem;\n  height: 3.5rem;\n}\n\n.card-body[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n  padding: 1.25rem;\n  -ms-flex: 1 1 auto;\n  min-height: 1px;\n}\n.card-footer[_ngcontent-%COMP%] {\n  background-color: white;\n  text-transform: uppercase;\n  color: rgba(13, 27, 62, 0.7);\n  font-weight: bold;\n}\n@media (max-width: 768px) {\n  .table[_ngcontent-%COMP%]{\n    font-size: .7rem;\n  }\n  .card-footer[_ngcontent-%COMP%]{\n    font-size: .7rem;\n  }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9zdHVkZW50LXNlcnZpY2VzL2ZlZS1zdHJ1Y3R1cmUvZmVlLXN0cnVjdHVyZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UseUJBQXlCO0VBQ3pCLGVBQWU7QUFDakI7QUFDQTtFQUNFLHdEQUF3RDtFQUN4RCxnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsNEJBQTRCO0VBQzVCLGlCQUFpQjtFQUNqQix1QkFBdUI7O0VBRXZCLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIsd0JBQXdCO0VBQ3hCLGNBQWM7RUFDZCxpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGNBQWM7QUFDaEI7O0FBRUE7RUFDRSxjQUFjO0VBQ2QsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixlQUFlO0FBQ2pCO0FBQ0E7RUFDRSx1QkFBdUI7RUFDdkIseUJBQXlCO0VBQ3pCLDRCQUE0QjtFQUM1QixpQkFBaUI7QUFDbkI7QUFDQTtFQUNFO0lBQ0UsZ0JBQWdCO0VBQ2xCO0VBQ0E7SUFDRSxnQkFBZ0I7RUFDbEI7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbInRib2R5LmN1c3RvbS1ob3ZlciA+IHRyOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0UwRjNGRjtcbiAgdHJhbnNpdGlvbjogLjJzO1xufVxuLmNhcmQge1xuICBib3JkZXItcmFkaXVzOiBjYWxjKC4yNXJlbSAtIDFweCkgY2FsYyguMjVyZW0gLSAxcHgpIDAgMDtcbiAgZm9udC1zaXplOiAuOHJlbTtcbn1cblxuLmNhcmQtaGVhZGVyIHtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgY29sb3I6IHJnYmEoMTMsIDI3LCA2MiwgMC43KTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDFweDtcbiAgcGFkZGluZy10b3A6IDA7XG4gIHBhZGRpbmctYm90dG9tOiAwO1xuICBwYWRkaW5nLXJpZ2h0OiAuNjI1cmVtO1xuICBoZWlnaHQ6IDMuNXJlbTtcbn1cblxuLmNhcmQtYm9keSB7XG4gIGZsZXg6IDEgMSBhdXRvO1xuICBwYWRkaW5nOiAxLjI1cmVtO1xuICAtbXMtZmxleDogMSAxIGF1dG87XG4gIG1pbi1oZWlnaHQ6IDFweDtcbn1cbi5jYXJkLWZvb3RlciB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBjb2xvcjogcmdiYSgxMywgMjcsIDYyLCAwLjcpO1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cbkBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xuICAudGFibGV7XG4gICAgZm9udC1zaXplOiAuN3JlbTtcbiAgfVxuICAuY2FyZC1mb290ZXJ7XG4gICAgZm9udC1zaXplOiAuN3JlbTtcbiAgfVxufVxuXG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
    data: {
      animation: [(0,_transitions__WEBPACK_IMPORTED_MODULE_0__.SlideInFromLeft)()]
    }
  });
}

/***/ }),

/***/ 6281:
/*!***********************************************************************************************!*\
  !*** ./src/app/student/student-services/student-information/student-information.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudentInformationComponent": () => (/* binding */ StudentInformationComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _transitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../transitions */ 71629);
/* harmony import */ var _student_information_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./student-information.model */ 72746);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ 23488);
/* harmony import */ var _student_information_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./student-information.service */ 83271);
/* harmony import */ var src_app_auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/auth/_services/authentication.service */ 7893);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-toastr */ 94817);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 34497);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 2508);












const _c0 = ["f"];
function StudentInformationComponent_div_48_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 32)(1, "div", 33)(2, "form", null, 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "input", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function StudentInformationComponent_div_48_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r6);
      const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](3);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r5.editPhone(_r4));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6, "update");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function StudentInformationComponent_div_48_Template_button_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r6);
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r7.editPhoneNum = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function StudentInformationComponent_div_62_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 32)(1, "div", 33)(2, "form", null, 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "input", 38, 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function StudentInformationComponent_div_62_Template_button_click_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r11);
      const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](5);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r10.editEml(_r9));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "update");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function StudentInformationComponent_div_62_Template_button_click_8_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r11);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r12.editEmailBoolean = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, "cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function StudentInformationComponent_div_101_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 40)(1, "div", 41)(2, "a", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "\u00D7");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, " Please provide the obtain marks in ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6, "Intermediate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, ", total marks of intermediate and board roll number of Intermediate. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 43)(10, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "\u0628\u0631\u0627\u06C1 \u06A9\u0631\u0645 \u0627\u0646\u0679\u0631\u0645\u06CC\u0688\u06CC\u0679 \u0645\u06CC\u06BA \u062D\u0627\u0635\u0644 \u06A9\u0631\u062F\u06C1 \u0646\u0645\u0628\u0631\u060C \u0627\u0646\u0679\u0631\u0645\u06CC\u0688\u06CC\u0679 \u06A9\u06D2 \u06A9\u0644 \u0646\u0645\u0628\u0631 \u0627\u0648\u0631 \u0627\u0646\u0679\u0631\u0645\u06CC\u0688\u06CC\u0679 \u06A9\u0627 \u0628\u0648\u0631\u0688 \u0631\u0648\u0644 \u0646\u0645\u0628\u0631 \u0641\u0631\u0627\u06C1\u0645 \u06A9\u0631\u06CC\u06BA\u06D4");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "form", 44, 34)(14, "div", 45)(15, "div", 46)(16, "label", 47)(17, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, "Intermediate/A Level Obtain Marks:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](19, "input", 48, 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div", 46)(22, "label", 50)(23, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](24, "Total Marks:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](25, "input", 51, 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "div", 46)(28, "label", 53)(29, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](30, "Board Roll Number:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](31, "input", 54, 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("ngModel", ctx_r2.Fall2024Data.interObt);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("ngModel", ctx_r2.Fall2024Data.interTotal);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("ngModel", ctx_r2.Fall2024Data.BRD_RN);
  }
}
function StudentInformationComponent_div_102_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 40)(1, "div", 41)(2, "a", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "\u00D7");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, " Please provide the obtain marks in ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6, "Matric");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, ", total marks of Matric and board roll number of Matric. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 43)(10, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "\u0628\u0631\u0627\u06C1 \u06A9\u0631\u0645 \u0645\u06CC\u0679\u0631\u06A9 \u0645\u06CC\u06BA \u062D\u0627\u0635\u0644 \u06A9\u0631\u062F\u06C1 \u0646\u0645\u0628\u0631\u060C \u0645\u06CC\u0679\u0631\u06A9 \u06A9\u06D2 \u06A9\u0644 \u0646\u0645\u0628\u0631 \u0627\u0648\u0631 \u0645\u06CC\u0679\u0631\u06A9 \u06A9\u0627 \u0628\u0648\u0631\u0688 \u0631\u0648\u0644 \u0646\u0645\u0628\u0631 \u0641\u0631\u0627\u06C1\u0645 \u06A9\u0631\u06CC\u06BA\u06D4");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "form", 44, 34)(14, "div", 45)(15, "div", 46)(16, "label", 47)(17, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, "Matric/O Level Obtain Marks:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](19, "input", 48, 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div", 46)(22, "label", 50)(23, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](24, "Total Marks:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](25, "input", 51, 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "div", 46)(28, "label", 53)(29, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](30, "Board Roll Number:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](31, "input", 54, 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](33, "div", 46)(34, "label", 56)(35, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](36, "Board Name:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](37, "input", 57, 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](39, "div", 46)(40, "label", 59)(41, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](42, "Matric passing Year:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](43, "input", 60, 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](45, "div", 46)(46, "label", 62)(47, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](48, "Division:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](49, "input", 63, 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](51, "div", 46)(52, "label", 65)(53, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](54, "Grade:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](55, "input", 66, 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("ngModel", ctx_r3.Fall2024Data.interObt);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("ngModel", ctx_r3.Fall2024Data.interTotal);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("ngModel", ctx_r3.Fall2024Data.BRD_RN);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("ngModel", ctx_r3.Fall2024Data.BRD_NM);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("ngModel", ctx_r3.Fall2024Data.PASS_YEAR);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("ngModel", ctx_r3.Fall2024Data.DIVISION);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("ngModel", ctx_r3.Fall2024Data.GRADE);
  }
}
const _c1 = function (a0) {
  return {
    "show": a0
  };
};
const _c2 = function (a0) {
  return {
    "display": a0
  };
};
const _c3 = function () {
  return [2, 3, 11, 20, 21, 27, 30, 31, 36, 40, 48, 49, 58, 116];
};
const _c4 = function () {
  return [1, 111];
};
class StudentInformationComponent {
  // imgbyUser=null;
  constructor(store, studentInformationService, authenticationService, toastr, http, sanitizer) {
    this.store = store;
    this.studentInformationService = studentInformationService;
    this.authenticationService = authenticationService;
    this.toastr = toastr;
    this.http = http;
    this.sanitizer = sanitizer;
    this.editPhoneNum = false;
    this.editEmailBoolean = false;
    this.imageUrl = null;
    this.usr = this.authenticationService.getUser();
    this.isModalVisible = false;
    this.user_ClassCode = 0;
    this.c_codes = [];
    this.Fall2024Data = {};
    this.close = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
    this.studentInformation = new _student_information_model__WEBPACK_IMPORTED_MODULE_1__.StudentInformationModel("", "", "", "", "", "", "", "", "", "", "", "", "");
  }
  ngOnInit() {
    this.getFall2024Data();
    const usr = this.authenticationService.getUser();
    // this.imgbyUser=`http://111.68.103.118:10081/get-file/${this.authenticationService.getUser()?.C_CODE}/${this.authenticationService.getUser()?.SE_ID}/${this.authenticationService.getUser()?.MAJ_ID}/${this.authenticationService.getUser()?.ROLNO}`;
    this.getPicture();
    this.studentInformationService.getStudentInformation(usr.ROLNO).subscribe(res => {
      this.studentInformation = new _student_information_model__WEBPACK_IMPORTED_MODULE_1__.StudentInformationModel(res.REG_NO, res.NM, res.F_NM, res.NIC, res.PH1, res.ROLNO, res.DOB, res.ADD1, res.GENDER, res.RELIG, res.PHTO, res.EMAIL, res.D_NM);
    });
  }
  getFall2024Data() {
    this.Fall2024Data = [];
    this.c_codes = [];
    this.user_ClassCode = this.usr.C_CODE;
    // console.log(this.usr, "USER");
    this.studentInformationService.S_GetFall2024Data({
      c_code: this.usr.C_CODE,
      se_id: this.usr.SE_ID,
      maj_id: this.usr.MAJ_ID,
      rn: this.usr.RN
    }).subscribe(res => {
      // console.log(res);
      this.c_codes = res[0][0];
      this.c_codes = Object.values(res[0][0]);
      this.Fall2024Data = res[1][0];
      // console.log(this.c_codes)
      if (this.c_codes.includes(this.usr.C_CODE) && this.usr.YEAR == 2024) {
        this.showModal();
      }
    });
  }
  showModal() {
    this.isModalVisible = true;
  }
  hideModal() {
    this.isModalVisible = false;
  }
  Update() {
    const {
      obt,
      tot,
      brd_rn,
      brd_nm,
      pass_year,
      division,
      grd
    } = this.formref.value;
    if (!obt || !tot || !brd_rn) {
      this.toastr.warning("Fill all the Fields!");
      return;
    }
    this.studentInformationService.S_UpdateFall2024Data({
      c_code: this.usr.C_CODE,
      se_id: this.usr.SE_ID,
      maj_id: this.usr.MAJ_ID,
      rn: this.usr.RN,
      obt: obt,
      tot: tot,
      brd_rn: brd_rn,
      brd_nm: brd_nm,
      pass_year: pass_year,
      division: division,
      grd: grd
    }).subscribe(res => {
      // console.log(res);
      if (res[0][0].msg) {
        // this.hideModal();
        this.toastr.success(res[0][0].msg);
        this.getFall2024Data();
      } else {
        this.toastr.error("Could Not Update");
      }
    });
  }
  editEml(rn) {
    var params = {
      RolNo: this.studentInformation.rollNumber,
      Email: rn.value
    };
    if (params.Email == '') {
      this.toastr.warning('Fields Must Be Filled.');
    } else {
      this.studentInformationService.editEmail(params).subscribe(response => {
        this.toastr.success('Successfully updated.');
        this.editEmailBoolean = false;
      }, error => {
        this.toastr.warning(' Error Occured.');
        this.editEmailBoolean = false;
      });
      this.studentInformation.email = rn.value;
    }
  }
  editPhone(form) {
    var params = {
      RolNo: this.studentInformation.rollNumber,
      PH1: form.value.phone
    };
    if (params.PH1 == '') {
      this.toastr.warning('Fields Must Be Filled.');
    } else {
      this.studentInformationService.editPhone(params).subscribe(res => {
        this.toastr.success('Successfully updated.');
        this.editPhoneNum = false;
      }, error => {
        this.toastr.warning(' Error Occured.');
        this.editPhoneNum = false;
      });
      this.studentInformation.phoneNumber = form.value.phone;
    }
  }
  onPhoneChange() {
    this.editPhoneNum = true;
  }
  onEmailChange() {
    this.editEmailBoolean = true;
  }
  // by Shoaib Abbas
  getPicture() {
    this.studentInformationService.S_getStdtPicture(this.usr.C_CODE, this.usr.SE_ID, this.usr.MAJ_ID, this.usr.ROLNO).subscribe(response => {
      const objectURL = URL.createObjectURL(response);
      this.imageUrl = this.sanitizer.bypassSecurityTrustUrl(objectURL);
      // console.log("Image", this.imageUrl);
    }, error => {
      console.error('Error retrieving student picture', error);
    });
  }
  static #_ = this.ɵfac = function StudentInformationComponent_Factory(t) {
    return new (t || StudentInformationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_5__.Store), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_student_information_service__WEBPACK_IMPORTED_MODULE_2__.StudentInformationService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_3__.AuthenticationService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](ngx_toastr__WEBPACK_IMPORTED_MODULE_6__.ToastrService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.DomSanitizer));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: StudentInformationComponent,
    selectors: [["app-student-information"]],
    viewQuery: function StudentInformationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.formref = _t.first);
      }
    },
    outputs: {
      close: "close"
    },
    decls: 106,
    vars: 24,
    consts: [[1, "container-fluid"], [1, "student-profile", "py-4"], [1, "container"], [1, "row"], [1, "col-lg-4"], [1, "card", "shadow-sm"], [1, "card-header", "bg-transparent", "text-center"], ["alt", "", 1, "profile_img", "mt-4", 3, "src"], [1, "mt-2"], [1, "col-lg-8"], [1, "card-header1", "bg-transparent", "border-0"], [1, "mt-4", "ml-4"], [1, "far", "fa-clone", "pr-1"], [1, "card-body", "pt-0"], [1, "table", "table-bordered"], ["width", "30%"], ["width", "2%"], [1, "d-flex", "justify-content-between"], [1, "mr-2"], ["href", "javascript:void(0);", 3, "click"], ["aria-hidden", "true", 1, "fa", "fa-pencil"], ["class", "d-flex justify-content-center", 4, "ngIf"], ["tabindex", "-1", "role", "dialog", 1, "modal", "fade", 3, "ngClass", "ngStyle"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered", "custom-modal"], [1, "modal-content"], [1, "modal-header"], [1, "modal-title"], ["type", "button", "aria-label", "Close", 1, "close", 3, "click"], ["aria-hidden", "true"], ["class", "modal-body", 4, "ngIf"], [1, "modal-footer"], ["type", "button", 1, "btn", "btn-outline-primary", 3, "click"], [1, "d-flex", "justify-content-center"], [1, "form-group", "mt-1", "mb-1"], ["f", "ngForm"], ["type", "text", "name", "phone", "ngModel", "", "required", "", 1, "form-control"], [1, "btn", "btn-sm", "btn-primary", "m-2", 3, "click"], ["form", "ngForm"], ["type", "email", "name", "mail", "ngModel", "", "required", "", 1, "form-control"], ["eee", ""], [1, "modal-body"], [1, "alert", "alert-info", "alert-dismissible"], ["href", "#", "data-dismiss", "alert", "aria-label", "close", 1, "close"], ["dir", "rtl", 1, "mt-2", 2, "text-align", "right", "margin-top", "2px"], [1, "px-0"], [1, "row", "card-body", "space-remover", "px-0"], [1, "col-lg-4", "form-group"], ["for", "obt"], ["name", "obt", "id", "obt", "type", "number", 1, "form-control", 3, "ngModel"], ["obt", ""], ["for", "tot"], ["name", "tot", "id", "tot", "type", "number", 1, "form-control", 3, "ngModel"], ["tot", ""], ["for", "brd_rn"], ["name", "brd_rn", "id", "brd_rn", "type", "text", 1, "form-control", 3, "ngModel"], ["brd_rn", ""], ["for", "brd_nm"], ["name", "brd_nm", "id", "brd_nm", "type", "text", 1, "form-control", 3, "ngModel"], ["brd_nm", ""], ["for", "pass_year"], ["name", "pass_year", "id", "pass_year", "type", "number", 1, "form-control", 3, "ngModel"], ["pass_year", ""], ["for", "division"], ["name", "division", "id", "division", "type", "text", "maxlength", "95", 1, "form-control", 3, "ngModel"], ["division", ""], ["for", "grd"], ["name", "grd", "id", "grd", "type", "text", "maxlength", "3", 1, "form-control", 3, "ngModel"], ["grd", ""]],
    template: function StudentInformationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "div", 0)(2, "div", 1)(3, "div", 2)(4, "div", 3)(5, "div", 4)(6, "div", 5)(7, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "img", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "h3", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "div", 9)(14, "div", 5)(15, "div", 10)(16, "h3", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](17, "i", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, "General Information");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "div", 13)(20, "table", 14)(21, "tr")(22, "th", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23, "Father Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "td", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](25, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "tr")(29, "th", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](30, "CNIC ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "td", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](32, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](33, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](34);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](35, "tr")(36, "th", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](37, "Phone no.");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](38, "td", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](39, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](40, "td")(41, "div", 17)(42, "span", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](43);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](44, "span")(45, "a", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function StudentInformationComponent_Template_a_click_45_listener() {
          return ctx.onPhoneChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](46, "i", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](47, " edit ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](48, StudentInformationComponent_div_48_Template, 9, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](49, "tr")(50, "th", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](51, "Email");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](52, "td", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](53, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](54, "td")(55, "div", 17)(56, "span", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](57);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](58, "span")(59, "a", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function StudentInformationComponent_Template_a_click_59_listener() {
          return ctx.onEmailChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](60, "i", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](61, " edit ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](62, StudentInformationComponent_div_62_Template, 10, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](63, "tr")(64, "th", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](65, "Gender");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](66, "td", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](67, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](68, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](69);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](70, "tr")(71, "th", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](72, "Religion");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](73, "td", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](74, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](75, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](76);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](77, "tr")(78, "th", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](79, "Address");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](80, "td", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](81, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](82, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](83);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](84, "tr")(85, "th", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](86, "Department");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](87, "td", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](88, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](89, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](90);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](91, "div", 2)(92, "div", 22)(93, "div", 23)(94, "div", 24)(95, "div", 25)(96, "h5", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](97, "Data Updation Form");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](98, "button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function StudentInformationComponent_Template_button_click_98_listener() {
          return ctx.hideModal();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](99, "span", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](100, "\u00D7");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](101, StudentInformationComponent_div_101_Template, 33, 3, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](102, StudentInformationComponent_div_102_Template, 57, 7, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](103, "div", 30)(104, "button", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function StudentInformationComponent_Template_button_click_104_listener() {
          return ctx.Update();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](105, "Update");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx.imageUrl, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.studentInformation.studentName);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.studentInformation.rollNumber);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.studentInformation.fatherName);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.studentInformation.cnic);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.studentInformation.phoneNumber);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.editPhoneNum);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.studentInformation.email);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.editEmailBoolean);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.studentInformation.gender == "M" ? "MALE" : "FEMALE");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.studentInformation.religion);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.studentInformation.address);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.studentInformation.deptName);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](18, _c1, ctx.isModalVisible))("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](20, _c2, ctx.isModalVisible ? "block" : "none"));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](22, _c3).includes(ctx.user_ClassCode));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](23, _c4).includes(ctx.user_ClassCode));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.MaxLengthValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgForm],
    styles: [".card-header[_ngcontent-%COMP%] {\n  text-transform:none;\n  color: rgba(13, 27, 62, 0.7);\n  font-weight: bold;\n  background-color: white;\n  display:block;\n  align-items: center;\n  border-bottom-width: 1px;\n  padding-top: 0;\n  padding-bottom: 0;\n  padding-right: 0.625rem;\n  height:auto;\n}\nbody[_ngcontent-%COMP%] {\n  padding: 0;\n  margin: 0;\n  font-family: 'Lato', sans-serif;\n  color: #000;\n}\n\n.student-profile[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%] {\n  border-radius: 10px;\n}\n\n.student-profile[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]   .profile_img[_ngcontent-%COMP%] {\n  width: 215px;\n  height: 215px;\n  object-fit: cover;\n  margin: 10px auto;\n  border: 10px solid #ccc;\n  border-radius: 50%;\n}\n\n.student-profile[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-size: 20px;\n  font-weight: 700;\n}\n\n.student-profile[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 16px;\n  color: #000;\n}\n\n.student-profile[_ngcontent-%COMP%]   .table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], .student-profile[_ngcontent-%COMP%]   .table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  font-size: 14px;\n  padding: 5px 10px;\n  color: #000;\n}\n.student-profile[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-header1[_ngcontent-%COMP%]   .profile_img[_ngcontent-%COMP%] {\n  width: 200px;\n  height: 200px;\n  object-fit: cover;\n  margin: 10px auto;\n  border: 10px solid #ccc;\n  border-radius: 50%;\n}\n\n\n\n\n.modal.show[_ngcontent-%COMP%] {\n  margin-top: 1rem;\n  display: block;\n  background-color: rgba(0, 0, 0, 0.5);\n  \n}\n\n.modal-dialog-centered.custom-modal[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  min-height: calc(100% - 1rem);\n  max-width: 80%;\n  \n  max-height: 80%;\n  \n}\n\n.custom-modal[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  overflow: hidden;\n  \n}\n\n.custom-modal[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%] {\n  overflow-y: auto;\n  \n  max-height: 60vh;\n  \n}\n\n.custom-modal-card[_ngcontent-%COMP%] {\n  max-height: 50vh;\n  \n  overflow-y: auto;\n  \n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9zdHVkZW50LXNlcnZpY2VzL3N0dWRlbnQtaW5mb3JtYXRpb24vc3R1ZGVudC1pbmZvcm1hdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7UUFNUTtBQUNSOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0F3Qkc7O0FBRUg7RUFDRSxtQkFBbUI7RUFDbkIsNEJBQTRCO0VBQzVCLGlCQUFpQjtFQUNqQix1QkFBdUI7RUFDdkIsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQix3QkFBd0I7RUFDeEIsY0FBYztFQUNkLGlCQUFpQjtFQUNqQix1QkFBdUI7RUFDdkIsV0FBVztBQUNiO0FBQ0E7RUFDRSxVQUFVO0VBQ1YsU0FBUztFQUNULCtCQUErQjtFQUMvQixXQUFXO0FBQ2I7O0FBRUE7RUFDRSxtQkFBbUI7QUFDckI7O0FBRUE7RUFDRSxZQUFZO0VBQ1osYUFBYTtFQUNiLGlCQUFpQjtFQUNqQixpQkFBaUI7RUFDakIsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGVBQWU7RUFDZixnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxlQUFlO0VBQ2YsV0FBVztBQUNiOztBQUVBOztFQUVFLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsV0FBVztBQUNiO0FBQ0E7RUFDRSxZQUFZO0VBQ1osYUFBYTtFQUNiLGlCQUFpQjtFQUNqQixpQkFBaUI7RUFDakIsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtBQUNwQjs7OztBQUlBLGVBQWU7QUFDZjtFQUNFLGdCQUFnQjtFQUNoQixjQUFjO0VBQ2Qsb0NBQW9DO0VBQ3BDLGdDQUFnQztBQUNsQzs7QUFFQTtFQUNFLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIsNkJBQTZCO0VBQzdCLGNBQWM7RUFDZCwrQkFBK0I7RUFDL0IsZUFBZTtFQUNmLGdDQUFnQztBQUNsQzs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQiwrQ0FBK0M7QUFDakQ7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsOEJBQThCO0VBQzlCLGdCQUFnQjtFQUNoQixnREFBZ0Q7QUFDbEQ7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsZ0RBQWdEO0VBQ2hELGdCQUFnQjtFQUNoQiw4QkFBOEI7QUFDaEMiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBAbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcbiAgLmNhcmQge1xuICAgIGZvbnQtc2l6ZTogLjdyZW07XG4gIH1cbn1cblxuLyogQ1NTICovXG4vKiAuY2FyZCB7XG4gIGJvcmRlci1yYWRpdXM6IGNhbGMoLjI1cmVtIC0gMXB4KSBjYWxjKC4yNXJlbSAtIDFweCkgMCAwO1xuICBmb250LXNpemU6IC44cmVtO1xufVxuXG4uY2FyZC1oZWFkZXIge1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBjb2xvcjogcmdiYSgxMywgMjcsIDYyLCAwLjcpO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG5cbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYm9yZGVyLWJvdHRvbS13aWR0aDogMXB4O1xuICBwYWRkaW5nLXRvcDogMDtcbiAgcGFkZGluZy1ib3R0b206IDA7XG4gIHBhZGRpbmctcmlnaHQ6IC42MjVyZW07XG4gIGhlaWdodDogMy41cmVtO1xufVxuLmNhcmQtYm9keSB7XG4gIGZsZXg6IDEgMSBhdXRvO1xuICBwYWRkaW5nOiAxLjI1cmVtO1xuICAtbXMtZmxleDogMSAxIGF1dG87XG4gIG1pbi1oZWlnaHQ6IDFweDsgXG59ICovXG5cbi5jYXJkLWhlYWRlciB7XG4gIHRleHQtdHJhbnNmb3JtOm5vbmU7XG4gIGNvbG9yOiByZ2JhKDEzLCAyNywgNjIsIDAuNyk7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgZGlzcGxheTpibG9jaztcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYm9yZGVyLWJvdHRvbS13aWR0aDogMXB4O1xuICBwYWRkaW5nLXRvcDogMDtcbiAgcGFkZGluZy1ib3R0b206IDA7XG4gIHBhZGRpbmctcmlnaHQ6IDAuNjI1cmVtO1xuICBoZWlnaHQ6YXV0bztcbn1cbmJvZHkge1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IDA7XG4gIGZvbnQtZmFtaWx5OiAnTGF0bycsIHNhbnMtc2VyaWY7XG4gIGNvbG9yOiAjMDAwO1xufVxuXG4uc3R1ZGVudC1wcm9maWxlIC5jYXJkIHtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cblxuLnN0dWRlbnQtcHJvZmlsZSAuY2FyZCAuY2FyZC1oZWFkZXIgLnByb2ZpbGVfaW1nIHtcbiAgd2lkdGg6IDIxNXB4O1xuICBoZWlnaHQ6IDIxNXB4O1xuICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgbWFyZ2luOiAxMHB4IGF1dG87XG4gIGJvcmRlcjogMTBweCBzb2xpZCAjY2NjO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG59XG5cbi5zdHVkZW50LXByb2ZpbGUgLmNhcmQgaDMge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG5cbi5zdHVkZW50LXByb2ZpbGUgLmNhcmQgcCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6ICMwMDA7XG59XG5cbi5zdHVkZW50LXByb2ZpbGUgLnRhYmxlIHRoLFxuLnN0dWRlbnQtcHJvZmlsZSAudGFibGUgdGQge1xuICBmb250LXNpemU6IDE0cHg7XG4gIHBhZGRpbmc6IDVweCAxMHB4O1xuICBjb2xvcjogIzAwMDtcbn1cbi5zdHVkZW50LXByb2ZpbGUgLmNhcmQgLmNhcmQtaGVhZGVyMSAucHJvZmlsZV9pbWcge1xuICB3aWR0aDogMjAwcHg7XG4gIGhlaWdodDogMjAwcHg7XG4gIG9iamVjdC1maXQ6IGNvdmVyO1xuICBtYXJnaW46IDEwcHggYXV0bztcbiAgYm9yZGVyOiAxMHB4IHNvbGlkICNjY2M7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuXG5cbi8qIHN0eWxlcy5jc3MgKi9cbi5tb2RhbC5zaG93IHtcbiAgbWFyZ2luLXRvcDogMXJlbTtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMC41KTtcbiAgLyogU2VtaS10cmFuc3BhcmVudCBiYWNrZ3JvdW5kICovXG59XG5cbi5tb2RhbC1kaWFsb2ctY2VudGVyZWQuY3VzdG9tLW1vZGFsIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWluLWhlaWdodDogY2FsYygxMDAlIC0gMXJlbSk7XG4gIG1heC13aWR0aDogODAlO1xuICAvKiBBZGp1c3QgdGhlIHdpZHRoIGFzIG5lZWRlZCAqL1xuICBtYXgtaGVpZ2h0OiA4MCU7XG4gIC8qIEFkanVzdCB0aGUgaGVpZ2h0IGFzIG5lZWRlZCAqL1xufVxuXG4uY3VzdG9tLW1vZGFsIC5tb2RhbC1jb250ZW50IHtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgLyogUHJldmVudCB0aGUgbW9kYWwgY29udGVudCBmcm9tIG92ZXJmbG93aW5nICovXG59XG5cbi5jdXN0b20tbW9kYWwgLm1vZGFsLWJvZHkge1xuICBvdmVyZmxvdy15OiBhdXRvO1xuICAvKiBFbmFibGUgdmVydGljYWwgc2Nyb2xsaW5nICovXG4gIG1heC1oZWlnaHQ6IDYwdmg7XG4gIC8qIEFkanVzdCB0aGUgbWF4aW11bSBoZWlnaHQgb2YgdGhlIG1vZGFsIGJvZHkgKi9cbn1cblxuLmN1c3RvbS1tb2RhbC1jYXJkIHtcbiAgbWF4LWhlaWdodDogNTB2aDtcbiAgLyogQWRqdXN0IHRoZSBtYXhpbXVtIGhlaWdodCBvZiB0aGUgdGFibGUgY2FyZCAqL1xuICBvdmVyZmxvdy15OiBhdXRvO1xuICAvKiBFbmFibGUgdmVydGljYWwgc2Nyb2xsaW5nICovXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"],
    data: {
      animation: [(0,_transitions__WEBPACK_IMPORTED_MODULE_0__.SlideInFromLeft)()]
    }
  });
}

/***/ }),

/***/ 72746:
/*!*******************************************************************************************!*\
  !*** ./src/app/student/student-services/student-information/student-information.model.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudentInformationModel": () => (/* binding */ StudentInformationModel)
/* harmony export */ });
class StudentInformationModel {
  constructor(registrationNo, studentName, fatherName, cnic, phoneNumber, rollNumber, dob, address, gender, religion, phto, email, deptName) {
    this.registrationNo = registrationNo;
    this.studentName = studentName;
    this.fatherName = fatherName;
    this.cnic = cnic;
    this.phoneNumber = phoneNumber;
    this.rollNumber = rollNumber;
    this.dob = dob;
    this.address = address;
    this.gender = gender;
    this.religion = religion;
    this.phto = phto;
    this.email = email;
    this.deptName = deptName;
  }
}

/***/ }),

/***/ 83271:
/*!*********************************************************************************************!*\
  !*** ./src/app/student/student-services/student-information/student-information.service.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudentInformationService": () => (/* binding */ StudentInformationService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var src_axios_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/axios.js */ 46491);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);




class StudentInformationService {
  constructor(http) {
    this.http = http;
    this.apiUrl = 'https://sfc.gcu.edu.pk/get-lms-img';
  }
  //ZAIN AHMAD, made
  getStudentInformation(rolNo) {
    return this.http.get(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/student/getStudentInformation/${rolNo}`);
  }
  editEmail(params) {
    return this.http.post(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/student/editEmailstd`, params);
  }
  editPhone(params) {
    return this.http.post(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/student/editPhonestd`, params);
  }
  // By Shoaib Abbas
  S_getStdtDetail_tm(ROLNO) {
    return this.http.post(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/student/S_getStdtDetail_tm`, {
      ROLNO
    });
  }
  S_StdtAssignmentDetail(ROLNO) {
    return this.http.post(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/student/S_StdtAssignmentDetail`, {
      ROLNO
    });
  }
  // S_getStdtPicture(c_code: any, se_id: any, maj_id: any, rolno: any) {
  //   return this.http.post(`${baseUrl}/api/student/S_getStdtPicture`, {c_code, se_id, maj_id, rolno});
  // }
  S_getStdtPicture(C_CODE, SE_ID, MAJ_ID, ROLNO) {
    const token = localStorage.getItem('gcuid'); // Retrieve the token from local storage
    const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
    const url = `${this.apiUrl}/${C_CODE}/${SE_ID}/${MAJ_ID}/${ROLNO}`;
    return this.http.get(url, {
      headers,
      responseType: 'blob'
    });
  }
  S_GetFall2024Data(param) {
    return this.http.post(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/util/S_GetFall2024Data`, {
      param
    });
  }
  S_UpdateFall2024Data(param) {
    return this.http.post(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/util/S_UpdateFall2024Data`, {
      param
    });
  }
  static #_ = this.ɵfac = function StudentInformationService_Factory(t) {
    return new (t || StudentInformationService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: StudentInformationService,
    factory: StudentInformationService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 52667:
/*!**********************************************!*\
  !*** ./src/app/student/student.component.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudentComponent": () => (/* binding */ StudentComponent)
/* harmony export */ });
/* harmony import */ var _transitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../transitions */ 71629);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _auth_services_srm_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../auth/_services/srm.service */ 13220);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _event_emmiter_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./event-emmiter.service */ 8938);
/* harmony import */ var _auth_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../auth/_services */ 29792);
/* harmony import */ var _main_shared_services_Fee_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../main/shared/services/Fee.service */ 87909);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./change-password/change-password.component */ 98867);









function StudentComponent_img_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "img", 71);
  }
}
function StudentComponent_img_57_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "img", 72);
  }
}
function StudentComponent_div_134_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 73)(1, "div", 74)(2, "a", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, "\u00D7");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](5, "Important! ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](8, ". Please download your challan from ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](10, "Challans");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](11, " section in ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](12, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](13, "LMS");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](14, ". ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx_r2.msg);
  }
}
function StudentComponent_app_change_password_136_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "app-change-password", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("close", function StudentComponent_app_change_password_136_Template_app_change_password_close_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r5);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r4.onCloseChangePasswordForm());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
class StudentComponent {
  constructor(SRM, router, route, clickEvent, authenticationService, feeService) {
    this.SRM = SRM;
    this.router = router;
    this.route = route;
    this.clickEvent = clickEvent;
    this.authenticationService = authenticationService;
    this.feeService = feeService;
    // from the role based authentication
    this.loading = false;
    this.IsUserLoggedIn = false;
    this.semesterCourses = new Array();
    this.showResetForm = false;
    this.showChangePassword = false;
    this.usr = null;
    this.currentUser = this.authenticationService.currentUserValue;
    this.showMessage = false;
    this.usr = this.authenticationService.getUser();
    this.feeAnnouncement();
  }
  storage() {
    window.localStorage.setItem("name", "waqas");
    window.localStorage.setItem("id", "1234");
    window.localStorage.setItem("location", "Lahore");
  }
  navigate(path) {
    this.router.navigate([path], {
      relativeTo: this.route
    });
  }
  OnStudentInformationClicked() {
    this.router.navigate(['studentInformation'], {
      relativeTo: this.route
    });
  }
  onHomeClicked() {
    this.router.navigate(['home'], {
      relativeTo: this.route
    });
  }
  OnFeeStructureClicked() {
    this.router.navigate(['feeStructure'], {
      relativeTo: this.route
    });
  }
  OnSemesterTranscriptClicked() {
    this.router.navigate(['semesterTranscript'], {
      relativeTo: this.route
    });
  }
  OnCompleteTranscriptClicked() {
    this.router.navigate(['completeTranscript'], {
      relativeTo: this.route
    });
  }
  OnDateSheetClicked() {
    this.router.navigate(['dateSheet'], {
      relativeTo: this.route
    });
  }
  OnTeacherAssesmentClicked() {
    this.router.navigate(['teacherAssessment'], {
      relativeTo: this.route
    });
  }
  OnCompliantClicked() {
    this.router.navigate(['complaints'], {
      relativeTo: this.route
    });
  }
  OnTimeTableClicked() {
    this.router.navigate(['timeTable'], {
      relativeTo: this.route
    });
  }
  navigateToAttendence() {
    this.router.navigate(['attendance'], {
      relativeTo: this.route
    });
  }
  OnProgressReportClicked() {
    this.router.navigate(['progressReport'], {
      relativeTo: this.route
    });
  }
  onGradesClicked() {
    this.router.navigate(['grades'], {
      relativeTo: this.route
    });
  }
  navigateToAllCourses() {
    this.router.navigate(['teacherEvaluation'], {
      relativeTo: this.route
    });
  }
  OnShowMenuListItem(id) {
    /*const menu = document.getElementById(id);
    const ul = menu.getElementsByTagName('ul')[0];
    if (ul.classList.contains('mm-show')) {
      ul.classList.remove('mm-show');
      menu.classList.remove('mm-active');
    } else {
      ul.classList.add('mm-show');
      menu.classList.add('mm-active');
    }*/
  }
  OnnavBarHamBtnClicked() {
    const HamButton = document.getElementById('navBarHamBtn');
    const mainDivContainingNav = document.getElementById('main-container');
    if (HamButton.classList.contains('is-active')) {
      HamButton.classList.remove('is-active');
      mainDivContainingNav.classList.remove('sidebar-mobile-open');
    } else {
      HamButton.classList.add('is-active');
      mainDivContainingNav.classList.add('sidebar-mobile-open');
    }
  }
  onClickSRMS() {
    let authuserdata2;
    let authuserdata1 = this.authenticationService.getUser();
    this.SRM.fmdetails(authuserdata1.FM_ID).subscribe(res => {
      window.open("http://111.68.103.118:10107?id=" + res, "SRM");
    });
  }
  OnnavBarHamBtn_lgClicked() {
    const hamButtonLg = document.getElementById('navBarHamBtn-lg');
    const mainDivContainingNav = document.getElementById('main-container');
    if (hamButtonLg.classList.contains('is-active')) {
      hamButtonLg.classList.remove('is-active');
      mainDivContainingNav.classList.remove('closed-sidebar');
      this.clickEvent.announceClick(false);
    } else {
      hamButtonLg.classList.add('is-active');
      mainDivContainingNav.classList.add('closed-sidebar');
      this.clickEvent.announceClick(true);
    }
  }
  OnAppHeaderMobileMenu() {
    const mobileMenu = document.getElementById('app-header-mobile-menu');
    const buttonContent = document.getElementById('content_mobile');
    const buttonActivated = mobileMenu.classList.contains('active');
    if (buttonActivated) {
      mobileMenu.classList.remove('active');
      buttonContent.classList.remove('header-mobile-open');
    } else {
      mobileMenu.classList.add('active');
      buttonContent.classList.add('header-mobile-open');
    }
  }
  ngOnInit() {
    this.studentName = this.usr?.NM;
    this.rollNumber = this.usr?.ROLNO;
    this.cgpa = this.usr?.CGPA;
    this.icon = `../../assets/images/avatars/1.png`;
    this.imgbyUser = `http://111.68.103.118:10081/get-file/${this.authenticationService.getUser()?.C_CODE}/${this.authenticationService.getUser()?.SE_ID}/${this.authenticationService.getUser()?.MAJ_ID}/${this.authenticationService.getUser()?.ROLNO}`;
    // this.HomeAnnouncementService.getEnrollSubByStd(this.usr?.YEAR, this.usr?.C_CODE, this.usr?.MAJ_ID,
    //   this.usr?.RN).pipe().subscribe(
    //     session => {
    //       // @ts-ignore
    //       for (const i in session) {
    //         this.semesterCourses.push(new CourseModal(session[i].sub_nm, session[i].sub_code, session[i].t_no, session[i].section));
    //       }
    //       if (this.semesterCourses.length > 0) {
    //         this.selectedCourse.announceSelectedCourse(this.semesterCourses[0]);
    //       }
    //     },
    //     error => {
    //       console.log(error);
    //     }
    //   );
    this.loading = true;
    $('.menu-list ul').on('click', () => {
      if (window.innerWidth < 992) {
        $('#navBarHamBtn').removeClass('is-active');
        $('#main-container').removeClass('sidebar-mobile-open');
      }
    });
    $('ul.vertical-nav-menu > li:not(.menu-list):not(.app-sidebar__heading)').on('click', () => {
      if (window.innerWidth < 992) {
        $('#navBarHamBtn').removeClass('is-active');
        $('#main-container').removeClass('sidebar-mobile-open');
      }
    });
    this.clickEvent.message.subscribe(value => {
      this.showMessage = true;
    });
  }
  onCloseResetForm() {
    this.showResetForm = false;
  }
  onShowResetForm() {
    this.showResetForm = true;
  }
  onLogout() {
    this.authenticationService.logout();
  }
  OnChangePasswordClicked() {
    this.showChangePassword = true;
  }
  onCloseChangePasswordForm() {
    this.showChangePassword = false;
  }
  onCloseMessage() {
    this.showMessage = false;
  }
  feeAnnouncement() {
    this.feeService.feeAnnouncement(this.currentUser["C_CODE"], this.currentUser["YEAR"], this.currentUser["MAJ_ID"], this.currentUser["INST_NO"], this.currentUser["RN"]).subscribe(res => {
      this.msg = res[0][0].msg;
      console.log(res[0]);
    });
  }
  static #_ = this.ɵfac = function StudentComponent_Factory(t) {
    return new (t || StudentComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_auth_services_srm_service__WEBPACK_IMPORTED_MODULE_1__.SRMService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_event_emmiter_service__WEBPACK_IMPORTED_MODULE_2__.AppComponentEventEmitterService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_auth_services__WEBPACK_IMPORTED_MODULE_3__.AuthenticationService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_main_shared_services_Fee_service__WEBPACK_IMPORTED_MODULE_4__.FeeService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: StudentComponent,
    selectors: [["app-student"]],
    decls: 137,
    vars: 9,
    consts: [["id", "main-container", 1, "app-container", "app-theme-white", "body-tabs-shadow", "fixed-header", "fixed-sidebar"], [1, "app-header", "header-shadow"], [1, "app-header__logo"], [1, "logo-src"], [1, "header__pane", "ml-auto"], ["id", "navBarHamBtn-lg", "type", "button", "data-class", "closed-sidebar", 1, "hamburger", "close-sidebar-btn", "hamburger--elastic", 3, "click"], [1, "hamburger-box"], [1, "hamburger-inner"], [1, "app-header__mobile-menu"], ["id", "navBarHamBtn", "type", "button", 1, "hamburger", "hamburger--elastic", "mobile-toggle-nav", 3, "click"], [1, "app-header__menu"], ["id", "contentId", 1, "collapse"], [1, "card", 2, "margin-top", "250px", "margin-right", "-40px"], [1, "card-header", 2, "color", "white", "min-width", "200px", "background-color", "rgba(0,105,217,0.63)"], [1, "card-body"], [1, "btn", "btn-link", 3, "click"], ["id", "app-header-mobile-menu", "type", "button", "data-toggle", "collapse", "data-target", "#contentId", "aria-expanded", "false", "aria-controls", "contentId", 1, "fixed", "btn-icon", "btn-icon-only", "btn", "btn-primary", "btn-sm", "mobile-toggle-header-nav", 2, "transition", ".4s", 3, "click"], [1, "btn-icon-wrapper"], [1, "fa", "fa-ellipsis-v", "fa-w-6"], ["id", "content_mobile", 1, "app-header__content", "hider"], [1, "app-header-left"], ["id", "heading"], [2, "display", "inline", "font-size", "10px", "color", "darkgray", "margin-left", "5px"], [1, "app-header-right"], [1, "header-btn-lg", "pr-0"], [1, "widget-content", "p-0"], [1, "widget-content-wrapper"], [1, "widget-content-left"], ["id", "profile-btn", 1, "btn-group"], ["data-toggle", "dropdown", "aria-haspopup", "true", "aria-expanded", "false", 1, "p-0", "btn"], ["width", "42", "height", "45", "class", "rounded-circle", "src", "../../assets/images/avatars/1.png", "alt", "", 4, "ngIf"], [1, "fa", "fa-angle-down", "ml-2", "opacity-8"], ["tabindex", "-1", "role", "menu", "aria-hidden", "true", 1, "rm-pointers", "dropdown-menu-lg", "dropdown-menu", "dropdown-menu-right", "mb-0", "pb-0"], [1, "dropdown-menu-header", "pb-0", "mb-0"], [1, "dropdown-menu-header-inner", "bg-info"], [1, "menu-header-image", "opacity-2", 2, "background-image", "url('../../assets/images/dropdown-header/city3.jpg')"], [1, "menu-header-content", "text-left"], [1, "widget-content-left", "mr-3"], ["width", "45", "height", "50", "class", "rounded-circle", "src", "../../assets/images/avatars/1.png", "alt", "", 4, "ngIf"], [1, "widget-heading"], [1, "widget-content-right", "mr-2"], [1, "btn", "btn-link", "text-white", 3, "click"], [1, "scroll-area-xs", "mb-0", "pb-0", 2, "height", "150px"], [1, "scrollbar-container", "ps", "opacity"], [1, "nav", "flex-column", "opacity"], [1, "nav-item-header", "nav-item", "opacity"], [1, "nav-item"], ["href", "javascript:void(0);", 1, "nav-link", 3, "click"], [1, "widget-content-left", "ml-3", "header-user-info"], [1, "widget-subheading"], [1, "app-main"], [1, "app-sidebar", "sidebar-shadow"], ["type", "button", "data-class", "closed-sidebar", 1, "hamburger", "close-sidebar-btn", "hamburger--elastic"], ["type", "button", 1, "hamburger", "hamburger--elastic", "mobile-toggle-nav"], ["type", "button", 1, "btn-icon", "btn-icon-only", "btn", "btn-primary", "btn-sm", "mobile-toggle-header-nav"], [1, "scrollbar-sidebar", "scroll-hide"], [1, "app-sidebar__inner", "scroll-hide", 2, "max-height", "100%"], [1, "vertical-nav-menu"], [1, "app-sidebar__heading"], [3, "click"], [1, "metismenu-icon"], ["src", "../../../assets/home.svg", "alt", "", 1, "collapse-arrow", 2, "width", "2rem", "margin-left", "1px", "margin-top", "-3px"], ["src", "../../../assets/timetable.svg", "alt", "", 1, "collapse-arrow", "ml-1", 2, "width", "2.2rem"], [1, "metismenu-state-icon"], ["src", "../../../assets/attendance.svg", "alt", "", 1, "collapse-arrow", "ml-1", 2, "width", "1.9rem"], ["src", "../../../assets/grades.svg", "alt", "", 1, "collapse-arrow", "mt-1", 2, "width", "1.9rem", "margin-left", "7px"], ["src", "../../../assets/challan.svg", "alt", "", 1, "collapse-arrow", 2, "width", "1.7rem", "margin-left", "7px"], [1, "app-main__outer"], [1, "app-main__inner"], ["class", "row mb-0 px-3", 4, "ngIf"], [3, "close", 4, "ngIf"], ["width", "42", "height", "45", "src", "../../assets/images/avatars/1.png", "alt", "", 1, "rounded-circle"], ["width", "45", "height", "50", "src", "../../assets/images/avatars/1.png", "alt", "", 1, "rounded-circle"], [1, "row", "mb-0", "px-3"], [1, "alert", "alert-danger", "alert-dismissible", "col-12"], ["href", "#", "data-dismiss", "alert", "aria-label", "close", 1, "close"], [3, "close"]],
    template: function StudentComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "div", 4)(5, "div")(6, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_button_click_6_listener() {
          return ctx.OnnavBarHamBtn_lgClicked();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](8, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "div", 8)(10, "div")(11, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_button_click_11_listener() {
          return ctx.OnnavBarHamBtnClicked();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](12, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](13, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](19, "div", 14)(20, "div")(21, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_button_click_21_listener() {
          return ctx.OnStudentInformationClicked();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](22, "Profile");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](23, "div")(24, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_button_click_24_listener() {
          return ctx.OnChangePasswordClicked();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](25, "Change Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](26, "div")(27, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_button_click_27_listener() {
          return ctx.onLogout();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](28, "Logout");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](29, "span")(30, "button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_button_click_30_listener() {
          return ctx.OnAppHeaderMobileMenu();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "span", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](32, "i", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](33, "div", 19)(34, "div", 20)(35, "div", 21)(36, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](37, "GCU L.M.S [Student Panel]");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](38, "h6", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](39, "V03.05.10");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](40, "div", 23)(41, "div", 24)(42, "div", 25)(43, "div", 26)(44, "div", 27)(45, "div", 28)(46, "a", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](47, StudentComponent_img_47_Template, 1, 0, "img", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](48, "i", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](49, "div", 32)(50, "div", 33)(51, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](52, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](53, "div", 36)(54, "div", 25)(55, "div", 26)(56, "div", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](57, StudentComponent_img_57_Template, 1, 0, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](58, "div", 27)(59, "div", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](61, "div", 40)(62, "button", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_button_click_62_listener() {
          return ctx.onLogout();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](63, " Logout ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](64, "div", 42)(65, "div", 43)(66, "ul", 44)(67, "li", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](68, "Activity");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](69, "li", 46)(70, "a", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_a_click_70_listener() {
          return ctx.OnStudentInformationClicked();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](71, "Profile ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](72, "li", 46)(73, "a", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_a_click_73_listener() {
          return ctx.OnChangePasswordClicked();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](74, "Change Password ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](75, "div", 48)(76, "div", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](77);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](78, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](79);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](80, "div", 50)(81, "div", 51)(82, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](83, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](84, "div", 4)(85, "div")(86, "button", 52)(87, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](88, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](89, "div", 8)(90, "div")(91, "button", 53)(92, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](93, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](94, "div", 10)(95, "span")(96, "button", 54)(97, "span", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](98, "i", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](99, "div", 55)(100, "div", 56)(101, "ul", 57)(102, "li", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](103, "Menu");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](104, "li")(105, "a", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_a_click_105_listener() {
          return ctx.onHomeClicked();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](106, "i", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](107, "img", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](108, " Home");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](109, "li")(110, "a", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_a_click_110_listener() {
          return ctx.OnTimeTableClicked();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](111, "i", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](112, "img", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](113, " TimeTable ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](114, "i", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](115, "li", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](116, "Student");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](117, "li")(118, "a", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_a_click_118_listener() {
          return ctx.navigateToAttendence();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](119, "i", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](120, "img", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](121, " Attendance ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](122, "li")(123, "a", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_a_click_123_listener() {
          return ctx.onGradesClicked();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](124, "i", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](125, "img", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](126, " Grades ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](127, "li")(128, "a", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function StudentComponent_Template_a_click_128_listener() {
          return ctx.navigate("Challans");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](129, "i", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](130, "img", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](131, " Challans ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](132, "div", 67)(133, "div", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](134, StudentComponent_div_134_Template, 15, 1, "div", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](135, "router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](136, StudentComponent_app_change_password_136_Template, 1, 0, "app-change-password", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("@FadeIn", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.studentName, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.imgbyUser);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.imgbyUser);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"]("", ctx.studentName, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.studentName, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.rollNumber, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](55);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.msg && ctx.msg != "0");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.showChangePassword);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterOutlet, _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_5__.ChangePasswordComponent],
    styles: ["#heading[_ngcontent-%COMP%]{\n  font-family: 'Simplifica', sans-serif;\n  \n  color: #464e54;\n  letter-spacing: 3px;\n  word-spacing: 8px;\n}\n\n.scroll-hide[_ngcontent-%COMP%] {\n  overflow-y: scroll;\n  overflow-x: scroll;\n}\n\n.scroll-hide[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n\n.scroll-hide[_ngcontent-%COMP%] {\n  -ms-overflow-style: none;\n  \n  scrollbar-width: none;\n  \n}\n\n\n@media (max-width: 992px) {\n\n  .hider[_ngcontent-%COMP%]{\n    display: none !important;\n  }\n}\n#background-image[_ngcontent-%COMP%]{\n  background: url(\"https://images.fineartamerica.com/images/artworkimages/mediumlarge/1/gc-university-lahore-zubair-qureshi.jpg\");\n  position: absolute;\n  width: 100%;\n  height: 100%;\n}\n\nhtml[_ngcontent-%COMP%] {\n  font-family: sans-serif;\n  line-height: 1.15;\n  -webkit-text-size-adjust: 100%;\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0)\n}\n\narticle[_ngcontent-%COMP%], aside[_ngcontent-%COMP%], figcaption[_ngcontent-%COMP%], figure[_ngcontent-%COMP%], footer[_ngcontent-%COMP%], header[_ngcontent-%COMP%], hgroup[_ngcontent-%COMP%], main[_ngcontent-%COMP%], nav[_ngcontent-%COMP%], section[_ngcontent-%COMP%] {\n  display: block\n}\n\n.app-main[_ngcontent-%COMP%] {\n  font-size: .8rem;\n}\n\nul.vertical-nav-menu[_ngcontent-%COMP%]    > li.app-sidebar__heading[_ngcontent-%COMP%] {\n  cursor: default;\n}\n\nul.vertical-nav-menu[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]:not(.app-sidebar__heading) {\n  cursor: pointer;\n  outline: none;\n}\n\nbody[_ngcontent-%COMP%] {\n  margin: 0;\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, \"Noto Sans\", sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\";\n  font-size: .88rem;\n  font-weight: 400;\n  line-height: 1.5;\n  color: #495057;\n  text-align: left;\n  background-color: #fff\n}\n\n.table-bordered[_ngcontent-%COMP%] {\n  border: 1px solid #e9ecef\n}\n\n.table-bordered[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], .table-bordered[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  border: 1px solid #e9ecef\n}\n\n.table-bordered[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], .table-bordered[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  border-bottom-width: 2px\n}\n\n.btn[_ngcontent-%COMP%] {\n  display: inline-block;\n  font-weight: 400;\n  color: #495057;\n  text-align: center;\n  vertical-align: middle;\n  -webkit-user-select: none;\n          user-select: none;\n  background-color: transparent;\n  border: 1px solid transparent;\n  padding: .375rem .75rem;\n  font-size: 1rem;\n  line-height: 1.5;\n  border-radius: .25rem;\n  transition: color 0.15s, background-color 0.15s, border-color 0.15s, box-shadow 0.15s\n}\n\n@media screen and (prefers-reduced-motion: reduce) {\n  .btn[_ngcontent-%COMP%] {\n    transition: none\n  }\n}\n\n\n.btn[_ngcontent-%COMP%]:focus, .btn.focus[_ngcontent-%COMP%] {\n  outline: 0;\n  box-shadow: none\n}\n\n.btn.disabled[_ngcontent-%COMP%], .btn[_ngcontent-%COMP%]:disabled {\n  opacity: .65\n}\n\n.btn[_ngcontent-%COMP%]:not(:disabled):not(.disabled) {\n  cursor: pointer\n}\n\n\n.btn-primary[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #3f6ad8;\n  border-color: #3f6ad8\n}\n\n.btn-primary[_ngcontent-%COMP%]:hover {\n  color: #fff;\n  background-color: #2955c8;\n  border-color: #2651be\n}\n\n.btn-primary[_ngcontent-%COMP%]:focus, .btn-primary.focus[_ngcontent-%COMP%] {\n  box-shadow: 0 0 0 0 rgba(92, 128, 222, 0.5)\n}\n\n.btn-primary.disabled[_ngcontent-%COMP%], .btn-primary[_ngcontent-%COMP%]:disabled {\n  color: #fff;\n  background-color: #3f6ad8;\n  border-color: #3f6ad8\n}\n\n.btn-primary[_ngcontent-%COMP%]:not(:disabled):not(.disabled):active, .btn-primary[_ngcontent-%COMP%]:not(:disabled):not(.disabled).active, .show[_ngcontent-%COMP%]    > .btn-primary.dropdown-toggle[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #2651be;\n  border-color: #244cb3\n}\n\n.btn-primary[_ngcontent-%COMP%]:not(:disabled):not(.disabled):active:focus, .btn-primary[_ngcontent-%COMP%]:not(:disabled):not(.disabled).active:focus, .show[_ngcontent-%COMP%]    > .btn-primary.dropdown-toggle[_ngcontent-%COMP%]:focus {\n  box-shadow: 0 0 0 0 rgba(92, 128, 222, 0.5)\n}\n\n.btn-link[_ngcontent-%COMP%]:hover {\n  color: #0056b3;\n  text-decoration: underline\n}\n\n.btn-link[_ngcontent-%COMP%]:focus, .btn-link.focus[_ngcontent-%COMP%] {\n  text-decoration: underline;\n  box-shadow: none\n}\n\n.btn-link[_ngcontent-%COMP%]:disabled, .btn-link.disabled[_ngcontent-%COMP%] {\n  color: #6c757d;\n  pointer-events: none\n}\n\n.dropup[_ngcontent-%COMP%], .dropright[_ngcontent-%COMP%], .dropdown[_ngcontent-%COMP%], .dropleft[_ngcontent-%COMP%] {\n  position: relative\n}\n\n.dropdown-toggle[_ngcontent-%COMP%]::after {\n  display: inline-block;\n  margin-left: .255em;\n  vertical-align: .255em;\n  content: \"\";\n  border-top: .3em solid;\n  border-right: .3em solid transparent;\n  border-bottom: 0;\n  border-left: .3em solid transparent\n}\n\n.dropdown-toggle[_ngcontent-%COMP%]:empty::after {\n  margin-left: 0\n}\n\n.dropdown-menu[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 100%;\n  left: 0;\n  z-index: 1000;\n  display: none;\n  float: left;\n  min-width: 15rem;\n  padding: .65rem 0;\n  margin: .125rem 0 0;\n  font-size: .88rem;\n  color: #495057;\n  text-align: left;\n  list-style: none;\n  background-color: #fff;\n  background-clip: padding-box;\n  border: 1px solid rgba(0, 0, 0, 0.15);\n  border-radius: .25rem\n}\n\n.dropdown-menu-right[_ngcontent-%COMP%] {\n  right: 0;\n  left: auto\n}\n\n@media (min-width: 576px) {\n  .dropdown-menu-sm-right[_ngcontent-%COMP%] {\n    right: 0;\n    left: auto\n  }\n}\n\n@media (min-width: 768px) {\n  .dropdown-menu-md-right[_ngcontent-%COMP%] {\n    right: 0;\n    left: auto\n  }\n}\n\n@media (min-width: 992px) {\n  .dropdown-menu-lg-right[_ngcontent-%COMP%] {\n    right: 0;\n    left: auto\n  }\n}\n\n@media (min-width: 1200px) {\n  .dropdown-menu-xl-right[_ngcontent-%COMP%] {\n    right: 0;\n    left: auto\n  }\n}\n\n.dropdown-menu-left[_ngcontent-%COMP%] {\n  right: auto;\n  left: 0\n}\n\n@media (min-width: 576px) {\n  .dropdown-menu-sm-left[_ngcontent-%COMP%] {\n    right: auto;\n    left: 0\n  }\n}\n\n@media (min-width: 768px) {\n  .dropdown-menu-md-left[_ngcontent-%COMP%] {\n    right: auto;\n    left: 0\n  }\n}\n\n@media (min-width: 992px) {\n  .dropdown-menu-lg-left[_ngcontent-%COMP%] {\n    right: auto;\n    left: 0\n  }\n}\n\n@media (min-width: 1200px) {\n  .dropdown-menu-xl-left[_ngcontent-%COMP%] {\n    right: auto;\n    left: 0\n  }\n}\n\n.dropup[_ngcontent-%COMP%]   .dropdown-menu[_ngcontent-%COMP%] {\n  top: auto;\n  bottom: 100%;\n  margin-top: 0;\n  margin-bottom: .125rem\n}\n\n.dropup[_ngcontent-%COMP%]   .dropdown-toggle[_ngcontent-%COMP%]::after {\n  display: inline-block;\n  margin-left: .255em;\n  vertical-align: .255em;\n  content: \"\";\n  border-top: 0;\n  border-right: .3em solid transparent;\n  border-bottom: .3em solid;\n  border-left: .3em solid transparent\n}\n\n.dropup[_ngcontent-%COMP%]   .dropdown-toggle[_ngcontent-%COMP%]:empty::after {\n  margin-left: 0\n}\n\n.dropdown-menu[x-placement^=\"top\"][_ngcontent-%COMP%], .dropdown-menu[x-placement^=\"right\"][_ngcontent-%COMP%], .dropdown-menu[x-placement^=\"bottom\"][_ngcontent-%COMP%], .dropdown-menu[x-placement^=\"left\"][_ngcontent-%COMP%] {\n  right: auto;\n  bottom: auto\n}\n\n.dropdown-menu.show[_ngcontent-%COMP%] {\n  display: block\n}\n\n.dropdown-header[_ngcontent-%COMP%] {\n  display: block;\n  padding: .65rem 1.5rem;\n  margin-bottom: 0;\n  font-size: .968rem;\n  color: #6c757d;\n  white-space: nowrap\n}\n\n.dropdown-item-text[_ngcontent-%COMP%] {\n  display: block;\n  padding: .4rem 1.5rem;\n  color: #212529\n}\n\n.btn-group[_ngcontent-%COMP%], .btn-group-vertical[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-flex;\n  vertical-align: middle\n}\n\n.btn-group[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%], .btn-group-vertical[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%] {\n  position: relative;\n  flex: 1 1 auto\n}\n\n.btn-group[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]:hover, .btn-group-vertical[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]:hover {\n  z-index: 1\n}\n\n.btn-group[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]:focus, .btn-group[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]:active, .btn-group[_ngcontent-%COMP%]    > .btn.active[_ngcontent-%COMP%], .btn-group-vertical[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]:focus, .btn-group-vertical[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]:active, .btn-group-vertical[_ngcontent-%COMP%]    > .btn.active[_ngcontent-%COMP%] {\n  z-index: 1\n}\n\n.btn-group[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]:not(:first-child), .btn-group[_ngcontent-%COMP%]    > .btn-group[_ngcontent-%COMP%]:not(:first-child) {\n  margin-left: -1px\n}\n\n.btn-group[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]:not(:last-child):not(.dropdown-toggle), .btn-group[_ngcontent-%COMP%]    > .btn-group[_ngcontent-%COMP%]:not(:last-child)    > .btn[_ngcontent-%COMP%] {\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0\n}\n\n.btn-group[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]:not(:first-child), .btn-group[_ngcontent-%COMP%]    > .btn-group[_ngcontent-%COMP%]:not(:first-child)    > .btn[_ngcontent-%COMP%] {\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0\n}\n\n\n.nav[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  padding-left: 0;\n  margin-bottom: 0;\n  list-style: none\n}\n\n.nav-link[_ngcontent-%COMP%] {\n  display: block;\n  padding: .5rem 1rem\n}\n\n.nav-link[_ngcontent-%COMP%]:hover, .nav-link[_ngcontent-%COMP%]:focus {\n  text-decoration: none\n}\n\n.nav-link.disabled[_ngcontent-%COMP%] {\n  color: #6c757d;\n  pointer-events: none;\n  cursor: default\n}\n\n.nav-tabs[_ngcontent-%COMP%] {\n  border-bottom: 1px solid #dee2e6\n}\n\n.nav-tabs[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%] {\n  margin-bottom: -1px\n}\n\n.nav-tabs[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n  border: 1px solid transparent;\n  border-top-left-radius: .25rem;\n  border-top-right-radius: .25rem\n}\n\n.nav-tabs[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%]:hover, .nav-tabs[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%]:focus {\n  border-color: #e9ecef #e9ecef #dee2e6\n}\n\n.nav-tabs[_ngcontent-%COMP%]   .nav-link.disabled[_ngcontent-%COMP%] {\n  color: #6c757d;\n  background-color: transparent;\n  border-color: transparent\n}\n\n.nav-tabs[_ngcontent-%COMP%]   .nav-link.active[_ngcontent-%COMP%], .nav-tabs[_ngcontent-%COMP%]   .nav-item.show[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n  color: #495057;\n  background-color: #fff;\n  border-color: #dee2e6 #dee2e6 #fff\n}\n\n.nav-tabs[_ngcontent-%COMP%]   .dropdown-menu[_ngcontent-%COMP%] {\n  margin-top: -1px;\n  border-top-left-radius: 0;\n  border-top-right-radius: 0\n}\n\n.nav-pills[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n  border-radius: .25rem\n}\n\n.nav-pills[_ngcontent-%COMP%]   .nav-link.active[_ngcontent-%COMP%], .nav-pills[_ngcontent-%COMP%]   .show[_ngcontent-%COMP%]    > .nav-link[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #3f6ad8\n}\n\n.nav-fill[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n  text-align: center\n}\n\n.nav-justified[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%] {\n  flex-basis: 0;\n  flex-grow: 1;\n  text-align: center\n}\n\n.tab-content[_ngcontent-%COMP%]    > .tab-pane[_ngcontent-%COMP%] {\n  display: none\n}\n\n.tab-content[_ngcontent-%COMP%]    > .active[_ngcontent-%COMP%] {\n  display: block\n}\n\n.navbar[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  justify-content: space-between;\n  padding: .5rem 1rem\n}\n\n.navbar[_ngcontent-%COMP%]    > .container[_ngcontent-%COMP%], .navbar[_ngcontent-%COMP%]    > .container-fluid[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  justify-content: space-between\n}\n\n.navbar-brand[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding-top: .3125rem;\n  padding-bottom: .3125rem;\n  margin-right: 1rem;\n  font-size: 1.25rem;\n  line-height: inherit;\n  white-space: nowrap\n}\n\n.navbar-brand[_ngcontent-%COMP%]:hover, .navbar-brand[_ngcontent-%COMP%]:focus {\n  text-decoration: none\n}\n\n.navbar-nav[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding-left: 0;\n  margin-bottom: 0;\n  list-style: none\n}\n\n.navbar-nav[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n  padding-right: 0;\n  padding-left: 0\n}\n\n.navbar-nav[_ngcontent-%COMP%]   .dropdown-menu[_ngcontent-%COMP%] {\n  position: static;\n  float: none\n}\n\n.navbar-text[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding-top: .5rem;\n  padding-bottom: .5rem\n}\n\n.navbar-collapse[_ngcontent-%COMP%] {\n  flex-basis: 100%;\n  flex-grow: 1;\n  align-items: center\n}\n\n.navbar-toggler[_ngcontent-%COMP%] {\n  padding: .25rem .75rem;\n  font-size: 1.25rem;\n  line-height: 1;\n  background-color: transparent;\n  border: 1px solid transparent;\n  border-radius: .25rem\n}\n\n.navbar-toggler[_ngcontent-%COMP%]:hover, .navbar-toggler[_ngcontent-%COMP%]:focus {\n  text-decoration: none\n}\n\n.navbar-toggler[_ngcontent-%COMP%]:not(:disabled):not(.disabled) {\n  cursor: pointer\n}\n\n.navbar-toggler-icon[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: 1.5em;\n  height: 1.5em;\n  vertical-align: middle;\n  content: \"\";\n  background: no-repeat center center;\n  background-size: 100% 100%\n}\n\n@media (max-width: 575.98px) {\n  .navbar-expand-sm[_ngcontent-%COMP%]    > .container[_ngcontent-%COMP%], .navbar-expand-sm[_ngcontent-%COMP%]    > .container-fluid[_ngcontent-%COMP%] {\n    padding-right: 0;\n    padding-left: 0\n  }\n}\n\n@media (min-width: 576px) {\n  .navbar-expand-sm[_ngcontent-%COMP%] {\n    flex-flow: row nowrap;\n    justify-content: flex-start\n  }\n\n  .navbar-expand-sm[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%] {\n    flex-direction: row\n  }\n\n  .navbar-expand-sm[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .dropdown-menu[_ngcontent-%COMP%] {\n    position: absolute\n  }\n\n  .navbar-expand-sm[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n    padding-right: .5rem;\n    padding-left: .5rem\n  }\n\n  .navbar-expand-sm[_ngcontent-%COMP%]    > .container[_ngcontent-%COMP%], .navbar-expand-sm[_ngcontent-%COMP%]    > .container-fluid[_ngcontent-%COMP%] {\n    flex-wrap: nowrap\n  }\n\n  .navbar-expand-sm[_ngcontent-%COMP%]   .navbar-collapse[_ngcontent-%COMP%] {\n    display: flex !important;\n    flex-basis: auto\n  }\n\n  .navbar-expand-sm[_ngcontent-%COMP%]   .navbar-toggler[_ngcontent-%COMP%] {\n    display: none\n  }\n}\n\n@media (max-width: 767.98px) {\n  .navbar-expand-md[_ngcontent-%COMP%]    > .container[_ngcontent-%COMP%], .navbar-expand-md[_ngcontent-%COMP%]    > .container-fluid[_ngcontent-%COMP%] {\n    padding-right: 0;\n    padding-left: 0\n  }\n}\n\n@media (min-width: 768px) {\n  .navbar-expand-md[_ngcontent-%COMP%] {\n    flex-flow: row nowrap;\n    justify-content: flex-start\n  }\n\n  .navbar-expand-md[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%] {\n    flex-direction: row\n  }\n\n  .navbar-expand-md[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .dropdown-menu[_ngcontent-%COMP%] {\n    position: absolute\n  }\n\n  .navbar-expand-md[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n    padding-right: .5rem;\n    padding-left: .5rem\n  }\n\n  .navbar-expand-md[_ngcontent-%COMP%]    > .container[_ngcontent-%COMP%], .navbar-expand-md[_ngcontent-%COMP%]    > .container-fluid[_ngcontent-%COMP%] {\n    flex-wrap: nowrap\n  }\n\n  .navbar-expand-md[_ngcontent-%COMP%]   .navbar-collapse[_ngcontent-%COMP%] {\n    display: flex !important;\n    flex-basis: auto\n  }\n\n  .navbar-expand-md[_ngcontent-%COMP%]   .navbar-toggler[_ngcontent-%COMP%] {\n    display: none\n  }\n}\n\n@media (max-width: 991.98px) {\n  .navbar-expand-lg[_ngcontent-%COMP%]    > .container[_ngcontent-%COMP%], .navbar-expand-lg[_ngcontent-%COMP%]    > .container-fluid[_ngcontent-%COMP%] {\n    padding-right: 0;\n    padding-left: 0\n  }\n}\n\n@media (min-width: 992px) {\n  .navbar-expand-lg[_ngcontent-%COMP%] {\n    flex-flow: row nowrap;\n    justify-content: flex-start\n  }\n\n  .navbar-expand-lg[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%] {\n    flex-direction: row\n  }\n\n  .navbar-expand-lg[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .dropdown-menu[_ngcontent-%COMP%] {\n    position: absolute\n  }\n\n  .navbar-expand-lg[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n    padding-right: .5rem;\n    padding-left: .5rem\n  }\n\n  .navbar-expand-lg[_ngcontent-%COMP%]    > .container[_ngcontent-%COMP%], .navbar-expand-lg[_ngcontent-%COMP%]    > .container-fluid[_ngcontent-%COMP%] {\n    flex-wrap: nowrap\n  }\n\n  .navbar-expand-lg[_ngcontent-%COMP%]   .navbar-collapse[_ngcontent-%COMP%] {\n    display: flex !important;\n    flex-basis: auto\n  }\n\n  .navbar-expand-lg[_ngcontent-%COMP%]   .navbar-toggler[_ngcontent-%COMP%] {\n    display: none\n  }\n}\n\n@media (max-width: 1199.98px) {\n  .navbar-expand-xl[_ngcontent-%COMP%]    > .container[_ngcontent-%COMP%], .navbar-expand-xl[_ngcontent-%COMP%]    > .container-fluid[_ngcontent-%COMP%] {\n    padding-right: 0;\n    padding-left: 0\n  }\n}\n\n@media (min-width: 1200px) {\n  .navbar-expand-xl[_ngcontent-%COMP%] {\n    flex-flow: row nowrap;\n    justify-content: flex-start\n  }\n\n  .navbar-expand-xl[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%] {\n    flex-direction: row\n  }\n\n  .navbar-expand-xl[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .dropdown-menu[_ngcontent-%COMP%] {\n    position: absolute\n  }\n\n  .navbar-expand-xl[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n    padding-right: .5rem;\n    padding-left: .5rem\n  }\n\n  .navbar-expand-xl[_ngcontent-%COMP%]    > .container[_ngcontent-%COMP%], .navbar-expand-xl[_ngcontent-%COMP%]    > .container-fluid[_ngcontent-%COMP%] {\n    flex-wrap: nowrap\n  }\n\n  .navbar-expand-xl[_ngcontent-%COMP%]   .navbar-collapse[_ngcontent-%COMP%] {\n    display: flex !important;\n    flex-basis: auto\n  }\n\n  .navbar-expand-xl[_ngcontent-%COMP%]   .navbar-toggler[_ngcontent-%COMP%] {\n    display: none\n  }\n}\n\n.navbar-expand[_ngcontent-%COMP%] {\n  flex-flow: row nowrap;\n  justify-content: flex-start\n}\n\n.navbar-expand[_ngcontent-%COMP%]    > .container[_ngcontent-%COMP%], .navbar-expand[_ngcontent-%COMP%]    > .container-fluid[_ngcontent-%COMP%] {\n  padding-right: 0;\n  padding-left: 0\n}\n\n.navbar-expand[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%] {\n  flex-direction: row\n}\n\n.navbar-expand[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .dropdown-menu[_ngcontent-%COMP%] {\n  position: absolute\n}\n\n.navbar-expand[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n  padding-right: .5rem;\n  padding-left: .5rem\n}\n\n.navbar-expand[_ngcontent-%COMP%]    > .container[_ngcontent-%COMP%], .navbar-expand[_ngcontent-%COMP%]    > .container-fluid[_ngcontent-%COMP%] {\n  flex-wrap: nowrap\n}\n\n.navbar-expand[_ngcontent-%COMP%]   .navbar-collapse[_ngcontent-%COMP%] {\n  display: flex !important;\n  flex-basis: auto\n}\n\n.navbar-expand[_ngcontent-%COMP%]   .navbar-toggler[_ngcontent-%COMP%] {\n  display: none\n}\n\n.badge[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: .25em .4em;\n  font-size: 75%;\n  font-weight: 700;\n  line-height: 1;\n  text-align: center;\n  white-space: nowrap;\n  vertical-align: baseline;\n  border-radius: .25rem\n}\n\n.badge-primary[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #3f6ad8\n}\n\na.badge-primary[_ngcontent-%COMP%]:hover, a.badge-primary[_ngcontent-%COMP%]:focus {\n  color: #fff;\n  background-color: #2651be\n}\n\n.badge-success[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #3ac47d\n}\n\na.badge-success[_ngcontent-%COMP%]:hover, a.badge-success[_ngcontent-%COMP%]:focus {\n  color: #fff;\n  background-color: #2e9d64\n}\n\n.badge-warning[_ngcontent-%COMP%] {\n  color: #212529;\n  background-color: #f7b924\n}\n\na.badge-warning[_ngcontent-%COMP%]:hover, a.badge-warning[_ngcontent-%COMP%]:focus {\n  color: #212529;\n  background-color: #e0a008\n}\n\n.badge-danger[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #d92550\n}\n\na.badge-danger[_ngcontent-%COMP%]:hover, a.badge-danger[_ngcontent-%COMP%]:focus {\n  color: #fff;\n  background-color: #ad1e40\n}\n\na[_ngcontent-%COMP%], button[_ngcontent-%COMP%], .btn[_ngcontent-%COMP%] {\n  outline: none !important\n}\n\n.app-container[_ngcontent-%COMP%] {\n  display: flex;\n  min-height: 100vh;\n  flex-direction: column;\n  margin: 0\n}\n\n.icon-anim-pulse[_ngcontent-%COMP%] {\n  animation: pulse_animation;\n  animation-duration: 1000ms;\n  animation-iteration-count: infinite;\n  animation-timing-function: linear\n}\n\n.app-header[_ngcontent-%COMP%] {\n  height: 60px;\n  display: flex;\n  align-items: center;\n  align-content: center;\n  position: relative;\n  z-index: 10;\n  transition: all .2s\n}\n\n.app-header.header-shadow[_ngcontent-%COMP%] {\n  box-shadow: 0 0.46875rem 2.1875rem rgba(4, 9, 20, 0.03), 0 0.9375rem 1.40625rem rgba(4, 9, 20, 0.03), 0 0.25rem 0.53125rem rgba(4, 9, 20, 0.05), 0 0.125rem 0.1875rem rgba(4, 9, 20, 0.03)\n}\n\n.app-header[_ngcontent-%COMP%]   .app-header__content[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  align-content: center;\n  flex: 1;\n  padding: 0 1.5rem;\n  height: 60px\n}\n\n.app-header[_ngcontent-%COMP%]   .app-header__content[_ngcontent-%COMP%]   .app-header-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center\n}\n\n.app-header[_ngcontent-%COMP%]   .app-header__content[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  margin-left: auto\n}\n\n.app-header[_ngcontent-%COMP%]   .header-user-info[_ngcontent-%COMP%]    > .widget-heading[_ngcontent-%COMP%], .app-header[_ngcontent-%COMP%]   .header-user-info[_ngcontent-%COMP%]    > .widget-subheading[_ngcontent-%COMP%] {\n  white-space: nowrap\n}\n\n.app-header[_ngcontent-%COMP%]   .header-user-info[_ngcontent-%COMP%]    > .widget-subheading[_ngcontent-%COMP%] {\n  font-size: .8rem\n}\n\n.app-header__logo[_ngcontent-%COMP%] {\n  padding: 0 1.5rem;\n  height: 60px;\n  width: 280px;\n  display: flex;\n  align-items: center;\n  transition: width .2s\n}\n\n.app-header__logo[_ngcontent-%COMP%]   .logo-src[_ngcontent-%COMP%] {\n  height: 40px;\n  width: 115px;\n  background: url('gc-loogo-resized.png')\n}\n\n.app-header__menu[_ngcontent-%COMP%], .app-header__mobile-menu[_ngcontent-%COMP%] {\n  display: none;\n  padding: 0 1.5rem;\n  height: 60px;\n  align-items: center\n}\n\n.fixed-header[_ngcontent-%COMP%]   .app-header[_ngcontent-%COMP%] {\n  position: fixed;\n  width: 100%;\n  top: 0\n}\n\n.fixed-header[_ngcontent-%COMP%]   .app-header[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  visibility: visible\n}\n\n.fixed-header[_ngcontent-%COMP%]   .app-main[_ngcontent-%COMP%] {\n  padding-top: 60px\n}\n\n.fixed-header[_ngcontent-%COMP%]:not(.fixed-sidebar):not(.closed-sidebar)   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  visibility: hidden\n}\n\n.header-dots[_ngcontent-%COMP%] {\n  margin-left: auto;\n  display: flex\n}\n\n.header-dots[_ngcontent-%COMP%]    > .dropdown[_ngcontent-%COMP%] {\n  display: flex;\n  align-content: center\n}\n\n.header-dots[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%] {\n  margin: 0;\n  height: 44px;\n  width: 44px;\n  text-align: center;\n  overflow: visible\n}\n\n.header-dots[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .language-icon[_ngcontent-%COMP%] {\n  border-radius: 30px;\n  position: relative;\n  z-index: 4;\n  width: 32px;\n  height: 32px;\n  overflow: hidden;\n  margin: 0 auto\n}\n\n.header-dots[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .language-icon[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  position: relative;\n  top: 50%;\n  left: 50%;\n  margin: -22px 0 0 -20px\n}\n\n.header-dots[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .icon-wrapper-bg[_ngcontent-%COMP%] {\n  opacity: .1;\n  transition: opacity .2s;\n  border-radius: 40px\n}\n\n.header-dots[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  margin: 0 auto\n}\n\n@-moz-document url-prefix() {\n  .header-dots .icon-wrapper-alt svg {\n    width: 50%\n  }\n}\n\n.header-dots[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 1.3rem\n}\n\n.header-dots[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]:hover {\n  cursor: pointer\n}\n\n.header-dots[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]:hover   .icon-wrapper-bg[_ngcontent-%COMP%] {\n  opacity: .2\n}\n\n.header-dots[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .badge-dot[_ngcontent-%COMP%] {\n  top: 1px;\n  right: 1px;\n  border: 0\n}\n\n.header-btn-lg[_ngcontent-%COMP%] {\n  padding: 0 0 0 1.5rem;\n  margin-left: 1.5rem;\n  display: flex;\n  align-items: center;\n  position: relative\n}\n\n.header-btn-lg[_ngcontent-%COMP%]::before {\n  position: absolute;\n  left: -1px;\n  top: 50%;\n  background: #dee2e6;\n  width: 1px;\n  height: 30px;\n  margin-top: -15px;\n  content: ''\n}\n\n.header-btn-lg[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .header-btn-lg[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::before, .header-btn-lg[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::after {\n  background: #6c757d\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header-left[_ngcontent-%COMP%]    > .nav[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > .nav-link[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.7)\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header-left[_ngcontent-%COMP%]    > .nav[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > .nav-link[_ngcontent-%COMP%]   .nav-link-icon[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.8)\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header-left[_ngcontent-%COMP%]    > .nav[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > .nav-link[_ngcontent-%COMP%]:hover {\n  color: #fff\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .fa[_ngcontent-%COMP%], .app-header.header-text-light[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.7) !important;\n  transition: all .2s\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .icon-wrapper-bg[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.1) !important;\n  transition: all .2s;\n  opacity: 1\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]:hover   .fa[_ngcontent-%COMP%], .app-header.header-text-light[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]:hover   .icon[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.9) !important\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]:hover   .icon-wrapper-bg[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.15) !important\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .badge-dot[_ngcontent-%COMP%] {\n  border-color: transparent\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]    > .header-btn-lg[_ngcontent-%COMP%]   .widget-content-left[_ngcontent-%COMP%]   .btn-group[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%], .app-header.header-text-light[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]    > .header-btn-lg[_ngcontent-%COMP%]   .widget-heading[_ngcontent-%COMP%], .app-header.header-text-light[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]    > .header-btn-lg[_ngcontent-%COMP%]   .widget-subheading[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.8)\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]    > .header-btn-lg[_ngcontent-%COMP%]   .header-user-info[_ngcontent-%COMP%]    > .btn-shadow[_ngcontent-%COMP%] {\n  box-shadow: 0 0.125rem 0.625rem rgba(0, 0, 0, 0.1), 0 0.0625rem 0.125rem rgba(0, 0, 0, 0.2)\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0.1)\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::placeholder, .app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::-webkit-input-placeholder, .app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]:-ms-input-placeholder, .app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]:-moz-placeholder, .app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::-moz-placeholder {\n  color: rgba(255, 255, 255, 0.5) !important\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper.active[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.1)\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper.active[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.8)\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper.active[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.1)\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]::before {\n  background: rgba(255, 255, 255, 0.2)\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .app-header.header-text-light[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]   .hamburger.is-active[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .app-header.header-text-light[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::before, .app-header.header-text-light[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::after, .app-header.header-text-light[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .app-header.header-text-light[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%]   .hamburger.is-active[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .app-header.header-text-light[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::before, .app-header.header-text-light[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::after {\n  background-color: rgba(255, 255, 255, 0.8) !important\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]::after {\n  border-color: rgba(255, 255, 255, 0.8)\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .close[_ngcontent-%COMP%]::before, .app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .close[_ngcontent-%COMP%]::after, .app-header.header-text-light[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]::before {\n  background: rgba(255, 255, 255, 0.8)\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .logo-src[_ngcontent-%COMP%] {\n  background: url('logo.png')\n}\n\n.app-header.header-text-light[_ngcontent-%COMP%]   .app-header__mobile-menu[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .app-header.header-text-light[_ngcontent-%COMP%]   .app-header__mobile-menu[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::before, .app-header.header-text-light[_ngcontent-%COMP%]   .app-header__mobile-menu[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::after {\n  background: rgba(255, 255, 255, 0.9)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-left[_ngcontent-%COMP%]    > .nav[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > .nav-link[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.7)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-left[_ngcontent-%COMP%]    > .nav[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > .nav-link[_ngcontent-%COMP%]   .nav-link-icon[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.8)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-left[_ngcontent-%COMP%]    > .nav[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > .nav-link[_ngcontent-%COMP%]:hover {\n  color: #000\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .fa[_ngcontent-%COMP%], .app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.7) !important;\n  transition: all .2s\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .icon-wrapper-bg[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0.1) !important;\n  transition: all .2s;\n  opacity: 1\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]:hover   .fa[_ngcontent-%COMP%], .app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]:hover   .icon[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.95) !important\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]:hover   .icon-wrapper-bg[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0.15) !important\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]   .icon-wrapper-alt[_ngcontent-%COMP%]   .badge-dot[_ngcontent-%COMP%] {\n  border-color: transparent\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]    > .header-btn-lg[_ngcontent-%COMP%]   .widget-content-left[_ngcontent-%COMP%]   .btn-group[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%], .app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]    > .header-btn-lg[_ngcontent-%COMP%]   .widget-heading[_ngcontent-%COMP%], .app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]    > .header-btn-lg[_ngcontent-%COMP%]   .widget-subheading[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.8)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .app-header-right[_ngcontent-%COMP%]    > .header-btn-lg[_ngcontent-%COMP%]   .header-user-info[_ngcontent-%COMP%]    > .btn-shadow[_ngcontent-%COMP%] {\n  box-shadow: 0 0.125rem 0.625rem rgba(0, 0, 0, 0.1), 0 0.0625rem 0.125rem rgba(0, 0, 0, 0.2)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0.1)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .search-wrapper.active[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0.1)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .search-wrapper.active[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.8)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .search-wrapper.active[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0.1)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]::before {\n  background: rgba(0, 0, 0, 0.2)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .app-header.header-text-dark[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]   .hamburger.is-active[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .app-header.header-text-dark[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::before, .app-header.header-text-dark[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::after, .app-header.header-text-dark[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .app-header.header-text-dark[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%]   .hamburger.is-active[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .app-header.header-text-dark[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::before, .app-header.header-text-dark[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::after {\n  background-color: rgba(0, 0, 0, 0.8) !important\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]::after {\n  border-color: rgba(0, 0, 0, 0.8)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .close[_ngcontent-%COMP%]::before, .app-header.header-text-dark[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .close[_ngcontent-%COMP%]::after, .app-header.header-text-dark[_ngcontent-%COMP%]   .search-wrapper[_ngcontent-%COMP%]   .input-holder[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]::before {\n  background: rgba(0, 0, 0, 0.8)\n}\n\n.app-header.header-text-dark[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .logo-src[_ngcontent-%COMP%] {\n  background: url('logo-inverse.png')\n}\n\n.app-sidebar[_ngcontent-%COMP%] {\n  width: 280px;\n  display: flex;\n  z-index: 11;\n  overflow: hidden;\n  min-width: 280px;\n  position: relative;\n  flex: 0 0 280px;\n  margin-top: -60px;\n  padding-top: 60px;\n  transition: all .2s\n}\n\n.app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%] {\n  padding: 2px 1.5rem 1.5rem\n}\n\n.app-sidebar[_ngcontent-%COMP%]   .scrollbar-sidebar[_ngcontent-%COMP%] {\n  z-index: 15;\n  width: 100%\n}\n\n.app-sidebar[_ngcontent-%COMP%]   .app-sidebar-bg[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 0;\n  top: 0;\n  height: 100%;\n  width: 100%;\n  opacity: 0.05;\n  background-size: cover;\n  z-index: 10\n}\n\n.app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 0;\n  top: 0;\n  display: none;\n  z-index: 11\n}\n\n.app-sidebar.sidebar-shadow[_ngcontent-%COMP%] {\n  box-shadow: 7px 0 60px rgba(0, 0, 0, 0.05)\n}\n\n.app-sidebar__heading[_ngcontent-%COMP%] {\n  text-transform: uppercase;\n  font-size: .8rem;\n  margin: .75rem 0;\n  font-weight: bold;\n  color: #3f6ad8;\n  white-space: nowrap;\n  position: relative\n}\n\n.sidebar-mobile-overlay[_ngcontent-%COMP%] {\n  display: none;\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  background: #333;\n  opacity: .6;\n  left: 0;\n  top: 0;\n  z-index: 12\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 0;\n  position: relative;\n  list-style: none\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]::after {\n  content: \" \";\n  pointer-events: none;\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  top: 0\n}\n\n\n.vertical-nav-menu[_ngcontent-%COMP%]:before {\n  opacity: 0;\n  transition: opacity 300ms\n}\n\n\n.vertical-nav-menu[_ngcontent-%COMP%]   .mm-collapse[_ngcontent-%COMP%]:not(.mm-show) {\n  display: none\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   .mm-collapsing[_ngcontent-%COMP%] {\n  position: relative;\n  height: 0;\n  overflow: hidden;\n  transition-timing-function: ease;\n  transition-duration: .25s;\n  transition-property: height, visibility\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 0;\n  position: relative;\n  list-style: none\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: block;\n  line-height: 2.4rem;\n  height: 2.4rem;\n  padding: 0 1.5rem 0 45px;\n  position: relative;\n  border-radius: .25rem;\n  color: #343a40;\n  white-space: nowrap;\n  transition: all .2s;\n  margin: .1rem 0\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background: #e0f3ff;\n  text-decoration: none\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover   i.metismenu-icon[_ngcontent-%COMP%] {\n  opacity: .6\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover   i.metismenu-state-icon[_ngcontent-%COMP%] {\n  opacity: 1\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   li.mm-active[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   li.mm-active[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%]   i.metismenu-state-icon[_ngcontent-%COMP%] {\n  transform: rotate(-180deg)\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a.mm-active[_ngcontent-%COMP%] {\n  color: #3f6ad8;\n  background: #e0f3ff;\n  font-weight: bold\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   i.metismenu-state-icon[_ngcontent-%COMP%], .vertical-nav-menu[_ngcontent-%COMP%]   i.metismenu-icon[_ngcontent-%COMP%] {\n  text-align: center;\n  width: 34px;\n  height: 34px;\n  line-height: 34px;\n  position: absolute;\n  left: 5px;\n  top: 50%;\n  margin-top: -17px;\n  font-size: 1.5rem;\n  opacity: .3;\n  transition: color 300ms\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   i.metismenu-state-icon[_ngcontent-%COMP%] {\n  transition: transform 300ms;\n  left: auto;\n  right: 0\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  transition: padding 300ms;\n  padding: .5em 0 0 2rem\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]:before {\n  content: '';\n  height: 100%;\n  opacity: 1;\n  width: 3px;\n  background: #e0f3ff;\n  position: absolute;\n  left: 20px;\n  top: 0;\n  border-radius: 15px\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%] {\n  color: #6c757d;\n  height: 2rem;\n  line-height: 2rem;\n  padding: 0 1.5rem 0\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%]:hover {\n  color: #3f6ad8\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%]   .metismenu-icon[_ngcontent-%COMP%] {\n  display: none\n}\n\n.vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a.mm-active[_ngcontent-%COMP%] {\n  color: #3f6ad8;\n  background: #e0f3ff;\n  font-weight: bold\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%] {\n  border-right: 0 !important\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .app-sidebar__heading[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.6)\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .app-sidebar__heading[_ngcontent-%COMP%]::before {\n  background: rgba(255, 255, 255, 0.5) !important\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.7)\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   i.metismenu-icon[_ngcontent-%COMP%] {\n  opacity: .5\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   i.metismenu-state-icon[_ngcontent-%COMP%] {\n  opacity: .5\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background: rgba(255, 255, 255, 0.15);\n  color: #fff\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover   i.metismenu-icon[_ngcontent-%COMP%] {\n  opacity: .8\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover   i.metismenu-state-icon[_ngcontent-%COMP%] {\n  opacity: 1\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a.mm-active[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.7);\n  background: rgba(255, 255, 255, 0.15)\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]:before {\n  background: rgba(255, 255, 255, 0.1)\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.6)\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%]:hover {\n  color: #fff\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a.mm-active[_ngcontent-%COMP%] {\n  color: #fff;\n  background: rgba(255, 255, 255, 0.15)\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .ps__thumb-y[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.3)\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .ps__rail-y[_ngcontent-%COMP%]:hover   .ps__thumb-y[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.2)\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .logo-src[_ngcontent-%COMP%] {\n  background: url('logo.png')\n}\n\n.app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::before, .app-sidebar.sidebar-text-light[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::after {\n  background-color: rgba(255, 255, 255, 0.8)\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%] {\n  border-right: 0 !important\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .app-sidebar__heading[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.6)\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .app-sidebar__heading[_ngcontent-%COMP%]::before {\n  background: rgba(0, 0, 0, 0.5) !important\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.6)\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   i.metismenu-icon[_ngcontent-%COMP%] {\n  opacity: .5\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   i.metismenu-state-icon[_ngcontent-%COMP%] {\n  opacity: .5\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background: rgba(0, 0, 0, 0.15);\n  color: rgba(0, 0, 0, 0.7)\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover   i.metismenu-icon[_ngcontent-%COMP%] {\n  opacity: .7\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover   i.metismenu-state-icon[_ngcontent-%COMP%] {\n  opacity: 1\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a.mm-active[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.7);\n  background: rgba(0, 0, 0, 0.15)\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]:before {\n  background: rgba(0, 0, 0, 0.1)\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.4)\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%]:hover {\n  color: rgba(0, 0, 0, 0.7)\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .vertical-nav-menu[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a.mm-active[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.7);\n  background: rgba(0, 0, 0, 0.15)\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .ps__thumb-y[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0.3)\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .ps__rail-y[_ngcontent-%COMP%]:hover   .ps__thumb-y[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0.2)\n}\n\n.app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::before, .app-sidebar.sidebar-text-dark[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::after {\n  background-color: rgba(0, 0, 0, 0.8)\n}\n\n.fixed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%] {\n  position: fixed;\n  height: 100vh\n}\n\n.fixed-sidebar[_ngcontent-%COMP%]   .app-main[_ngcontent-%COMP%]   .app-main__outer[_ngcontent-%COMP%] {\n  z-index: 9;\n  padding-left: 280px\n}\n\n.fixed-sidebar.fixed-header[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  display: none\n}\n\n.fixed-sidebar[_ngcontent-%COMP%]:not(.fixed-header)   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  display: flex\n}\n\n.fixed-sidebar[_ngcontent-%COMP%]:not(.fixed-header)   .app-header[_ngcontent-%COMP%] {\n  margin-left: 280px\n}\n\n.fixed-sidebar[_ngcontent-%COMP%]:not(.fixed-header)   .app-header[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  display: none\n}\n\n.fixed-sidebar.closed-sidebar[_ngcontent-%COMP%]:not(.fixed-header)   .app-header[_ngcontent-%COMP%] {\n  margin-left: 80px\n}\n\n.fixed-sidebar.closed-sidebar[_ngcontent-%COMP%]:not(.fixed-header)   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  width: 80px;\n  padding: 0\n}\n\n.fixed-sidebar.closed-sidebar[_ngcontent-%COMP%]:not(.fixed-header)   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .logo-src[_ngcontent-%COMP%] {\n  display: none\n}\n\n.fixed-sidebar.closed-sidebar[_ngcontent-%COMP%]:not(.fixed-header)   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%] {\n  margin-right: auto\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%] {\n  transition: all .3s ease;\n  width: 80px;\n  min-width: 80px;\n  flex: 0 0 80px;\n  z-index: 13\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   .app-sidebar__heading[_ngcontent-%COMP%] {\n  text-indent: -999em\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   .app-sidebar__heading[_ngcontent-%COMP%]::before {\n  content: '';\n  position: absolute;\n  top: 50%;\n  left: 0;\n  width: 100%;\n  height: 1px;\n  background: #e0f3ff;\n  text-indent: 1px\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  text-indent: -99rem;\n  padding: 0\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   .metismenu-icon[_ngcontent-%COMP%] {\n  text-indent: 0;\n  left: 50%;\n  margin-left: -17px\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   .metismenu-state-icon[_ngcontent-%COMP%] {\n  visibility: hidden\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]::before {\n  display: none\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   ul.mm-show[_ngcontent-%COMP%] {\n  padding: 0\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   ul.mm-show[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%] {\n  height: 0\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover {\n  flex: 0 0 280px !important;\n  width: 280px !important\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover   .app-sidebar__inner[_ngcontent-%COMP%]   .app-sidebar__heading[_ngcontent-%COMP%] {\n  text-indent: initial\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover   .app-sidebar__inner[_ngcontent-%COMP%]   .app-sidebar__heading[_ngcontent-%COMP%]::before {\n  display: none\n}\n\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover   .app-sidebar__inner[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]::before {\n  display: block\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover   .app-sidebar__inner[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  text-indent: initial;\n  padding: 0 1.5rem 0 45px\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover   .app-sidebar__inner[_ngcontent-%COMP%]   .metismenu-icon[_ngcontent-%COMP%] {\n  text-indent: initial;\n  left: 5px;\n  margin-left: 0\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover   .app-sidebar__inner[_ngcontent-%COMP%]   .metismenu-state-icon[_ngcontent-%COMP%] {\n  visibility: visible\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover   .app-sidebar__inner[_ngcontent-%COMP%]   ul.mm-show[_ngcontent-%COMP%] {\n  padding: .5em 0 0 2rem\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover   .app-sidebar__inner[_ngcontent-%COMP%]   ul.mm-show[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%] {\n  height: 2.3em\n}\n\n.closed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover   .app-sidebar__inner[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  padding-left: 1em\n}\n\n.closed-sidebar[_ngcontent-%COMP%]:not(.sidebar-mobile-open)   .app-sidebar[_ngcontent-%COMP%]   .scrollbar-sidebar[_ngcontent-%COMP%] {\n  position: static;\n  height: auto;\n  overflow: initial !important\n}\n\n.closed-sidebar[_ngcontent-%COMP%]:not(.sidebar-mobile-open)   .app-sidebar[_ngcontent-%COMP%]:hover   .scrollbar-sidebar[_ngcontent-%COMP%] {\n  position: absolute;\n  height: 100%;\n  overflow: hidden !important\n}\n\n.closed-sidebar[_ngcontent-%COMP%]:not(.closed-sidebar-mobile)   .app-header[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  width: 80px\n}\n\n.closed-sidebar[_ngcontent-%COMP%]:not(.closed-sidebar-mobile)   .app-header[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .logo-src[_ngcontent-%COMP%] {\n  display: none\n}\n\n.closed-sidebar[_ngcontent-%COMP%]:not(.closed-sidebar-mobile)   .app-header[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%] {\n  margin-right: auto\n}\n\n.closed-sidebar.fixed-sidebar[_ngcontent-%COMP%]   .app-main__outer[_ngcontent-%COMP%] {\n  padding-left: 80px\n}\n\n.closed-sidebar.fixed-header[_ngcontent-%COMP%]:not(.fixed-sidebar)   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  visibility: hidden\n}\n\n.closed-sidebar.closed-sidebar-mobile[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%], .closed-sidebar.closed-sidebar-mobile[_ngcontent-%COMP%]   .app-header[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  width: auto;\n  display: flex\n}\n\n.closed-sidebar.closed-sidebar-mobile[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%], .closed-sidebar.closed-sidebar-mobile[_ngcontent-%COMP%]   .app-header[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%] {\n  display: none\n}\n\n.closed-sidebar.closed-sidebar-mobile[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  display: flex;\n  width: 80px;\n  padding: 0 1.5rem !important\n}\n\n.closed-sidebar.closed-sidebar-mobile[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .logo-src[_ngcontent-%COMP%] {\n  display: block !important;\n  margin: 0 auto;\n  width: 21px\n}\n\n.closed-sidebar.closed-sidebar-mobile[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .header__pane[_ngcontent-%COMP%] {\n  display: none\n}\n\n.closed-sidebar.closed-sidebar-mobile[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover   .app-header__logo[_ngcontent-%COMP%] {\n  width: 280px\n\n}\n\n.closed-sidebar.closed-sidebar-mobile[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]:hover   .app-header__logo[_ngcontent-%COMP%]   .logo-src[_ngcontent-%COMP%] {\n  width: 97px;\n  margin: 0\n}\n\n.closed-sidebar.closed-sidebar-mobile[_ngcontent-%COMP%]   .app-header[_ngcontent-%COMP%] {\n  margin-left: 0 !important\n}\n\n.closed-sidebar.fixed-footer[_ngcontent-%COMP%]   .app-footer__inner[_ngcontent-%COMP%] {\n  margin-left: 0 !important\n}\n\n.app-main[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  z-index: 8;\n  position: relative\n}\n\n.app-main[_ngcontent-%COMP%]   .app-main__outer[_ngcontent-%COMP%] {\n  flex: 1;\n  flex-direction: column;\n  display: flex;\n  z-index: 12\n}\n\n.app-main[_ngcontent-%COMP%]   .app-main__inner[_ngcontent-%COMP%] {\n  padding: 30px 30px 0;\n  flex: 1\n}\n\n.app-theme-white.app-container[_ngcontent-%COMP%] {\n  background: #f1f4f6\n}\n\n.app-theme-white[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%] {\n  background: #fff\n}\n\n.app-theme-white[_ngcontent-%COMP%]   .app-page-title[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.45)\n}\n\n.app-theme-white[_ngcontent-%COMP%]   .app-footer[_ngcontent-%COMP%]   .app-footer__inner[_ngcontent-%COMP%], .app-theme-white[_ngcontent-%COMP%]   .app-header[_ngcontent-%COMP%] {\n  background: #fafbfc\n}\n\n.app-theme-white.fixed-header[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  background: rgba(250, 251, 252, 0.1)\n}\n\n.app-theme-gray.app-container[_ngcontent-%COMP%] {\n  background: #fff\n}\n\n.app-theme-gray[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%] {\n  background: #fff;\n  border-right: #dee2e6 solid 1px\n}\n\n.app-theme-gray[_ngcontent-%COMP%]   .app-page-title[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0.03)\n}\n\n.app-theme-gray[_ngcontent-%COMP%]   .app-footer[_ngcontent-%COMP%], .app-theme-gray[_ngcontent-%COMP%]   .app-header[_ngcontent-%COMP%] {\n  background: #f8f9fa\n}\n\n.app-theme-gray[_ngcontent-%COMP%]   .app-footer[_ngcontent-%COMP%] {\n  border-top: #dee2e6 solid 1px\n}\n\n.app-theme-gray[_ngcontent-%COMP%]   .app-header[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  border-right: rgba(0, 0, 0, 0.1) solid 1px\n}\n\n.app-theme-gray.fixed-header[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0.03)\n}\n\n.app-theme-gray[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%] {\n  border-width: 1px\n}\n\n.app-theme-gray[_ngcontent-%COMP%]   .main-card[_ngcontent-%COMP%] {\n  box-shadow: 0 0 0 0 transparent !important\n}\n\n.app-theme-gray[_ngcontent-%COMP%]   .main-card[_ngcontent-%COMP%]    > .card-body[_ngcontent-%COMP%]    > .card-title[_ngcontent-%COMP%] {\n  text-transform: none;\n  font-size: 1.1rem;\n  font-weight: normal;\n  border-bottom: #dee2e6 solid 1px;\n  position: relative;\n  padding: 0 0 1.125rem;\n  margin: 0 0 1.125rem\n}\n\n.app-theme-gray[_ngcontent-%COMP%]   .main-card[_ngcontent-%COMP%]    > .card-body[_ngcontent-%COMP%]    > .card-title[_ngcontent-%COMP%]::before {\n  position: absolute;\n  width: 40px;\n  background: #3f6ad8;\n  border-radius: 30px;\n  height: 5px;\n  left: 0;\n  bottom: -2px;\n  content: \"\"\n}\n\n.app-theme-gray[_ngcontent-%COMP%]   .app-inner-layout__sidebar[_ngcontent-%COMP%] {\n  border-left: 0 !important\n}\n\n.fixed-footer[_ngcontent-%COMP%]   .app-footer[_ngcontent-%COMP%] {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  left: 0;\n  z-index: 7\n}\n\n.fixed-footer[_ngcontent-%COMP%]   .app-footer[_ngcontent-%COMP%]   .app-footer__inner[_ngcontent-%COMP%] {\n  margin-left: 280px;\n  box-shadow: 0.3rem -0.46875rem 2.1875rem rgba(4, 9, 20, 0.02), 0.3rem -0.9375rem 1.40625rem rgba(4, 9, 20, 0.02), 0.3rem -0.25rem 0.53125rem rgba(4, 9, 20, 0.04), 0.3rem -0.125rem 0.1875rem rgba(4, 9, 20, 0.02)\n}\n\n.fixed-footer[_ngcontent-%COMP%]   .app-main[_ngcontent-%COMP%]   .app-main__outer[_ngcontent-%COMP%] {\n  padding-bottom: 60px\n}\n\n.app-page-title[_ngcontent-%COMP%] {\n  padding: 30px;\n  margin: -30px -30px 30px;\n  position: relative\n}\n\n.app-page-title[_ngcontent-%COMP%]    + .body-tabs-layout[_ngcontent-%COMP%] {\n  margin-top: -30px !important\n}\n\n.app-page-title[_ngcontent-%COMP%]   .page-title-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  align-items: center\n}\n\n.app-page-title[_ngcontent-%COMP%]   .page-title-heading[_ngcontent-%COMP%], .app-page-title[_ngcontent-%COMP%]   .page-title-subheading[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 0\n}\n\n.app-page-title[_ngcontent-%COMP%]   .page-title-heading[_ngcontent-%COMP%] {\n  font-size: 1.25rem;\n  font-weight: 400;\n  display: flex;\n  align-content: center;\n  align-items: center\n}\n\n.app-page-title[_ngcontent-%COMP%]   .page-title-subheading[_ngcontent-%COMP%] {\n  padding: 3px 0 0;\n  font-size: .88rem;\n  opacity: .6\n}\n\n.app-page-title[_ngcontent-%COMP%]   .page-title-subheading[_ngcontent-%COMP%]   .breadcrumb[_ngcontent-%COMP%] {\n  padding: 0;\n  margin: 3px 0 0;\n  background: transparent\n}\n\n.app-page-title[_ngcontent-%COMP%]   .page-title-actions[_ngcontent-%COMP%] {\n  margin-left: auto\n}\n\n.app-page-title[_ngcontent-%COMP%]   .page-title-actions[_ngcontent-%COMP%]   .breadcrumb[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 0;\n  background: transparent\n}\n\n.app-page-title[_ngcontent-%COMP%]   .page-title-icon[_ngcontent-%COMP%] {\n  font-size: 2rem;\n  display: flex;\n  align-items: center;\n  align-content: center;\n  text-align: center;\n  padding: .83333rem;\n  margin: 0 30px 0 0;\n  background: #fff;\n  box-shadow: 0 0.46875rem 2.1875rem rgba(4, 9, 20, 0.03), 0 0.9375rem 1.40625rem rgba(4, 9, 20, 0.03), 0 0.25rem 0.53125rem rgba(4, 9, 20, 0.05), 0 0.125rem 0.1875rem rgba(4, 9, 20, 0.03);\n  border-radius: .25rem;\n  width: 60px;\n  height: 60px\n}\n\n.app-page-title[_ngcontent-%COMP%]   .page-title-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  margin: auto\n}\n\n.app-page-title[_ngcontent-%COMP%]   .page-title-icon.rounded-circle[_ngcontent-%COMP%] {\n  margin: 0 20px 0 0\n}\n\n.app-page-title[_ngcontent-%COMP%]    + .RRT__container[_ngcontent-%COMP%] {\n  margin-top: -23.07692px\n}\n\n.app-page-title.app-page-title-simple[_ngcontent-%COMP%] {\n  margin: 0;\n  background: none !important;\n  padding-left: 0;\n  padding-right: 0;\n  padding-top: 0\n}\n\n.page-title-icon-rounded[_ngcontent-%COMP%]   .page-title-icon[_ngcontent-%COMP%] {\n  border-radius: 50px\n}\n\nbody[_ngcontent-%COMP%] {\n  -webkit-backface-visibility: hidden\n}\n\n.dropdown-menu.show[_ngcontent-%COMP%] {\n  animation: fade-in2 0.2s cubic-bezier(0.39, 0.575, 0.565, 1) both\n}\n\n.popover[_ngcontent-%COMP%]:not([data-placement^=\"top\"]).show {\n  animation: fade-in2 0.2s cubic-bezier(0.39, 0.575, 0.565, 1) both\n}\n\n.dropdown-menu[data-placement^=\"top\"].show[_ngcontent-%COMP%] {\n  animation: fade-in3 0.2s cubic-bezier(0.39, 0.575, 0.565, 1) both;\n  bottom: auto !important;\n  top: auto !important\n}\n\n.dropdown-menu[_ngcontent-%COMP%] {\n  box-shadow: 0 0.46875rem 2.1875rem rgba(4, 9, 20, 0.03), 0 0.9375rem 1.40625rem rgba(4, 9, 20, 0.03), 0 0.25rem 0.53125rem rgba(4, 9, 20, 0.05), 0 0.125rem 0.1875rem rgba(4, 9, 20, 0.03);\n  margin: .125rem\n}\n\n.dropdown-menu.dropdown-menu-right[_ngcontent-%COMP%] {\n  right: 0 !important\n}\n\n.dropdown-menu[_ngcontent-%COMP%]   .dropdown-header[_ngcontent-%COMP%] {\n  text-transform: uppercase;\n  font-size: .73333rem;\n  color: #3f6ad8;\n  font-weight: bold\n}\n\n.dropdown-menu[_ngcontent-%COMP%]   .dropdown-item[_ngcontent-%COMP%] {\n  font-size: .88rem;\n  display: flex;\n  align-items: center;\n  transition: background-color 0.3s ease, color 0.3s ease;\n  cursor: pointer;\n  z-index: 6;\n  position: relative\n}\n\n.dropdown-menu[_ngcontent-%COMP%]   .dropdown-item[_ngcontent-%COMP%]   .dropdown-icon[_ngcontent-%COMP%] {\n  font-size: 1rem;\n  margin-right: .325rem;\n  width: 30px;\n  text-align: center;\n  opacity: .3;\n  margin-left: -10px\n}\n\n.dropdown-menu[_ngcontent-%COMP%]   .dropdown-item[_ngcontent-%COMP%]:hover   .dropdown-icon[_ngcontent-%COMP%] {\n  opacity: .7\n}\n\n.dropdown-menu.dropdown-menu-shadow[_ngcontent-%COMP%] {\n  box-shadow: 0 0.66875rem 2.3875rem rgba(4, 9, 20, 0.03), 0 1.1375rem 1.60625rem rgba(4, 9, 20, 0.03), 0 0.45rem 0.73125rem rgba(4, 9, 20, 0.05), 0 0.325rem 0.3875rem rgba(4, 9, 20, 0.03)\n}\n\n.dropdown-menu-rounded[_ngcontent-%COMP%] {\n  border-radius: 10px;\n  padding: .65rem\n}\n\n.dropdown-menu-rounded[_ngcontent-%COMP%]   .dropdown-item[_ngcontent-%COMP%] {\n  border-radius: 30px\n}\n\n.dropdown-menu-rounded[_ngcontent-%COMP%]   .dropdown-divider[_ngcontent-%COMP%] {\n  margin-left: -.65rem;\n  margin-right: -.65rem\n}\n\n.dropdown-menu-rounded[_ngcontent-%COMP%]   .dropdown-menu-header[_ngcontent-%COMP%] {\n  margin-left: -.65rem;\n  margin-right: -.65rem;\n  border-top-left-radius: 10px;\n  border-top-right-radius: 10px\n}\n\n.dropdown-menu-rounded[_ngcontent-%COMP%]   .menu-header-image[_ngcontent-%COMP%], .dropdown-menu-rounded[_ngcontent-%COMP%]   .dropdown-menu-header-inner[_ngcontent-%COMP%] {\n  border-top-left-radius: 10px;\n  border-top-right-radius: 10px\n}\n\n.dropdown-menu-hover-link[_ngcontent-%COMP%]   .dropdown-item[_ngcontent-%COMP%]:hover {\n  background: none;\n  color: #3f6ad8\n}\n\n.dropdown-menu-hover-primary[_ngcontent-%COMP%]   .dropdown-item[_ngcontent-%COMP%]:hover {\n  background: #3f6ad8;\n  color: #fff\n}\n\n.dropdown-menu.dropdown-menu-lg[_ngcontent-%COMP%] {\n  min-width: 22rem\n}\n\n.dropdown-menu.dropdown-menu-xl[_ngcontent-%COMP%] {\n  min-width: 25rem\n}\n\n.dropdown-menu[_ngcontent-%COMP%]   .dropdown-menu-header[_ngcontent-%COMP%], .dropdown-menu[_ngcontent-%COMP%]   .menu-header-image[_ngcontent-%COMP%], .dropdown-menu[_ngcontent-%COMP%]   .dropdown-menu-header-inner[_ngcontent-%COMP%] {\n  border-top-left-radius: .25rem;\n  border-top-right-radius: .25rem\n}\n\n.dropdown-menu-header[_ngcontent-%COMP%] {\n  color: #fff;\n  margin-top: -.65rem;\n  margin-bottom: .65rem;\n  position: relative;\n  z-index: 6\n}\n\n.dropdown-menu-header[_ngcontent-%COMP%]   .dropdown-menu-header-inner[_ngcontent-%COMP%] {\n  margin: -1px -1px 0;\n  padding: 1.5rem .5rem;\n  position: relative\n}\n\n.dropdown-menu-header[_ngcontent-%COMP%]   .menu-header-image[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 0;\n  top: 0;\n  height: 100%;\n  width: 100%;\n  z-index: 8;\n  opacity: .25;\n  filter: grayscale(80%);\n  background-size: cover\n}\n\n.dropdown-menu-header[_ngcontent-%COMP%]   .menu-header-content[_ngcontent-%COMP%] {\n  text-align: center;\n  position: relative;\n  z-index: 10\n}\n\n.dropdown-menu-header[_ngcontent-%COMP%]   .menu-header-content.text-left[_ngcontent-%COMP%] {\n  padding-left: .5rem\n}\n\n.dropdown-menu-header[_ngcontent-%COMP%]   .menu-header-content.btn-pane-right[_ngcontent-%COMP%] {\n  padding-left: .5rem;\n  padding-right: .5rem;\n  display: flex;\n  align-content: center;\n  align-items: center;\n  text-align: left\n}\n\n.dropdown-menu-header[_ngcontent-%COMP%]   .menu-header-content.btn-pane-right[_ngcontent-%COMP%]   .menu-header-btn-pane[_ngcontent-%COMP%] {\n  margin: 0 0 0 auto\n}\n\n.dropdown-menu-header[_ngcontent-%COMP%]   .menu-header-content[_ngcontent-%COMP%]   .menu-header-btn-pane[_ngcontent-%COMP%] {\n  margin-top: 10px;\n  margin-bottom: 3px\n}\n\n.dropdown-menu-header[_ngcontent-%COMP%]    + .grid-menu[_ngcontent-%COMP%] {\n  margin-top: -.65rem\n}\n\n.menu-header-title[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 1.25rem;\n  margin: 0\n}\n\n.menu-header-subtitle[_ngcontent-%COMP%] {\n  \n  margin: 5px 0 0;\n  opacity: .8\n}\n\n.dropdown-menu[_ngcontent-%COMP%]   .grid-menu[_ngcontent-%COMP%] {\n  margin-bottom: -.65rem;\n  padding: 1px\n}\n\n.dropdown-menu[_ngcontent-%COMP%]   .grid-menu[_ngcontent-%COMP%]   [class*=\"col-\"][_ngcontent-%COMP%] {\n  padding: .65rem\n}\n\n.dropdown-menu[_ngcontent-%COMP%]   .grid-menu-xl[_ngcontent-%COMP%] {\n  margin-bottom: -.48148rem\n}\n\n.dropdown-menu[_ngcontent-%COMP%]   .grid-menu-xl[_ngcontent-%COMP%]   [class*=\"col-\"][_ngcontent-%COMP%] {\n  padding: 0\n}\n\n.dropdown-toggle[_ngcontent-%COMP%]::after {\n  position: relative;\n  top: 2px;\n  opacity: .8;\n  margin-left: 5px\n}\n\n.dropdown-toggle-split[_ngcontent-%COMP%]::after {\n  margin-left: 0\n}\n\nbody[_ngcontent-%COMP%]   .dropdown-menu.dropdown-menu-inline[_ngcontent-%COMP%] {\n  border: 0;\n  position: static !important;\n  box-shadow: 0 0 0 transparent;\n  background: transparent;\n  border-radius: 0;\n  display: inline-block;\n  float: none;\n  left: 0 !important;\n  top: 0 !important;\n  width: 100% !important;\n  transform: translateY(0) !important\n}\n\nbody[_ngcontent-%COMP%]   .dropdown-menu.dropdown-menu-inline[_ngcontent-%COMP%]::before, body[_ngcontent-%COMP%]   .dropdown-menu.dropdown-menu-inline[_ngcontent-%COMP%]::after {\n  display: none\n}\n\n.nav-item[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n  font-weight: normal\n}\n\n.nav-link[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  transition: background-color 0.3s ease, color 0.3s ease;\n  cursor: pointer\n}\n\n.nav-link[_ngcontent-%COMP%]   .nav-link-icon[_ngcontent-%COMP%] {\n  color: #3f6ad8;\n  font-size: 1rem;\n  width: 30px;\n  text-align: center;\n  opacity: .45;\n  margin-left: -10px\n}\n\n.nav-link[_ngcontent-%COMP%]:hover {\n  color: #495057\n}\n\n.nav-link[_ngcontent-%COMP%]:hover   .nav-link-icon[_ngcontent-%COMP%] {\n  opacity: .9;\n  color: #3f6ad8\n}\n\n.nav-link[_ngcontent-%COMP%]:disabled   .nav-link-icon[_ngcontent-%COMP%], .nav-link.disabled[_ngcontent-%COMP%]   .nav-link-icon[_ngcontent-%COMP%] {\n  opacity: .3\n}\n\n.nav-item.nav-item-header[_ngcontent-%COMP%] {\n  text-transform: uppercase;\n  font-size: .73333rem;\n  color: #6c757d;\n  font-weight: bold;\n  padding: .5rem 1rem\n}\n\n.nav-item.nav-item-btn[_ngcontent-%COMP%] {\n  padding: .5rem 1rem\n}\n\n.nav-item.nav-item-divider[_ngcontent-%COMP%] {\n  margin: .5rem 0;\n  height: 1px;\n  overflow: hidden;\n  background: #dee2e6\n}\n\n.nav[_ngcontent-%COMP%]   .badge[_ngcontent-%COMP%] {\n  margin-left: 8px\n}\n\n.nav-pills[_ngcontent-%COMP%]   .nav-link.active[_ngcontent-%COMP%], .nav-pills[_ngcontent-%COMP%]   .nav-link.active[_ngcontent-%COMP%]:hover {\n  color: #fff\n}\n\n.nav-pills[_ngcontent-%COMP%]   .nav-link.active[_ngcontent-%COMP%]   .nav-link-icon[_ngcontent-%COMP%], .nav-pills[_ngcontent-%COMP%]   .nav-link.active[_ngcontent-%COMP%]:hover   .nav-link-icon[_ngcontent-%COMP%] {\n  color: #fff;\n  opacity: .8\n}\n\n.nav-pills[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%]:hover {\n  color: #495057 !important\n}\n\n.nav-justified[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%]   .nav-text[_ngcontent-%COMP%] {\n  display: block;\n  width: 100%;\n  text-align: center\n}\n\n.badge-primary[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #3f6ad8\n}\n\na.badge-primary[_ngcontent-%COMP%]:hover, a.badge-primary[_ngcontent-%COMP%]:focus {\n  color: #fff;\n  background-color: #2651be\n}\n\n.badge-secondary[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #6c757d\n}\n\na.badge-secondary[_ngcontent-%COMP%]:hover, a.badge-secondary[_ngcontent-%COMP%]:focus {\n  color: #fff;\n  background-color: #545b62\n}\n\n.badge-success[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #3ac47d\n}\n\na.badge-success[_ngcontent-%COMP%]:hover, a.badge-success[_ngcontent-%COMP%]:focus {\n  color: #fff;\n  background-color: #2e9d64\n}\n\n.badge-warning[_ngcontent-%COMP%] {\n  color: #212529;\n  background-color: #f7b924\n}\n\na.badge-warning[_ngcontent-%COMP%]:hover, a.badge-warning[_ngcontent-%COMP%]:focus {\n  color: #212529;\n  background-color: #e0a008\n}\n\n.badge-danger[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #d92550\n}\n\na.badge-danger[_ngcontent-%COMP%]:hover, a.badge-danger[_ngcontent-%COMP%]:focus {\n  color: #fff;\n  background-color: #ad1e40\n}\n\n.badge-light[_ngcontent-%COMP%] {\n  color: #212529;\n  background-color: #eee\n}\n\na.badge-light[_ngcontent-%COMP%]:hover, a.badge-light[_ngcontent-%COMP%]:focus {\n  color: #212529;\n  background-color: #d5d5d5\n}\n\n.badge-dark[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #343a40\n}\n\na.badge-dark[_ngcontent-%COMP%]:hover, a.badge-dark[_ngcontent-%COMP%]:focus {\n  color: #fff;\n  background-color: #1d2124\n}\n\n.badge-focus[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #444054\n}\n\na.badge-focus[_ngcontent-%COMP%]:hover, a.badge-focus[_ngcontent-%COMP%]:focus {\n  color: #fff;\n  background-color: #2d2a37\n}\n\n.badge-alternate[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #794c8a\n}\n\na.badge-alternate[_ngcontent-%COMP%]:hover, a.badge-alternate[_ngcontent-%COMP%]:focus {\n  color: #fff;\n  background-color: #5c3a69\n}\n\n.badge[_ngcontent-%COMP%] {\n  font-weight: bold;\n  text-transform: uppercase;\n  padding: 5px 10px;\n  min-width: 19px\n}\n\n.badge-light[_ngcontent-%COMP%] {\n  background: #fff\n}\n\n.badge-dot[_ngcontent-%COMP%] {\n  text-indent: -999em;\n  padding: 0;\n  width: 8px;\n  height: 8px;\n  border: transparent solid 1px;\n  border-radius: 30px;\n  min-width: 2px\n}\n\n.badge-dot-lg[_ngcontent-%COMP%] {\n  width: 10px;\n  height: 10px\n}\n\n.badge-dot-xl[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  position: relative\n}\n\n.badge-dot-xl[_ngcontent-%COMP%]::before {\n  content: '';\n  width: 10px;\n  height: 10px;\n  border-radius: .25rem;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  margin: -5px 0 0 -5px;\n  background: #fff\n}\n\n.badge-dot-sm[_ngcontent-%COMP%] {\n  width: 6px;\n  height: 6px\n}\n\n.btn[_ngcontent-%COMP%]   .badge[_ngcontent-%COMP%] {\n  margin-left: 8px\n}\n\n.btn[_ngcontent-%COMP%]   .badge-dot[_ngcontent-%COMP%] {\n  position: absolute;\n  border: #fff solid 2px;\n  top: -5px;\n  right: -5px;\n  width: 11px;\n  height: 11px\n}\n\n.btn[_ngcontent-%COMP%]   .badge-dot.badge-dot-lg[_ngcontent-%COMP%] {\n  width: 14px;\n  height: 14px\n}\n\n.btn[_ngcontent-%COMP%]   .badge-dot.badge-dot-sm[_ngcontent-%COMP%] {\n  width: 8px;\n  height: 8px;\n  border-width: 1px\n}\n\n.btn[_ngcontent-%COMP%]   .badge-dot-inside[_ngcontent-%COMP%] {\n  top: 10px;\n  right: 10px\n}\n\n.btn-sm[_ngcontent-%COMP%]   .badge-dot-sm[_ngcontent-%COMP%], .btn-group-sm[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]   .badge-dot-sm[_ngcontent-%COMP%] {\n  top: 1px;\n  right: 4px\n}\n\n.btn-sm[_ngcontent-%COMP%]   .badge-dot[_ngcontent-%COMP%], .btn-group-sm[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]   .badge-dot[_ngcontent-%COMP%] {\n  top: 0px;\n  right: 2px\n}\n\n.btn-sm[_ngcontent-%COMP%]   .badge-dot-lg[_ngcontent-%COMP%], .btn-group-sm[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]   .badge-dot-lg[_ngcontent-%COMP%] {\n  top: -3px;\n  right: -2px\n}\n\n.btn-sm[_ngcontent-%COMP%]   .badge-pill[_ngcontent-%COMP%], .btn-group-sm[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%]   .badge-pill[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -4px;\n  right: -4px\n}\n\n.badge-abs[_ngcontent-%COMP%] {\n  position: absolute;\n  right: -3px;\n  top: -3px\n}\n\n.vertical-timeline[_ngcontent-%COMP%] {\n  width: 100%;\n  position: relative;\n  padding: 1.5rem 0 1rem\n}\n\n.vertical-timeline[_ngcontent-%COMP%]::after {\n  content: '';\n  display: table;\n  clear: both\n}\n\n.vertical-timeline[_ngcontent-%COMP%]::before {\n  content: '';\n  position: absolute;\n  top: 0;\n  left: 67px;\n  height: 100%;\n  width: 4px;\n  background: #e9ecef;\n  border-radius: .25rem\n}\n\n.vertical-timeline-element[_ngcontent-%COMP%] {\n  position: relative;\n  margin: 0 0 1rem\n}\n\n.vertical-timeline-element[_ngcontent-%COMP%]:after {\n  content: \"\";\n  display: table;\n  clear: both\n}\n\n.vertical-timeline-element[_ngcontent-%COMP%]:last-child {\n  margin-bottom: 0\n}\n\n.vertical-timeline-element-content[_ngcontent-%COMP%] {\n  position: relative;\n  margin-left: 90px;\n  font-size: .8rem\n}\n\n.vertical-timeline-element-content[_ngcontent-%COMP%]:after {\n  content: \"\";\n  display: table;\n  clear: both\n}\n\n.vertical-timeline-element-content[_ngcontent-%COMP%]   .timeline-title[_ngcontent-%COMP%] {\n  font-size: .8rem;\n  text-transform: uppercase;\n  margin: 0 0 .5rem;\n  padding: 2px 0 0;\n  font-weight: bold\n}\n\n.vertical-timeline-element-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: #6c757d;\n  margin: 0 0 .5rem\n}\n\n.vertical-timeline-element-content[_ngcontent-%COMP%]   .vertical-timeline-element-date[_ngcontent-%COMP%] {\n  display: block;\n  position: absolute;\n  left: -90px;\n  top: 0;\n  padding-right: 10px;\n  text-align: right;\n  color: #adb5bd;\n  font-size: .7619rem;\n  white-space: nowrap\n}\n\n.vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 60px\n}\n\n.vertical-timeline-element-icon[_ngcontent-%COMP%]   .badge-dot-xl[_ngcontent-%COMP%] {\n  box-shadow: 0 0 0 5px #fff\n}\n\n.vertical-timeline-element--no-children[_ngcontent-%COMP%]   .vertical-timeline-element-content[_ngcontent-%COMP%] {\n  background: 0 0;\n  box-shadow: none\n}\n\n.vertical-timeline-element--no-children[_ngcontent-%COMP%]   .vertical-timeline-element-content[_ngcontent-%COMP%]::before {\n  display: none\n}\n\n.vertical-without-time[_ngcontent-%COMP%]::before {\n  left: 11px\n}\n\n.vertical-without-time[_ngcontent-%COMP%]   .vertical-timeline-element-content[_ngcontent-%COMP%] {\n  margin-left: 36px\n}\n\n.vertical-without-time[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  left: 4px\n}\n\n.vertical-time-icons[_ngcontent-%COMP%] {\n  padding: 2rem 0 0\n}\n\n.vertical-time-icons[_ngcontent-%COMP%]::before {\n  content: '';\n  position: absolute;\n  top: 0;\n  left: 14px;\n  height: 100%;\n  width: 6px;\n  background: #e9ecef;\n  border-radius: .25rem\n}\n\n.vertical-time-icons[_ngcontent-%COMP%]   .vertical-timeline-element[_ngcontent-%COMP%] {\n  margin-bottom: 1rem\n}\n\n.vertical-time-icons[_ngcontent-%COMP%]   .vertical-timeline-element-content[_ngcontent-%COMP%] {\n  margin-left: 50px\n}\n\n.vertical-time-icons[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  width: 34px;\n  height: 34px;\n  left: 0;\n  top: -7px\n}\n\n.vertical-time-icons[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%]   .timeline-icon[_ngcontent-%COMP%] {\n  width: 34px;\n  height: 34px;\n  background: #fff;\n  border-radius: 50px;\n  border-width: 2px;\n  border-style: solid;\n  box-shadow: 0 0 0 5px #fff;\n  text-align: center;\n  display: flex;\n  align-items: center;\n  align-content: center\n}\n\n.vertical-time-icons[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%]   .timeline-icon[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 1.1rem;\n  margin: 0 auto\n}\n\n.vertical-time-icons[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%]   .timeline-icon[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  margin: 0 auto\n}\n\n.vertical-time-simple[_ngcontent-%COMP%] {\n  padding: .5rem 0\n}\n\n.vertical-time-simple[_ngcontent-%COMP%]   .vertical-timeline-element[_ngcontent-%COMP%] {\n  margin: 0 0 .5rem\n}\n\n.vertical-time-simple[_ngcontent-%COMP%]   .timeline-title[_ngcontent-%COMP%] {\n  font-weight: normal;\n  font-size: .91667rem;\n  padding: 0\n}\n\n.vertical-time-simple[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  height: 14px;\n  width: 14px;\n  background: #e9ecef;\n  position: absolute;\n  left: 6px;\n  top: 2px;\n  display: block;\n  border-radius: 20px\n}\n\n.vertical-time-simple[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%]::after {\n  content: '';\n  position: absolute;\n  background: #fff;\n  left: 50%;\n  top: 50%;\n  margin: -4px 0 0 -4px;\n  display: block;\n  width: 8px;\n  height: 8px;\n  border-radius: 20px\n}\n\n.vertical-time-simple[_ngcontent-%COMP%]   .timeline-title[_ngcontent-%COMP%] {\n  text-transform: none\n}\n\n.dot-primary[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  background: #3f6ad8\n}\n\n.dot-secondary[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  background: #6c757d\n}\n\n.dot-success[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  background: #3ac47d\n}\n\n.dot-info[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  background: #16aaff\n}\n\n.dot-warning[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  background: #f7b924\n}\n\n.dot-danger[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  background: #d92550\n}\n\n.dot-light[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  background: #eee\n}\n\n.dot-dark[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  background: #343a40\n}\n\n.dot-focus[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  background: #444054\n}\n\n.dot-alternate[_ngcontent-%COMP%]   .vertical-timeline-element-icon[_ngcontent-%COMP%] {\n  background: #794c8a\n}\n\n.vertical-timeline--animate[_ngcontent-%COMP%]   .vertical-timeline-element-icon.is-hidden[_ngcontent-%COMP%] {\n  visibility: hidden\n}\n\n.vertical-timeline--animate[_ngcontent-%COMP%]   .vertical-timeline-element-icon.bounce-in[_ngcontent-%COMP%] {\n  visibility: visible;\n  animation: cd-bounce-1 .8s\n}\n\n.vertical-timeline--animate[_ngcontent-%COMP%]   .vertical-timeline-element-content.is-hidden[_ngcontent-%COMP%] {\n  visibility: hidden\n}\n\n.vertical-timeline--animate[_ngcontent-%COMP%]   .vertical-timeline-element-content.bounce-in[_ngcontent-%COMP%] {\n  visibility: visible;\n  animation: cd-bounce-2 .6s\n}\n\n@media only screen and (min-width: 1170px) {\n  .vertical-timeline--two-columns.vertical-timeline--animate[_ngcontent-%COMP%]   .vertical-timeline-element.vertical-timeline-element--right[_ngcontent-%COMP%]   .vertical-timeline-element-content.bounce-in[_ngcontent-%COMP%], .vertical-timeline--two-columns.vertical-timeline--animate[_ngcontent-%COMP%]   .vertical-timeline-element[_ngcontent-%COMP%]:nth-child(even):not(.vertical-timeline-element--left)   .vertical-timeline-element-content.bounce-in[_ngcontent-%COMP%] {\n    animation: cd-bounce-2-inverse .6s\n  }\n}\n\n@media only screen and (max-width: 1169px) {\n  .vertical-timeline--animate[_ngcontent-%COMP%]   .vertical-timeline-element-content.bounce-in[_ngcontent-%COMP%] {\n    visibility: visible;\n    animation: cd-bounce-2-inverse .6s\n  }\n}\n\n.icon-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-content: center;\n  align-items: center;\n  width: 54px;\n  height: 54px;\n  margin: 0 auto;\n  position: relative;\n  overflow: hidden\n}\n\n.icon-wrapper[class*=\"border-\"][_ngcontent-%COMP%] {\n  border-width: 1px;\n  border-style: solid\n}\n\n.icon-wrapper[_ngcontent-%COMP%]   .icon-wrapper-bg[_ngcontent-%COMP%] {\n  position: absolute;\n  height: 100%;\n  width: 100%;\n  z-index: 3;\n  opacity: .2\n}\n\n.icon-wrapper[_ngcontent-%COMP%]   .icon-wrapper-bg.bg-light[_ngcontent-%COMP%] {\n  opacity: .08\n}\n\n.icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  margin: 0 auto;\n  font-size: 1.7rem;\n  position: relative;\n  z-index: 5\n}\n\n.icon-wrapper[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]:before {\n  margin-top: -3px\n}\n\n.icon-wrapper[_ngcontent-%COMP%]   .progress-circle-wrapper[_ngcontent-%COMP%] {\n  width: 100%;\n  margin-right: 0\n}\n\n.widget-numbers-sm[_ngcontent-%COMP%] {\n  font-size: 1.5rem\n}\n\n.widget-content[_ngcontent-%COMP%] {\n  padding: 1rem;\n  flex-direction: row;\n  align-items: center\n}\n\n.widget-content[_ngcontent-%COMP%]   .widget-content-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex: 1;\n  position: relative;\n  align-items: center\n}\n\n.widget-content[_ngcontent-%COMP%]   .widget-content-left[_ngcontent-%COMP%]   .widget-heading[_ngcontent-%COMP%] {\n  opacity: .8;\n  font-weight: bold\n}\n\n.widget-content[_ngcontent-%COMP%]   .widget-content-left[_ngcontent-%COMP%]   .widget-subheading[_ngcontent-%COMP%] {\n  opacity: .5\n}\n\n.widget-content[_ngcontent-%COMP%]   .widget-content-right[_ngcontent-%COMP%] {\n  margin-left: auto\n}\n\n.widget-content[_ngcontent-%COMP%]   .widget-numbers[_ngcontent-%COMP%] {\n  font-weight: bold;\n  font-size: 1.8rem;\n  display: block\n}\n\n.widget-content[_ngcontent-%COMP%]   .widget-content-outer[_ngcontent-%COMP%] {\n  display: flex;\n  flex: 1;\n  flex-direction: column\n}\n\n.widget-content[_ngcontent-%COMP%]   .widget-progress-wrapper[_ngcontent-%COMP%] {\n  margin-top: 1rem\n}\n\n.widget-content[_ngcontent-%COMP%]   .widget-progress-wrapper[_ngcontent-%COMP%]   .progress-sub-label[_ngcontent-%COMP%] {\n  margin-top: .33333rem;\n  opacity: .5;\n  display: flex;\n  align-content: center;\n  align-items: center\n}\n\n.widget-content[_ngcontent-%COMP%]   .widget-progress-wrapper[_ngcontent-%COMP%]   .progress-sub-label[_ngcontent-%COMP%]   .sub-label-right[_ngcontent-%COMP%] {\n  margin-left: auto\n}\n\n.widget-content[_ngcontent-%COMP%]   .widget-content-right.widget-content-actions[_ngcontent-%COMP%] {\n  visibility: hidden;\n  opacity: 0;\n  transition: opacity .2s\n}\n\n.widget-content[_ngcontent-%COMP%]:hover   .widget-content-right.widget-content-actions[_ngcontent-%COMP%] {\n  visibility: visible;\n  opacity: 1\n}\n\n\n.mobile-app-menu-btn[_ngcontent-%COMP%] {\n  display: none;\n  margin: 3px 1.5rem 0 0\n}\n\n.scrollbar-sidebar[_ngcontent-%COMP%], .scrollbar-container[_ngcontent-%COMP%] {\n  position: relative;\n  height: 100%\n}\n\n.scroll-area[_ngcontent-%COMP%] {\n  overflow-x: hidden;\n  height: 400px\n}\n\n.scroll-area-xs[_ngcontent-%COMP%] {\n  height: 150px;\n  overflow-x: hidden\n}\n\n.scroll-area-sm[_ngcontent-%COMP%] {\n  height: 200px;\n  overflow-x: hidden\n}\n\n.scroll-area-md[_ngcontent-%COMP%] {\n  height: 300px;\n  overflow-x: hidden\n}\n\n.scroll-area-lg[_ngcontent-%COMP%] {\n  height: 400px;\n  overflow-x: hidden\n}\n\n.scroll-area-x[_ngcontent-%COMP%] {\n  overflow-x: auto;\n  width: 100%;\n  max-width: 100%\n}\n\n@font-face {\n  font-family: \"Ionicons\";\n  src: url('ionicons.eot');\n  src: url('ionicons.eot#iefix') format(\"embedded-opentype\"), url('ionicons.ttf') format(\"truetype\"), url('ionicons.woff') format(\"woff\"), url('ionicons.svg#Ionicons') format(\"svg\");\n  font-weight: normal;\n  font-style: normal\n}\n\n.ion[_ngcontent-%COMP%], .ionicons[_ngcontent-%COMP%], .ion-alert[_ngcontent-%COMP%]:before, .ion-alert-circled[_ngcontent-%COMP%]:before, .ion-android-add[_ngcontent-%COMP%]:before, .ion-android-add-circle[_ngcontent-%COMP%]:before, .ion-android-alarm-clock[_ngcontent-%COMP%]:before, .ion-android-alert[_ngcontent-%COMP%]:before, .ion-android-apps[_ngcontent-%COMP%]:before, .ion-android-archive[_ngcontent-%COMP%]:before, .ion-android-arrow-back[_ngcontent-%COMP%]:before, .ion-android-arrow-down[_ngcontent-%COMP%]:before, .ion-android-arrow-dropdown[_ngcontent-%COMP%]:before, .ion-android-arrow-dropdown-circle[_ngcontent-%COMP%]:before, .ion-android-arrow-dropleft[_ngcontent-%COMP%]:before, .ion-android-arrow-dropleft-circle[_ngcontent-%COMP%]:before, .ion-android-arrow-dropright[_ngcontent-%COMP%]:before, .ion-android-arrow-dropright-circle[_ngcontent-%COMP%]:before, .ion-android-arrow-dropup[_ngcontent-%COMP%]:before, .ion-android-arrow-dropup-circle[_ngcontent-%COMP%]:before, .ion-android-arrow-forward[_ngcontent-%COMP%]:before, .ion-android-arrow-up[_ngcontent-%COMP%]:before, .ion-android-attach[_ngcontent-%COMP%]:before, .ion-android-bar[_ngcontent-%COMP%]:before, .ion-android-bicycle[_ngcontent-%COMP%]:before, .ion-android-boat[_ngcontent-%COMP%]:before, .ion-android-bookmark[_ngcontent-%COMP%]:before, .ion-android-bulb[_ngcontent-%COMP%]:before, .ion-android-bus[_ngcontent-%COMP%]:before, .ion-android-calendar[_ngcontent-%COMP%]:before, .ion-android-call[_ngcontent-%COMP%]:before, .ion-android-camera[_ngcontent-%COMP%]:before, .ion-android-cancel[_ngcontent-%COMP%]:before, .ion-android-car[_ngcontent-%COMP%]:before, .ion-android-cart[_ngcontent-%COMP%]:before, .ion-android-chat[_ngcontent-%COMP%]:before, .ion-android-checkbox[_ngcontent-%COMP%]:before, .ion-android-checkbox-blank[_ngcontent-%COMP%]:before, .ion-android-checkbox-outline[_ngcontent-%COMP%]:before, .ion-android-checkbox-outline-blank[_ngcontent-%COMP%]:before, .ion-android-checkmark-circle[_ngcontent-%COMP%]:before, .ion-android-clipboard[_ngcontent-%COMP%]:before, .ion-android-close[_ngcontent-%COMP%]:before, .ion-android-cloud[_ngcontent-%COMP%]:before, .ion-android-cloud-circle[_ngcontent-%COMP%]:before, .ion-android-cloud-done[_ngcontent-%COMP%]:before, .ion-android-cloud-outline[_ngcontent-%COMP%]:before, .ion-android-color-palette[_ngcontent-%COMP%]:before, .ion-android-compass[_ngcontent-%COMP%]:before, .ion-android-contact[_ngcontent-%COMP%]:before, .ion-android-contacts[_ngcontent-%COMP%]:before, .ion-android-contract[_ngcontent-%COMP%]:before, .ion-android-create[_ngcontent-%COMP%]:before, .ion-android-delete[_ngcontent-%COMP%]:before, .ion-android-desktop[_ngcontent-%COMP%]:before, .ion-android-document[_ngcontent-%COMP%]:before, .ion-android-done[_ngcontent-%COMP%]:before, .ion-android-done-all[_ngcontent-%COMP%]:before, .ion-android-download[_ngcontent-%COMP%]:before, .ion-android-drafts[_ngcontent-%COMP%]:before, .ion-android-exit[_ngcontent-%COMP%]:before, .ion-android-expand[_ngcontent-%COMP%]:before, .ion-android-favorite[_ngcontent-%COMP%]:before, .ion-android-favorite-outline[_ngcontent-%COMP%]:before, .ion-android-film[_ngcontent-%COMP%]:before, .ion-android-folder[_ngcontent-%COMP%]:before, .ion-android-folder-open[_ngcontent-%COMP%]:before, .ion-android-funnel[_ngcontent-%COMP%]:before, .ion-android-globe[_ngcontent-%COMP%]:before, .ion-android-hand[_ngcontent-%COMP%]:before, .ion-android-hangout[_ngcontent-%COMP%]:before, .ion-android-happy[_ngcontent-%COMP%]:before, .ion-android-home[_ngcontent-%COMP%]:before, .ion-android-image[_ngcontent-%COMP%]:before, .ion-android-laptop[_ngcontent-%COMP%]:before, .ion-android-list[_ngcontent-%COMP%]:before, .ion-android-locate[_ngcontent-%COMP%]:before, .ion-android-lock[_ngcontent-%COMP%]:before, .ion-android-mail[_ngcontent-%COMP%]:before, .ion-android-map[_ngcontent-%COMP%]:before, .ion-android-menu[_ngcontent-%COMP%]:before, .ion-android-microphone[_ngcontent-%COMP%]:before, .ion-android-microphone-off[_ngcontent-%COMP%]:before, .ion-android-more-horizontal[_ngcontent-%COMP%]:before, .ion-android-more-vertical[_ngcontent-%COMP%]:before, .ion-android-navigate[_ngcontent-%COMP%]:before, .ion-android-notifications[_ngcontent-%COMP%]:before, .ion-android-notifications-none[_ngcontent-%COMP%]:before, .ion-android-notifications-off[_ngcontent-%COMP%]:before, .ion-android-open[_ngcontent-%COMP%]:before, .ion-android-options[_ngcontent-%COMP%]:before, .ion-android-people[_ngcontent-%COMP%]:before, .ion-android-person[_ngcontent-%COMP%]:before, .ion-android-person-add[_ngcontent-%COMP%]:before, .ion-android-phone-landscape[_ngcontent-%COMP%]:before, .ion-android-phone-portrait[_ngcontent-%COMP%]:before, .ion-android-pin[_ngcontent-%COMP%]:before, .ion-android-plane[_ngcontent-%COMP%]:before, .ion-android-playstore[_ngcontent-%COMP%]:before, .ion-android-print[_ngcontent-%COMP%]:before, .ion-android-radio-button-off[_ngcontent-%COMP%]:before, .ion-android-radio-button-on[_ngcontent-%COMP%]:before, .ion-android-refresh[_ngcontent-%COMP%]:before, .ion-android-remove[_ngcontent-%COMP%]:before, .ion-android-remove-circle[_ngcontent-%COMP%]:before, .ion-android-restaurant[_ngcontent-%COMP%]:before, .ion-android-sad[_ngcontent-%COMP%]:before, .ion-android-search[_ngcontent-%COMP%]:before, .ion-android-send[_ngcontent-%COMP%]:before, .ion-android-settings[_ngcontent-%COMP%]:before, .ion-android-share[_ngcontent-%COMP%]:before, .ion-android-share-alt[_ngcontent-%COMP%]:before, .ion-android-star[_ngcontent-%COMP%]:before, .ion-android-star-half[_ngcontent-%COMP%]:before, .ion-android-star-outline[_ngcontent-%COMP%]:before, .ion-android-stopwatch[_ngcontent-%COMP%]:before, .ion-android-subway[_ngcontent-%COMP%]:before, .ion-android-sunny[_ngcontent-%COMP%]:before, .ion-android-sync[_ngcontent-%COMP%]:before, .ion-android-textsms[_ngcontent-%COMP%]:before, .ion-android-time[_ngcontent-%COMP%]:before, .ion-android-train[_ngcontent-%COMP%]:before, .ion-android-unlock[_ngcontent-%COMP%]:before, .ion-android-upload[_ngcontent-%COMP%]:before, .ion-android-volume-down[_ngcontent-%COMP%]:before, .ion-android-volume-mute[_ngcontent-%COMP%]:before, .ion-android-volume-off[_ngcontent-%COMP%]:before, .ion-android-volume-up[_ngcontent-%COMP%]:before, .ion-android-walk[_ngcontent-%COMP%]:before, .ion-android-warning[_ngcontent-%COMP%]:before, .ion-android-watch[_ngcontent-%COMP%]:before, .ion-android-wifi[_ngcontent-%COMP%]:before, .ion-aperture[_ngcontent-%COMP%]:before, .ion-archive[_ngcontent-%COMP%]:before, .ion-arrow-down-a[_ngcontent-%COMP%]:before, .ion-arrow-down-b[_ngcontent-%COMP%]:before, .ion-arrow-down-c[_ngcontent-%COMP%]:before, .ion-arrow-expand[_ngcontent-%COMP%]:before, .ion-arrow-graph-down-left[_ngcontent-%COMP%]:before, .ion-arrow-graph-down-right[_ngcontent-%COMP%]:before, .ion-arrow-graph-up-left[_ngcontent-%COMP%]:before, .ion-arrow-graph-up-right[_ngcontent-%COMP%]:before, .ion-arrow-left-a[_ngcontent-%COMP%]:before, .ion-arrow-left-b[_ngcontent-%COMP%]:before, .ion-arrow-left-c[_ngcontent-%COMP%]:before, .ion-arrow-move[_ngcontent-%COMP%]:before, .ion-arrow-resize[_ngcontent-%COMP%]:before, .ion-arrow-return-left[_ngcontent-%COMP%]:before, .ion-arrow-return-right[_ngcontent-%COMP%]:before, .ion-arrow-right-a[_ngcontent-%COMP%]:before, .ion-arrow-right-b[_ngcontent-%COMP%]:before, .ion-arrow-right-c[_ngcontent-%COMP%]:before, .ion-arrow-shrink[_ngcontent-%COMP%]:before, .ion-arrow-swap[_ngcontent-%COMP%]:before, .ion-arrow-up-a[_ngcontent-%COMP%]:before, .ion-arrow-up-b[_ngcontent-%COMP%]:before, .ion-arrow-up-c[_ngcontent-%COMP%]:before, .ion-asterisk[_ngcontent-%COMP%]:before, .ion-at[_ngcontent-%COMP%]:before, .ion-backspace[_ngcontent-%COMP%]:before, .ion-backspace-outline[_ngcontent-%COMP%]:before, .ion-bag[_ngcontent-%COMP%]:before, .ion-battery-charging[_ngcontent-%COMP%]:before, .ion-battery-empty[_ngcontent-%COMP%]:before, .ion-battery-full[_ngcontent-%COMP%]:before, .ion-battery-half[_ngcontent-%COMP%]:before, .ion-battery-low[_ngcontent-%COMP%]:before, .ion-beaker[_ngcontent-%COMP%]:before, .ion-beer[_ngcontent-%COMP%]:before, .ion-bluetooth[_ngcontent-%COMP%]:before, .ion-bonfire[_ngcontent-%COMP%]:before, .ion-bookmark[_ngcontent-%COMP%]:before, .ion-bowtie[_ngcontent-%COMP%]:before, .ion-briefcase[_ngcontent-%COMP%]:before, .ion-bug[_ngcontent-%COMP%]:before, .ion-calculator[_ngcontent-%COMP%]:before, .ion-calendar[_ngcontent-%COMP%]:before, .ion-camera[_ngcontent-%COMP%]:before, .ion-card[_ngcontent-%COMP%]:before, .ion-cash[_ngcontent-%COMP%]:before, .ion-chatbox[_ngcontent-%COMP%]:before, .ion-chatbox-working[_ngcontent-%COMP%]:before, .ion-chatboxes[_ngcontent-%COMP%]:before, .ion-chatbubble[_ngcontent-%COMP%]:before, .ion-chatbubble-working[_ngcontent-%COMP%]:before, .ion-chatbubbles[_ngcontent-%COMP%]:before, .ion-checkmark[_ngcontent-%COMP%]:before, .ion-checkmark-circled[_ngcontent-%COMP%]:before, .ion-checkmark-round[_ngcontent-%COMP%]:before, .ion-chevron-down[_ngcontent-%COMP%]:before, .ion-chevron-left[_ngcontent-%COMP%]:before, .ion-chevron-right[_ngcontent-%COMP%]:before, .ion-chevron-up[_ngcontent-%COMP%]:before, .ion-clipboard[_ngcontent-%COMP%]:before, .ion-clock[_ngcontent-%COMP%]:before, .ion-close[_ngcontent-%COMP%]:before, .ion-close-circled[_ngcontent-%COMP%]:before, .ion-close-round[_ngcontent-%COMP%]:before, .ion-closed-captioning[_ngcontent-%COMP%]:before, .ion-cloud[_ngcontent-%COMP%]:before, .ion-code[_ngcontent-%COMP%]:before, .ion-code-download[_ngcontent-%COMP%]:before, .ion-code-working[_ngcontent-%COMP%]:before, .ion-coffee[_ngcontent-%COMP%]:before, .ion-compass[_ngcontent-%COMP%]:before, .ion-compose[_ngcontent-%COMP%]:before, .ion-connection-bars[_ngcontent-%COMP%]:before, .ion-contrast[_ngcontent-%COMP%]:before, .ion-crop[_ngcontent-%COMP%]:before, .ion-cube[_ngcontent-%COMP%]:before, .ion-disc[_ngcontent-%COMP%]:before, .ion-document[_ngcontent-%COMP%]:before, .ion-document-text[_ngcontent-%COMP%]:before, .ion-drag[_ngcontent-%COMP%]:before, .ion-earth[_ngcontent-%COMP%]:before, .ion-easel[_ngcontent-%COMP%]:before, .ion-edit[_ngcontent-%COMP%]:before, .ion-egg[_ngcontent-%COMP%]:before, .ion-eject[_ngcontent-%COMP%]:before, .ion-email[_ngcontent-%COMP%]:before, .ion-email-unread[_ngcontent-%COMP%]:before, .ion-erlenmeyer-flask[_ngcontent-%COMP%]:before, .ion-erlenmeyer-flask-bubbles[_ngcontent-%COMP%]:before, .ion-eye[_ngcontent-%COMP%]:before, .ion-eye-disabled[_ngcontent-%COMP%]:before, .ion-female[_ngcontent-%COMP%]:before, .ion-filing[_ngcontent-%COMP%]:before, .ion-film-marker[_ngcontent-%COMP%]:before, .ion-fireball[_ngcontent-%COMP%]:before, .ion-flag[_ngcontent-%COMP%]:before, .ion-flame[_ngcontent-%COMP%]:before, .ion-flash[_ngcontent-%COMP%]:before, .ion-flash-off[_ngcontent-%COMP%]:before, .ion-folder[_ngcontent-%COMP%]:before, .ion-fork[_ngcontent-%COMP%]:before, .ion-fork-repo[_ngcontent-%COMP%]:before, .ion-forward[_ngcontent-%COMP%]:before, .ion-funnel[_ngcontent-%COMP%]:before, .ion-gear-a[_ngcontent-%COMP%]:before, .ion-gear-b[_ngcontent-%COMP%]:before, .ion-grid[_ngcontent-%COMP%]:before, .ion-hammer[_ngcontent-%COMP%]:before, .ion-happy[_ngcontent-%COMP%]:before, .ion-happy-outline[_ngcontent-%COMP%]:before, .ion-headphone[_ngcontent-%COMP%]:before, .ion-heart[_ngcontent-%COMP%]:before, .ion-heart-broken[_ngcontent-%COMP%]:before, .ion-help[_ngcontent-%COMP%]:before, .ion-help-buoy[_ngcontent-%COMP%]:before, .ion-help-circled[_ngcontent-%COMP%]:before, .ion-home[_ngcontent-%COMP%]:before, .ion-icecream[_ngcontent-%COMP%]:before, .ion-image[_ngcontent-%COMP%]:before, .ion-images[_ngcontent-%COMP%]:before, .ion-information[_ngcontent-%COMP%]:before, .ion-information-circled[_ngcontent-%COMP%]:before, .ion-ionic[_ngcontent-%COMP%]:before, .ion-ios-alarm[_ngcontent-%COMP%]:before, .ion-ios-alarm-outline[_ngcontent-%COMP%]:before, .ion-ios-albums[_ngcontent-%COMP%]:before, .ion-ios-albums-outline[_ngcontent-%COMP%]:before, .ion-ios-americanfootball[_ngcontent-%COMP%]:before, .ion-ios-americanfootball-outline[_ngcontent-%COMP%]:before, .ion-ios-analytics[_ngcontent-%COMP%]:before, .ion-ios-analytics-outline[_ngcontent-%COMP%]:before, .ion-ios-arrow-back[_ngcontent-%COMP%]:before, .ion-ios-arrow-down[_ngcontent-%COMP%]:before, .ion-ios-arrow-forward[_ngcontent-%COMP%]:before, .ion-ios-arrow-left[_ngcontent-%COMP%]:before, .ion-ios-arrow-right[_ngcontent-%COMP%]:before, .ion-ios-arrow-thin-down[_ngcontent-%COMP%]:before, .ion-ios-arrow-thin-left[_ngcontent-%COMP%]:before, .ion-ios-arrow-thin-right[_ngcontent-%COMP%]:before, .ion-ios-arrow-thin-up[_ngcontent-%COMP%]:before, .ion-ios-arrow-up[_ngcontent-%COMP%]:before, .ion-ios-at[_ngcontent-%COMP%]:before, .ion-ios-at-outline[_ngcontent-%COMP%]:before, .ion-ios-barcode[_ngcontent-%COMP%]:before, .ion-ios-barcode-outline[_ngcontent-%COMP%]:before, .ion-ios-baseball[_ngcontent-%COMP%]:before, .ion-ios-baseball-outline[_ngcontent-%COMP%]:before, .ion-ios-basketball[_ngcontent-%COMP%]:before, .ion-ios-basketball-outline[_ngcontent-%COMP%]:before, .ion-ios-bell[_ngcontent-%COMP%]:before, .ion-ios-bell-outline[_ngcontent-%COMP%]:before, .ion-ios-body[_ngcontent-%COMP%]:before, .ion-ios-body-outline[_ngcontent-%COMP%]:before, .ion-ios-bolt[_ngcontent-%COMP%]:before, .ion-ios-bolt-outline[_ngcontent-%COMP%]:before, .ion-ios-book[_ngcontent-%COMP%]:before, .ion-ios-book-outline[_ngcontent-%COMP%]:before, .ion-ios-bookmarks[_ngcontent-%COMP%]:before, .ion-ios-bookmarks-outline[_ngcontent-%COMP%]:before, .ion-ios-box[_ngcontent-%COMP%]:before, .ion-ios-box-outline[_ngcontent-%COMP%]:before, .ion-ios-briefcase[_ngcontent-%COMP%]:before, .ion-ios-briefcase-outline[_ngcontent-%COMP%]:before, .ion-ios-browsers[_ngcontent-%COMP%]:before, .ion-ios-browsers-outline[_ngcontent-%COMP%]:before, .ion-ios-calculator[_ngcontent-%COMP%]:before, .ion-ios-calculator-outline[_ngcontent-%COMP%]:before, .ion-ios-calendar[_ngcontent-%COMP%]:before, .ion-ios-calendar-outline[_ngcontent-%COMP%]:before, .ion-ios-camera[_ngcontent-%COMP%]:before, .ion-ios-camera-outline[_ngcontent-%COMP%]:before, .ion-ios-cart[_ngcontent-%COMP%]:before, .ion-ios-cart-outline[_ngcontent-%COMP%]:before, .ion-ios-chatboxes[_ngcontent-%COMP%]:before, .ion-ios-chatboxes-outline[_ngcontent-%COMP%]:before, .ion-ios-chatbubble[_ngcontent-%COMP%]:before, .ion-ios-chatbubble-outline[_ngcontent-%COMP%]:before, .ion-ios-checkmark[_ngcontent-%COMP%]:before, .ion-ios-checkmark-empty[_ngcontent-%COMP%]:before, .ion-ios-checkmark-outline[_ngcontent-%COMP%]:before, .ion-ios-circle-filled[_ngcontent-%COMP%]:before, .ion-ios-circle-outline[_ngcontent-%COMP%]:before, .ion-ios-clock[_ngcontent-%COMP%]:before, .ion-ios-clock-outline[_ngcontent-%COMP%]:before, .ion-ios-close[_ngcontent-%COMP%]:before, .ion-ios-close-empty[_ngcontent-%COMP%]:before, .ion-ios-close-outline[_ngcontent-%COMP%]:before, .ion-ios-cloud[_ngcontent-%COMP%]:before, .ion-ios-cloud-download[_ngcontent-%COMP%]:before, .ion-ios-cloud-download-outline[_ngcontent-%COMP%]:before, .ion-ios-cloud-outline[_ngcontent-%COMP%]:before, .ion-ios-cloud-upload[_ngcontent-%COMP%]:before, .ion-ios-cloud-upload-outline[_ngcontent-%COMP%]:before, .ion-ios-cloudy[_ngcontent-%COMP%]:before, .ion-ios-cloudy-night[_ngcontent-%COMP%]:before, .ion-ios-cloudy-night-outline[_ngcontent-%COMP%]:before, .ion-ios-cloudy-outline[_ngcontent-%COMP%]:before, .ion-ios-cog[_ngcontent-%COMP%]:before, .ion-ios-cog-outline[_ngcontent-%COMP%]:before, .ion-ios-color-filter[_ngcontent-%COMP%]:before, .ion-ios-color-filter-outline[_ngcontent-%COMP%]:before, .ion-ios-color-wand[_ngcontent-%COMP%]:before, .ion-ios-color-wand-outline[_ngcontent-%COMP%]:before, .ion-ios-compose[_ngcontent-%COMP%]:before, .ion-ios-compose-outline[_ngcontent-%COMP%]:before, .ion-ios-contact[_ngcontent-%COMP%]:before, .ion-ios-contact-outline[_ngcontent-%COMP%]:before, .ion-ios-copy[_ngcontent-%COMP%]:before, .ion-ios-copy-outline[_ngcontent-%COMP%]:before, .ion-ios-crop[_ngcontent-%COMP%]:before, .ion-ios-crop-strong[_ngcontent-%COMP%]:before, .ion-ios-download[_ngcontent-%COMP%]:before, .ion-ios-download-outline[_ngcontent-%COMP%]:before, .ion-ios-drag[_ngcontent-%COMP%]:before, .ion-ios-email[_ngcontent-%COMP%]:before, .ion-ios-email-outline[_ngcontent-%COMP%]:before, .ion-ios-eye[_ngcontent-%COMP%]:before, .ion-ios-eye-outline[_ngcontent-%COMP%]:before, .ion-ios-fastforward[_ngcontent-%COMP%]:before, .ion-ios-fastforward-outline[_ngcontent-%COMP%]:before, .ion-ios-filing[_ngcontent-%COMP%]:before, .ion-ios-filing-outline[_ngcontent-%COMP%]:before, .ion-ios-film[_ngcontent-%COMP%]:before, .ion-ios-film-outline[_ngcontent-%COMP%]:before, .ion-ios-flag[_ngcontent-%COMP%]:before, .ion-ios-flag-outline[_ngcontent-%COMP%]:before, .ion-ios-flame[_ngcontent-%COMP%]:before, .ion-ios-flame-outline[_ngcontent-%COMP%]:before, .ion-ios-flask[_ngcontent-%COMP%]:before, .ion-ios-flask-outline[_ngcontent-%COMP%]:before, .ion-ios-flower[_ngcontent-%COMP%]:before, .ion-ios-flower-outline[_ngcontent-%COMP%]:before, .ion-ios-folder[_ngcontent-%COMP%]:before, .ion-ios-folder-outline[_ngcontent-%COMP%]:before, .ion-ios-football[_ngcontent-%COMP%]:before, .ion-ios-football-outline[_ngcontent-%COMP%]:before, .ion-ios-game-controller-a[_ngcontent-%COMP%]:before, .ion-ios-game-controller-a-outline[_ngcontent-%COMP%]:before, .ion-ios-game-controller-b[_ngcontent-%COMP%]:before, .ion-ios-game-controller-b-outline[_ngcontent-%COMP%]:before, .ion-ios-gear[_ngcontent-%COMP%]:before, .ion-ios-gear-outline[_ngcontent-%COMP%]:before, .ion-ios-glasses[_ngcontent-%COMP%]:before, .ion-ios-glasses-outline[_ngcontent-%COMP%]:before, .ion-ios-grid-view[_ngcontent-%COMP%]:before, .ion-ios-grid-view-outline[_ngcontent-%COMP%]:before, .ion-ios-heart[_ngcontent-%COMP%]:before, .ion-ios-heart-outline[_ngcontent-%COMP%]:before, .ion-ios-help[_ngcontent-%COMP%]:before, .ion-ios-help-empty[_ngcontent-%COMP%]:before, .ion-ios-help-outline[_ngcontent-%COMP%]:before, .ion-ios-home[_ngcontent-%COMP%]:before, .ion-ios-home-outline[_ngcontent-%COMP%]:before, .ion-ios-infinite[_ngcontent-%COMP%]:before, .ion-ios-infinite-outline[_ngcontent-%COMP%]:before, .ion-ios-information[_ngcontent-%COMP%]:before, .ion-ios-information-empty[_ngcontent-%COMP%]:before, .ion-ios-information-outline[_ngcontent-%COMP%]:before, .ion-ios-ionic-outline[_ngcontent-%COMP%]:before, .ion-ios-keypad[_ngcontent-%COMP%]:before, .ion-ios-keypad-outline[_ngcontent-%COMP%]:before, .ion-ios-lightbulb[_ngcontent-%COMP%]:before, .ion-ios-lightbulb-outline[_ngcontent-%COMP%]:before, .ion-ios-list[_ngcontent-%COMP%]:before, .ion-ios-list-outline[_ngcontent-%COMP%]:before, .ion-ios-location[_ngcontent-%COMP%]:before, .ion-ios-location-outline[_ngcontent-%COMP%]:before, .ion-ios-locked[_ngcontent-%COMP%]:before, .ion-ios-locked-outline[_ngcontent-%COMP%]:before, .ion-ios-loop[_ngcontent-%COMP%]:before, .ion-ios-loop-strong[_ngcontent-%COMP%]:before, .ion-ios-medical[_ngcontent-%COMP%]:before, .ion-ios-medical-outline[_ngcontent-%COMP%]:before, .ion-ios-medkit[_ngcontent-%COMP%]:before, .ion-ios-medkit-outline[_ngcontent-%COMP%]:before, .ion-ios-mic[_ngcontent-%COMP%]:before, .ion-ios-mic-off[_ngcontent-%COMP%]:before, .ion-ios-mic-outline[_ngcontent-%COMP%]:before, .ion-ios-minus[_ngcontent-%COMP%]:before, .ion-ios-minus-empty[_ngcontent-%COMP%]:before, .ion-ios-minus-outline[_ngcontent-%COMP%]:before, .ion-ios-monitor[_ngcontent-%COMP%]:before, .ion-ios-monitor-outline[_ngcontent-%COMP%]:before, .ion-ios-moon[_ngcontent-%COMP%]:before, .ion-ios-moon-outline[_ngcontent-%COMP%]:before, .ion-ios-more[_ngcontent-%COMP%]:before, .ion-ios-more-outline[_ngcontent-%COMP%]:before, .ion-ios-musical-note[_ngcontent-%COMP%]:before, .ion-ios-musical-notes[_ngcontent-%COMP%]:before, .ion-ios-navigate[_ngcontent-%COMP%]:before, .ion-ios-navigate-outline[_ngcontent-%COMP%]:before, .ion-ios-nutrition[_ngcontent-%COMP%]:before, .ion-ios-nutrition-outline[_ngcontent-%COMP%]:before, .ion-ios-paper[_ngcontent-%COMP%]:before, .ion-ios-paper-outline[_ngcontent-%COMP%]:before, .ion-ios-paperplane[_ngcontent-%COMP%]:before, .ion-ios-paperplane-outline[_ngcontent-%COMP%]:before, .ion-ios-partlysunny[_ngcontent-%COMP%]:before, .ion-ios-partlysunny-outline[_ngcontent-%COMP%]:before, .ion-ios-pause[_ngcontent-%COMP%]:before, .ion-ios-pause-outline[_ngcontent-%COMP%]:before, .ion-ios-paw[_ngcontent-%COMP%]:before, .ion-ios-paw-outline[_ngcontent-%COMP%]:before, .ion-ios-people[_ngcontent-%COMP%]:before, .ion-ios-people-outline[_ngcontent-%COMP%]:before, .ion-ios-person[_ngcontent-%COMP%]:before, .ion-ios-person-outline[_ngcontent-%COMP%]:before, .ion-ios-personadd[_ngcontent-%COMP%]:before, .ion-ios-personadd-outline[_ngcontent-%COMP%]:before, .ion-ios-photos[_ngcontent-%COMP%]:before, .ion-ios-photos-outline[_ngcontent-%COMP%]:before, .ion-ios-pie[_ngcontent-%COMP%]:before, .ion-ios-pie-outline[_ngcontent-%COMP%]:before, .ion-ios-pint[_ngcontent-%COMP%]:before, .ion-ios-pint-outline[_ngcontent-%COMP%]:before, .ion-ios-play[_ngcontent-%COMP%]:before, .ion-ios-play-outline[_ngcontent-%COMP%]:before, .ion-ios-plus[_ngcontent-%COMP%]:before, .ion-ios-plus-empty[_ngcontent-%COMP%]:before, .ion-ios-plus-outline[_ngcontent-%COMP%]:before, .ion-ios-pricetag[_ngcontent-%COMP%]:before, .ion-ios-pricetag-outline[_ngcontent-%COMP%]:before, .ion-ios-pricetags[_ngcontent-%COMP%]:before, .ion-ios-pricetags-outline[_ngcontent-%COMP%]:before, .ion-ios-printer[_ngcontent-%COMP%]:before, .ion-ios-printer-outline[_ngcontent-%COMP%]:before, .ion-ios-pulse[_ngcontent-%COMP%]:before, .ion-ios-pulse-strong[_ngcontent-%COMP%]:before, .ion-ios-rainy[_ngcontent-%COMP%]:before, .ion-ios-rainy-outline[_ngcontent-%COMP%]:before, .ion-ios-recording[_ngcontent-%COMP%]:before, .ion-ios-recording-outline[_ngcontent-%COMP%]:before, .ion-ios-redo[_ngcontent-%COMP%]:before, .ion-ios-redo-outline[_ngcontent-%COMP%]:before, .ion-ios-refresh[_ngcontent-%COMP%]:before, .ion-ios-refresh-empty[_ngcontent-%COMP%]:before, .ion-ios-refresh-outline[_ngcontent-%COMP%]:before, .ion-ios-reload[_ngcontent-%COMP%]:before, .ion-ios-reverse-camera[_ngcontent-%COMP%]:before, .ion-ios-reverse-camera-outline[_ngcontent-%COMP%]:before, .ion-ios-rewind[_ngcontent-%COMP%]:before, .ion-ios-rewind-outline[_ngcontent-%COMP%]:before, .ion-ios-rose[_ngcontent-%COMP%]:before, .ion-ios-rose-outline[_ngcontent-%COMP%]:before, .ion-ios-search[_ngcontent-%COMP%]:before, .ion-ios-search-strong[_ngcontent-%COMP%]:before, .ion-ios-settings[_ngcontent-%COMP%]:before, .ion-ios-settings-strong[_ngcontent-%COMP%]:before, .ion-ios-shuffle[_ngcontent-%COMP%]:before, .ion-ios-shuffle-strong[_ngcontent-%COMP%]:before, .ion-ios-skipbackward[_ngcontent-%COMP%]:before, .ion-ios-skipbackward-outline[_ngcontent-%COMP%]:before, .ion-ios-skipforward[_ngcontent-%COMP%]:before, .ion-ios-skipforward-outline[_ngcontent-%COMP%]:before, .ion-ios-snowy[_ngcontent-%COMP%]:before, .ion-ios-speedometer[_ngcontent-%COMP%]:before, .ion-ios-speedometer-outline[_ngcontent-%COMP%]:before, .ion-ios-star[_ngcontent-%COMP%]:before, .ion-ios-star-half[_ngcontent-%COMP%]:before, .ion-ios-star-outline[_ngcontent-%COMP%]:before, .ion-ios-stopwatch[_ngcontent-%COMP%]:before, .ion-ios-stopwatch-outline[_ngcontent-%COMP%]:before, .ion-ios-sunny[_ngcontent-%COMP%]:before, .ion-ios-sunny-outline[_ngcontent-%COMP%]:before, .ion-ios-telephone[_ngcontent-%COMP%]:before, .ion-ios-telephone-outline[_ngcontent-%COMP%]:before, .ion-ios-tennisball[_ngcontent-%COMP%]:before, .ion-ios-tennisball-outline[_ngcontent-%COMP%]:before, .ion-ios-thunderstorm[_ngcontent-%COMP%]:before, .ion-ios-thunderstorm-outline[_ngcontent-%COMP%]:before, .ion-ios-time[_ngcontent-%COMP%]:before, .ion-ios-time-outline[_ngcontent-%COMP%]:before, .ion-ios-timer[_ngcontent-%COMP%]:before, .ion-ios-timer-outline[_ngcontent-%COMP%]:before, .ion-ios-toggle[_ngcontent-%COMP%]:before, .ion-ios-toggle-outline[_ngcontent-%COMP%]:before, .ion-ios-trash[_ngcontent-%COMP%]:before, .ion-ios-trash-outline[_ngcontent-%COMP%]:before, .ion-ios-undo[_ngcontent-%COMP%]:before, .ion-ios-undo-outline[_ngcontent-%COMP%]:before, .ion-ios-unlocked[_ngcontent-%COMP%]:before, .ion-ios-unlocked-outline[_ngcontent-%COMP%]:before, .ion-ios-upload[_ngcontent-%COMP%]:before, .ion-ios-upload-outline[_ngcontent-%COMP%]:before, .ion-ios-videocam[_ngcontent-%COMP%]:before, .ion-ios-videocam-outline[_ngcontent-%COMP%]:before, .ion-ios-volume-high[_ngcontent-%COMP%]:before, .ion-ios-volume-low[_ngcontent-%COMP%]:before, .ion-ios-wineglass[_ngcontent-%COMP%]:before, .ion-ios-wineglass-outline[_ngcontent-%COMP%]:before, .ion-ios-world[_ngcontent-%COMP%]:before, .ion-ios-world-outline[_ngcontent-%COMP%]:before, .ion-ipad[_ngcontent-%COMP%]:before, .ion-iphone[_ngcontent-%COMP%]:before, .ion-ipod[_ngcontent-%COMP%]:before, .ion-jet[_ngcontent-%COMP%]:before, .ion-key[_ngcontent-%COMP%]:before, .ion-knife[_ngcontent-%COMP%]:before, .ion-laptop[_ngcontent-%COMP%]:before, .ion-leaf[_ngcontent-%COMP%]:before, .ion-levels[_ngcontent-%COMP%]:before, .ion-lightbulb[_ngcontent-%COMP%]:before, .ion-link[_ngcontent-%COMP%]:before, .ion-load-a[_ngcontent-%COMP%]:before, .ion-load-b[_ngcontent-%COMP%]:before, .ion-load-c[_ngcontent-%COMP%]:before, .ion-load-d[_ngcontent-%COMP%]:before, .ion-location[_ngcontent-%COMP%]:before, .ion-lock-combination[_ngcontent-%COMP%]:before, .ion-locked[_ngcontent-%COMP%]:before, .ion-log-in[_ngcontent-%COMP%]:before, .ion-log-out[_ngcontent-%COMP%]:before, .ion-loop[_ngcontent-%COMP%]:before, .ion-magnet[_ngcontent-%COMP%]:before, .ion-male[_ngcontent-%COMP%]:before, .ion-man[_ngcontent-%COMP%]:before, .ion-map[_ngcontent-%COMP%]:before, .ion-medkit[_ngcontent-%COMP%]:before, .ion-merge[_ngcontent-%COMP%]:before, .ion-mic-a[_ngcontent-%COMP%]:before, .ion-mic-b[_ngcontent-%COMP%]:before, .ion-mic-c[_ngcontent-%COMP%]:before, .ion-minus[_ngcontent-%COMP%]:before, .ion-minus-circled[_ngcontent-%COMP%]:before, .ion-minus-round[_ngcontent-%COMP%]:before, .ion-model-s[_ngcontent-%COMP%]:before, .ion-monitor[_ngcontent-%COMP%]:before, .ion-more[_ngcontent-%COMP%]:before, .ion-mouse[_ngcontent-%COMP%]:before, .ion-music-note[_ngcontent-%COMP%]:before, .ion-navicon[_ngcontent-%COMP%]:before, .ion-navicon-round[_ngcontent-%COMP%]:before, .ion-navigate[_ngcontent-%COMP%]:before, .ion-network[_ngcontent-%COMP%]:before, .ion-no-smoking[_ngcontent-%COMP%]:before, .ion-nuclear[_ngcontent-%COMP%]:before, .ion-outlet[_ngcontent-%COMP%]:before, .ion-paintbrush[_ngcontent-%COMP%]:before, .ion-paintbucket[_ngcontent-%COMP%]:before, .ion-paper-airplane[_ngcontent-%COMP%]:before, .ion-paperclip[_ngcontent-%COMP%]:before, .ion-pause[_ngcontent-%COMP%]:before, .ion-person[_ngcontent-%COMP%]:before, .ion-person-add[_ngcontent-%COMP%]:before, .ion-person-stalker[_ngcontent-%COMP%]:before, .ion-pie-graph[_ngcontent-%COMP%]:before, .ion-pin[_ngcontent-%COMP%]:before, .ion-pinpoint[_ngcontent-%COMP%]:before, .ion-pizza[_ngcontent-%COMP%]:before, .ion-plane[_ngcontent-%COMP%]:before, .ion-planet[_ngcontent-%COMP%]:before, .ion-play[_ngcontent-%COMP%]:before, .ion-playstation[_ngcontent-%COMP%]:before, .ion-plus[_ngcontent-%COMP%]:before, .ion-plus-circled[_ngcontent-%COMP%]:before, .ion-plus-round[_ngcontent-%COMP%]:before, .ion-podium[_ngcontent-%COMP%]:before, .ion-pound[_ngcontent-%COMP%]:before, .ion-power[_ngcontent-%COMP%]:before, .ion-pricetag[_ngcontent-%COMP%]:before, .ion-pricetags[_ngcontent-%COMP%]:before, .ion-printer[_ngcontent-%COMP%]:before, .ion-pull-request[_ngcontent-%COMP%]:before, .ion-qr-scanner[_ngcontent-%COMP%]:before, .ion-quote[_ngcontent-%COMP%]:before, .ion-radio-waves[_ngcontent-%COMP%]:before, .ion-record[_ngcontent-%COMP%]:before, .ion-refresh[_ngcontent-%COMP%]:before, .ion-reply[_ngcontent-%COMP%]:before, .ion-reply-all[_ngcontent-%COMP%]:before, .ion-ribbon-a[_ngcontent-%COMP%]:before, .ion-ribbon-b[_ngcontent-%COMP%]:before, .ion-sad[_ngcontent-%COMP%]:before, .ion-sad-outline[_ngcontent-%COMP%]:before, .ion-scissors[_ngcontent-%COMP%]:before, .ion-search[_ngcontent-%COMP%]:before, .ion-settings[_ngcontent-%COMP%]:before, .ion-share[_ngcontent-%COMP%]:before, .ion-shuffle[_ngcontent-%COMP%]:before, .ion-skip-backward[_ngcontent-%COMP%]:before, .ion-skip-forward[_ngcontent-%COMP%]:before, .ion-social-android[_ngcontent-%COMP%]:before, .ion-social-android-outline[_ngcontent-%COMP%]:before, .ion-social-angular[_ngcontent-%COMP%]:before, .ion-social-angular-outline[_ngcontent-%COMP%]:before, .ion-social-apple[_ngcontent-%COMP%]:before, .ion-social-apple-outline[_ngcontent-%COMP%]:before, .ion-social-bitcoin[_ngcontent-%COMP%]:before, .ion-social-bitcoin-outline[_ngcontent-%COMP%]:before, .ion-social-buffer[_ngcontent-%COMP%]:before, .ion-social-buffer-outline[_ngcontent-%COMP%]:before, .ion-social-chrome[_ngcontent-%COMP%]:before, .ion-social-chrome-outline[_ngcontent-%COMP%]:before, .ion-social-codepen[_ngcontent-%COMP%]:before, .ion-social-codepen-outline[_ngcontent-%COMP%]:before, .ion-social-css3[_ngcontent-%COMP%]:before, .ion-social-css3-outline[_ngcontent-%COMP%]:before, .ion-social-designernews[_ngcontent-%COMP%]:before, .ion-social-designernews-outline[_ngcontent-%COMP%]:before, .ion-social-dribbble[_ngcontent-%COMP%]:before, .ion-social-dribbble-outline[_ngcontent-%COMP%]:before, .ion-social-dropbox[_ngcontent-%COMP%]:before, .ion-social-dropbox-outline[_ngcontent-%COMP%]:before, .ion-social-euro[_ngcontent-%COMP%]:before, .ion-social-euro-outline[_ngcontent-%COMP%]:before, .ion-social-facebook[_ngcontent-%COMP%]:before, .ion-social-facebook-outline[_ngcontent-%COMP%]:before, .ion-social-foursquare[_ngcontent-%COMP%]:before, .ion-social-foursquare-outline[_ngcontent-%COMP%]:before, .ion-social-freebsd-devil[_ngcontent-%COMP%]:before, .ion-social-github[_ngcontent-%COMP%]:before, .ion-social-github-outline[_ngcontent-%COMP%]:before, .ion-social-google[_ngcontent-%COMP%]:before, .ion-social-google-outline[_ngcontent-%COMP%]:before, .ion-social-googleplus[_ngcontent-%COMP%]:before, .ion-social-googleplus-outline[_ngcontent-%COMP%]:before, .ion-social-hackernews[_ngcontent-%COMP%]:before, .ion-social-hackernews-outline[_ngcontent-%COMP%]:before, .ion-social-html5[_ngcontent-%COMP%]:before, .ion-social-html5-outline[_ngcontent-%COMP%]:before, .ion-social-instagram[_ngcontent-%COMP%]:before, .ion-social-instagram-outline[_ngcontent-%COMP%]:before, .ion-social-javascript[_ngcontent-%COMP%]:before, .ion-social-javascript-outline[_ngcontent-%COMP%]:before, .ion-social-linkedin[_ngcontent-%COMP%]:before, .ion-social-linkedin-outline[_ngcontent-%COMP%]:before, .ion-social-markdown[_ngcontent-%COMP%]:before, .ion-social-nodejs[_ngcontent-%COMP%]:before, .ion-social-octocat[_ngcontent-%COMP%]:before, .ion-social-pinterest[_ngcontent-%COMP%]:before, .ion-social-pinterest-outline[_ngcontent-%COMP%]:before, .ion-social-python[_ngcontent-%COMP%]:before, .ion-social-reddit[_ngcontent-%COMP%]:before, .ion-social-reddit-outline[_ngcontent-%COMP%]:before, .ion-social-rss[_ngcontent-%COMP%]:before, .ion-social-rss-outline[_ngcontent-%COMP%]:before, .ion-social-sass[_ngcontent-%COMP%]:before, .ion-social-skype[_ngcontent-%COMP%]:before, .ion-social-skype-outline[_ngcontent-%COMP%]:before, .ion-social-snapchat[_ngcontent-%COMP%]:before, .ion-social-snapchat-outline[_ngcontent-%COMP%]:before, .ion-social-tumblr[_ngcontent-%COMP%]:before, .ion-social-tumblr-outline[_ngcontent-%COMP%]:before, .ion-social-tux[_ngcontent-%COMP%]:before, .ion-social-twitch[_ngcontent-%COMP%]:before, .ion-social-twitch-outline[_ngcontent-%COMP%]:before, .ion-social-twitter[_ngcontent-%COMP%]:before, .ion-social-twitter-outline[_ngcontent-%COMP%]:before, .ion-social-usd[_ngcontent-%COMP%]:before, .ion-social-usd-outline[_ngcontent-%COMP%]:before, .ion-social-vimeo[_ngcontent-%COMP%]:before, .ion-social-vimeo-outline[_ngcontent-%COMP%]:before, .ion-social-whatsapp[_ngcontent-%COMP%]:before, .ion-social-whatsapp-outline[_ngcontent-%COMP%]:before, .ion-social-windows[_ngcontent-%COMP%]:before, .ion-social-windows-outline[_ngcontent-%COMP%]:before, .ion-social-wordpress[_ngcontent-%COMP%]:before, .ion-social-wordpress-outline[_ngcontent-%COMP%]:before, .ion-social-yahoo[_ngcontent-%COMP%]:before, .ion-social-yahoo-outline[_ngcontent-%COMP%]:before, .ion-social-yen[_ngcontent-%COMP%]:before, .ion-social-yen-outline[_ngcontent-%COMP%]:before, .ion-social-youtube[_ngcontent-%COMP%]:before, .ion-social-youtube-outline[_ngcontent-%COMP%]:before, .ion-soup-can[_ngcontent-%COMP%]:before, .ion-soup-can-outline[_ngcontent-%COMP%]:before, .ion-speakerphone[_ngcontent-%COMP%]:before, .ion-speedometer[_ngcontent-%COMP%]:before, .ion-spoon[_ngcontent-%COMP%]:before, .ion-star[_ngcontent-%COMP%]:before, .ion-stats-bars[_ngcontent-%COMP%]:before, .ion-steam[_ngcontent-%COMP%]:before, .ion-stop[_ngcontent-%COMP%]:before, .ion-thermometer[_ngcontent-%COMP%]:before, .ion-thumbsdown[_ngcontent-%COMP%]:before, .ion-thumbsup[_ngcontent-%COMP%]:before, .ion-toggle[_ngcontent-%COMP%]:before, .ion-toggle-filled[_ngcontent-%COMP%]:before, .ion-transgender[_ngcontent-%COMP%]:before, .ion-trash-a[_ngcontent-%COMP%]:before, .ion-trash-b[_ngcontent-%COMP%]:before, .ion-trophy[_ngcontent-%COMP%]:before, .ion-tshirt[_ngcontent-%COMP%]:before, .ion-tshirt-outline[_ngcontent-%COMP%]:before, .ion-umbrella[_ngcontent-%COMP%]:before, .ion-university[_ngcontent-%COMP%]:before, .ion-unlocked[_ngcontent-%COMP%]:before, .ion-upload[_ngcontent-%COMP%]:before, .ion-usb[_ngcontent-%COMP%]:before, .ion-videocamera[_ngcontent-%COMP%]:before, .ion-volume-high[_ngcontent-%COMP%]:before, .ion-volume-low[_ngcontent-%COMP%]:before, .ion-volume-medium[_ngcontent-%COMP%]:before, .ion-volume-mute[_ngcontent-%COMP%]:before, .ion-wand[_ngcontent-%COMP%]:before, .ion-waterdrop[_ngcontent-%COMP%]:before, .ion-wifi[_ngcontent-%COMP%]:before, .ion-wineglass[_ngcontent-%COMP%]:before, .ion-woman[_ngcontent-%COMP%]:before, .ion-wrench[_ngcontent-%COMP%]:before, .ion-xbox[_ngcontent-%COMP%]:before {\n  display: inline-block;\n  font-family: \"Ionicons\";\n  speak: none;\n  font-style: normal;\n  font-weight: normal;\n  font-variant: normal;\n  text-transform: none;\n  text-rendering: auto;\n  line-height: 1;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale\n}\n\n.ion-android-notifications[_ngcontent-%COMP%]:before {\n  content: \"\uF39B\"\n}\n\n.hamburger[_ngcontent-%COMP%] {\n  padding: 0px 0px;\n  display: inline-block;\n  cursor: pointer;\n  transition-property: opacity, filter;\n  transition-duration: 0.15s;\n  transition-timing-function: linear;\n  font: inherit;\n  color: inherit;\n  text-transform: none;\n  background-color: transparent;\n  border: 0;\n  margin: 0;\n  overflow: visible\n}\n\n.hamburger[_ngcontent-%COMP%]:hover {\n  opacity: .7\n}\n\n.hamburger.is-active[_ngcontent-%COMP%]:hover {\n  opacity: .7\n}\n\n.hamburger.is-active[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%], .hamburger.is-active[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::before, .hamburger.is-active[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::after {\n  background-color: #3f6ad8\n}\n\n.hamburger-box[_ngcontent-%COMP%] {\n  width: 24px;\n  height: 14px;\n  display: inline-block;\n  position: relative\n}\n\n.hamburger-inner[_ngcontent-%COMP%] {\n  display: block;\n  top: 50%;\n  margin-top: -1px\n}\n\n.hamburger-inner[_ngcontent-%COMP%], .hamburger-inner[_ngcontent-%COMP%]::before, .hamburger-inner[_ngcontent-%COMP%]::after {\n  width: 24px;\n  height: 2px;\n  background-color: #3f6ad8;\n  border-radius: 10px;\n  position: absolute;\n  transition-property: transform;\n  transition-duration: 0.15s;\n  transition-timing-function: ease\n}\n\n.hamburger-inner[_ngcontent-%COMP%]::before, .hamburger-inner[_ngcontent-%COMP%]::after {\n  content: \"\";\n  display: block\n}\n\n.hamburger-inner[_ngcontent-%COMP%]::before {\n  top: -6px\n}\n\n.hamburger-inner[_ngcontent-%COMP%]::after {\n  bottom: -6px\n}\n\n.hamburger--elastic[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%] {\n  top: 1px;\n  transition-duration: 0.275s;\n  transition-timing-function: cubic-bezier(0.68, -0.55, 0.265, 1.55)\n}\n\n.hamburger--elastic[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::before {\n  top: 6px;\n  transition: opacity 0.125s 0.275s ease\n}\n\n.hamburger--elastic[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::after {\n  top: 12px;\n  transition: transform 0.275s cubic-bezier(0.68, -0.55, 0.265, 1.55)\n}\n\n.hamburger--elastic.is-active[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%] {\n  transform: translate3d(0, 6px, 0) rotate(135deg);\n  transition-delay: 0.075s\n}\n\n.hamburger--elastic.is-active[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::before {\n  transition-delay: 0s;\n  opacity: 0\n}\n\n.hamburger--elastic.is-active[_ngcontent-%COMP%]   .hamburger-inner[_ngcontent-%COMP%]::after {\n  transform: translate3d(0, -12px, 0) rotate(-270deg);\n  transition-delay: 0.075s\n}\n\n@media only screen and (max-width: 1320px) {\n  .header-user-info[_ngcontent-%COMP%] {\n    display: none\n  }\n}\n\n@media (max-width: 991.98px) {\n  .app-main[_ngcontent-%COMP%] {\n    display: block\n  }\n\n  .dropdown-menu[_ngcontent-%COMP%]::before, .dropdown-menu[_ngcontent-%COMP%]::after {\n    display: none\n  }\n\n  .app-sidebar[_ngcontent-%COMP%] {\n    flex: 0 0 280px !important;\n    width: 280px !important;\n    transform: translateX(-280px);\n    position: fixed\n  }\n\n  .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n    display: none\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%] {\n    transform: translateX(0)\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   .app-sidebar__heading[_ngcontent-%COMP%] {\n    text-indent: initial\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   .app-sidebar__heading[_ngcontent-%COMP%]::before {\n    display: none\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n    text-indent: initial;\n    padding: 0 1.5rem 0 45px\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   .metismenu-icon[_ngcontent-%COMP%] {\n    text-indent: initial;\n    left: 5px;\n    margin-left: 0\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   .metismenu-state-icon[_ngcontent-%COMP%] {\n    visibility: visible\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]::before {\n    display: block\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n    padding-left: 1em\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   ul.mm-show[_ngcontent-%COMP%] {\n    padding: .5em 0 0 2rem\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-sidebar__inner[_ngcontent-%COMP%]   ul.mm-show[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]    > a[_ngcontent-%COMP%] {\n    height: 2rem;\n    line-height: 2rem\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n    width: auto !important\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%]   .logo-src[_ngcontent-%COMP%] {\n    width: 97px !important;\n    margin-left: auto;\n    margin-right: 0\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .fixed-sidebar[_ngcontent-%COMP%]   .app-sidebar[_ngcontent-%COMP%] {\n    height: 100%\n  }\n\n  .sidebar-mobile-open[_ngcontent-%COMP%]   .sidebar-mobile-overlay[_ngcontent-%COMP%] {\n    display: block\n  }\n\n  .app-main[_ngcontent-%COMP%]   .app-main__outer[_ngcontent-%COMP%] {\n    padding-left: 0 !important\n  }\n\n  .app-header[_ngcontent-%COMP%] {\n    justify-content: space-between\n  }\n\n  .app-header[_ngcontent-%COMP%]   .app-header__logo[_ngcontent-%COMP%] {\n    display: none;\n    order: 2;\n    background: transparent !important;\n    border: 0 !important\n  }\n\n  .app-header[_ngcontent-%COMP%]   .app-header__content[_ngcontent-%COMP%] {\n    visibility: hidden;\n    opacity: 0;\n    box-shadow: 0 0.46875rem 2.1875rem rgba(4, 9, 20, 0.03), 0 0.9375rem 1.40625rem rgba(4, 9, 20, 0.03), 0 0.25rem 0.53125rem rgba(4, 9, 20, 0.05), 0 0.125rem 0.1875rem rgba(4, 9, 20, 0.03);\n    position: absolute;\n    left: 5%;\n    width: 90%;\n    top: 0;\n    transition: all .2s;\n    background: #fff;\n    border-radius: 50px;\n    padding: 0 10px;\n    overflow: hidden\n  }\n\n  .app-header[_ngcontent-%COMP%]   .app-header__content[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%] {\n    margin-left: .5rem;\n    padding: 0 .5rem\n  }\n\n  .app-header[_ngcontent-%COMP%]   .app-header__content[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]   .hamburger-box[_ngcontent-%COMP%] {\n    margin-top: 5px\n  }\n\n  .app-header[_ngcontent-%COMP%]   .app-header__content[_ngcontent-%COMP%]   .header-btn-lg[_ngcontent-%COMP%]    + .header-btn-lg[_ngcontent-%COMP%] {\n    display: none\n  }\n\n  .app-header[_ngcontent-%COMP%]   .app-header__content[_ngcontent-%COMP%]   .app-header-left[_ngcontent-%COMP%]   .nav[_ngcontent-%COMP%] {\n    display: none\n  }\n\n  .app-header[_ngcontent-%COMP%]   .app-header__content.header-mobile-open[_ngcontent-%COMP%] {\n    visibility: visible;\n    opacity: 1;\n    top: 80px\n  }\n\n  .app-header[_ngcontent-%COMP%]   .app-header__mobile-menu[_ngcontent-%COMP%] {\n    display: flex;\n    order: 1\n  }\n\n  .app-header[_ngcontent-%COMP%]   .app-header__menu[_ngcontent-%COMP%] {\n    display: flex;\n    order: 3\n  }\n\n  .app-header.header-text-light[_ngcontent-%COMP%]   .app-header__menu[_ngcontent-%COMP%]    > span[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%], .app-header.header-text-light[_ngcontent-%COMP%]   .app-header__menu[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%] {\n    background: rgba(255, 255, 255, 0.1);\n    border-color: rgba(255, 255, 255, 0.1)\n  }\n\n  .app-header.header-text-light[_ngcontent-%COMP%]   .header-mobile-open[_ngcontent-%COMP%] {\n    background: #343a40\n  }\n\n  .app-page-title[_ngcontent-%COMP%] {\n    text-align: center\n  }\n\n  .app-page-title[_ngcontent-%COMP%]   .page-title-heading[_ngcontent-%COMP%], .app-page-title[_ngcontent-%COMP%]   .page-title-wrapper[_ngcontent-%COMP%] {\n    margin: 0 auto;\n    display: block\n  }\n\n  .app-page-title[_ngcontent-%COMP%]   .page-title-actions[_ngcontent-%COMP%] {\n    margin: 15px auto 0\n  }\n\n  .app-page-title[_ngcontent-%COMP%]   .page-title-actions[_ngcontent-%COMP%]   .breadcrumb-item[_ngcontent-%COMP%], .app-page-title[_ngcontent-%COMP%]   .page-title-actions[_ngcontent-%COMP%]   .breadcrumb[_ngcontent-%COMP%], .app-page-title[_ngcontent-%COMP%]   .page-title-subheading[_ngcontent-%COMP%]   .breadcrumb-item[_ngcontent-%COMP%], .app-page-title[_ngcontent-%COMP%]   .page-title-subheading[_ngcontent-%COMP%]   .breadcrumb[_ngcontent-%COMP%] {\n    display: inline-block\n  }\n\n  .app-footer[_ngcontent-%COMP%]   .app-footer__inner[_ngcontent-%COMP%]   .app-footer-right[_ngcontent-%COMP%] {\n    display: none\n  }\n\n  .app-footer[_ngcontent-%COMP%]   .app-footer__inner[_ngcontent-%COMP%]   .app-footer-left[_ngcontent-%COMP%] {\n    width: 100%\n  }\n\n  .app-footer[_ngcontent-%COMP%]   .app-footer__inner[_ngcontent-%COMP%]   .app-footer-left[_ngcontent-%COMP%]   .footer-dots[_ngcontent-%COMP%] {\n    margin: 0 auto\n  }\n\n  .widget-content[_ngcontent-%COMP%]   .widget-numbers[_ngcontent-%COMP%] {\n    font-size: 1.6rem;\n    line-height: 1\n  }\n\n  .slick-slider-sm[_ngcontent-%COMP%]   .slick-slider[_ngcontent-%COMP%] {\n    max-width: 650px !important\n  }\n\n  .bg-transparent.list-group-item[_ngcontent-%COMP%] {\n    border-color: transparent\n  }\n\n  .tabs-lg-alternate.card-header[_ngcontent-%COMP%]    > .nav[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%]   .widget-number[_ngcontent-%COMP%] {\n    font-size: 1.5rem\n  }\n\n  .page-title-head[_ngcontent-%COMP%] {\n    display: block\n  }\n}\n\n@media (max-width: 991.98px) {\n  .app-page-title[_ngcontent-%COMP%]   .page-title-icon[_ngcontent-%COMP%], .ui-theme-settings[_ngcontent-%COMP%] {\n    display: none\n  }\n\n}\n\n@media (max-width: 767.98px) {\n  .app-main[_ngcontent-%COMP%]   .app-main__inner[_ngcontent-%COMP%] {\n    padding: 15px 15px 0\n  }\n\n  .mbg-3[_ngcontent-%COMP%], body[_ngcontent-%COMP%]   .card.mb-3[_ngcontent-%COMP%] {\n    margin-bottom: 15px !important\n  }\n\n  .app-page-title[_ngcontent-%COMP%] {\n    padding: 15px;\n    margin: -15px -15px 15px\n  }\n\n  .app-page-title[_ngcontent-%COMP%]    + .body-tabs-layout[_ngcontent-%COMP%] {\n    margin-top: -15px !important\n  }\n}\n\n\n.closed-sidebar.fixed-sidebar[_ngcontent-%COMP%]   .app-main__outer[_ngcontent-%COMP%] {\n  padding-left: 80px !important;\n}\n\n.card[_ngcontent-%COMP%] {\n  border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0;\n}\n\n.card-header[_ngcontent-%COMP%] {\n  text-transform: uppercase;\n  color: rgba(13, 27, 62, 0.7);\n  font-weight: bold;\n  font-size: .88rem;\n  background-color: white;\n\n  display: flex;\n  align-items: center;\n  border-bottom-width: 1px;\n  padding-top: 0;\n  padding-bottom: 0;\n  padding-right: .625rem;\n  height: 3.5rem;\n}\n\n.card-body[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n  padding: 1.25rem;\n  -ms-flex: 1 1 auto;\n  min-height: 1px;\n}\n\n.table[_ngcontent-%COMP%] {\n  width: 100%;\n  margin-bottom: 1rem;\n  color: #212529;\n}\n\n.table-bordered[_ngcontent-%COMP%] {\n  border: 1px solid #adafb2;\n}\n\n.card-footer[_ngcontent-%COMP%] {\n  background-color: white;\n}\n\ntbody.custom-hover[_ngcontent-%COMP%]    > tr[_ngcontent-%COMP%]:hover {\n  background-color: #E0F3FF;\n  transition: .2s;\n}\n\n.bck-img[_ngcontent-%COMP%] {\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 100% 100%;\n}\n\n.opacity[_ngcontent-%COMP%] {\n  opacity: 1 !important;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC9zdHVkZW50LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZUFBZTtBQUNmLHFHQUFxRzs7O0FBR3JHO0VBQ0UscUNBQXFDO0VBQ3JDLG1CQUFtQjtFQUNuQixjQUFjO0VBQ2QsbUJBQW1CO0VBQ25CLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxhQUFhO0FBQ2Y7O0FBRUE7RUFDRSx3QkFBd0I7RUFDeEIsZ0JBQWdCO0VBQ2hCLHFCQUFxQjtFQUNyQixZQUFZO0FBQ2Q7OztBQUdBOztFQUVFO0lBQ0Usd0JBQXdCO0VBQzFCO0FBQ0Y7QUFDQTtFQUNFLCtIQUErSDtFQUMvSCxrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFlBQVk7QUFDZDs7QUFFQTtFQUNFLHVCQUF1QjtFQUN2QixpQkFBaUI7RUFDakIsOEJBQThCO0VBQzlCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLGVBQWU7RUFDZixhQUFhO0FBQ2Y7O0FBRUE7RUFDRSxTQUFTO0VBQ1Qsa01BQWtNO0VBQ2xNLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEIsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCxnQkFBZ0I7RUFDaEI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLHFCQUFxQjtFQUNyQixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLGtCQUFrQjtFQUNsQixzQkFBc0I7RUFDdEIseUJBQWlCO1VBQWpCLGlCQUFpQjtFQUNqQiw2QkFBNkI7RUFDN0IsNkJBQTZCO0VBQzdCLHVCQUF1QjtFQUN2QixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLHFCQUFxQjtFQUNyQjtBQUNGOztBQUVBO0VBQ0U7SUFDRTtFQUNGO0FBQ0Y7OztBQUdBO0VBQ0UsVUFBVTtFQUNWO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7O0FBR0E7RUFDRSxXQUFXO0VBQ1gseUJBQXlCO0VBQ3pCO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1gseUJBQXlCO0VBQ3pCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYLHlCQUF5QjtFQUN6QjtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYLHlCQUF5QjtFQUN6QjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGNBQWM7RUFDZDtBQUNGOztBQUVBO0VBQ0UsMEJBQTBCO0VBQzFCO0FBQ0Y7O0FBRUE7RUFDRSxjQUFjO0VBQ2Q7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBcUI7RUFDckIsbUJBQW1CO0VBQ25CLHNCQUFzQjtFQUN0QixXQUFXO0VBQ1gsc0JBQXNCO0VBQ3RCLG9DQUFvQztFQUNwQyxnQkFBZ0I7RUFDaEI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsU0FBUztFQUNULE9BQU87RUFDUCxhQUFhO0VBQ2IsYUFBYTtFQUNiLFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLG1CQUFtQjtFQUNuQixpQkFBaUI7RUFDakIsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixnQkFBZ0I7RUFDaEIsc0JBQXNCO0VBQ3RCLDRCQUE0QjtFQUM1QixxQ0FBcUM7RUFDckM7QUFDRjs7QUFFQTtFQUNFLFFBQVE7RUFDUjtBQUNGOztBQUVBO0VBQ0U7SUFDRSxRQUFRO0lBQ1I7RUFDRjtBQUNGOztBQUVBO0VBQ0U7SUFDRSxRQUFRO0lBQ1I7RUFDRjtBQUNGOztBQUVBO0VBQ0U7SUFDRSxRQUFRO0lBQ1I7RUFDRjtBQUNGOztBQUVBO0VBQ0U7SUFDRSxRQUFRO0lBQ1I7RUFDRjtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFLFdBQVc7SUFDWDtFQUNGO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFLFdBQVc7SUFDWDtFQUNGO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFLFdBQVc7SUFDWDtFQUNGO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFLFdBQVc7SUFDWDtFQUNGO0FBQ0Y7O0FBRUE7RUFDRSxTQUFTO0VBQ1QsWUFBWTtFQUNaLGFBQWE7RUFDYjtBQUNGOztBQUVBO0VBQ0UscUJBQXFCO0VBQ3JCLG1CQUFtQjtFQUNuQixzQkFBc0I7RUFDdEIsV0FBVztFQUNYLGFBQWE7RUFDYixvQ0FBb0M7RUFDcEMseUJBQXlCO0VBQ3pCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLGNBQWM7RUFDZDtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkLHFCQUFxQjtFQUNyQjtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLG9CQUFvQjtFQUNwQjtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSwwQkFBMEI7RUFDMUI7QUFDRjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6QjtBQUNGOzs7QUFHQTtFQUNFLGFBQWE7RUFDYixlQUFlO0VBQ2YsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQjtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkLG9CQUFvQjtFQUNwQjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSw2QkFBNkI7RUFDN0IsOEJBQThCO0VBQzlCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkLDZCQUE2QjtFQUM3QjtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkLHNCQUFzQjtFQUN0QjtBQUNGOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLHlCQUF5QjtFQUN6QjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkO0FBQ0Y7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsWUFBWTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixhQUFhO0VBQ2IsZUFBZTtFQUNmLG1CQUFtQjtFQUNuQiw4QkFBOEI7RUFDOUI7QUFDRjs7QUFFQTtFQUNFLGFBQWE7RUFDYixlQUFlO0VBQ2YsbUJBQW1CO0VBQ25CO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBcUI7RUFDckIscUJBQXFCO0VBQ3JCLHdCQUF3QjtFQUN4QixrQkFBa0I7RUFDbEIsa0JBQWtCO0VBQ2xCLG9CQUFvQjtFQUNwQjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQjtBQUNGOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEI7QUFDRjs7QUFFQTtFQUNFLHFCQUFxQjtFQUNyQixrQkFBa0I7RUFDbEI7QUFDRjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixZQUFZO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLHNCQUFzQjtFQUN0QixrQkFBa0I7RUFDbEIsY0FBYztFQUNkLDZCQUE2QjtFQUM3Qiw2QkFBNkI7RUFDN0I7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UscUJBQXFCO0VBQ3JCLFlBQVk7RUFDWixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLFdBQVc7RUFDWCxtQ0FBbUM7RUFDbkM7QUFDRjs7QUFFQTtFQUNFO0lBQ0UsZ0JBQWdCO0lBQ2hCO0VBQ0Y7QUFDRjs7QUFFQTtFQUNFO0lBQ0UscUJBQXFCO0lBQ3JCO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFLG9CQUFvQjtJQUNwQjtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFLHdCQUF3QjtJQUN4QjtFQUNGOztFQUVBO0lBQ0U7RUFDRjtBQUNGOztBQUVBO0VBQ0U7SUFDRSxnQkFBZ0I7SUFDaEI7RUFDRjtBQUNGOztBQUVBO0VBQ0U7SUFDRSxxQkFBcUI7SUFDckI7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGOztFQUVBO0lBQ0Usb0JBQW9CO0lBQ3BCO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGOztFQUVBO0lBQ0Usd0JBQXdCO0lBQ3hCO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFLGdCQUFnQjtJQUNoQjtFQUNGO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFLHFCQUFxQjtJQUNyQjtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRSxvQkFBb0I7SUFDcEI7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRSx3QkFBd0I7SUFDeEI7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7QUFDRjs7QUFFQTtFQUNFO0lBQ0UsZ0JBQWdCO0lBQ2hCO0VBQ0Y7QUFDRjs7QUFFQTtFQUNFO0lBQ0UscUJBQXFCO0lBQ3JCO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFLG9CQUFvQjtJQUNwQjtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFLHdCQUF3QjtJQUN4QjtFQUNGOztFQUVBO0lBQ0U7RUFDRjtBQUNGOztBQUVBO0VBQ0UscUJBQXFCO0VBQ3JCO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0Usb0JBQW9CO0VBQ3BCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0Usd0JBQXdCO0VBQ3hCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UscUJBQXFCO0VBQ3JCLG1CQUFtQjtFQUNuQixjQUFjO0VBQ2QsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLHdCQUF3QjtFQUN4QjtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxjQUFjO0VBQ2Q7QUFDRjs7QUFFQTtFQUNFLGNBQWM7RUFDZDtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QjtBQUNGOztBQUVBO0VBQ0UsMEJBQTBCO0VBQzFCLDBCQUEwQjtFQUMxQixtQ0FBbUM7RUFDbkM7QUFDRjs7QUFFQTtFQUNFLFlBQVk7RUFDWixhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLHFCQUFxQjtFQUNyQixrQkFBa0I7RUFDbEIsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQixxQkFBcUI7RUFDckIsT0FBTztFQUNQLGlCQUFpQjtFQUNqQjtBQUNGOztBQUVBO0VBQ0UsYUFBYTtFQUNiO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBbUI7RUFDbkIsYUFBYTtFQUNiO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGlCQUFpQjtFQUNqQixZQUFZO0VBQ1osWUFBWTtFQUNaLGFBQWE7RUFDYixtQkFBbUI7RUFDbkI7QUFDRjs7QUFFQTtFQUNFLFlBQVk7RUFDWixZQUFZO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLGFBQWE7RUFDYixpQkFBaUI7RUFDakIsWUFBWTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSxlQUFlO0VBQ2YsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBaUI7RUFDakI7QUFDRjs7QUFFQTtFQUNFLGFBQWE7RUFDYjtBQUNGOztBQUVBO0VBQ0UsU0FBUztFQUNULFlBQVk7RUFDWixXQUFXO0VBQ1gsa0JBQWtCO0VBQ2xCO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBbUI7RUFDbkIsa0JBQWtCO0VBQ2xCLFVBQVU7RUFDVixXQUFXO0VBQ1gsWUFBWTtFQUNaLGdCQUFnQjtFQUNoQjtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLFFBQVE7RUFDUixTQUFTO0VBQ1Q7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWCx1QkFBdUI7RUFDdkI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFO0VBQ0Y7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLFFBQVE7RUFDUixVQUFVO0VBQ1Y7QUFDRjs7QUFFQTtFQUNFLHFCQUFxQjtFQUNyQixtQkFBbUI7RUFDbkIsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQjtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLFVBQVU7RUFDVixRQUFRO0VBQ1IsbUJBQW1CO0VBQ25CLFVBQVU7RUFDVixZQUFZO0VBQ1osaUJBQWlCO0VBQ2pCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsMENBQTBDO0VBQzFDO0FBQ0Y7O0FBRUE7RUFDRSwrQ0FBK0M7RUFDL0MsbUJBQW1CO0VBQ25CO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0Usb0NBQW9DO0VBQ3BDO0FBQ0Y7O0FBRUE7RUFDRSx5Q0FBeUM7RUFDekMsbUJBQW1CO0VBQ25CO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLFlBQVk7RUFDWixhQUFhO0VBQ2IsV0FBVztFQUNYLGdCQUFnQjtFQUNoQixnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsaUJBQWlCO0VBQ2pCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsT0FBTztFQUNQLE1BQU07RUFDTixZQUFZO0VBQ1osV0FBVztFQUNYLGFBQWE7RUFDYixzQkFBc0I7RUFDdEI7QUFDRjs7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixPQUFPO0VBQ1AsTUFBTTtFQUNOLGFBQWE7RUFDYjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6QixnQkFBZ0I7RUFDaEIsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixjQUFjO0VBQ2QsbUJBQW1CO0VBQ25CO0FBQ0Y7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsZUFBZTtFQUNmLFdBQVc7RUFDWCxZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLFdBQVc7RUFDWCxPQUFPO0VBQ1AsTUFBTTtFQUNOO0FBQ0Y7O0FBRUE7RUFDRSxTQUFTO0VBQ1QsVUFBVTtFQUNWLGtCQUFrQjtFQUNsQjtBQUNGOztBQUVBO0VBQ0UsWUFBWTtFQUNaLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsU0FBUztFQUNULE9BQU87RUFDUCxRQUFRO0VBQ1I7QUFDRjs7O0FBR0E7RUFDRSxVQUFVO0VBQ1Y7QUFDRjs7O0FBR0E7RUFDRTtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLFNBQVM7RUFDVCxnQkFBZ0I7RUFDaEIsZ0NBQWdDO0VBQ2hDLHlCQUF5QjtFQUN6QjtBQUNGOztBQUVBO0VBQ0UsU0FBUztFQUNULFVBQVU7RUFDVixrQkFBa0I7RUFDbEI7QUFDRjs7QUFFQTtFQUNFLGNBQWM7RUFDZCxtQkFBbUI7RUFDbkIsY0FBYztFQUNkLHdCQUF3QjtFQUN4QixrQkFBa0I7RUFDbEIscUJBQXFCO0VBQ3JCLGNBQWM7RUFDZCxtQkFBbUI7RUFDbkIsbUJBQW1CO0VBQ25CO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBbUI7RUFDbkI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsaUJBQWlCO0FBQ25COztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGNBQWM7RUFDZCxtQkFBbUI7RUFDbkI7QUFDRjs7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsWUFBWTtFQUNaLGlCQUFpQjtFQUNqQixrQkFBa0I7RUFDbEIsU0FBUztFQUNULFFBQVE7RUFDUixpQkFBaUI7RUFDakIsaUJBQWlCO0VBQ2pCLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UsMkJBQTJCO0VBQzNCLFVBQVU7RUFDVjtBQUNGOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsWUFBWTtFQUNaLFVBQVU7RUFDVixVQUFVO0VBQ1YsbUJBQW1CO0VBQ25CLGtCQUFrQjtFQUNsQixVQUFVO0VBQ1YsTUFBTTtFQUNOO0FBQ0Y7O0FBRUE7RUFDRSxjQUFjO0VBQ2QsWUFBWTtFQUNaLGlCQUFpQjtFQUNqQjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxjQUFjO0VBQ2QsbUJBQW1CO0VBQ25CO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxxQ0FBcUM7RUFDckM7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsK0JBQStCO0VBQy9CO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSwrQkFBK0I7RUFDL0I7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGVBQWU7RUFDZjtBQUNGOztBQUVBO0VBQ0UsVUFBVTtFQUNWO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSx3QkFBd0I7RUFDeEIsV0FBVztFQUNYLGVBQWU7RUFDZixjQUFjO0VBQ2Q7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsa0JBQWtCO0VBQ2xCLFFBQVE7RUFDUixPQUFPO0VBQ1AsV0FBVztFQUNYLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkI7QUFDRjs7QUFFQTtFQUNFLG1CQUFtQjtFQUNuQjtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkLFNBQVM7RUFDVDtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLDBCQUEwQjtFQUMxQjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7OztBQUdBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLG9CQUFvQjtFQUNwQjtBQUNGOztBQUVBO0VBQ0Usb0JBQW9CO0VBQ3BCLFNBQVM7RUFDVDtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixZQUFZO0VBQ1o7QUFDRjs7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixZQUFZO0VBQ1o7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsYUFBYTtFQUNiLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLGNBQWM7RUFDZDtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFOztBQUVGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLE9BQU87RUFDUCxhQUFhO0VBQ2IsVUFBVTtFQUNWO0FBQ0Y7O0FBRUE7RUFDRSxPQUFPO0VBQ1Asc0JBQXNCO0VBQ3RCLGFBQWE7RUFDYjtBQUNGOztBQUVBO0VBQ0Usb0JBQW9CO0VBQ3BCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBb0I7RUFDcEIsaUJBQWlCO0VBQ2pCLG1CQUFtQjtFQUNuQixnQ0FBZ0M7RUFDaEMsa0JBQWtCO0VBQ2xCLHFCQUFxQjtFQUNyQjtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkIsbUJBQW1CO0VBQ25CLFdBQVc7RUFDWCxPQUFPO0VBQ1AsWUFBWTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsZUFBZTtFQUNmLFdBQVc7RUFDWCxTQUFTO0VBQ1QsT0FBTztFQUNQO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxhQUFhO0VBQ2Isd0JBQXdCO0VBQ3hCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLGFBQWE7RUFDYjtBQUNGOztBQUVBO0VBQ0UsU0FBUztFQUNUO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLGFBQWE7RUFDYixxQkFBcUI7RUFDckI7QUFDRjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakI7QUFDRjs7QUFFQTtFQUNFLFVBQVU7RUFDVixlQUFlO0VBQ2Y7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxTQUFTO0VBQ1QsVUFBVTtFQUNWO0FBQ0Y7O0FBRUE7RUFDRSxlQUFlO0VBQ2YsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQixxQkFBcUI7RUFDckIsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLDBMQUEwTDtFQUMxTCxxQkFBcUI7RUFDckIsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxTQUFTO0VBQ1QsMkJBQTJCO0VBQzNCLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxpRUFBaUU7RUFDakUsdUJBQXVCO0VBQ3ZCO0FBQ0Y7O0FBRUE7RUFDRSwwTEFBMEw7RUFDMUw7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsb0JBQW9CO0VBQ3BCLGNBQWM7RUFDZDtBQUNGOztBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIsdURBQXVEO0VBQ3ZELGVBQWU7RUFDZixVQUFVO0VBQ1Y7QUFDRjs7QUFFQTtFQUNFLGVBQWU7RUFDZixxQkFBcUI7RUFDckIsV0FBVztFQUNYLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsbUJBQW1CO0VBQ25CO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0Usb0JBQW9CO0VBQ3BCO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBb0I7RUFDcEIscUJBQXFCO0VBQ3JCLDRCQUE0QjtFQUM1QjtBQUNGOztBQUVBO0VBQ0UsNEJBQTRCO0VBQzVCO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEI7QUFDRjs7QUFFQTtFQUNFLG1CQUFtQjtFQUNuQjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSw4QkFBOEI7RUFDOUI7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkIscUJBQXFCO0VBQ3JCLGtCQUFrQjtFQUNsQjtBQUNGOztBQUVBO0VBQ0UsbUJBQW1CO0VBQ25CLHFCQUFxQjtFQUNyQjtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLE9BQU87RUFDUCxNQUFNO0VBQ04sWUFBWTtFQUNaLFdBQVc7RUFDWCxVQUFVO0VBQ1YsWUFBWTtFQUNaLHNCQUFzQjtFQUN0QjtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLG1CQUFtQjtFQUNuQixvQkFBb0I7RUFDcEIsYUFBYTtFQUNiLHFCQUFxQjtFQUNyQixtQkFBbUI7RUFDbkI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCO0FBQ0Y7O0FBRUE7RUFDRSxvTUFBb007RUFDcE0sZUFBZTtFQUNmO0FBQ0Y7O0FBRUE7RUFDRSxzQkFBc0I7RUFDdEI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixRQUFRO0VBQ1IsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsU0FBUztFQUNULDJCQUEyQjtFQUMzQiw2QkFBNkI7RUFDN0IsdUJBQXVCO0VBQ3ZCLGdCQUFnQjtFQUNoQixxQkFBcUI7RUFDckIsV0FBVztFQUNYLGtCQUFrQjtFQUNsQixpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIsdURBQXVEO0VBQ3ZEO0FBQ0Y7O0FBRUE7RUFDRSxjQUFjO0VBQ2QsZUFBZTtFQUNmLFdBQVc7RUFDWCxrQkFBa0I7RUFDbEIsWUFBWTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLG9CQUFvQjtFQUNwQixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsZUFBZTtFQUNmLFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkO0FBQ0Y7O0FBRUE7RUFDRSxjQUFjO0VBQ2Q7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxjQUFjO0VBQ2Q7QUFDRjs7QUFFQTtFQUNFLGNBQWM7RUFDZDtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCLHlCQUF5QjtFQUN6QixpQkFBaUI7RUFDakI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBbUI7RUFDbkIsVUFBVTtFQUNWLFVBQVU7RUFDVixXQUFXO0VBQ1gsNkJBQTZCO0VBQzdCLG1CQUFtQjtFQUNuQjtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsWUFBWTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsV0FBVztFQUNYLFlBQVk7RUFDWixxQkFBcUI7RUFDckIsa0JBQWtCO0VBQ2xCLFNBQVM7RUFDVCxRQUFRO0VBQ1IscUJBQXFCO0VBQ3JCO0FBQ0Y7O0FBRUE7RUFDRSxVQUFVO0VBQ1Y7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsc0JBQXNCO0VBQ3RCLFNBQVM7RUFDVCxXQUFXO0VBQ1gsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFLFVBQVU7RUFDVixXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFLFNBQVM7RUFDVDtBQUNGOztBQUVBO0VBQ0UsUUFBUTtFQUNSO0FBQ0Y7O0FBRUE7RUFDRSxRQUFRO0VBQ1I7QUFDRjs7QUFFQTtFQUNFLFNBQVM7RUFDVDtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLFNBQVM7RUFDVDtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYLGtCQUFrQjtFQUNsQjtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYLGNBQWM7RUFDZDtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYLGtCQUFrQjtFQUNsQixNQUFNO0VBQ04sVUFBVTtFQUNWLFlBQVk7RUFDWixVQUFVO0VBQ1YsbUJBQW1CO0VBQ25CO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEI7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxjQUFjO0VBQ2Q7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsY0FBYztFQUNkO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIseUJBQXlCO0VBQ3pCLGlCQUFpQjtFQUNqQixnQkFBZ0I7RUFDaEI7QUFDRjs7QUFFQTtFQUNFLGNBQWM7RUFDZDtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsTUFBTTtFQUNOLG1CQUFtQjtFQUNuQixpQkFBaUI7RUFDakIsY0FBYztFQUNkLG1CQUFtQjtFQUNuQjtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLE1BQU07RUFDTjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGVBQWU7RUFDZjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsa0JBQWtCO0VBQ2xCLE1BQU07RUFDTixVQUFVO0VBQ1YsWUFBWTtFQUNaLFVBQVU7RUFDVixtQkFBbUI7RUFDbkI7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixPQUFPO0VBQ1A7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLG1CQUFtQjtFQUNuQixpQkFBaUI7RUFDakIsbUJBQW1CO0VBQ25CLDBCQUEwQjtFQUMxQixrQkFBa0I7RUFDbEIsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQjtBQUNGOztBQUVBO0VBQ0UsY0FBYztFQUNkLGlCQUFpQjtFQUNqQjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQjtBQUNGOztBQUVBO0VBQ0UsWUFBWTtFQUNaLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkIsa0JBQWtCO0VBQ2xCLFNBQVM7RUFDVCxRQUFRO0VBQ1IsY0FBYztFQUNkO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixTQUFTO0VBQ1QsUUFBUTtFQUNSLHFCQUFxQjtFQUNyQixjQUFjO0VBQ2QsVUFBVTtFQUNWLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsbUJBQW1CO0VBQ25CO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsbUJBQW1CO0VBR25CO0FBQ0Y7O0FBRUE7RUFDRTtJQUdFO0VBQ0Y7QUFDRjs7QUFFQTtFQUNFO0lBQ0UsbUJBQW1CO0lBR25CO0VBQ0Y7QUFDRjs7QUFFQTtFQUNFLGFBQWE7RUFDYixxQkFBcUI7RUFDckIsbUJBQW1CO0VBQ25CLFdBQVc7RUFDWCxZQUFZO0VBQ1osY0FBYztFQUNkLGtCQUFrQjtFQUNsQjtBQUNGOztBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLFdBQVc7RUFDWCxVQUFVO0VBQ1Y7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGtCQUFrQjtFQUNsQjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGFBQWE7RUFDYixtQkFBbUI7RUFDbkI7QUFDRjs7QUFFQTtFQUNFLGFBQWE7RUFDYixPQUFPO0VBQ1Asa0JBQWtCO0VBQ2xCO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1g7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCLGlCQUFpQjtFQUNqQjtBQUNGOztBQUVBO0VBQ0UsYUFBYTtFQUNiLE9BQU87RUFDUDtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLHFCQUFxQjtFQUNyQixXQUFXO0VBQ1gsYUFBYTtFQUNiLHFCQUFxQjtFQUNyQjtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixVQUFVO0VBQ1Y7QUFDRjs7QUFFQTtFQUNFLG1CQUFtQjtFQUNuQjtBQUNGOzs7QUFHQTtFQUNFLGFBQWE7RUFDYjtBQUNGOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEI7QUFDRjs7QUFFQTtFQUNFLGFBQWE7RUFDYjtBQUNGOztBQUVBO0VBQ0UsYUFBYTtFQUNiO0FBQ0Y7O0FBRUE7RUFDRSxhQUFhO0VBQ2I7QUFDRjs7QUFFQTtFQUNFLGFBQWE7RUFDYjtBQUNGOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLFdBQVc7RUFDWDtBQUNGOztBQUVBO0VBQ0UsdUJBQXVCO0VBQ3ZCLHdCQUF1QztFQUN2QyxtTEFBK087RUFDL08sbUJBQW1CO0VBQ25CO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBcUI7RUFDckIsdUJBQXVCO0VBQ3ZCLFdBQVc7RUFDWCxrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQixvQkFBb0I7RUFDcEIsb0JBQW9CO0VBQ3BCLGNBQWM7RUFDZCxtQ0FBbUM7RUFDbkM7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIscUJBQXFCO0VBQ3JCLGVBQWU7RUFDZixvQ0FBb0M7RUFDcEMsMEJBQTBCO0VBQzFCLGtDQUFrQztFQUNsQyxhQUFhO0VBQ2IsY0FBYztFQUNkLG9CQUFvQjtFQUNwQiw2QkFBNkI7RUFDN0IsU0FBUztFQUNULFNBQVM7RUFDVDtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixxQkFBcUI7RUFDckI7QUFDRjs7QUFFQTtFQUNFLGNBQWM7RUFDZCxRQUFRO0VBQ1I7QUFDRjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxXQUFXO0VBQ1gseUJBQXlCO0VBQ3pCLG1CQUFtQjtFQUNuQixrQkFBa0I7RUFDbEIsOEJBQThCO0VBQzlCLDBCQUEwQjtFQUMxQjtBQUNGOztBQUVBO0VBQ0UsV0FBVztFQUNYO0FBQ0Y7O0FBRUE7RUFDRTtBQUNGOztBQUVBO0VBQ0U7QUFDRjs7QUFFQTtFQUNFLFFBQVE7RUFDUiwyQkFBMkI7RUFDM0I7QUFDRjs7QUFFQTtFQUNFLFFBQVE7RUFDUjtBQUNGOztBQUVBO0VBQ0UsU0FBUztFQUNUO0FBQ0Y7O0FBRUE7RUFDRSxnREFBZ0Q7RUFDaEQ7QUFDRjs7QUFFQTtFQUNFLG9CQUFvQjtFQUNwQjtBQUNGOztBQUVBO0VBQ0UsbURBQW1EO0VBQ25EO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFO0VBQ0Y7QUFDRjs7QUFFQTtFQUNFO0lBQ0U7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRSwwQkFBMEI7SUFDMUIsdUJBQXVCO0lBQ3ZCLDZCQUE2QjtJQUM3QjtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFLG9CQUFvQjtJQUNwQjtFQUNGOztFQUVBO0lBQ0Usb0JBQW9CO0lBQ3BCLFNBQVM7SUFDVDtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFLFlBQVk7SUFDWjtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFLHNCQUFzQjtJQUN0QixpQkFBaUI7SUFDakI7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRSxhQUFhO0lBQ2IsUUFBUTtJQUNSLGtDQUFrQztJQUNsQztFQUNGOztFQUVBO0lBQ0Usa0JBQWtCO0lBQ2xCLFVBQVU7SUFDViwwTEFBMEw7SUFDMUwsa0JBQWtCO0lBQ2xCLFFBQVE7SUFDUixVQUFVO0lBQ1YsTUFBTTtJQUNOLG1CQUFtQjtJQUNuQixnQkFBZ0I7SUFDaEIsbUJBQW1CO0lBQ25CLGVBQWU7SUFDZjtFQUNGOztFQUVBO0lBQ0Usa0JBQWtCO0lBQ2xCO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRSxtQkFBbUI7SUFDbkIsVUFBVTtJQUNWO0VBQ0Y7O0VBRUE7SUFDRSxhQUFhO0lBQ2I7RUFDRjs7RUFFQTtJQUNFLGFBQWE7SUFDYjtFQUNGOztFQUVBO0lBQ0Usb0NBQW9DO0lBQ3BDO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFLGNBQWM7SUFDZDtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRSxpQkFBaUI7SUFDakI7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRTtFQUNGOztFQUVBO0lBQ0U7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7QUFDRjs7QUFFQTtFQUNFO0lBQ0U7RUFDRjs7QUFFRjs7QUFFQTtFQUNFO0lBQ0U7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7O0VBRUE7SUFDRSxhQUFhO0lBQ2I7RUFDRjs7RUFFQTtJQUNFO0VBQ0Y7QUFDRjs7O0FBR0E7RUFDRSw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRSx3REFBd0Q7QUFDMUQ7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsNEJBQTRCO0VBQzVCLGlCQUFpQjtFQUNqQixpQkFBaUI7RUFDakIsdUJBQXVCOztFQUV2QixhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLHdCQUF3QjtFQUN4QixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixjQUFjO0FBQ2hCOztBQUVBO0VBQ0UsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixrQkFBa0I7RUFDbEIsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkIsY0FBYztBQUNoQjs7QUFFQTtFQUNFLHlCQUF5QjtBQUMzQjs7QUFFQTtFQUNFLHVCQUF1QjtBQUN6Qjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6QixlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsNEJBQTRCO0VBQzVCLDJCQUEyQjtFQUMzQiwwQkFBMEI7QUFDNUI7O0FBRUE7RUFDRSxxQkFBcUI7QUFDdkIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBIZWFkZXIgQ3NzICovXG4vKkBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVVidW50dTppdGFsLHdnaHRAMCw3MDA7MSw3MDAmZGlzcGxheT1zd2FwJyk7Ki9cblxuXG4jaGVhZGluZ3tcbiAgZm9udC1mYW1pbHk6ICdTaW1wbGlmaWNhJywgc2Fucy1zZXJpZjtcbiAgLypmb250LXNpemU6IDMwcHg7Ki9cbiAgY29sb3I6ICM0NjRlNTQ7XG4gIGxldHRlci1zcGFjaW5nOiAzcHg7XG4gIHdvcmQtc3BhY2luZzogOHB4O1xufVxuXG4uc2Nyb2xsLWhpZGUge1xuICBvdmVyZmxvdy15OiBzY3JvbGw7XG4gIG92ZXJmbG93LXg6IHNjcm9sbDtcbn1cblxuLnNjcm9sbC1oaWRlOjotd2Via2l0LXNjcm9sbGJhciB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5zY3JvbGwtaGlkZSB7XG4gIC1tcy1vdmVyZmxvdy1zdHlsZTogbm9uZTtcbiAgLyogSUUgYW5kIEVkZ2UgKi9cbiAgc2Nyb2xsYmFyLXdpZHRoOiBub25lO1xuICAvKiBGaXJlZm94ICovXG59XG5cblxuQG1lZGlhIChtYXgtd2lkdGg6IDk5MnB4KSB7XG5cbiAgLmhpZGVye1xuICAgIGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDtcbiAgfVxufVxuI2JhY2tncm91bmQtaW1hZ2V7XG4gIGJhY2tncm91bmQ6IHVybChcImh0dHBzOi8vaW1hZ2VzLmZpbmVhcnRhbWVyaWNhLmNvbS9pbWFnZXMvYXJ0d29ya2ltYWdlcy9tZWRpdW1sYXJnZS8xL2djLXVuaXZlcnNpdHktbGFob3JlLXp1YmFpci1xdXJlc2hpLmpwZ1wiKTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG5odG1sIHtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG4gIGxpbmUtaGVpZ2h0OiAxLjE1O1xuICAtd2Via2l0LXRleHQtc2l6ZS1hZGp1c3Q6IDEwMCU7XG4gIC13ZWJraXQtdGFwLWhpZ2hsaWdodC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwKVxufVxuXG5hcnRpY2xlLCBhc2lkZSwgZmlnY2FwdGlvbiwgZmlndXJlLCBmb290ZXIsIGhlYWRlciwgaGdyb3VwLCBtYWluLCBuYXYsIHNlY3Rpb24ge1xuICBkaXNwbGF5OiBibG9ja1xufVxuXG4uYXBwLW1haW4ge1xuICBmb250LXNpemU6IC44cmVtO1xufVxuXG51bC52ZXJ0aWNhbC1uYXYtbWVudSA+IGxpLmFwcC1zaWRlYmFyX19oZWFkaW5nIHtcbiAgY3Vyc29yOiBkZWZhdWx0O1xufVxuXG51bC52ZXJ0aWNhbC1uYXYtbWVudSA+IGxpOm5vdCguYXBwLXNpZGViYXJfX2hlYWRpbmcpIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBvdXRsaW5lOiBub25lO1xufVxuXG5ib2R5IHtcbiAgbWFyZ2luOiAwO1xuICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIFJvYm90bywgXCJIZWx2ZXRpY2EgTmV1ZVwiLCBBcmlhbCwgXCJOb3RvIFNhbnNcIiwgc2Fucy1zZXJpZiwgXCJBcHBsZSBDb2xvciBFbW9qaVwiLCBcIlNlZ29lIFVJIEVtb2ppXCIsIFwiU2Vnb2UgVUkgU3ltYm9sXCIsIFwiTm90byBDb2xvciBFbW9qaVwiO1xuICBmb250LXNpemU6IC44OHJlbTtcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgY29sb3I6ICM0OTUwNTc7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmZcbn1cblxuLnRhYmxlLWJvcmRlcmVkIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2U5ZWNlZlxufVxuXG4udGFibGUtYm9yZGVyZWQgdGgsIC50YWJsZS1ib3JkZXJlZCB0ZCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlOWVjZWZcbn1cblxuLnRhYmxlLWJvcmRlcmVkIHRoZWFkIHRoLCAudGFibGUtYm9yZGVyZWQgdGhlYWQgdGQge1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAycHhcbn1cblxuLmJ0biB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgY29sb3I6ICM0OTUwNTc7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgdXNlci1zZWxlY3Q6IG5vbmU7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcbiAgcGFkZGluZzogLjM3NXJlbSAuNzVyZW07XG4gIGZvbnQtc2l6ZTogMXJlbTtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgYm9yZGVyLXJhZGl1czogLjI1cmVtO1xuICB0cmFuc2l0aW9uOiBjb2xvciAwLjE1cywgYmFja2dyb3VuZC1jb2xvciAwLjE1cywgYm9yZGVyLWNvbG9yIDAuMTVzLCBib3gtc2hhZG93IDAuMTVzXG59XG5cbkBtZWRpYSBzY3JlZW4gYW5kIChwcmVmZXJzLXJlZHVjZWQtbW90aW9uOiByZWR1Y2UpIHtcbiAgLmJ0biB7XG4gICAgdHJhbnNpdGlvbjogbm9uZVxuICB9XG59XG5cblxuLmJ0bjpmb2N1cywgLmJ0bi5mb2N1cyB7XG4gIG91dGxpbmU6IDA7XG4gIGJveC1zaGFkb3c6IG5vbmVcbn1cblxuLmJ0bi5kaXNhYmxlZCwgLmJ0bjpkaXNhYmxlZCB7XG4gIG9wYWNpdHk6IC42NVxufVxuXG4uYnRuOm5vdCg6ZGlzYWJsZWQpOm5vdCguZGlzYWJsZWQpIHtcbiAgY3Vyc29yOiBwb2ludGVyXG59XG5cblxuLmJ0bi1wcmltYXJ5IHtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzZjZhZDg7XG4gIGJvcmRlci1jb2xvcjogIzNmNmFkOFxufVxuXG4uYnRuLXByaW1hcnk6aG92ZXIge1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzI5NTVjODtcbiAgYm9yZGVyLWNvbG9yOiAjMjY1MWJlXG59XG5cbi5idG4tcHJpbWFyeTpmb2N1cywgLmJ0bi1wcmltYXJ5LmZvY3VzIHtcbiAgYm94LXNoYWRvdzogMCAwIDAgMCByZ2JhKDkyLCAxMjgsIDIyMiwgMC41KVxufVxuXG4uYnRuLXByaW1hcnkuZGlzYWJsZWQsIC5idG4tcHJpbWFyeTpkaXNhYmxlZCB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2Y2YWQ4O1xuICBib3JkZXItY29sb3I6ICMzZjZhZDhcbn1cblxuLmJ0bi1wcmltYXJ5Om5vdCg6ZGlzYWJsZWQpOm5vdCguZGlzYWJsZWQpOmFjdGl2ZSwgLmJ0bi1wcmltYXJ5Om5vdCg6ZGlzYWJsZWQpOm5vdCguZGlzYWJsZWQpLmFjdGl2ZSwgLnNob3cgPiAuYnRuLXByaW1hcnkuZHJvcGRvd24tdG9nZ2xlIHtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtY29sb3I6ICMyNjUxYmU7XG4gIGJvcmRlci1jb2xvcjogIzI0NGNiM1xufVxuXG4uYnRuLXByaW1hcnk6bm90KDpkaXNhYmxlZCk6bm90KC5kaXNhYmxlZCk6YWN0aXZlOmZvY3VzLCAuYnRuLXByaW1hcnk6bm90KDpkaXNhYmxlZCk6bm90KC5kaXNhYmxlZCkuYWN0aXZlOmZvY3VzLCAuc2hvdyA+IC5idG4tcHJpbWFyeS5kcm9wZG93bi10b2dnbGU6Zm9jdXMge1xuICBib3gtc2hhZG93OiAwIDAgMCAwIHJnYmEoOTIsIDEyOCwgMjIyLCAwLjUpXG59XG5cbi5idG4tbGluazpob3ZlciB7XG4gIGNvbG9yOiAjMDA1NmIzO1xuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZVxufVxuXG4uYnRuLWxpbms6Zm9jdXMsIC5idG4tbGluay5mb2N1cyB7XG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICBib3gtc2hhZG93OiBub25lXG59XG5cbi5idG4tbGluazpkaXNhYmxlZCwgLmJ0bi1saW5rLmRpc2FibGVkIHtcbiAgY29sb3I6ICM2Yzc1N2Q7XG4gIHBvaW50ZXItZXZlbnRzOiBub25lXG59XG5cbi5kcm9wdXAsIC5kcm9wcmlnaHQsIC5kcm9wZG93biwgLmRyb3BsZWZ0IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlXG59XG5cbi5kcm9wZG93bi10b2dnbGU6OmFmdGVyIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBtYXJnaW4tbGVmdDogLjI1NWVtO1xuICB2ZXJ0aWNhbC1hbGlnbjogLjI1NWVtO1xuICBjb250ZW50OiBcIlwiO1xuICBib3JkZXItdG9wOiAuM2VtIHNvbGlkO1xuICBib3JkZXItcmlnaHQ6IC4zZW0gc29saWQgdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1ib3R0b206IDA7XG4gIGJvcmRlci1sZWZ0OiAuM2VtIHNvbGlkIHRyYW5zcGFyZW50XG59XG5cbi5kcm9wZG93bi10b2dnbGU6ZW1wdHk6OmFmdGVyIHtcbiAgbWFyZ2luLWxlZnQ6IDBcbn1cblxuLmRyb3Bkb3duLW1lbnUge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMTAwJTtcbiAgbGVmdDogMDtcbiAgei1pbmRleDogMTAwMDtcbiAgZGlzcGxheTogbm9uZTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIG1pbi13aWR0aDogMTVyZW07XG4gIHBhZGRpbmc6IC42NXJlbSAwO1xuICBtYXJnaW46IC4xMjVyZW0gMCAwO1xuICBmb250LXNpemU6IC44OHJlbTtcbiAgY29sb3I6ICM0OTUwNTc7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGxpc3Qtc3R5bGU6IG5vbmU7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtY2xpcDogcGFkZGluZy1ib3g7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoMCwgMCwgMCwgMC4xNSk7XG4gIGJvcmRlci1yYWRpdXM6IC4yNXJlbVxufVxuXG4uZHJvcGRvd24tbWVudS1yaWdodCB7XG4gIHJpZ2h0OiAwO1xuICBsZWZ0OiBhdXRvXG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiA1NzZweCkge1xuICAuZHJvcGRvd24tbWVudS1zbS1yaWdodCB7XG4gICAgcmlnaHQ6IDA7XG4gICAgbGVmdDogYXV0b1xuICB9XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiA3NjhweCkge1xuICAuZHJvcGRvd24tbWVudS1tZC1yaWdodCB7XG4gICAgcmlnaHQ6IDA7XG4gICAgbGVmdDogYXV0b1xuICB9XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiA5OTJweCkge1xuICAuZHJvcGRvd24tbWVudS1sZy1yaWdodCB7XG4gICAgcmlnaHQ6IDA7XG4gICAgbGVmdDogYXV0b1xuICB9XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiAxMjAwcHgpIHtcbiAgLmRyb3Bkb3duLW1lbnUteGwtcmlnaHQge1xuICAgIHJpZ2h0OiAwO1xuICAgIGxlZnQ6IGF1dG9cbiAgfVxufVxuXG4uZHJvcGRvd24tbWVudS1sZWZ0IHtcbiAgcmlnaHQ6IGF1dG87XG4gIGxlZnQ6IDBcbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDU3NnB4KSB7XG4gIC5kcm9wZG93bi1tZW51LXNtLWxlZnQge1xuICAgIHJpZ2h0OiBhdXRvO1xuICAgIGxlZnQ6IDBcbiAgfVxufVxuXG5AbWVkaWEgKG1pbi13aWR0aDogNzY4cHgpIHtcbiAgLmRyb3Bkb3duLW1lbnUtbWQtbGVmdCB7XG4gICAgcmlnaHQ6IGF1dG87XG4gICAgbGVmdDogMFxuICB9XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiA5OTJweCkge1xuICAuZHJvcGRvd24tbWVudS1sZy1sZWZ0IHtcbiAgICByaWdodDogYXV0bztcbiAgICBsZWZ0OiAwXG4gIH1cbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDEyMDBweCkge1xuICAuZHJvcGRvd24tbWVudS14bC1sZWZ0IHtcbiAgICByaWdodDogYXV0bztcbiAgICBsZWZ0OiAwXG4gIH1cbn1cblxuLmRyb3B1cCAuZHJvcGRvd24tbWVudSB7XG4gIHRvcDogYXV0bztcbiAgYm90dG9tOiAxMDAlO1xuICBtYXJnaW4tdG9wOiAwO1xuICBtYXJnaW4tYm90dG9tOiAuMTI1cmVtXG59XG5cbi5kcm9wdXAgLmRyb3Bkb3duLXRvZ2dsZTo6YWZ0ZXIge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIG1hcmdpbi1sZWZ0OiAuMjU1ZW07XG4gIHZlcnRpY2FsLWFsaWduOiAuMjU1ZW07XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIGJvcmRlci10b3A6IDA7XG4gIGJvcmRlci1yaWdodDogLjNlbSBzb2xpZCB0cmFuc3BhcmVudDtcbiAgYm9yZGVyLWJvdHRvbTogLjNlbSBzb2xpZDtcbiAgYm9yZGVyLWxlZnQ6IC4zZW0gc29saWQgdHJhbnNwYXJlbnRcbn1cblxuLmRyb3B1cCAuZHJvcGRvd24tdG9nZ2xlOmVtcHR5OjphZnRlciB7XG4gIG1hcmdpbi1sZWZ0OiAwXG59XG5cbi5kcm9wZG93bi1tZW51W3gtcGxhY2VtZW50Xj1cInRvcFwiXSwgLmRyb3Bkb3duLW1lbnVbeC1wbGFjZW1lbnRePVwicmlnaHRcIl0sIC5kcm9wZG93bi1tZW51W3gtcGxhY2VtZW50Xj1cImJvdHRvbVwiXSwgLmRyb3Bkb3duLW1lbnVbeC1wbGFjZW1lbnRePVwibGVmdFwiXSB7XG4gIHJpZ2h0OiBhdXRvO1xuICBib3R0b206IGF1dG9cbn1cblxuLmRyb3Bkb3duLW1lbnUuc2hvdyB7XG4gIGRpc3BsYXk6IGJsb2NrXG59XG5cbi5kcm9wZG93bi1oZWFkZXIge1xuICBkaXNwbGF5OiBibG9jaztcbiAgcGFkZGluZzogLjY1cmVtIDEuNXJlbTtcbiAgbWFyZ2luLWJvdHRvbTogMDtcbiAgZm9udC1zaXplOiAuOTY4cmVtO1xuICBjb2xvcjogIzZjNzU3ZDtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcFxufVxuXG4uZHJvcGRvd24taXRlbS10ZXh0IHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHBhZGRpbmc6IC40cmVtIDEuNXJlbTtcbiAgY29sb3I6ICMyMTI1Mjlcbn1cblxuLmJ0bi1ncm91cCwgLmJ0bi1ncm91cC12ZXJ0aWNhbCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGVcbn1cblxuLmJ0bi1ncm91cCA+IC5idG4sIC5idG4tZ3JvdXAtdmVydGljYWwgPiAuYnRuIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBmbGV4OiAxIDEgYXV0b1xufVxuXG4uYnRuLWdyb3VwID4gLmJ0bjpob3ZlciwgLmJ0bi1ncm91cC12ZXJ0aWNhbCA+IC5idG46aG92ZXIge1xuICB6LWluZGV4OiAxXG59XG5cbi5idG4tZ3JvdXAgPiAuYnRuOmZvY3VzLCAuYnRuLWdyb3VwID4gLmJ0bjphY3RpdmUsIC5idG4tZ3JvdXAgPiAuYnRuLmFjdGl2ZSwgLmJ0bi1ncm91cC12ZXJ0aWNhbCA+IC5idG46Zm9jdXMsIC5idG4tZ3JvdXAtdmVydGljYWwgPiAuYnRuOmFjdGl2ZSwgLmJ0bi1ncm91cC12ZXJ0aWNhbCA+IC5idG4uYWN0aXZlIHtcbiAgei1pbmRleDogMVxufVxuXG4uYnRuLWdyb3VwID4gLmJ0bjpub3QoOmZpcnN0LWNoaWxkKSwgLmJ0bi1ncm91cCA+IC5idG4tZ3JvdXA6bm90KDpmaXJzdC1jaGlsZCkge1xuICBtYXJnaW4tbGVmdDogLTFweFxufVxuXG4uYnRuLWdyb3VwID4gLmJ0bjpub3QoOmxhc3QtY2hpbGQpOm5vdCguZHJvcGRvd24tdG9nZ2xlKSwgLmJ0bi1ncm91cCA+IC5idG4tZ3JvdXA6bm90KDpsYXN0LWNoaWxkKSA+IC5idG4ge1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDBcbn1cblxuLmJ0bi1ncm91cCA+IC5idG46bm90KDpmaXJzdC1jaGlsZCksIC5idG4tZ3JvdXAgPiAuYnRuLWdyb3VwOm5vdCg6Zmlyc3QtY2hpbGQpID4gLmJ0biB7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDA7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDBcbn1cblxuXG4ubmF2IHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC13cmFwOiB3cmFwO1xuICBwYWRkaW5nLWxlZnQ6IDA7XG4gIG1hcmdpbi1ib3R0b206IDA7XG4gIGxpc3Qtc3R5bGU6IG5vbmVcbn1cblxuLm5hdi1saW5rIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHBhZGRpbmc6IC41cmVtIDFyZW1cbn1cblxuLm5hdi1saW5rOmhvdmVyLCAubmF2LWxpbms6Zm9jdXMge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmVcbn1cblxuLm5hdi1saW5rLmRpc2FibGVkIHtcbiAgY29sb3I6ICM2Yzc1N2Q7XG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICBjdXJzb3I6IGRlZmF1bHRcbn1cblxuLm5hdi10YWJzIHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkZWUyZTZcbn1cblxuLm5hdi10YWJzIC5uYXYtaXRlbSB7XG4gIG1hcmdpbi1ib3R0b206IC0xcHhcbn1cblxuLm5hdi10YWJzIC5uYXYtbGluayB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAuMjVyZW07XG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAuMjVyZW1cbn1cblxuLm5hdi10YWJzIC5uYXYtbGluazpob3ZlciwgLm5hdi10YWJzIC5uYXYtbGluazpmb2N1cyB7XG4gIGJvcmRlci1jb2xvcjogI2U5ZWNlZiAjZTllY2VmICNkZWUyZTZcbn1cblxuLm5hdi10YWJzIC5uYXYtbGluay5kaXNhYmxlZCB7XG4gIGNvbG9yOiAjNmM3NTdkO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudFxufVxuXG4ubmF2LXRhYnMgLm5hdi1saW5rLmFjdGl2ZSwgLm5hdi10YWJzIC5uYXYtaXRlbS5zaG93IC5uYXYtbGluayB7XG4gIGNvbG9yOiAjNDk1MDU3O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBib3JkZXItY29sb3I6ICNkZWUyZTYgI2RlZTJlNiAjZmZmXG59XG5cbi5uYXYtdGFicyAuZHJvcGRvd24tbWVudSB7XG4gIG1hcmdpbi10b3A6IC0xcHg7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDA7XG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAwXG59XG5cbi5uYXYtcGlsbHMgLm5hdi1saW5rIHtcbiAgYm9yZGVyLXJhZGl1czogLjI1cmVtXG59XG5cbi5uYXYtcGlsbHMgLm5hdi1saW5rLmFjdGl2ZSwgLm5hdi1waWxscyAuc2hvdyA+IC5uYXYtbGluayB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2Y2YWQ4XG59XG5cbi5uYXYtZmlsbCAubmF2LWl0ZW0ge1xuICBmbGV4OiAxIDEgYXV0bztcbiAgdGV4dC1hbGlnbjogY2VudGVyXG59XG5cbi5uYXYtanVzdGlmaWVkIC5uYXYtaXRlbSB7XG4gIGZsZXgtYmFzaXM6IDA7XG4gIGZsZXgtZ3JvdzogMTtcbiAgdGV4dC1hbGlnbjogY2VudGVyXG59XG5cbi50YWItY29udGVudCA+IC50YWItcGFuZSB7XG4gIGRpc3BsYXk6IG5vbmVcbn1cblxuLnRhYi1jb250ZW50ID4gLmFjdGl2ZSB7XG4gIGRpc3BsYXk6IGJsb2NrXG59XG5cbi5uYXZiYXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBwYWRkaW5nOiAuNXJlbSAxcmVtXG59XG5cbi5uYXZiYXIgPiAuY29udGFpbmVyLCAubmF2YmFyID4gLmNvbnRhaW5lci1mbHVpZCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtd3JhcDogd3JhcDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuXG59XG5cbi5uYXZiYXItYnJhbmQge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHBhZGRpbmctdG9wOiAuMzEyNXJlbTtcbiAgcGFkZGluZy1ib3R0b206IC4zMTI1cmVtO1xuICBtYXJnaW4tcmlnaHQ6IDFyZW07XG4gIGZvbnQtc2l6ZTogMS4yNXJlbTtcbiAgbGluZS1oZWlnaHQ6IGluaGVyaXQ7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXBcbn1cblxuLm5hdmJhci1icmFuZDpob3ZlciwgLm5hdmJhci1icmFuZDpmb2N1cyB7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZVxufVxuXG4ubmF2YmFyLW5hdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIHBhZGRpbmctbGVmdDogMDtcbiAgbWFyZ2luLWJvdHRvbTogMDtcbiAgbGlzdC1zdHlsZTogbm9uZVxufVxuXG4ubmF2YmFyLW5hdiAubmF2LWxpbmsge1xuICBwYWRkaW5nLXJpZ2h0OiAwO1xuICBwYWRkaW5nLWxlZnQ6IDBcbn1cblxuLm5hdmJhci1uYXYgLmRyb3Bkb3duLW1lbnUge1xuICBwb3NpdGlvbjogc3RhdGljO1xuICBmbG9hdDogbm9uZVxufVxuXG4ubmF2YmFyLXRleHQge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHBhZGRpbmctdG9wOiAuNXJlbTtcbiAgcGFkZGluZy1ib3R0b206IC41cmVtXG59XG5cbi5uYXZiYXItY29sbGFwc2Uge1xuICBmbGV4LWJhc2lzOiAxMDAlO1xuICBmbGV4LWdyb3c6IDE7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXJcbn1cblxuLm5hdmJhci10b2dnbGVyIHtcbiAgcGFkZGluZzogLjI1cmVtIC43NXJlbTtcbiAgZm9udC1zaXplOiAxLjI1cmVtO1xuICBsaW5lLWhlaWdodDogMTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICBib3JkZXItcmFkaXVzOiAuMjVyZW1cbn1cblxuLm5hdmJhci10b2dnbGVyOmhvdmVyLCAubmF2YmFyLXRvZ2dsZXI6Zm9jdXMge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmVcbn1cblxuLm5hdmJhci10b2dnbGVyOm5vdCg6ZGlzYWJsZWQpOm5vdCguZGlzYWJsZWQpIHtcbiAgY3Vyc29yOiBwb2ludGVyXG59XG5cbi5uYXZiYXItdG9nZ2xlci1pY29uIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogMS41ZW07XG4gIGhlaWdodDogMS41ZW07XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIGJhY2tncm91bmQ6IG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyO1xuICBiYWNrZ3JvdW5kLXNpemU6IDEwMCUgMTAwJVxufVxuXG5AbWVkaWEgKG1heC13aWR0aDogNTc1Ljk4cHgpIHtcbiAgLm5hdmJhci1leHBhbmQtc20gPiAuY29udGFpbmVyLCAubmF2YmFyLWV4cGFuZC1zbSA+IC5jb250YWluZXItZmx1aWQge1xuICAgIHBhZGRpbmctcmlnaHQ6IDA7XG4gICAgcGFkZGluZy1sZWZ0OiAwXG4gIH1cbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDU3NnB4KSB7XG4gIC5uYXZiYXItZXhwYW5kLXNtIHtcbiAgICBmbGV4LWZsb3c6IHJvdyBub3dyYXA7XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0XG4gIH1cblxuICAubmF2YmFyLWV4cGFuZC1zbSAubmF2YmFyLW5hdiB7XG4gICAgZmxleC1kaXJlY3Rpb246IHJvd1xuICB9XG5cbiAgLm5hdmJhci1leHBhbmQtc20gLm5hdmJhci1uYXYgLmRyb3Bkb3duLW1lbnUge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZVxuICB9XG5cbiAgLm5hdmJhci1leHBhbmQtc20gLm5hdmJhci1uYXYgLm5hdi1saW5rIHtcbiAgICBwYWRkaW5nLXJpZ2h0OiAuNXJlbTtcbiAgICBwYWRkaW5nLWxlZnQ6IC41cmVtXG4gIH1cblxuICAubmF2YmFyLWV4cGFuZC1zbSA+IC5jb250YWluZXIsIC5uYXZiYXItZXhwYW5kLXNtID4gLmNvbnRhaW5lci1mbHVpZCB7XG4gICAgZmxleC13cmFwOiBub3dyYXBcbiAgfVxuXG4gIC5uYXZiYXItZXhwYW5kLXNtIC5uYXZiYXItY29sbGFwc2Uge1xuICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICBmbGV4LWJhc2lzOiBhdXRvXG4gIH1cblxuICAubmF2YmFyLWV4cGFuZC1zbSAubmF2YmFyLXRvZ2dsZXIge1xuICAgIGRpc3BsYXk6IG5vbmVcbiAgfVxufVxuXG5AbWVkaWEgKG1heC13aWR0aDogNzY3Ljk4cHgpIHtcbiAgLm5hdmJhci1leHBhbmQtbWQgPiAuY29udGFpbmVyLCAubmF2YmFyLWV4cGFuZC1tZCA+IC5jb250YWluZXItZmx1aWQge1xuICAgIHBhZGRpbmctcmlnaHQ6IDA7XG4gICAgcGFkZGluZy1sZWZ0OiAwXG4gIH1cbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XG4gIC5uYXZiYXItZXhwYW5kLW1kIHtcbiAgICBmbGV4LWZsb3c6IHJvdyBub3dyYXA7XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0XG4gIH1cblxuICAubmF2YmFyLWV4cGFuZC1tZCAubmF2YmFyLW5hdiB7XG4gICAgZmxleC1kaXJlY3Rpb246IHJvd1xuICB9XG5cbiAgLm5hdmJhci1leHBhbmQtbWQgLm5hdmJhci1uYXYgLmRyb3Bkb3duLW1lbnUge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZVxuICB9XG5cbiAgLm5hdmJhci1leHBhbmQtbWQgLm5hdmJhci1uYXYgLm5hdi1saW5rIHtcbiAgICBwYWRkaW5nLXJpZ2h0OiAuNXJlbTtcbiAgICBwYWRkaW5nLWxlZnQ6IC41cmVtXG4gIH1cblxuICAubmF2YmFyLWV4cGFuZC1tZCA+IC5jb250YWluZXIsIC5uYXZiYXItZXhwYW5kLW1kID4gLmNvbnRhaW5lci1mbHVpZCB7XG4gICAgZmxleC13cmFwOiBub3dyYXBcbiAgfVxuXG4gIC5uYXZiYXItZXhwYW5kLW1kIC5uYXZiYXItY29sbGFwc2Uge1xuICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICBmbGV4LWJhc2lzOiBhdXRvXG4gIH1cblxuICAubmF2YmFyLWV4cGFuZC1tZCAubmF2YmFyLXRvZ2dsZXIge1xuICAgIGRpc3BsYXk6IG5vbmVcbiAgfVxufVxuXG5AbWVkaWEgKG1heC13aWR0aDogOTkxLjk4cHgpIHtcbiAgLm5hdmJhci1leHBhbmQtbGcgPiAuY29udGFpbmVyLCAubmF2YmFyLWV4cGFuZC1sZyA+IC5jb250YWluZXItZmx1aWQge1xuICAgIHBhZGRpbmctcmlnaHQ6IDA7XG4gICAgcGFkZGluZy1sZWZ0OiAwXG4gIH1cbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDk5MnB4KSB7XG4gIC5uYXZiYXItZXhwYW5kLWxnIHtcbiAgICBmbGV4LWZsb3c6IHJvdyBub3dyYXA7XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0XG4gIH1cblxuICAubmF2YmFyLWV4cGFuZC1sZyAubmF2YmFyLW5hdiB7XG4gICAgZmxleC1kaXJlY3Rpb246IHJvd1xuICB9XG5cbiAgLm5hdmJhci1leHBhbmQtbGcgLm5hdmJhci1uYXYgLmRyb3Bkb3duLW1lbnUge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZVxuICB9XG5cbiAgLm5hdmJhci1leHBhbmQtbGcgLm5hdmJhci1uYXYgLm5hdi1saW5rIHtcbiAgICBwYWRkaW5nLXJpZ2h0OiAuNXJlbTtcbiAgICBwYWRkaW5nLWxlZnQ6IC41cmVtXG4gIH1cblxuICAubmF2YmFyLWV4cGFuZC1sZyA+IC5jb250YWluZXIsIC5uYXZiYXItZXhwYW5kLWxnID4gLmNvbnRhaW5lci1mbHVpZCB7XG4gICAgZmxleC13cmFwOiBub3dyYXBcbiAgfVxuXG4gIC5uYXZiYXItZXhwYW5kLWxnIC5uYXZiYXItY29sbGFwc2Uge1xuICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICBmbGV4LWJhc2lzOiBhdXRvXG4gIH1cblxuICAubmF2YmFyLWV4cGFuZC1sZyAubmF2YmFyLXRvZ2dsZXIge1xuICAgIGRpc3BsYXk6IG5vbmVcbiAgfVxufVxuXG5AbWVkaWEgKG1heC13aWR0aDogMTE5OS45OHB4KSB7XG4gIC5uYXZiYXItZXhwYW5kLXhsID4gLmNvbnRhaW5lciwgLm5hdmJhci1leHBhbmQteGwgPiAuY29udGFpbmVyLWZsdWlkIHtcbiAgICBwYWRkaW5nLXJpZ2h0OiAwO1xuICAgIHBhZGRpbmctbGVmdDogMFxuICB9XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiAxMjAwcHgpIHtcbiAgLm5hdmJhci1leHBhbmQteGwge1xuICAgIGZsZXgtZmxvdzogcm93IG5vd3JhcDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnRcbiAgfVxuXG4gIC5uYXZiYXItZXhwYW5kLXhsIC5uYXZiYXItbmF2IHtcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93XG4gIH1cblxuICAubmF2YmFyLWV4cGFuZC14bCAubmF2YmFyLW5hdiAuZHJvcGRvd24tbWVudSB7XG4gICAgcG9zaXRpb246IGFic29sdXRlXG4gIH1cblxuICAubmF2YmFyLWV4cGFuZC14bCAubmF2YmFyLW5hdiAubmF2LWxpbmsge1xuICAgIHBhZGRpbmctcmlnaHQ6IC41cmVtO1xuICAgIHBhZGRpbmctbGVmdDogLjVyZW1cbiAgfVxuXG4gIC5uYXZiYXItZXhwYW5kLXhsID4gLmNvbnRhaW5lciwgLm5hdmJhci1leHBhbmQteGwgPiAuY29udGFpbmVyLWZsdWlkIHtcbiAgICBmbGV4LXdyYXA6IG5vd3JhcFxuICB9XG5cbiAgLm5hdmJhci1leHBhbmQteGwgLm5hdmJhci1jb2xsYXBzZSB7XG4gICAgZGlzcGxheTogZmxleCAhaW1wb3J0YW50O1xuICAgIGZsZXgtYmFzaXM6IGF1dG9cbiAgfVxuXG4gIC5uYXZiYXItZXhwYW5kLXhsIC5uYXZiYXItdG9nZ2xlciB7XG4gICAgZGlzcGxheTogbm9uZVxuICB9XG59XG5cbi5uYXZiYXItZXhwYW5kIHtcbiAgZmxleC1mbG93OiByb3cgbm93cmFwO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnRcbn1cblxuLm5hdmJhci1leHBhbmQgPiAuY29udGFpbmVyLCAubmF2YmFyLWV4cGFuZCA+IC5jb250YWluZXItZmx1aWQge1xuICBwYWRkaW5nLXJpZ2h0OiAwO1xuICBwYWRkaW5nLWxlZnQ6IDBcbn1cblxuLm5hdmJhci1leHBhbmQgLm5hdmJhci1uYXYge1xuICBmbGV4LWRpcmVjdGlvbjogcm93XG59XG5cbi5uYXZiYXItZXhwYW5kIC5uYXZiYXItbmF2IC5kcm9wZG93bi1tZW51IHtcbiAgcG9zaXRpb246IGFic29sdXRlXG59XG5cbi5uYXZiYXItZXhwYW5kIC5uYXZiYXItbmF2IC5uYXYtbGluayB7XG4gIHBhZGRpbmctcmlnaHQ6IC41cmVtO1xuICBwYWRkaW5nLWxlZnQ6IC41cmVtXG59XG5cbi5uYXZiYXItZXhwYW5kID4gLmNvbnRhaW5lciwgLm5hdmJhci1leHBhbmQgPiAuY29udGFpbmVyLWZsdWlkIHtcbiAgZmxleC13cmFwOiBub3dyYXBcbn1cblxuLm5hdmJhci1leHBhbmQgLm5hdmJhci1jb2xsYXBzZSB7XG4gIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgZmxleC1iYXNpczogYXV0b1xufVxuXG4ubmF2YmFyLWV4cGFuZCAubmF2YmFyLXRvZ2dsZXIge1xuICBkaXNwbGF5OiBub25lXG59XG5cbi5iYWRnZSB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcGFkZGluZzogLjI1ZW0gLjRlbTtcbiAgZm9udC1zaXplOiA3NSU7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGxpbmUtaGVpZ2h0OiAxO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIHZlcnRpY2FsLWFsaWduOiBiYXNlbGluZTtcbiAgYm9yZGVyLXJhZGl1czogLjI1cmVtXG59XG5cbi5iYWRnZS1wcmltYXJ5IHtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzZjZhZDhcbn1cblxuYS5iYWRnZS1wcmltYXJ5OmhvdmVyLCBhLmJhZGdlLXByaW1hcnk6Zm9jdXMge1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzI2NTFiZVxufVxuXG4uYmFkZ2Utc3VjY2VzcyB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2FjNDdkXG59XG5cbmEuYmFkZ2Utc3VjY2Vzczpob3ZlciwgYS5iYWRnZS1zdWNjZXNzOmZvY3VzIHtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtY29sb3I6ICMyZTlkNjRcbn1cblxuLmJhZGdlLXdhcm5pbmcge1xuICBjb2xvcjogIzIxMjUyOTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y3YjkyNFxufVxuXG5hLmJhZGdlLXdhcm5pbmc6aG92ZXIsIGEuYmFkZ2Utd2FybmluZzpmb2N1cyB7XG4gIGNvbG9yOiAjMjEyNTI5O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTBhMDA4XG59XG5cbi5iYWRnZS1kYW5nZXIge1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Q5MjU1MFxufVxuXG5hLmJhZGdlLWRhbmdlcjpob3ZlciwgYS5iYWRnZS1kYW5nZXI6Zm9jdXMge1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2FkMWU0MFxufVxuXG5hLCBidXR0b24sIC5idG4ge1xuICBvdXRsaW5lOiBub25lICFpbXBvcnRhbnRcbn1cblxuLmFwcC1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBtaW4taGVpZ2h0OiAxMDB2aDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgbWFyZ2luOiAwXG59XG5cbi5pY29uLWFuaW0tcHVsc2Uge1xuICBhbmltYXRpb246IHB1bHNlX2FuaW1hdGlvbjtcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAxMDAwbXM7XG4gIGFuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6IGluZmluaXRlO1xuICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBsaW5lYXJcbn1cblxuLmFwcC1oZWFkZXIge1xuICBoZWlnaHQ6IDYwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB6LWluZGV4OiAxMDtcbiAgdHJhbnNpdGlvbjogYWxsIC4yc1xufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItc2hhZG93IHtcbiAgYm94LXNoYWRvdzogMCAwLjQ2ODc1cmVtIDIuMTg3NXJlbSByZ2JhKDQsIDksIDIwLCAwLjAzKSwgMCAwLjkzNzVyZW0gMS40MDYyNXJlbSByZ2JhKDQsIDksIDIwLCAwLjAzKSwgMCAwLjI1cmVtIDAuNTMxMjVyZW0gcmdiYSg0LCA5LCAyMCwgMC4wNSksIDAgMC4xMjVyZW0gMC4xODc1cmVtIHJnYmEoNCwgOSwgMjAsIDAuMDMpXG59XG5cbi5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xuICBmbGV4OiAxO1xuICBwYWRkaW5nOiAwIDEuNXJlbTtcbiAgaGVpZ2h0OiA2MHB4XG59XG5cbi5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19jb250ZW50IC5hcHAtaGVhZGVyLWxlZnQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyXG59XG5cbi5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19jb250ZW50IC5hcHAtaGVhZGVyLXJpZ2h0IHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZGlzcGxheTogZmxleDtcbiAgbWFyZ2luLWxlZnQ6IGF1dG9cbn1cblxuLmFwcC1oZWFkZXIgLmhlYWRlci11c2VyLWluZm8gPiAud2lkZ2V0LWhlYWRpbmcsIC5hcHAtaGVhZGVyIC5oZWFkZXItdXNlci1pbmZvID4gLndpZGdldC1zdWJoZWFkaW5nIHtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcFxufVxuXG4uYXBwLWhlYWRlciAuaGVhZGVyLXVzZXItaW5mbyA+IC53aWRnZXQtc3ViaGVhZGluZyB7XG4gIGZvbnQtc2l6ZTogLjhyZW1cbn1cblxuLmFwcC1oZWFkZXJfX2xvZ28ge1xuICBwYWRkaW5nOiAwIDEuNXJlbTtcbiAgaGVpZ2h0OiA2MHB4O1xuICB3aWR0aDogMjgwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIHRyYW5zaXRpb246IHdpZHRoIC4yc1xufVxuXG4uYXBwLWhlYWRlcl9fbG9nbyAubG9nby1zcmMge1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiAxMTVweDtcbiAgYmFja2dyb3VuZDogdXJsKHNyYy9hc3NldHMvaW1hZ2VzL2djLWxvb2dvLXJlc2l6ZWQucG5nKVxufVxuXG4uYXBwLWhlYWRlcl9fbWVudSwgLmFwcC1oZWFkZXJfX21vYmlsZS1tZW51IHtcbiAgZGlzcGxheTogbm9uZTtcbiAgcGFkZGluZzogMCAxLjVyZW07XG4gIGhlaWdodDogNjBweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlclxufVxuXG4uZml4ZWQtaGVhZGVyIC5hcHAtaGVhZGVyIHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICB3aWR0aDogMTAwJTtcbiAgdG9wOiAwXG59XG5cbi5maXhlZC1oZWFkZXIgLmFwcC1oZWFkZXIgLmFwcC1oZWFkZXJfX2xvZ28ge1xuICB2aXNpYmlsaXR5OiB2aXNpYmxlXG59XG5cbi5maXhlZC1oZWFkZXIgLmFwcC1tYWluIHtcbiAgcGFkZGluZy10b3A6IDYwcHhcbn1cblxuLmZpeGVkLWhlYWRlcjpub3QoLmZpeGVkLXNpZGViYXIpOm5vdCguY2xvc2VkLXNpZGViYXIpIC5hcHAtc2lkZWJhciAuYXBwLWhlYWRlcl9fbG9nbyB7XG4gIHZpc2liaWxpdHk6IGhpZGRlblxufVxuXG4uaGVhZGVyLWRvdHMge1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgZGlzcGxheTogZmxleFxufVxuXG4uaGVhZGVyLWRvdHMgPiAuZHJvcGRvd24ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1jb250ZW50OiBjZW50ZXJcbn1cblxuLmhlYWRlci1kb3RzIC5pY29uLXdyYXBwZXItYWx0IHtcbiAgbWFyZ2luOiAwO1xuICBoZWlnaHQ6IDQ0cHg7XG4gIHdpZHRoOiA0NHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG92ZXJmbG93OiB2aXNpYmxlXG59XG5cbi5oZWFkZXItZG90cyAuaWNvbi13cmFwcGVyLWFsdCAubGFuZ3VhZ2UtaWNvbiB7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogNDtcbiAgd2lkdGg6IDMycHg7XG4gIGhlaWdodDogMzJweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgbWFyZ2luOiAwIGF1dG9cbn1cblxuLmhlYWRlci1kb3RzIC5pY29uLXdyYXBwZXItYWx0IC5sYW5ndWFnZS1pY29uIGltZyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgbWFyZ2luOiAtMjJweCAwIDAgLTIwcHhcbn1cblxuLmhlYWRlci1kb3RzIC5pY29uLXdyYXBwZXItYWx0IC5pY29uLXdyYXBwZXItYmcge1xuICBvcGFjaXR5OiAuMTtcbiAgdHJhbnNpdGlvbjogb3BhY2l0eSAuMnM7XG4gIGJvcmRlci1yYWRpdXM6IDQwcHhcbn1cblxuLmhlYWRlci1kb3RzIC5pY29uLXdyYXBwZXItYWx0IHN2ZyB7XG4gIG1hcmdpbjogMCBhdXRvXG59XG5cbkAtbW96LWRvY3VtZW50IHVybC1wcmVmaXgoKSB7XG4gIC5oZWFkZXItZG90cyAuaWNvbi13cmFwcGVyLWFsdCBzdmcge1xuICAgIHdpZHRoOiA1MCVcbiAgfVxufVxuXG4uaGVhZGVyLWRvdHMgLmljb24td3JhcHBlci1hbHQgaSB7XG4gIGZvbnQtc2l6ZTogMS4zcmVtXG59XG5cbi5oZWFkZXItZG90cyAuaWNvbi13cmFwcGVyLWFsdDpob3ZlciB7XG4gIGN1cnNvcjogcG9pbnRlclxufVxuXG4uaGVhZGVyLWRvdHMgLmljb24td3JhcHBlci1hbHQ6aG92ZXIgLmljb24td3JhcHBlci1iZyB7XG4gIG9wYWNpdHk6IC4yXG59XG5cbi5oZWFkZXItZG90cyAuaWNvbi13cmFwcGVyLWFsdCAuYmFkZ2UtZG90IHtcbiAgdG9wOiAxcHg7XG4gIHJpZ2h0OiAxcHg7XG4gIGJvcmRlcjogMFxufVxuXG4uaGVhZGVyLWJ0bi1sZyB7XG4gIHBhZGRpbmc6IDAgMCAwIDEuNXJlbTtcbiAgbWFyZ2luLWxlZnQ6IDEuNXJlbTtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlXG59XG5cbi5oZWFkZXItYnRuLWxnOjpiZWZvcmUge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IC0xcHg7XG4gIHRvcDogNTAlO1xuICBiYWNrZ3JvdW5kOiAjZGVlMmU2O1xuICB3aWR0aDogMXB4O1xuICBoZWlnaHQ6IDMwcHg7XG4gIG1hcmdpbi10b3A6IC0xNXB4O1xuICBjb250ZW50OiAnJ1xufVxuXG4uaGVhZGVyLWJ0bi1sZyAuaGFtYnVyZ2VyLWlubmVyLCAuaGVhZGVyLWJ0bi1sZyAuaGFtYnVyZ2VyLWlubmVyOjpiZWZvcmUsIC5oZWFkZXItYnRuLWxnIC5oYW1idXJnZXItaW5uZXI6OmFmdGVyIHtcbiAgYmFja2dyb3VuZDogIzZjNzU3ZFxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlci1sZWZ0ID4gLm5hdiA+IGxpID4gLm5hdi1saW5rIHtcbiAgY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC43KVxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlci1sZWZ0ID4gLm5hdiA+IGxpID4gLm5hdi1saW5rIC5uYXYtbGluay1pY29uIHtcbiAgY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC44KVxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlci1sZWZ0ID4gLm5hdiA+IGxpID4gLm5hdi1saW5rOmhvdmVyIHtcbiAgY29sb3I6ICNmZmZcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLmFwcC1oZWFkZXItcmlnaHQgLmljb24td3JhcHBlci1hbHQgLmZhLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlci1yaWdodCAuaWNvbi13cmFwcGVyLWFsdCAuaWNvbiB7XG4gIGNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNykgIWltcG9ydGFudDtcbiAgdHJhbnNpdGlvbjogYWxsIC4yc1xufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlci1yaWdodCAuaWNvbi13cmFwcGVyLWFsdCAuaWNvbi13cmFwcGVyLWJnIHtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjEpICFpbXBvcnRhbnQ7XG4gIHRyYW5zaXRpb246IGFsbCAuMnM7XG4gIG9wYWNpdHk6IDFcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLmFwcC1oZWFkZXItcmlnaHQgLmljb24td3JhcHBlci1hbHQ6aG92ZXIgLmZhLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlci1yaWdodCAuaWNvbi13cmFwcGVyLWFsdDpob3ZlciAuaWNvbiB7XG4gIGNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOSkgIWltcG9ydGFudFxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlci1yaWdodCAuaWNvbi13cmFwcGVyLWFsdDpob3ZlciAuaWNvbi13cmFwcGVyLWJnIHtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjE1KSAhaW1wb3J0YW50XG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWxpZ2h0IC5hcHAtaGVhZGVyLXJpZ2h0IC5pY29uLXdyYXBwZXItYWx0IC5iYWRnZS1kb3Qge1xuICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50XG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWxpZ2h0IC5hcHAtaGVhZGVyLXJpZ2h0ID4gLmhlYWRlci1idG4tbGcgLndpZGdldC1jb250ZW50LWxlZnQgLmJ0bi1ncm91cCA+IC5idG4sIC5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWxpZ2h0IC5hcHAtaGVhZGVyLXJpZ2h0ID4gLmhlYWRlci1idG4tbGcgLndpZGdldC1oZWFkaW5nLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlci1yaWdodCA+IC5oZWFkZXItYnRuLWxnIC53aWRnZXQtc3ViaGVhZGluZyB7XG4gIGNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOClcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLmFwcC1oZWFkZXItcmlnaHQgPiAuaGVhZGVyLWJ0bi1sZyAuaGVhZGVyLXVzZXItaW5mbyA+IC5idG4tc2hhZG93IHtcbiAgYm94LXNoYWRvdzogMCAwLjEyNXJlbSAwLjYyNXJlbSByZ2JhKDAsIDAsIDAsIDAuMSksIDAgMC4wNjI1cmVtIDAuMTI1cmVtIHJnYmEoMCwgMCwgMCwgMC4yKVxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuc2VhcmNoLXdyYXBwZXIgLmlucHV0LWhvbGRlciAuc2VhcmNoLWljb24ge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuMSlcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLnNlYXJjaC13cmFwcGVyIC5pbnB1dC1ob2xkZXIgLnNlYXJjaC1pbnB1dDo6cGxhY2Vob2xkZXIsIC5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWxpZ2h0IC5zZWFyY2gtd3JhcHBlciAuaW5wdXQtaG9sZGVyIC5zZWFyY2gtaW5wdXQ6Oi13ZWJraXQtaW5wdXQtcGxhY2Vob2xkZXIsIC5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWxpZ2h0IC5zZWFyY2gtd3JhcHBlciAuaW5wdXQtaG9sZGVyIC5zZWFyY2gtaW5wdXQ6LW1zLWlucHV0LXBsYWNlaG9sZGVyLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuc2VhcmNoLXdyYXBwZXIgLmlucHV0LWhvbGRlciAuc2VhcmNoLWlucHV0Oi1tb3otcGxhY2Vob2xkZXIsIC5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWxpZ2h0IC5zZWFyY2gtd3JhcHBlciAuaW5wdXQtaG9sZGVyIC5zZWFyY2gtaW5wdXQ6Oi1tb3otcGxhY2Vob2xkZXIge1xuICBjb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjUpICFpbXBvcnRhbnRcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLnNlYXJjaC13cmFwcGVyLmFjdGl2ZSAuaW5wdXQtaG9sZGVyIHtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjEpXG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWxpZ2h0IC5zZWFyY2gtd3JhcHBlci5hY3RpdmUgLmlucHV0LWhvbGRlciAuc2VhcmNoLWlucHV0IHtcbiAgY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC44KVxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuc2VhcmNoLXdyYXBwZXIuYWN0aXZlIC5pbnB1dC1ob2xkZXIgLnNlYXJjaC1pY29uIHtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjEpXG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWxpZ2h0IC5oZWFkZXItYnRuLWxnOjpiZWZvcmUge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMilcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLmhlYWRlci1idG4tbGcgLmhhbWJ1cmdlci1pbm5lciwgLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLmhlYWRlci1idG4tbGcgLmhhbWJ1cmdlci5pcy1hY3RpdmUgLmhhbWJ1cmdlci1pbm5lciwgLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLmhlYWRlci1idG4tbGcgLmhhbWJ1cmdlci1pbm5lcjo6YmVmb3JlLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuaGVhZGVyLWJ0bi1sZyAuaGFtYnVyZ2VyLWlubmVyOjphZnRlciwgLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLmhlYWRlcl9fcGFuZSAuaGFtYnVyZ2VyLWlubmVyLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuaGVhZGVyX19wYW5lIC5oYW1idXJnZXIuaXMtYWN0aXZlIC5oYW1idXJnZXItaW5uZXIsIC5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWxpZ2h0IC5oZWFkZXJfX3BhbmUgLmhhbWJ1cmdlci1pbm5lcjo6YmVmb3JlLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuaGVhZGVyX19wYW5lIC5oYW1idXJnZXItaW5uZXI6OmFmdGVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjgpICFpbXBvcnRhbnRcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLnNlYXJjaC13cmFwcGVyIC5pbnB1dC1ob2xkZXIgLnNlYXJjaC1pY29uIHNwYW46OmFmdGVyIHtcbiAgYm9yZGVyLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOClcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLnNlYXJjaC13cmFwcGVyIC5jbG9zZTo6YmVmb3JlLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuc2VhcmNoLXdyYXBwZXIgLmNsb3NlOjphZnRlciwgLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLnNlYXJjaC13cmFwcGVyIC5pbnB1dC1ob2xkZXIgLnNlYXJjaC1pY29uIHNwYW46OmJlZm9yZSB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC44KVxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlcl9fbG9nbyAubG9nby1zcmMge1xuICBiYWNrZ3JvdW5kOiB1cmwoc3JjL2Fzc2V0cy9pbWFnZXMvbG9nby5wbmcpXG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWxpZ2h0IC5hcHAtaGVhZGVyX19tb2JpbGUtbWVudSAuaGFtYnVyZ2VyLWlubmVyLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlcl9fbW9iaWxlLW1lbnUgLmhhbWJ1cmdlci1pbm5lcjo6YmVmb3JlLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlcl9fbW9iaWxlLW1lbnUgLmhhbWJ1cmdlci1pbm5lcjo6YWZ0ZXIge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOSlcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtZGFyayAuYXBwLWhlYWRlci1sZWZ0ID4gLm5hdiA+IGxpID4gLm5hdi1saW5rIHtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC43KVxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5hcHAtaGVhZGVyLWxlZnQgPiAubmF2ID4gbGkgPiAubmF2LWxpbmsgLm5hdi1saW5rLWljb24ge1xuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjgpXG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWRhcmsgLmFwcC1oZWFkZXItbGVmdCA+IC5uYXYgPiBsaSA+IC5uYXYtbGluazpob3ZlciB7XG4gIGNvbG9yOiAjMDAwXG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWRhcmsgLmFwcC1oZWFkZXItcmlnaHQgLmljb24td3JhcHBlci1hbHQgLmZhLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5hcHAtaGVhZGVyLXJpZ2h0IC5pY29uLXdyYXBwZXItYWx0IC5pY29uIHtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC43KSAhaW1wb3J0YW50O1xuICB0cmFuc2l0aW9uOiBhbGwgLjJzXG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWRhcmsgLmFwcC1oZWFkZXItcmlnaHQgLmljb24td3JhcHBlci1hbHQgLmljb24td3JhcHBlci1iZyB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4xKSAhaW1wb3J0YW50O1xuICB0cmFuc2l0aW9uOiBhbGwgLjJzO1xuICBvcGFjaXR5OiAxXG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWRhcmsgLmFwcC1oZWFkZXItcmlnaHQgLmljb24td3JhcHBlci1hbHQ6aG92ZXIgLmZhLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5hcHAtaGVhZGVyLXJpZ2h0IC5pY29uLXdyYXBwZXItYWx0OmhvdmVyIC5pY29uIHtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC45NSkgIWltcG9ydGFudFxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5hcHAtaGVhZGVyLXJpZ2h0IC5pY29uLXdyYXBwZXItYWx0OmhvdmVyIC5pY29uLXdyYXBwZXItYmcge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuMTUpICFpbXBvcnRhbnRcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtZGFyayAuYXBwLWhlYWRlci1yaWdodCAuaWNvbi13cmFwcGVyLWFsdCAuYmFkZ2UtZG90IHtcbiAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudFxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5hcHAtaGVhZGVyLXJpZ2h0ID4gLmhlYWRlci1idG4tbGcgLndpZGdldC1jb250ZW50LWxlZnQgLmJ0bi1ncm91cCA+IC5idG4sIC5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWRhcmsgLmFwcC1oZWFkZXItcmlnaHQgPiAuaGVhZGVyLWJ0bi1sZyAud2lkZ2V0LWhlYWRpbmcsIC5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWRhcmsgLmFwcC1oZWFkZXItcmlnaHQgPiAuaGVhZGVyLWJ0bi1sZyAud2lkZ2V0LXN1YmhlYWRpbmcge1xuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjgpXG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWRhcmsgLmFwcC1oZWFkZXItcmlnaHQgPiAuaGVhZGVyLWJ0bi1sZyAuaGVhZGVyLXVzZXItaW5mbyA+IC5idG4tc2hhZG93IHtcbiAgYm94LXNoYWRvdzogMCAwLjEyNXJlbSAwLjYyNXJlbSByZ2JhKDAsIDAsIDAsIDAuMSksIDAgMC4wNjI1cmVtIDAuMTI1cmVtIHJnYmEoMCwgMCwgMCwgMC4yKVxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5zZWFyY2gtd3JhcHBlciAuaW5wdXQtaG9sZGVyIC5zZWFyY2gtaWNvbiB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4xKVxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5zZWFyY2gtd3JhcHBlci5hY3RpdmUgLmlucHV0LWhvbGRlciB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4xKVxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5zZWFyY2gtd3JhcHBlci5hY3RpdmUgLmlucHV0LWhvbGRlciAuc2VhcmNoLWlucHV0IHtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC44KVxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5zZWFyY2gtd3JhcHBlci5hY3RpdmUgLmlucHV0LWhvbGRlciAuc2VhcmNoLWljb24ge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuMSlcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtZGFyayAuaGVhZGVyLWJ0bi1sZzo6YmVmb3JlIHtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjIpXG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWRhcmsgLmhlYWRlci1idG4tbGcgLmhhbWJ1cmdlci1pbm5lciwgLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtZGFyayAuaGVhZGVyLWJ0bi1sZyAuaGFtYnVyZ2VyLmlzLWFjdGl2ZSAuaGFtYnVyZ2VyLWlubmVyLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5oZWFkZXItYnRuLWxnIC5oYW1idXJnZXItaW5uZXI6OmJlZm9yZSwgLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtZGFyayAuaGVhZGVyLWJ0bi1sZyAuaGFtYnVyZ2VyLWlubmVyOjphZnRlciwgLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtZGFyayAuaGVhZGVyX19wYW5lIC5oYW1idXJnZXItaW5uZXIsIC5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWRhcmsgLmhlYWRlcl9fcGFuZSAuaGFtYnVyZ2VyLmlzLWFjdGl2ZSAuaGFtYnVyZ2VyLWlubmVyLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5oZWFkZXJfX3BhbmUgLmhhbWJ1cmdlci1pbm5lcjo6YmVmb3JlLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5oZWFkZXJfX3BhbmUgLmhhbWJ1cmdlci1pbm5lcjo6YWZ0ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuOCkgIWltcG9ydGFudFxufVxuXG4uYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5zZWFyY2gtd3JhcHBlciAuaW5wdXQtaG9sZGVyIC5zZWFyY2gtaWNvbiBzcGFuOjphZnRlciB7XG4gIGJvcmRlci1jb2xvcjogcmdiYSgwLCAwLCAwLCAwLjgpXG59XG5cbi5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWRhcmsgLnNlYXJjaC13cmFwcGVyIC5jbG9zZTo6YmVmb3JlLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5zZWFyY2gtd3JhcHBlciAuY2xvc2U6OmFmdGVyLCAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1kYXJrIC5zZWFyY2gtd3JhcHBlciAuaW5wdXQtaG9sZGVyIC5zZWFyY2gtaWNvbiBzcGFuOjpiZWZvcmUge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuOClcbn1cblxuLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtZGFyayAuYXBwLWhlYWRlcl9fbG9nbyAubG9nby1zcmMge1xuICBiYWNrZ3JvdW5kOiB1cmwoc3JjL2Fzc2V0cy9pbWFnZXMvbG9nby1pbnZlcnNlLnBuZylcbn1cblxuLmFwcC1zaWRlYmFyIHtcbiAgd2lkdGg6IDI4MHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICB6LWluZGV4OiAxMTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgbWluLXdpZHRoOiAyODBweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBmbGV4OiAwIDAgMjgwcHg7XG4gIG1hcmdpbi10b3A6IC02MHB4O1xuICBwYWRkaW5nLXRvcDogNjBweDtcbiAgdHJhbnNpdGlvbjogYWxsIC4yc1xufVxuXG4uYXBwLXNpZGViYXIgLmFwcC1zaWRlYmFyX19pbm5lciB7XG4gIHBhZGRpbmc6IDJweCAxLjVyZW0gMS41cmVtXG59XG5cbi5hcHAtc2lkZWJhciAuc2Nyb2xsYmFyLXNpZGViYXIge1xuICB6LWluZGV4OiAxNTtcbiAgd2lkdGg6IDEwMCVcbn1cblxuLmFwcC1zaWRlYmFyIC5hcHAtc2lkZWJhci1iZyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgdG9wOiAwO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xuICBvcGFjaXR5OiAwLjA1O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICB6LWluZGV4OiAxMFxufVxuXG4uYXBwLXNpZGViYXIgLmFwcC1oZWFkZXJfX2xvZ28ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDA7XG4gIHRvcDogMDtcbiAgZGlzcGxheTogbm9uZTtcbiAgei1pbmRleDogMTFcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItc2hhZG93IHtcbiAgYm94LXNoYWRvdzogN3B4IDAgNjBweCByZ2JhKDAsIDAsIDAsIDAuMDUpXG59XG5cbi5hcHAtc2lkZWJhcl9faGVhZGluZyB7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGZvbnQtc2l6ZTogLjhyZW07XG4gIG1hcmdpbjogLjc1cmVtIDA7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjb2xvcjogIzNmNmFkODtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgcG9zaXRpb246IHJlbGF0aXZlXG59XG5cbi5zaWRlYmFyLW1vYmlsZS1vdmVybGF5IHtcbiAgZGlzcGxheTogbm9uZTtcbiAgcG9zaXRpb246IGZpeGVkO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBiYWNrZ3JvdW5kOiAjMzMzO1xuICBvcGFjaXR5OiAuNjtcbiAgbGVmdDogMDtcbiAgdG9wOiAwO1xuICB6LWluZGV4OiAxMlxufVxuXG4udmVydGljYWwtbmF2LW1lbnUge1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgbGlzdC1zdHlsZTogbm9uZVxufVxuXG4udmVydGljYWwtbmF2LW1lbnU6OmFmdGVyIHtcbiAgY29udGVudDogXCIgXCI7XG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMDtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogMFxufVxuXG5cbi52ZXJ0aWNhbC1uYXYtbWVudTpiZWZvcmUge1xuICBvcGFjaXR5OiAwO1xuICB0cmFuc2l0aW9uOiBvcGFjaXR5IDMwMG1zXG59XG5cblxuLnZlcnRpY2FsLW5hdi1tZW51IC5tbS1jb2xsYXBzZTpub3QoLm1tLXNob3cpIHtcbiAgZGlzcGxheTogbm9uZVxufVxuXG4udmVydGljYWwtbmF2LW1lbnUgLm1tLWNvbGxhcHNpbmcge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGhlaWdodDogMDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdHJhbnNpdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2U7XG4gIHRyYW5zaXRpb24tZHVyYXRpb246IC4yNXM7XG4gIHRyYW5zaXRpb24tcHJvcGVydHk6IGhlaWdodCwgdmlzaWJpbGl0eVxufVxuXG4udmVydGljYWwtbmF2LW1lbnUgdWwge1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgbGlzdC1zdHlsZTogbm9uZVxufVxuXG4udmVydGljYWwtbmF2LW1lbnUgbGkgYSB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBsaW5lLWhlaWdodDogMi40cmVtO1xuICBoZWlnaHQ6IDIuNHJlbTtcbiAgcGFkZGluZzogMCAxLjVyZW0gMCA0NXB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJvcmRlci1yYWRpdXM6IC4yNXJlbTtcbiAgY29sb3I6ICMzNDNhNDA7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIHRyYW5zaXRpb246IGFsbCAuMnM7XG4gIG1hcmdpbjogLjFyZW0gMFxufVxuXG4udmVydGljYWwtbmF2LW1lbnUgbGkgYTpob3ZlciB7XG4gIGJhY2tncm91bmQ6ICNlMGYzZmY7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZVxufVxuXG4udmVydGljYWwtbmF2LW1lbnUgbGkgYTpob3ZlciBpLm1ldGlzbWVudS1pY29uIHtcbiAgb3BhY2l0eTogLjZcbn1cblxuLnZlcnRpY2FsLW5hdi1tZW51IGxpIGE6aG92ZXIgaS5tZXRpc21lbnUtc3RhdGUtaWNvbiB7XG4gIG9wYWNpdHk6IDFcbn1cblxuLnZlcnRpY2FsLW5hdi1tZW51IGxpLm1tLWFjdGl2ZSA+IGEge1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLnZlcnRpY2FsLW5hdi1tZW51IGxpLm1tLWFjdGl2ZSA+IGEgaS5tZXRpc21lbnUtc3RhdGUtaWNvbiB7XG4gIHRyYW5zZm9ybTogcm90YXRlKC0xODBkZWcpXG59XG5cbi52ZXJ0aWNhbC1uYXYtbWVudSBsaSBhLm1tLWFjdGl2ZSB7XG4gIGNvbG9yOiAjM2Y2YWQ4O1xuICBiYWNrZ3JvdW5kOiAjZTBmM2ZmO1xuICBmb250LXdlaWdodDogYm9sZFxufVxuXG4udmVydGljYWwtbmF2LW1lbnUgaS5tZXRpc21lbnUtc3RhdGUtaWNvbiwgLnZlcnRpY2FsLW5hdi1tZW51IGkubWV0aXNtZW51LWljb24ge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHdpZHRoOiAzNHB4O1xuICBoZWlnaHQ6IDM0cHg7XG4gIGxpbmUtaGVpZ2h0OiAzNHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDVweDtcbiAgdG9wOiA1MCU7XG4gIG1hcmdpbi10b3A6IC0xN3B4O1xuICBmb250LXNpemU6IDEuNXJlbTtcbiAgb3BhY2l0eTogLjM7XG4gIHRyYW5zaXRpb246IGNvbG9yIDMwMG1zXG59XG5cbi52ZXJ0aWNhbC1uYXYtbWVudSBpLm1ldGlzbWVudS1zdGF0ZS1pY29uIHtcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDMwMG1zO1xuICBsZWZ0OiBhdXRvO1xuICByaWdodDogMFxufVxuXG4udmVydGljYWwtbmF2LW1lbnUgdWwge1xuICB0cmFuc2l0aW9uOiBwYWRkaW5nIDMwMG1zO1xuICBwYWRkaW5nOiAuNWVtIDAgMCAycmVtXG59XG5cbi52ZXJ0aWNhbC1uYXYtbWVudSB1bDpiZWZvcmUge1xuICBjb250ZW50OiAnJztcbiAgaGVpZ2h0OiAxMDAlO1xuICBvcGFjaXR5OiAxO1xuICB3aWR0aDogM3B4O1xuICBiYWNrZ3JvdW5kOiAjZTBmM2ZmO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDIwcHg7XG4gIHRvcDogMDtcbiAgYm9yZGVyLXJhZGl1czogMTVweFxufVxuXG4udmVydGljYWwtbmF2LW1lbnUgdWwgPiBsaSA+IGEge1xuICBjb2xvcjogIzZjNzU3ZDtcbiAgaGVpZ2h0OiAycmVtO1xuICBsaW5lLWhlaWdodDogMnJlbTtcbiAgcGFkZGluZzogMCAxLjVyZW0gMFxufVxuXG4udmVydGljYWwtbmF2LW1lbnUgdWwgPiBsaSA+IGE6aG92ZXIge1xuICBjb2xvcjogIzNmNmFkOFxufVxuXG4udmVydGljYWwtbmF2LW1lbnUgdWwgPiBsaSA+IGEgLm1ldGlzbWVudS1pY29uIHtcbiAgZGlzcGxheTogbm9uZVxufVxuXG4udmVydGljYWwtbmF2LW1lbnUgdWwgPiBsaSA+IGEubW0tYWN0aXZlIHtcbiAgY29sb3I6ICMzZjZhZDg7XG4gIGJhY2tncm91bmQ6ICNlMGYzZmY7XG4gIGZvbnQtd2VpZ2h0OiBib2xkXG59XG5cbi5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtbGlnaHQge1xuICBib3JkZXItcmlnaHQ6IDAgIWltcG9ydGFudFxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWxpZ2h0IC5hcHAtc2lkZWJhcl9faGVhZGluZyB7XG4gIGNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNilcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1saWdodCAuYXBwLXNpZGViYXJfX2hlYWRpbmc6OmJlZm9yZSB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC41KSAhaW1wb3J0YW50XG59XG5cbi5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtbGlnaHQgLnZlcnRpY2FsLW5hdi1tZW51IGxpIGEge1xuICBjb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjcpXG59XG5cbi5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtbGlnaHQgLnZlcnRpY2FsLW5hdi1tZW51IGxpIGEgaS5tZXRpc21lbnUtaWNvbiB7XG4gIG9wYWNpdHk6IC41XG59XG5cbi5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtbGlnaHQgLnZlcnRpY2FsLW5hdi1tZW51IGxpIGEgaS5tZXRpc21lbnUtc3RhdGUtaWNvbiB7XG4gIG9wYWNpdHk6IC41XG59XG5cbi5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtbGlnaHQgLnZlcnRpY2FsLW5hdi1tZW51IGxpIGE6aG92ZXIge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMTUpO1xuICBjb2xvcjogI2ZmZlxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWxpZ2h0IC52ZXJ0aWNhbC1uYXYtbWVudSBsaSBhOmhvdmVyIGkubWV0aXNtZW51LWljb24ge1xuICBvcGFjaXR5OiAuOFxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWxpZ2h0IC52ZXJ0aWNhbC1uYXYtbWVudSBsaSBhOmhvdmVyIGkubWV0aXNtZW51LXN0YXRlLWljb24ge1xuICBvcGFjaXR5OiAxXG59XG5cbi5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtbGlnaHQgLnZlcnRpY2FsLW5hdi1tZW51IGxpIGEubW0tYWN0aXZlIHtcbiAgY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC43KTtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjE1KVxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWxpZ2h0IC52ZXJ0aWNhbC1uYXYtbWVudSB1bDpiZWZvcmUge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMSlcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1saWdodCAudmVydGljYWwtbmF2LW1lbnUgdWwgPiBsaSA+IGEge1xuICBjb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjYpXG59XG5cbi5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtbGlnaHQgLnZlcnRpY2FsLW5hdi1tZW51IHVsID4gbGkgPiBhOmhvdmVyIHtcbiAgY29sb3I6ICNmZmZcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1saWdodCAudmVydGljYWwtbmF2LW1lbnUgdWwgPiBsaSA+IGEubW0tYWN0aXZlIHtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4xNSlcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1saWdodCAucHNfX3RodW1iLXkge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMylcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1saWdodCAucHNfX3JhaWwteTpob3ZlciAucHNfX3RodW1iLXkge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMilcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1saWdodCAuYXBwLWhlYWRlcl9fbG9nbyAubG9nby1zcmMge1xuICBiYWNrZ3JvdW5kOiB1cmwoc3JjL2Fzc2V0cy9pbWFnZXMvbG9nby5wbmcpXG59XG5cbi5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtbGlnaHQgLmFwcC1oZWFkZXJfX2xvZ28gLmhhbWJ1cmdlci1pbm5lciwgLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1saWdodCAuYXBwLWhlYWRlcl9fbG9nbyAuaGFtYnVyZ2VyLWlubmVyOjpiZWZvcmUsIC5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtbGlnaHQgLmFwcC1oZWFkZXJfX2xvZ28gLmhhbWJ1cmdlci1pbm5lcjo6YWZ0ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOClcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1kYXJrIHtcbiAgYm9yZGVyLXJpZ2h0OiAwICFpbXBvcnRhbnRcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1kYXJrIC5hcHAtc2lkZWJhcl9faGVhZGluZyB7XG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNilcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1kYXJrIC5hcHAtc2lkZWJhcl9faGVhZGluZzo6YmVmb3JlIHtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjUpICFpbXBvcnRhbnRcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1kYXJrIC52ZXJ0aWNhbC1uYXYtbWVudSBsaSBhIHtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42KVxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWRhcmsgLnZlcnRpY2FsLW5hdi1tZW51IGxpIGEgaS5tZXRpc21lbnUtaWNvbiB7XG4gIG9wYWNpdHk6IC41XG59XG5cbi5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtZGFyayAudmVydGljYWwtbmF2LW1lbnUgbGkgYSBpLm1ldGlzbWVudS1zdGF0ZS1pY29uIHtcbiAgb3BhY2l0eTogLjVcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1kYXJrIC52ZXJ0aWNhbC1uYXYtbWVudSBsaSBhOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjE1KTtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC43KVxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWRhcmsgLnZlcnRpY2FsLW5hdi1tZW51IGxpIGE6aG92ZXIgaS5tZXRpc21lbnUtaWNvbiB7XG4gIG9wYWNpdHk6IC43XG59XG5cbi5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtZGFyayAudmVydGljYWwtbmF2LW1lbnUgbGkgYTpob3ZlciBpLm1ldGlzbWVudS1zdGF0ZS1pY29uIHtcbiAgb3BhY2l0eTogMVxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWRhcmsgLnZlcnRpY2FsLW5hdi1tZW51IGxpIGEubW0tYWN0aXZlIHtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC43KTtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjE1KVxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWRhcmsgLnZlcnRpY2FsLW5hdi1tZW51IHVsOmJlZm9yZSB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4xKVxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWRhcmsgLnZlcnRpY2FsLW5hdi1tZW51IHVsID4gbGkgPiBhIHtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC40KVxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWRhcmsgLnZlcnRpY2FsLW5hdi1tZW51IHVsID4gbGkgPiBhOmhvdmVyIHtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC43KVxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWRhcmsgLnZlcnRpY2FsLW5hdi1tZW51IHVsID4gbGkgPiBhLm1tLWFjdGl2ZSB7XG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNyk7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4xNSlcbn1cblxuLmFwcC1zaWRlYmFyLnNpZGViYXItdGV4dC1kYXJrIC5wc19fdGh1bWIteSB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4zKVxufVxuXG4uYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWRhcmsgLnBzX19yYWlsLXk6aG92ZXIgLnBzX190aHVtYi15IHtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjIpXG59XG5cbi5hcHAtc2lkZWJhci5zaWRlYmFyLXRleHQtZGFyayAuYXBwLWhlYWRlcl9fbG9nbyAuaGFtYnVyZ2VyLWlubmVyLCAuYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWRhcmsgLmFwcC1oZWFkZXJfX2xvZ28gLmhhbWJ1cmdlci1pbm5lcjo6YmVmb3JlLCAuYXBwLXNpZGViYXIuc2lkZWJhci10ZXh0LWRhcmsgLmFwcC1oZWFkZXJfX2xvZ28gLmhhbWJ1cmdlci1pbm5lcjo6YWZ0ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuOClcbn1cblxuLmZpeGVkLXNpZGViYXIgLmFwcC1zaWRlYmFyIHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICBoZWlnaHQ6IDEwMHZoXG59XG5cbi5maXhlZC1zaWRlYmFyIC5hcHAtbWFpbiAuYXBwLW1haW5fX291dGVyIHtcbiAgei1pbmRleDogOTtcbiAgcGFkZGluZy1sZWZ0OiAyODBweFxufVxuXG4uZml4ZWQtc2lkZWJhci5maXhlZC1oZWFkZXIgLmFwcC1zaWRlYmFyIC5hcHAtaGVhZGVyX19sb2dvIHtcbiAgZGlzcGxheTogbm9uZVxufVxuXG4uZml4ZWQtc2lkZWJhcjpub3QoLmZpeGVkLWhlYWRlcikgLmFwcC1zaWRlYmFyIC5hcHAtaGVhZGVyX19sb2dvIHtcbiAgZGlzcGxheTogZmxleFxufVxuXG4uZml4ZWQtc2lkZWJhcjpub3QoLmZpeGVkLWhlYWRlcikgLmFwcC1oZWFkZXIge1xuICBtYXJnaW4tbGVmdDogMjgwcHhcbn1cblxuLmZpeGVkLXNpZGViYXI6bm90KC5maXhlZC1oZWFkZXIpIC5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19sb2dvIHtcbiAgZGlzcGxheTogbm9uZVxufVxuXG4uZml4ZWQtc2lkZWJhci5jbG9zZWQtc2lkZWJhcjpub3QoLmZpeGVkLWhlYWRlcikgLmFwcC1oZWFkZXIge1xuICBtYXJnaW4tbGVmdDogODBweFxufVxuXG4uZml4ZWQtc2lkZWJhci5jbG9zZWQtc2lkZWJhcjpub3QoLmZpeGVkLWhlYWRlcikgLmFwcC1zaWRlYmFyIC5hcHAtaGVhZGVyX19sb2dvIHtcbiAgd2lkdGg6IDgwcHg7XG4gIHBhZGRpbmc6IDBcbn1cblxuLmZpeGVkLXNpZGViYXIuY2xvc2VkLXNpZGViYXI6bm90KC5maXhlZC1oZWFkZXIpIC5hcHAtc2lkZWJhciAuYXBwLWhlYWRlcl9fbG9nbyAubG9nby1zcmMge1xuICBkaXNwbGF5OiBub25lXG59XG5cbi5maXhlZC1zaWRlYmFyLmNsb3NlZC1zaWRlYmFyOm5vdCguZml4ZWQtaGVhZGVyKSAuYXBwLXNpZGViYXIgLmFwcC1oZWFkZXJfX2xvZ28gLmhlYWRlcl9fcGFuZSB7XG4gIG1hcmdpbi1yaWdodDogYXV0b1xufVxuXG4uY2xvc2VkLXNpZGViYXIgLmFwcC1zaWRlYmFyIHtcbiAgdHJhbnNpdGlvbjogYWxsIC4zcyBlYXNlO1xuICB3aWR0aDogODBweDtcbiAgbWluLXdpZHRoOiA4MHB4O1xuICBmbGV4OiAwIDAgODBweDtcbiAgei1pbmRleDogMTNcbn1cblxuLmNsb3NlZC1zaWRlYmFyIC5hcHAtc2lkZWJhciAuYXBwLXNpZGViYXJfX2lubmVyIC5hcHAtc2lkZWJhcl9faGVhZGluZyB7XG4gIHRleHQtaW5kZW50OiAtOTk5ZW1cbn1cblxuLmNsb3NlZC1zaWRlYmFyIC5hcHAtc2lkZWJhciAuYXBwLXNpZGViYXJfX2lubmVyIC5hcHAtc2lkZWJhcl9faGVhZGluZzo6YmVmb3JlIHtcbiAgY29udGVudDogJyc7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDFweDtcbiAgYmFja2dyb3VuZDogI2UwZjNmZjtcbiAgdGV4dC1pbmRlbnQ6IDFweFxufVxuXG4uY2xvc2VkLXNpZGViYXIgLmFwcC1zaWRlYmFyIC5hcHAtc2lkZWJhcl9faW5uZXIgdWwgbGkgYSB7XG4gIHRleHQtaW5kZW50OiAtOTlyZW07XG4gIHBhZGRpbmc6IDBcbn1cblxuLmNsb3NlZC1zaWRlYmFyIC5hcHAtc2lkZWJhciAuYXBwLXNpZGViYXJfX2lubmVyIC5tZXRpc21lbnUtaWNvbiB7XG4gIHRleHQtaW5kZW50OiAwO1xuICBsZWZ0OiA1MCU7XG4gIG1hcmdpbi1sZWZ0OiAtMTdweFxufVxuXG4uY2xvc2VkLXNpZGViYXIgLmFwcC1zaWRlYmFyIC5hcHAtc2lkZWJhcl9faW5uZXIgLm1ldGlzbWVudS1zdGF0ZS1pY29uIHtcbiAgdmlzaWJpbGl0eTogaGlkZGVuXG59XG5cbi5jbG9zZWQtc2lkZWJhciAuYXBwLXNpZGViYXIgLmFwcC1zaWRlYmFyX19pbm5lciB1bDo6YmVmb3JlIHtcbiAgZGlzcGxheTogbm9uZVxufVxuXG4uY2xvc2VkLXNpZGViYXIgLmFwcC1zaWRlYmFyIC5hcHAtc2lkZWJhcl9faW5uZXIgdWwubW0tc2hvdyB7XG4gIHBhZGRpbmc6IDBcbn1cblxuLmNsb3NlZC1zaWRlYmFyIC5hcHAtc2lkZWJhciAuYXBwLXNpZGViYXJfX2lubmVyIHVsLm1tLXNob3cgPiBsaSA+IGEge1xuICBoZWlnaHQ6IDBcbn1cblxuLmNsb3NlZC1zaWRlYmFyIC5hcHAtc2lkZWJhcjpob3ZlciB7XG4gIGZsZXg6IDAgMCAyODBweCAhaW1wb3J0YW50O1xuICB3aWR0aDogMjgwcHggIWltcG9ydGFudFxufVxuXG4uY2xvc2VkLXNpZGViYXIgLmFwcC1zaWRlYmFyOmhvdmVyIC5hcHAtc2lkZWJhcl9faW5uZXIgLmFwcC1zaWRlYmFyX19oZWFkaW5nIHtcbiAgdGV4dC1pbmRlbnQ6IGluaXRpYWxcbn1cblxuLmNsb3NlZC1zaWRlYmFyIC5hcHAtc2lkZWJhcjpob3ZlciAuYXBwLXNpZGViYXJfX2lubmVyIC5hcHAtc2lkZWJhcl9faGVhZGluZzo6YmVmb3JlIHtcbiAgZGlzcGxheTogbm9uZVxufVxuXG5cbi5jbG9zZWQtc2lkZWJhciAuYXBwLXNpZGViYXI6aG92ZXIgLmFwcC1zaWRlYmFyX19pbm5lciB1bDo6YmVmb3JlIHtcbiAgZGlzcGxheTogYmxvY2tcbn1cblxuLmNsb3NlZC1zaWRlYmFyIC5hcHAtc2lkZWJhcjpob3ZlciAuYXBwLXNpZGViYXJfX2lubmVyIHVsIGxpIGEge1xuICB0ZXh0LWluZGVudDogaW5pdGlhbDtcbiAgcGFkZGluZzogMCAxLjVyZW0gMCA0NXB4XG59XG5cbi5jbG9zZWQtc2lkZWJhciAuYXBwLXNpZGViYXI6aG92ZXIgLmFwcC1zaWRlYmFyX19pbm5lciAubWV0aXNtZW51LWljb24ge1xuICB0ZXh0LWluZGVudDogaW5pdGlhbDtcbiAgbGVmdDogNXB4O1xuICBtYXJnaW4tbGVmdDogMFxufVxuXG4uY2xvc2VkLXNpZGViYXIgLmFwcC1zaWRlYmFyOmhvdmVyIC5hcHAtc2lkZWJhcl9faW5uZXIgLm1ldGlzbWVudS1zdGF0ZS1pY29uIHtcbiAgdmlzaWJpbGl0eTogdmlzaWJsZVxufVxuXG4uY2xvc2VkLXNpZGViYXIgLmFwcC1zaWRlYmFyOmhvdmVyIC5hcHAtc2lkZWJhcl9faW5uZXIgdWwubW0tc2hvdyB7XG4gIHBhZGRpbmc6IC41ZW0gMCAwIDJyZW1cbn1cblxuLmNsb3NlZC1zaWRlYmFyIC5hcHAtc2lkZWJhcjpob3ZlciAuYXBwLXNpZGViYXJfX2lubmVyIHVsLm1tLXNob3cgPiBsaSA+IGEge1xuICBoZWlnaHQ6IDIuM2VtXG59XG5cbi5jbG9zZWQtc2lkZWJhciAuYXBwLXNpZGViYXI6aG92ZXIgLmFwcC1zaWRlYmFyX19pbm5lciB1bCB1bCBsaSBhIHtcbiAgcGFkZGluZy1sZWZ0OiAxZW1cbn1cblxuLmNsb3NlZC1zaWRlYmFyOm5vdCguc2lkZWJhci1tb2JpbGUtb3BlbikgLmFwcC1zaWRlYmFyIC5zY3JvbGxiYXItc2lkZWJhciB7XG4gIHBvc2l0aW9uOiBzdGF0aWM7XG4gIGhlaWdodDogYXV0bztcbiAgb3ZlcmZsb3c6IGluaXRpYWwgIWltcG9ydGFudFxufVxuXG4uY2xvc2VkLXNpZGViYXI6bm90KC5zaWRlYmFyLW1vYmlsZS1vcGVuKSAuYXBwLXNpZGViYXI6aG92ZXIgLnNjcm9sbGJhci1zaWRlYmFyIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIG92ZXJmbG93OiBoaWRkZW4gIWltcG9ydGFudFxufVxuXG4uY2xvc2VkLXNpZGViYXI6bm90KC5jbG9zZWQtc2lkZWJhci1tb2JpbGUpIC5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19sb2dvIHtcbiAgd2lkdGg6IDgwcHhcbn1cblxuLmNsb3NlZC1zaWRlYmFyOm5vdCguY2xvc2VkLXNpZGViYXItbW9iaWxlKSAuYXBwLWhlYWRlciAuYXBwLWhlYWRlcl9fbG9nbyAubG9nby1zcmMge1xuICBkaXNwbGF5OiBub25lXG59XG5cbi5jbG9zZWQtc2lkZWJhcjpub3QoLmNsb3NlZC1zaWRlYmFyLW1vYmlsZSkgLmFwcC1oZWFkZXIgLmFwcC1oZWFkZXJfX2xvZ28gLmhlYWRlcl9fcGFuZSB7XG4gIG1hcmdpbi1yaWdodDogYXV0b1xufVxuXG4uY2xvc2VkLXNpZGViYXIuZml4ZWQtc2lkZWJhciAuYXBwLW1haW5fX291dGVyIHtcbiAgcGFkZGluZy1sZWZ0OiA4MHB4XG59XG5cbi5jbG9zZWQtc2lkZWJhci5maXhlZC1oZWFkZXI6bm90KC5maXhlZC1zaWRlYmFyKSAuYXBwLXNpZGViYXIgLmFwcC1oZWFkZXJfX2xvZ28ge1xuICB2aXNpYmlsaXR5OiBoaWRkZW5cbn1cblxuLmNsb3NlZC1zaWRlYmFyLmNsb3NlZC1zaWRlYmFyLW1vYmlsZSAuYXBwLXNpZGViYXIgLmFwcC1oZWFkZXJfX2xvZ28sIC5jbG9zZWQtc2lkZWJhci5jbG9zZWQtc2lkZWJhci1tb2JpbGUgLmFwcC1oZWFkZXIgLmFwcC1oZWFkZXJfX2xvZ28ge1xuICB3aWR0aDogYXV0bztcbiAgZGlzcGxheTogZmxleFxufVxuXG4uY2xvc2VkLXNpZGViYXIuY2xvc2VkLXNpZGViYXItbW9iaWxlIC5hcHAtc2lkZWJhciAuYXBwLWhlYWRlcl9fbG9nbyAuaGVhZGVyX19wYW5lLCAuY2xvc2VkLXNpZGViYXIuY2xvc2VkLXNpZGViYXItbW9iaWxlIC5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19sb2dvIC5oZWFkZXJfX3BhbmUge1xuICBkaXNwbGF5OiBub25lXG59XG5cbi5jbG9zZWQtc2lkZWJhci5jbG9zZWQtc2lkZWJhci1tb2JpbGUgLmFwcC1zaWRlYmFyIC5hcHAtaGVhZGVyX19sb2dvIHtcbiAgZGlzcGxheTogZmxleDtcbiAgd2lkdGg6IDgwcHg7XG4gIHBhZGRpbmc6IDAgMS41cmVtICFpbXBvcnRhbnRcbn1cblxuLmNsb3NlZC1zaWRlYmFyLmNsb3NlZC1zaWRlYmFyLW1vYmlsZSAuYXBwLXNpZGViYXIgLmFwcC1oZWFkZXJfX2xvZ28gLmxvZ28tc3JjIHtcbiAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcbiAgbWFyZ2luOiAwIGF1dG87XG4gIHdpZHRoOiAyMXB4XG59XG5cbi5jbG9zZWQtc2lkZWJhci5jbG9zZWQtc2lkZWJhci1tb2JpbGUgLmFwcC1zaWRlYmFyIC5hcHAtaGVhZGVyX19sb2dvIC5oZWFkZXJfX3BhbmUge1xuICBkaXNwbGF5OiBub25lXG59XG5cbi5jbG9zZWQtc2lkZWJhci5jbG9zZWQtc2lkZWJhci1tb2JpbGUgLmFwcC1zaWRlYmFyOmhvdmVyIC5hcHAtaGVhZGVyX19sb2dvIHtcbiAgd2lkdGg6IDI4MHB4XG5cbn1cblxuLmNsb3NlZC1zaWRlYmFyLmNsb3NlZC1zaWRlYmFyLW1vYmlsZSAuYXBwLXNpZGViYXI6aG92ZXIgLmFwcC1oZWFkZXJfX2xvZ28gLmxvZ28tc3JjIHtcbiAgd2lkdGg6IDk3cHg7XG4gIG1hcmdpbjogMFxufVxuXG4uY2xvc2VkLXNpZGViYXIuY2xvc2VkLXNpZGViYXItbW9iaWxlIC5hcHAtaGVhZGVyIHtcbiAgbWFyZ2luLWxlZnQ6IDAgIWltcG9ydGFudFxufVxuXG4uY2xvc2VkLXNpZGViYXIuZml4ZWQtZm9vdGVyIC5hcHAtZm9vdGVyX19pbm5lciB7XG4gIG1hcmdpbi1sZWZ0OiAwICFpbXBvcnRhbnRcbn1cblxuLmFwcC1tYWluIHtcbiAgZmxleDogMTtcbiAgZGlzcGxheTogZmxleDtcbiAgei1pbmRleDogODtcbiAgcG9zaXRpb246IHJlbGF0aXZlXG59XG5cbi5hcHAtbWFpbiAuYXBwLW1haW5fX291dGVyIHtcbiAgZmxleDogMTtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgZGlzcGxheTogZmxleDtcbiAgei1pbmRleDogMTJcbn1cblxuLmFwcC1tYWluIC5hcHAtbWFpbl9faW5uZXIge1xuICBwYWRkaW5nOiAzMHB4IDMwcHggMDtcbiAgZmxleDogMVxufVxuXG4uYXBwLXRoZW1lLXdoaXRlLmFwcC1jb250YWluZXIge1xuICBiYWNrZ3JvdW5kOiAjZjFmNGY2XG59XG5cbi5hcHAtdGhlbWUtd2hpdGUgLmFwcC1zaWRlYmFyIHtcbiAgYmFja2dyb3VuZDogI2ZmZlxufVxuXG4uYXBwLXRoZW1lLXdoaXRlIC5hcHAtcGFnZS10aXRsZSB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC40NSlcbn1cblxuLmFwcC10aGVtZS13aGl0ZSAuYXBwLWZvb3RlciAuYXBwLWZvb3Rlcl9faW5uZXIsIC5hcHAtdGhlbWUtd2hpdGUgLmFwcC1oZWFkZXIge1xuICBiYWNrZ3JvdW5kOiAjZmFmYmZjXG59XG5cbi5hcHAtdGhlbWUtd2hpdGUuZml4ZWQtaGVhZGVyIC5hcHAtaGVhZGVyX19sb2dvIHtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTAsIDI1MSwgMjUyLCAwLjEpXG59XG5cbi5hcHAtdGhlbWUtZ3JheS5hcHAtY29udGFpbmVyIHtcbiAgYmFja2dyb3VuZDogI2ZmZlxufVxuXG4uYXBwLXRoZW1lLWdyYXkgLmFwcC1zaWRlYmFyIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgYm9yZGVyLXJpZ2h0OiAjZGVlMmU2IHNvbGlkIDFweFxufVxuXG4uYXBwLXRoZW1lLWdyYXkgLmFwcC1wYWdlLXRpdGxlIHtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjAzKVxufVxuXG4uYXBwLXRoZW1lLWdyYXkgLmFwcC1mb290ZXIsIC5hcHAtdGhlbWUtZ3JheSAuYXBwLWhlYWRlciB7XG4gIGJhY2tncm91bmQ6ICNmOGY5ZmFcbn1cblxuLmFwcC10aGVtZS1ncmF5IC5hcHAtZm9vdGVyIHtcbiAgYm9yZGVyLXRvcDogI2RlZTJlNiBzb2xpZCAxcHhcbn1cblxuLmFwcC10aGVtZS1ncmF5IC5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19sb2dvIHtcbiAgYm9yZGVyLXJpZ2h0OiByZ2JhKDAsIDAsIDAsIDAuMSkgc29saWQgMXB4XG59XG5cbi5hcHAtdGhlbWUtZ3JheS5maXhlZC1oZWFkZXIgLmFwcC1oZWFkZXJfX2xvZ28ge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuMDMpXG59XG5cbi5hcHAtdGhlbWUtZ3JheSAuY2FyZCB7XG4gIGJvcmRlci13aWR0aDogMXB4XG59XG5cbi5hcHAtdGhlbWUtZ3JheSAubWFpbi1jYXJkIHtcbiAgYm94LXNoYWRvdzogMCAwIDAgMCB0cmFuc3BhcmVudCAhaW1wb3J0YW50XG59XG5cbi5hcHAtdGhlbWUtZ3JheSAubWFpbi1jYXJkID4gLmNhcmQtYm9keSA+IC5jYXJkLXRpdGxlIHtcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gIGZvbnQtc2l6ZTogMS4xcmVtO1xuICBmb250LXdlaWdodDogbm9ybWFsO1xuICBib3JkZXItYm90dG9tOiAjZGVlMmU2IHNvbGlkIDFweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBwYWRkaW5nOiAwIDAgMS4xMjVyZW07XG4gIG1hcmdpbjogMCAwIDEuMTI1cmVtXG59XG5cbi5hcHAtdGhlbWUtZ3JheSAubWFpbi1jYXJkID4gLmNhcmQtYm9keSA+IC5jYXJkLXRpdGxlOjpiZWZvcmUge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiA0MHB4O1xuICBiYWNrZ3JvdW5kOiAjM2Y2YWQ4O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBoZWlnaHQ6IDVweDtcbiAgbGVmdDogMDtcbiAgYm90dG9tOiAtMnB4O1xuICBjb250ZW50OiBcIlwiXG59XG5cbi5hcHAtdGhlbWUtZ3JheSAuYXBwLWlubmVyLWxheW91dF9fc2lkZWJhciB7XG4gIGJvcmRlci1sZWZ0OiAwICFpbXBvcnRhbnRcbn1cblxuLmZpeGVkLWZvb3RlciAuYXBwLWZvb3RlciB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvdHRvbTogMDtcbiAgbGVmdDogMDtcbiAgei1pbmRleDogN1xufVxuXG4uZml4ZWQtZm9vdGVyIC5hcHAtZm9vdGVyIC5hcHAtZm9vdGVyX19pbm5lciB7XG4gIG1hcmdpbi1sZWZ0OiAyODBweDtcbiAgYm94LXNoYWRvdzogMC4zcmVtIC0wLjQ2ODc1cmVtIDIuMTg3NXJlbSByZ2JhKDQsIDksIDIwLCAwLjAyKSwgMC4zcmVtIC0wLjkzNzVyZW0gMS40MDYyNXJlbSByZ2JhKDQsIDksIDIwLCAwLjAyKSwgMC4zcmVtIC0wLjI1cmVtIDAuNTMxMjVyZW0gcmdiYSg0LCA5LCAyMCwgMC4wNCksIDAuM3JlbSAtMC4xMjVyZW0gMC4xODc1cmVtIHJnYmEoNCwgOSwgMjAsIDAuMDIpXG59XG5cbi5maXhlZC1mb290ZXIgLmFwcC1tYWluIC5hcHAtbWFpbl9fb3V0ZXIge1xuICBwYWRkaW5nLWJvdHRvbTogNjBweFxufVxuXG4uYXBwLXBhZ2UtdGl0bGUge1xuICBwYWRkaW5nOiAzMHB4O1xuICBtYXJnaW46IC0zMHB4IC0zMHB4IDMwcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZVxufVxuXG4uYXBwLXBhZ2UtdGl0bGUgKyAuYm9keS10YWJzLWxheW91dCB7XG4gIG1hcmdpbi10b3A6IC0zMHB4ICFpbXBvcnRhbnRcbn1cblxuLmFwcC1wYWdlLXRpdGxlIC5wYWdlLXRpdGxlLXdyYXBwZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXJcbn1cblxuLmFwcC1wYWdlLXRpdGxlIC5wYWdlLXRpdGxlLWhlYWRpbmcsIC5hcHAtcGFnZS10aXRsZSAucGFnZS10aXRsZS1zdWJoZWFkaW5nIHtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwXG59XG5cbi5hcHAtcGFnZS10aXRsZSAucGFnZS10aXRsZS1oZWFkaW5nIHtcbiAgZm9udC1zaXplOiAxLjI1cmVtO1xuICBmb250LXdlaWdodDogNDAwO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXJcbn1cblxuLmFwcC1wYWdlLXRpdGxlIC5wYWdlLXRpdGxlLXN1YmhlYWRpbmcge1xuICBwYWRkaW5nOiAzcHggMCAwO1xuICBmb250LXNpemU6IC44OHJlbTtcbiAgb3BhY2l0eTogLjZcbn1cblxuLmFwcC1wYWdlLXRpdGxlIC5wYWdlLXRpdGxlLXN1YmhlYWRpbmcgLmJyZWFkY3J1bWIge1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IDNweCAwIDA7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50XG59XG5cbi5hcHAtcGFnZS10aXRsZSAucGFnZS10aXRsZS1hY3Rpb25zIHtcbiAgbWFyZ2luLWxlZnQ6IGF1dG9cbn1cblxuLmFwcC1wYWdlLXRpdGxlIC5wYWdlLXRpdGxlLWFjdGlvbnMgLmJyZWFkY3J1bWIge1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50XG59XG5cbi5hcHAtcGFnZS10aXRsZSAucGFnZS10aXRsZS1pY29uIHtcbiAgZm9udC1zaXplOiAycmVtO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogLjgzMzMzcmVtO1xuICBtYXJnaW46IDAgMzBweCAwIDA7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGJveC1zaGFkb3c6IDAgMC40Njg3NXJlbSAyLjE4NzVyZW0gcmdiYSg0LCA5LCAyMCwgMC4wMyksIDAgMC45Mzc1cmVtIDEuNDA2MjVyZW0gcmdiYSg0LCA5LCAyMCwgMC4wMyksIDAgMC4yNXJlbSAwLjUzMTI1cmVtIHJnYmEoNCwgOSwgMjAsIDAuMDUpLCAwIDAuMTI1cmVtIDAuMTg3NXJlbSByZ2JhKDQsIDksIDIwLCAwLjAzKTtcbiAgYm9yZGVyLXJhZGl1czogLjI1cmVtO1xuICB3aWR0aDogNjBweDtcbiAgaGVpZ2h0OiA2MHB4XG59XG5cbi5hcHAtcGFnZS10aXRsZSAucGFnZS10aXRsZS1pY29uIGkge1xuICBtYXJnaW46IGF1dG9cbn1cblxuLmFwcC1wYWdlLXRpdGxlIC5wYWdlLXRpdGxlLWljb24ucm91bmRlZC1jaXJjbGUge1xuICBtYXJnaW46IDAgMjBweCAwIDBcbn1cblxuLmFwcC1wYWdlLXRpdGxlICsgLlJSVF9fY29udGFpbmVyIHtcbiAgbWFyZ2luLXRvcDogLTIzLjA3NjkycHhcbn1cblxuLmFwcC1wYWdlLXRpdGxlLmFwcC1wYWdlLXRpdGxlLXNpbXBsZSB7XG4gIG1hcmdpbjogMDtcbiAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWxlZnQ6IDA7XG4gIHBhZGRpbmctcmlnaHQ6IDA7XG4gIHBhZGRpbmctdG9wOiAwXG59XG5cbi5wYWdlLXRpdGxlLWljb24tcm91bmRlZCAucGFnZS10aXRsZS1pY29uIHtcbiAgYm9yZGVyLXJhZGl1czogNTBweFxufVxuXG5ib2R5IHtcbiAgLXdlYmtpdC1iYWNrZmFjZS12aXNpYmlsaXR5OiBoaWRkZW5cbn1cblxuLmRyb3Bkb3duLW1lbnUuc2hvdyB7XG4gIGFuaW1hdGlvbjogZmFkZS1pbjIgMC4ycyBjdWJpYy1iZXppZXIoMC4zOSwgMC41NzUsIDAuNTY1LCAxKSBib3RoXG59XG5cbi5wb3BvdmVyOm5vdChbZGF0YS1wbGFjZW1lbnRePVwidG9wXCJdKS5zaG93IHtcbiAgYW5pbWF0aW9uOiBmYWRlLWluMiAwLjJzIGN1YmljLWJlemllcigwLjM5LCAwLjU3NSwgMC41NjUsIDEpIGJvdGhcbn1cblxuLmRyb3Bkb3duLW1lbnVbZGF0YS1wbGFjZW1lbnRePVwidG9wXCJdLnNob3cge1xuICBhbmltYXRpb246IGZhZGUtaW4zIDAuMnMgY3ViaWMtYmV6aWVyKDAuMzksIDAuNTc1LCAwLjU2NSwgMSkgYm90aDtcbiAgYm90dG9tOiBhdXRvICFpbXBvcnRhbnQ7XG4gIHRvcDogYXV0byAhaW1wb3J0YW50XG59XG5cbi5kcm9wZG93bi1tZW51IHtcbiAgYm94LXNoYWRvdzogMCAwLjQ2ODc1cmVtIDIuMTg3NXJlbSByZ2JhKDQsIDksIDIwLCAwLjAzKSwgMCAwLjkzNzVyZW0gMS40MDYyNXJlbSByZ2JhKDQsIDksIDIwLCAwLjAzKSwgMCAwLjI1cmVtIDAuNTMxMjVyZW0gcmdiYSg0LCA5LCAyMCwgMC4wNSksIDAgMC4xMjVyZW0gMC4xODc1cmVtIHJnYmEoNCwgOSwgMjAsIDAuMDMpO1xuICBtYXJnaW46IC4xMjVyZW1cbn1cblxuLmRyb3Bkb3duLW1lbnUuZHJvcGRvd24tbWVudS1yaWdodCB7XG4gIHJpZ2h0OiAwICFpbXBvcnRhbnRcbn1cblxuLmRyb3Bkb3duLW1lbnUgLmRyb3Bkb3duLWhlYWRlciB7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGZvbnQtc2l6ZTogLjczMzMzcmVtO1xuICBjb2xvcjogIzNmNmFkODtcbiAgZm9udC13ZWlnaHQ6IGJvbGRcbn1cblxuLmRyb3Bkb3duLW1lbnUgLmRyb3Bkb3duLWl0ZW0ge1xuICBmb250LXNpemU6IC44OHJlbTtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgdHJhbnNpdGlvbjogYmFja2dyb3VuZC1jb2xvciAwLjNzIGVhc2UsIGNvbG9yIDAuM3MgZWFzZTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICB6LWluZGV4OiA2O1xuICBwb3NpdGlvbjogcmVsYXRpdmVcbn1cblxuLmRyb3Bkb3duLW1lbnUgLmRyb3Bkb3duLWl0ZW0gLmRyb3Bkb3duLWljb24ge1xuICBmb250LXNpemU6IDFyZW07XG4gIG1hcmdpbi1yaWdodDogLjMyNXJlbTtcbiAgd2lkdGg6IDMwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgb3BhY2l0eTogLjM7XG4gIG1hcmdpbi1sZWZ0OiAtMTBweFxufVxuXG4uZHJvcGRvd24tbWVudSAuZHJvcGRvd24taXRlbTpob3ZlciAuZHJvcGRvd24taWNvbiB7XG4gIG9wYWNpdHk6IC43XG59XG5cbi5kcm9wZG93bi1tZW51LmRyb3Bkb3duLW1lbnUtc2hhZG93IHtcbiAgYm94LXNoYWRvdzogMCAwLjY2ODc1cmVtIDIuMzg3NXJlbSByZ2JhKDQsIDksIDIwLCAwLjAzKSwgMCAxLjEzNzVyZW0gMS42MDYyNXJlbSByZ2JhKDQsIDksIDIwLCAwLjAzKSwgMCAwLjQ1cmVtIDAuNzMxMjVyZW0gcmdiYSg0LCA5LCAyMCwgMC4wNSksIDAgMC4zMjVyZW0gMC4zODc1cmVtIHJnYmEoNCwgOSwgMjAsIDAuMDMpXG59XG5cbi5kcm9wZG93bi1tZW51LXJvdW5kZWQge1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBwYWRkaW5nOiAuNjVyZW1cbn1cblxuLmRyb3Bkb3duLW1lbnUtcm91bmRlZCAuZHJvcGRvd24taXRlbSB7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHhcbn1cblxuLmRyb3Bkb3duLW1lbnUtcm91bmRlZCAuZHJvcGRvd24tZGl2aWRlciB7XG4gIG1hcmdpbi1sZWZ0OiAtLjY1cmVtO1xuICBtYXJnaW4tcmlnaHQ6IC0uNjVyZW1cbn1cblxuLmRyb3Bkb3duLW1lbnUtcm91bmRlZCAuZHJvcGRvd24tbWVudS1oZWFkZXIge1xuICBtYXJnaW4tbGVmdDogLS42NXJlbTtcbiAgbWFyZ2luLXJpZ2h0OiAtLjY1cmVtO1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAxMHB4O1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMTBweFxufVxuXG4uZHJvcGRvd24tbWVudS1yb3VuZGVkIC5tZW51LWhlYWRlci1pbWFnZSwgLmRyb3Bkb3duLW1lbnUtcm91bmRlZCAuZHJvcGRvd24tbWVudS1oZWFkZXItaW5uZXIge1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAxMHB4O1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMTBweFxufVxuXG4uZHJvcGRvd24tbWVudS1ob3Zlci1saW5rIC5kcm9wZG93bi1pdGVtOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbiAgY29sb3I6ICMzZjZhZDhcbn1cblxuLmRyb3Bkb3duLW1lbnUtaG92ZXItcHJpbWFyeSAuZHJvcGRvd24taXRlbTpob3ZlciB7XG4gIGJhY2tncm91bmQ6ICMzZjZhZDg7XG4gIGNvbG9yOiAjZmZmXG59XG5cbi5kcm9wZG93bi1tZW51LmRyb3Bkb3duLW1lbnUtbGcge1xuICBtaW4td2lkdGg6IDIycmVtXG59XG5cbi5kcm9wZG93bi1tZW51LmRyb3Bkb3duLW1lbnUteGwge1xuICBtaW4td2lkdGg6IDI1cmVtXG59XG5cbi5kcm9wZG93bi1tZW51IC5kcm9wZG93bi1tZW51LWhlYWRlciwgLmRyb3Bkb3duLW1lbnUgLm1lbnUtaGVhZGVyLWltYWdlLCAuZHJvcGRvd24tbWVudSAuZHJvcGRvd24tbWVudS1oZWFkZXItaW5uZXIge1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAuMjVyZW07XG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAuMjVyZW1cbn1cblxuLmRyb3Bkb3duLW1lbnUtaGVhZGVyIHtcbiAgY29sb3I6ICNmZmY7XG4gIG1hcmdpbi10b3A6IC0uNjVyZW07XG4gIG1hcmdpbi1ib3R0b206IC42NXJlbTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB6LWluZGV4OiA2XG59XG5cbi5kcm9wZG93bi1tZW51LWhlYWRlciAuZHJvcGRvd24tbWVudS1oZWFkZXItaW5uZXIge1xuICBtYXJnaW46IC0xcHggLTFweCAwO1xuICBwYWRkaW5nOiAxLjVyZW0gLjVyZW07XG4gIHBvc2l0aW9uOiByZWxhdGl2ZVxufVxuXG4uZHJvcGRvd24tbWVudS1oZWFkZXIgLm1lbnUtaGVhZGVyLWltYWdlIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICB0b3A6IDA7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIHotaW5kZXg6IDg7XG4gIG9wYWNpdHk6IC4yNTtcbiAgZmlsdGVyOiBncmF5c2NhbGUoODAlKTtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlclxufVxuXG4uZHJvcGRvd24tbWVudS1oZWFkZXIgLm1lbnUtaGVhZGVyLWNvbnRlbnQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMTBcbn1cblxuLmRyb3Bkb3duLW1lbnUtaGVhZGVyIC5tZW51LWhlYWRlci1jb250ZW50LnRleHQtbGVmdCB7XG4gIHBhZGRpbmctbGVmdDogLjVyZW1cbn1cblxuLmRyb3Bkb3duLW1lbnUtaGVhZGVyIC5tZW51LWhlYWRlci1jb250ZW50LmJ0bi1wYW5lLXJpZ2h0IHtcbiAgcGFkZGluZy1sZWZ0OiAuNXJlbTtcbiAgcGFkZGluZy1yaWdodDogLjVyZW07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgdGV4dC1hbGlnbjogbGVmdFxufVxuXG4uZHJvcGRvd24tbWVudS1oZWFkZXIgLm1lbnUtaGVhZGVyLWNvbnRlbnQuYnRuLXBhbmUtcmlnaHQgLm1lbnUtaGVhZGVyLWJ0bi1wYW5lIHtcbiAgbWFyZ2luOiAwIDAgMCBhdXRvXG59XG5cbi5kcm9wZG93bi1tZW51LWhlYWRlciAubWVudS1oZWFkZXItY29udGVudCAubWVudS1oZWFkZXItYnRuLXBhbmUge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAzcHhcbn1cblxuLmRyb3Bkb3duLW1lbnUtaGVhZGVyICsgLmdyaWQtbWVudSB7XG4gIG1hcmdpbi10b3A6IC0uNjVyZW1cbn1cblxuLm1lbnUtaGVhZGVyLXRpdGxlIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zaXplOiAxLjI1cmVtO1xuICBtYXJnaW46IDBcbn1cblxuLm1lbnUtaGVhZGVyLXN1YnRpdGxlIHtcbiAgLypmb250LXNpemU6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIFwiSGVsdmV0aWNhIE5ldWVcIiwgQXJpYWwsIFwiTm90byBTYW5zXCIsIHNhbnMtc2VyaWYsIFwiQXBwbGUgQ29sb3IgRW1vamlcIiwgXCJTZWdvZSBVSSBFbW9qaVwiLCBcIlNlZ29lIFVJIFN5bWJvbFwiLCBcIk5vdG8gQ29sb3IgRW1vamlcIjsqL1xuICBtYXJnaW46IDVweCAwIDA7XG4gIG9wYWNpdHk6IC44XG59XG5cbi5kcm9wZG93bi1tZW51IC5ncmlkLW1lbnUge1xuICBtYXJnaW4tYm90dG9tOiAtLjY1cmVtO1xuICBwYWRkaW5nOiAxcHhcbn1cblxuLmRyb3Bkb3duLW1lbnUgLmdyaWQtbWVudSBbY2xhc3MqPVwiY29sLVwiXSB7XG4gIHBhZGRpbmc6IC42NXJlbVxufVxuXG4uZHJvcGRvd24tbWVudSAuZ3JpZC1tZW51LXhsIHtcbiAgbWFyZ2luLWJvdHRvbTogLS40ODE0OHJlbVxufVxuXG4uZHJvcGRvd24tbWVudSAuZ3JpZC1tZW51LXhsIFtjbGFzcyo9XCJjb2wtXCJdIHtcbiAgcGFkZGluZzogMFxufVxuXG4uZHJvcGRvd24tdG9nZ2xlOjphZnRlciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdG9wOiAycHg7XG4gIG9wYWNpdHk6IC44O1xuICBtYXJnaW4tbGVmdDogNXB4XG59XG5cbi5kcm9wZG93bi10b2dnbGUtc3BsaXQ6OmFmdGVyIHtcbiAgbWFyZ2luLWxlZnQ6IDBcbn1cblxuYm9keSAuZHJvcGRvd24tbWVudS5kcm9wZG93bi1tZW51LWlubGluZSB7XG4gIGJvcmRlcjogMDtcbiAgcG9zaXRpb246IHN0YXRpYyAhaW1wb3J0YW50O1xuICBib3gtc2hhZG93OiAwIDAgMCB0cmFuc3BhcmVudDtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDA7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZmxvYXQ6IG5vbmU7XG4gIGxlZnQ6IDAgIWltcG9ydGFudDtcbiAgdG9wOiAwICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKSAhaW1wb3J0YW50XG59XG5cbmJvZHkgLmRyb3Bkb3duLW1lbnUuZHJvcGRvd24tbWVudS1pbmxpbmU6OmJlZm9yZSwgYm9keSAuZHJvcGRvd24tbWVudS5kcm9wZG93bi1tZW51LWlubGluZTo6YWZ0ZXIge1xuICBkaXNwbGF5OiBub25lXG59XG5cbi5uYXYtaXRlbSAubmF2LWxpbmsge1xuICBmb250LXdlaWdodDogbm9ybWFsXG59XG5cbi5uYXYtbGluayB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIHRyYW5zaXRpb246IGJhY2tncm91bmQtY29sb3IgMC4zcyBlYXNlLCBjb2xvciAwLjNzIGVhc2U7XG4gIGN1cnNvcjogcG9pbnRlclxufVxuXG4ubmF2LWxpbmsgLm5hdi1saW5rLWljb24ge1xuICBjb2xvcjogIzNmNmFkODtcbiAgZm9udC1zaXplOiAxcmVtO1xuICB3aWR0aDogMzBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBvcGFjaXR5OiAuNDU7XG4gIG1hcmdpbi1sZWZ0OiAtMTBweFxufVxuXG4ubmF2LWxpbms6aG92ZXIge1xuICBjb2xvcjogIzQ5NTA1N1xufVxuXG4ubmF2LWxpbms6aG92ZXIgLm5hdi1saW5rLWljb24ge1xuICBvcGFjaXR5OiAuOTtcbiAgY29sb3I6ICMzZjZhZDhcbn1cblxuLm5hdi1saW5rOmRpc2FibGVkIC5uYXYtbGluay1pY29uLCAubmF2LWxpbmsuZGlzYWJsZWQgLm5hdi1saW5rLWljb24ge1xuICBvcGFjaXR5OiAuM1xufVxuXG4ubmF2LWl0ZW0ubmF2LWl0ZW0taGVhZGVyIHtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgZm9udC1zaXplOiAuNzMzMzNyZW07XG4gIGNvbG9yOiAjNmM3NTdkO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgcGFkZGluZzogLjVyZW0gMXJlbVxufVxuXG4ubmF2LWl0ZW0ubmF2LWl0ZW0tYnRuIHtcbiAgcGFkZGluZzogLjVyZW0gMXJlbVxufVxuXG4ubmF2LWl0ZW0ubmF2LWl0ZW0tZGl2aWRlciB7XG4gIG1hcmdpbjogLjVyZW0gMDtcbiAgaGVpZ2h0OiAxcHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGJhY2tncm91bmQ6ICNkZWUyZTZcbn1cblxuLm5hdiAuYmFkZ2Uge1xuICBtYXJnaW4tbGVmdDogOHB4XG59XG5cbi5uYXYtcGlsbHMgLm5hdi1saW5rLmFjdGl2ZSwgLm5hdi1waWxscyAubmF2LWxpbmsuYWN0aXZlOmhvdmVyIHtcbiAgY29sb3I6ICNmZmZcbn1cblxuLm5hdi1waWxscyAubmF2LWxpbmsuYWN0aXZlIC5uYXYtbGluay1pY29uLCAubmF2LXBpbGxzIC5uYXYtbGluay5hY3RpdmU6aG92ZXIgLm5hdi1saW5rLWljb24ge1xuICBjb2xvcjogI2ZmZjtcbiAgb3BhY2l0eTogLjhcbn1cblxuLm5hdi1waWxscyAubmF2LWxpbms6aG92ZXIge1xuICBjb2xvcjogIzQ5NTA1NyAhaW1wb3J0YW50XG59XG5cbi5uYXYtanVzdGlmaWVkIC5uYXYtbGluayAubmF2LXRleHQge1xuICBkaXNwbGF5OiBibG9jaztcbiAgd2lkdGg6IDEwMCU7XG4gIHRleHQtYWxpZ246IGNlbnRlclxufVxuXG4uYmFkZ2UtcHJpbWFyeSB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2Y2YWQ4XG59XG5cbmEuYmFkZ2UtcHJpbWFyeTpob3ZlciwgYS5iYWRnZS1wcmltYXJ5OmZvY3VzIHtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtY29sb3I6ICMyNjUxYmVcbn1cblxuLmJhZGdlLXNlY29uZGFyeSB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNmM3NTdkXG59XG5cbmEuYmFkZ2Utc2Vjb25kYXJ5OmhvdmVyLCBhLmJhZGdlLXNlY29uZGFyeTpmb2N1cyB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNTQ1YjYyXG59XG5cbi5iYWRnZS1zdWNjZXNzIHtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzYWM0N2Rcbn1cblxuYS5iYWRnZS1zdWNjZXNzOmhvdmVyLCBhLmJhZGdlLXN1Y2Nlc3M6Zm9jdXMge1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzJlOWQ2NFxufVxuXG4uYmFkZ2Utd2FybmluZyB7XG4gIGNvbG9yOiAjMjEyNTI5O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjdiOTI0XG59XG5cbmEuYmFkZ2Utd2FybmluZzpob3ZlciwgYS5iYWRnZS13YXJuaW5nOmZvY3VzIHtcbiAgY29sb3I6ICMyMTI1Mjk7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlMGEwMDhcbn1cblxuLmJhZGdlLWRhbmdlciB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZDkyNTUwXG59XG5cbmEuYmFkZ2UtZGFuZ2VyOmhvdmVyLCBhLmJhZGdlLWRhbmdlcjpmb2N1cyB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYWQxZTQwXG59XG5cbi5iYWRnZS1saWdodCB7XG4gIGNvbG9yOiAjMjEyNTI5O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWVlXG59XG5cbmEuYmFkZ2UtbGlnaHQ6aG92ZXIsIGEuYmFkZ2UtbGlnaHQ6Zm9jdXMge1xuICBjb2xvcjogIzIxMjUyOTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Q1ZDVkNVxufVxuXG4uYmFkZ2UtZGFyayB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzQzYTQwXG59XG5cbmEuYmFkZ2UtZGFyazpob3ZlciwgYS5iYWRnZS1kYXJrOmZvY3VzIHtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtY29sb3I6ICMxZDIxMjRcbn1cblxuLmJhZGdlLWZvY3VzIHtcbiAgY29sb3I6ICNmZmY7XG4gIGJhY2tncm91bmQtY29sb3I6ICM0NDQwNTRcbn1cblxuYS5iYWRnZS1mb2N1czpob3ZlciwgYS5iYWRnZS1mb2N1czpmb2N1cyB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMmQyYTM3XG59XG5cbi5iYWRnZS1hbHRlcm5hdGUge1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzc5NGM4YVxufVxuXG5hLmJhZGdlLWFsdGVybmF0ZTpob3ZlciwgYS5iYWRnZS1hbHRlcm5hdGU6Zm9jdXMge1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzVjM2E2OVxufVxuXG4uYmFkZ2Uge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgcGFkZGluZzogNXB4IDEwcHg7XG4gIG1pbi13aWR0aDogMTlweFxufVxuXG4uYmFkZ2UtbGlnaHQge1xuICBiYWNrZ3JvdW5kOiAjZmZmXG59XG5cbi5iYWRnZS1kb3Qge1xuICB0ZXh0LWluZGVudDogLTk5OWVtO1xuICBwYWRkaW5nOiAwO1xuICB3aWR0aDogOHB4O1xuICBoZWlnaHQ6IDhweDtcbiAgYm9yZGVyOiB0cmFuc3BhcmVudCBzb2xpZCAxcHg7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIG1pbi13aWR0aDogMnB4XG59XG5cbi5iYWRnZS1kb3QtbGcge1xuICB3aWR0aDogMTBweDtcbiAgaGVpZ2h0OiAxMHB4XG59XG5cbi5iYWRnZS1kb3QteGwge1xuICB3aWR0aDogMThweDtcbiAgaGVpZ2h0OiAxOHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmVcbn1cblxuLmJhZGdlLWRvdC14bDo6YmVmb3JlIHtcbiAgY29udGVudDogJyc7XG4gIHdpZHRoOiAxMHB4O1xuICBoZWlnaHQ6IDEwcHg7XG4gIGJvcmRlci1yYWRpdXM6IC4yNXJlbTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiA1MCU7XG4gIHRvcDogNTAlO1xuICBtYXJnaW46IC01cHggMCAwIC01cHg7XG4gIGJhY2tncm91bmQ6ICNmZmZcbn1cblxuLmJhZGdlLWRvdC1zbSB7XG4gIHdpZHRoOiA2cHg7XG4gIGhlaWdodDogNnB4XG59XG5cbi5idG4gLmJhZGdlIHtcbiAgbWFyZ2luLWxlZnQ6IDhweFxufVxuXG4uYnRuIC5iYWRnZS1kb3Qge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvcmRlcjogI2ZmZiBzb2xpZCAycHg7XG4gIHRvcDogLTVweDtcbiAgcmlnaHQ6IC01cHg7XG4gIHdpZHRoOiAxMXB4O1xuICBoZWlnaHQ6IDExcHhcbn1cblxuLmJ0biAuYmFkZ2UtZG90LmJhZGdlLWRvdC1sZyB7XG4gIHdpZHRoOiAxNHB4O1xuICBoZWlnaHQ6IDE0cHhcbn1cblxuLmJ0biAuYmFkZ2UtZG90LmJhZGdlLWRvdC1zbSB7XG4gIHdpZHRoOiA4cHg7XG4gIGhlaWdodDogOHB4O1xuICBib3JkZXItd2lkdGg6IDFweFxufVxuXG4uYnRuIC5iYWRnZS1kb3QtaW5zaWRlIHtcbiAgdG9wOiAxMHB4O1xuICByaWdodDogMTBweFxufVxuXG4uYnRuLXNtIC5iYWRnZS1kb3Qtc20sIC5idG4tZ3JvdXAtc20gPiAuYnRuIC5iYWRnZS1kb3Qtc20ge1xuICB0b3A6IDFweDtcbiAgcmlnaHQ6IDRweFxufVxuXG4uYnRuLXNtIC5iYWRnZS1kb3QsIC5idG4tZ3JvdXAtc20gPiAuYnRuIC5iYWRnZS1kb3Qge1xuICB0b3A6IDBweDtcbiAgcmlnaHQ6IDJweFxufVxuXG4uYnRuLXNtIC5iYWRnZS1kb3QtbGcsIC5idG4tZ3JvdXAtc20gPiAuYnRuIC5iYWRnZS1kb3QtbGcge1xuICB0b3A6IC0zcHg7XG4gIHJpZ2h0OiAtMnB4XG59XG5cbi5idG4tc20gLmJhZGdlLXBpbGwsIC5idG4tZ3JvdXAtc20gPiAuYnRuIC5iYWRnZS1waWxsIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IC00cHg7XG4gIHJpZ2h0OiAtNHB4XG59XG5cbi5iYWRnZS1hYnMge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAtM3B4O1xuICB0b3A6IC0zcHhcbn1cblxuLnZlcnRpY2FsLXRpbWVsaW5lIHtcbiAgd2lkdGg6IDEwMCU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgcGFkZGluZzogMS41cmVtIDAgMXJlbVxufVxuXG4udmVydGljYWwtdGltZWxpbmU6OmFmdGVyIHtcbiAgY29udGVudDogJyc7XG4gIGRpc3BsYXk6IHRhYmxlO1xuICBjbGVhcjogYm90aFxufVxuXG4udmVydGljYWwtdGltZWxpbmU6OmJlZm9yZSB7XG4gIGNvbnRlbnQ6ICcnO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgbGVmdDogNjdweDtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogNHB4O1xuICBiYWNrZ3JvdW5kOiAjZTllY2VmO1xuICBib3JkZXItcmFkaXVzOiAuMjVyZW1cbn1cblxuLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG1hcmdpbjogMCAwIDFyZW1cbn1cblxuLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQ6YWZ0ZXIge1xuICBjb250ZW50OiBcIlwiO1xuICBkaXNwbGF5OiB0YWJsZTtcbiAgY2xlYXI6IGJvdGhcbn1cblxuLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQ6bGFzdC1jaGlsZCB7XG4gIG1hcmdpbi1ib3R0b206IDBcbn1cblxuLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtY29udGVudCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgbWFyZ2luLWxlZnQ6IDkwcHg7XG4gIGZvbnQtc2l6ZTogLjhyZW1cbn1cblxuLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtY29udGVudDphZnRlciB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIGRpc3BsYXk6IHRhYmxlO1xuICBjbGVhcjogYm90aFxufVxuXG4udmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1jb250ZW50IC50aW1lbGluZS10aXRsZSB7XG4gIGZvbnQtc2l6ZTogLjhyZW07XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIG1hcmdpbjogMCAwIC41cmVtO1xuICBwYWRkaW5nOiAycHggMCAwO1xuICBmb250LXdlaWdodDogYm9sZFxufVxuXG4udmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1jb250ZW50IHAge1xuICBjb2xvcjogIzZjNzU3ZDtcbiAgbWFyZ2luOiAwIDAgLjVyZW1cbn1cblxuLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtY29udGVudCAudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1kYXRlIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogLTkwcHg7XG4gIHRvcDogMDtcbiAgcGFkZGluZy1yaWdodDogMTBweDtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGNvbG9yOiAjYWRiNWJkO1xuICBmb250LXNpemU6IC43NjE5cmVtO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwXG59XG5cbi52ZXJ0aWNhbC10aW1lbGluZS1lbGVtZW50LWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgbGVmdDogNjBweFxufVxuXG4udmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1pY29uIC5iYWRnZS1kb3QteGwge1xuICBib3gtc2hhZG93OiAwIDAgMCA1cHggI2ZmZlxufVxuXG4udmVydGljYWwtdGltZWxpbmUtZWxlbWVudC0tbm8tY2hpbGRyZW4gLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtY29udGVudCB7XG4gIGJhY2tncm91bmQ6IDAgMDtcbiAgYm94LXNoYWRvdzogbm9uZVxufVxuXG4udmVydGljYWwtdGltZWxpbmUtZWxlbWVudC0tbm8tY2hpbGRyZW4gLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtY29udGVudDo6YmVmb3JlIHtcbiAgZGlzcGxheTogbm9uZVxufVxuXG4udmVydGljYWwtd2l0aG91dC10aW1lOjpiZWZvcmUge1xuICBsZWZ0OiAxMXB4XG59XG5cbi52ZXJ0aWNhbC13aXRob3V0LXRpbWUgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtY29udGVudCB7XG4gIG1hcmdpbi1sZWZ0OiAzNnB4XG59XG5cbi52ZXJ0aWNhbC13aXRob3V0LXRpbWUgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtaWNvbiB7XG4gIGxlZnQ6IDRweFxufVxuXG4udmVydGljYWwtdGltZS1pY29ucyB7XG4gIHBhZGRpbmc6IDJyZW0gMCAwXG59XG5cbi52ZXJ0aWNhbC10aW1lLWljb25zOjpiZWZvcmUge1xuICBjb250ZW50OiAnJztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDE0cHg7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDZweDtcbiAgYmFja2dyb3VuZDogI2U5ZWNlZjtcbiAgYm9yZGVyLXJhZGl1czogLjI1cmVtXG59XG5cbi52ZXJ0aWNhbC10aW1lLWljb25zIC52ZXJ0aWNhbC10aW1lbGluZS1lbGVtZW50IHtcbiAgbWFyZ2luLWJvdHRvbTogMXJlbVxufVxuXG4udmVydGljYWwtdGltZS1pY29ucyAudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1jb250ZW50IHtcbiAgbWFyZ2luLWxlZnQ6IDUwcHhcbn1cblxuLnZlcnRpY2FsLXRpbWUtaWNvbnMgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtaWNvbiB7XG4gIHdpZHRoOiAzNHB4O1xuICBoZWlnaHQ6IDM0cHg7XG4gIGxlZnQ6IDA7XG4gIHRvcDogLTdweFxufVxuXG4udmVydGljYWwtdGltZS1pY29ucyAudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1pY29uIC50aW1lbGluZS1pY29uIHtcbiAgd2lkdGg6IDM0cHg7XG4gIGhlaWdodDogMzRweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgYm9yZGVyLXdpZHRoOiAycHg7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJveC1zaGFkb3c6IDAgMCAwIDVweCAjZmZmO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGFsaWduLWNvbnRlbnQ6IGNlbnRlclxufVxuXG4udmVydGljYWwtdGltZS1pY29ucyAudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1pY29uIC50aW1lbGluZS1pY29uIGkge1xuICBkaXNwbGF5OiBibG9jaztcbiAgZm9udC1zaXplOiAxLjFyZW07XG4gIG1hcmdpbjogMCBhdXRvXG59XG5cbi52ZXJ0aWNhbC10aW1lLWljb25zIC52ZXJ0aWNhbC10aW1lbGluZS1lbGVtZW50LWljb24gLnRpbWVsaW5lLWljb24gc3ZnIHtcbiAgbWFyZ2luOiAwIGF1dG9cbn1cblxuLnZlcnRpY2FsLXRpbWUtc2ltcGxlIHtcbiAgcGFkZGluZzogLjVyZW0gMFxufVxuXG4udmVydGljYWwtdGltZS1zaW1wbGUgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQge1xuICBtYXJnaW46IDAgMCAuNXJlbVxufVxuXG4udmVydGljYWwtdGltZS1zaW1wbGUgLnRpbWVsaW5lLXRpdGxlIHtcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgZm9udC1zaXplOiAuOTE2NjdyZW07XG4gIHBhZGRpbmc6IDBcbn1cblxuLnZlcnRpY2FsLXRpbWUtc2ltcGxlIC52ZXJ0aWNhbC10aW1lbGluZS1lbGVtZW50LWljb24ge1xuICBoZWlnaHQ6IDE0cHg7XG4gIHdpZHRoOiAxNHB4O1xuICBiYWNrZ3JvdW5kOiAjZTllY2VmO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDZweDtcbiAgdG9wOiAycHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3JkZXItcmFkaXVzOiAyMHB4XG59XG5cbi52ZXJ0aWNhbC10aW1lLXNpbXBsZSAudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1pY29uOjphZnRlciB7XG4gIGNvbnRlbnQ6ICcnO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGxlZnQ6IDUwJTtcbiAgdG9wOiA1MCU7XG4gIG1hcmdpbjogLTRweCAwIDAgLTRweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHdpZHRoOiA4cHg7XG4gIGhlaWdodDogOHB4O1xuICBib3JkZXItcmFkaXVzOiAyMHB4XG59XG5cbi52ZXJ0aWNhbC10aW1lLXNpbXBsZSAudGltZWxpbmUtdGl0bGUge1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZVxufVxuXG4uZG90LXByaW1hcnkgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtaWNvbiB7XG4gIGJhY2tncm91bmQ6ICMzZjZhZDhcbn1cblxuLmRvdC1zZWNvbmRhcnkgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtaWNvbiB7XG4gIGJhY2tncm91bmQ6ICM2Yzc1N2Rcbn1cblxuLmRvdC1zdWNjZXNzIC52ZXJ0aWNhbC10aW1lbGluZS1lbGVtZW50LWljb24ge1xuICBiYWNrZ3JvdW5kOiAjM2FjNDdkXG59XG5cbi5kb3QtaW5mbyAudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1pY29uIHtcbiAgYmFja2dyb3VuZDogIzE2YWFmZlxufVxuXG4uZG90LXdhcm5pbmcgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtaWNvbiB7XG4gIGJhY2tncm91bmQ6ICNmN2I5MjRcbn1cblxuLmRvdC1kYW5nZXIgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtaWNvbiB7XG4gIGJhY2tncm91bmQ6ICNkOTI1NTBcbn1cblxuLmRvdC1saWdodCAudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1pY29uIHtcbiAgYmFja2dyb3VuZDogI2VlZVxufVxuXG4uZG90LWRhcmsgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtaWNvbiB7XG4gIGJhY2tncm91bmQ6ICMzNDNhNDBcbn1cblxuLmRvdC1mb2N1cyAudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1pY29uIHtcbiAgYmFja2dyb3VuZDogIzQ0NDA1NFxufVxuXG4uZG90LWFsdGVybmF0ZSAudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1pY29uIHtcbiAgYmFja2dyb3VuZDogIzc5NGM4YVxufVxuXG4udmVydGljYWwtdGltZWxpbmUtLWFuaW1hdGUgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtaWNvbi5pcy1oaWRkZW4ge1xuICB2aXNpYmlsaXR5OiBoaWRkZW5cbn1cblxuLnZlcnRpY2FsLXRpbWVsaW5lLS1hbmltYXRlIC52ZXJ0aWNhbC10aW1lbGluZS1lbGVtZW50LWljb24uYm91bmNlLWluIHtcbiAgdmlzaWJpbGl0eTogdmlzaWJsZTtcbiAgYW5pbWF0aW9uOiBjZC1ib3VuY2UtMSAuOHNcbn1cblxuLnZlcnRpY2FsLXRpbWVsaW5lLS1hbmltYXRlIC52ZXJ0aWNhbC10aW1lbGluZS1lbGVtZW50LWNvbnRlbnQuaXMtaGlkZGVuIHtcbiAgdmlzaWJpbGl0eTogaGlkZGVuXG59XG5cbi52ZXJ0aWNhbC10aW1lbGluZS0tYW5pbWF0ZSAudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1jb250ZW50LmJvdW5jZS1pbiB7XG4gIHZpc2liaWxpdHk6IHZpc2libGU7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBjZC1ib3VuY2UtMiAuNnM7XG4gIC1tb3otYW5pbWF0aW9uOiBjZC1ib3VuY2UtMiAuNnM7XG4gIGFuaW1hdGlvbjogY2QtYm91bmNlLTIgLjZzXG59XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMTE3MHB4KSB7XG4gIC52ZXJ0aWNhbC10aW1lbGluZS0tdHdvLWNvbHVtbnMudmVydGljYWwtdGltZWxpbmUtLWFuaW1hdGUgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC0tcmlnaHQgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtY29udGVudC5ib3VuY2UtaW4sIC52ZXJ0aWNhbC10aW1lbGluZS0tdHdvLWNvbHVtbnMudmVydGljYWwtdGltZWxpbmUtLWFuaW1hdGUgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQ6bnRoLWNoaWxkKGV2ZW4pOm5vdCgudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC0tbGVmdCkgLnZlcnRpY2FsLXRpbWVsaW5lLWVsZW1lbnQtY29udGVudC5ib3VuY2UtaW4ge1xuICAgIC13ZWJraXQtYW5pbWF0aW9uOiBjZC1ib3VuY2UtMi1pbnZlcnNlIC42cztcbiAgICAtbW96LWFuaW1hdGlvbjogY2QtYm91bmNlLTItaW52ZXJzZSAuNnM7XG4gICAgYW5pbWF0aW9uOiBjZC1ib3VuY2UtMi1pbnZlcnNlIC42c1xuICB9XG59XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogMTE2OXB4KSB7XG4gIC52ZXJ0aWNhbC10aW1lbGluZS0tYW5pbWF0ZSAudmVydGljYWwtdGltZWxpbmUtZWxlbWVudC1jb250ZW50LmJvdW5jZS1pbiB7XG4gICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcbiAgICAtd2Via2l0LWFuaW1hdGlvbjogY2QtYm91bmNlLTItaW52ZXJzZSAuNnM7XG4gICAgLW1vei1hbmltYXRpb246IGNkLWJvdW5jZS0yLWludmVyc2UgLjZzO1xuICAgIGFuaW1hdGlvbjogY2QtYm91bmNlLTItaW52ZXJzZSAuNnNcbiAgfVxufVxuXG4uaWNvbi13cmFwcGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB3aWR0aDogNTRweDtcbiAgaGVpZ2h0OiA1NHB4O1xuICBtYXJnaW46IDAgYXV0bztcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBvdmVyZmxvdzogaGlkZGVuXG59XG5cbi5pY29uLXdyYXBwZXJbY2xhc3MqPVwiYm9yZGVyLVwiXSB7XG4gIGJvcmRlci13aWR0aDogMXB4O1xuICBib3JkZXItc3R5bGU6IHNvbGlkXG59XG5cbi5pY29uLXdyYXBwZXIgLmljb24td3JhcHBlci1iZyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgei1pbmRleDogMztcbiAgb3BhY2l0eTogLjJcbn1cblxuLmljb24td3JhcHBlciAuaWNvbi13cmFwcGVyLWJnLmJnLWxpZ2h0IHtcbiAgb3BhY2l0eTogLjA4XG59XG5cbi5pY29uLXdyYXBwZXIgaSB7XG4gIG1hcmdpbjogMCBhdXRvO1xuICBmb250LXNpemU6IDEuN3JlbTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB6LWluZGV4OiA1XG59XG5cbi5pY29uLXdyYXBwZXIgaTpiZWZvcmUge1xuICBtYXJnaW4tdG9wOiAtM3B4XG59XG5cbi5pY29uLXdyYXBwZXIgLnByb2dyZXNzLWNpcmNsZS13cmFwcGVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIG1hcmdpbi1yaWdodDogMFxufVxuXG4ud2lkZ2V0LW51bWJlcnMtc20ge1xuICBmb250LXNpemU6IDEuNXJlbVxufVxuXG4ud2lkZ2V0LWNvbnRlbnQge1xuICBwYWRkaW5nOiAxcmVtO1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBhbGlnbi1pdGVtczogY2VudGVyXG59XG5cbi53aWRnZXQtY29udGVudCAud2lkZ2V0LWNvbnRlbnQtd3JhcHBlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXg6IDE7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYWxpZ24taXRlbXM6IGNlbnRlclxufVxuXG4ud2lkZ2V0LWNvbnRlbnQgLndpZGdldC1jb250ZW50LWxlZnQgLndpZGdldC1oZWFkaW5nIHtcbiAgb3BhY2l0eTogLjg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkXG59XG5cbi53aWRnZXQtY29udGVudCAud2lkZ2V0LWNvbnRlbnQtbGVmdCAud2lkZ2V0LXN1YmhlYWRpbmcge1xuICBvcGFjaXR5OiAuNVxufVxuXG4ud2lkZ2V0LWNvbnRlbnQgLndpZGdldC1jb250ZW50LXJpZ2h0IHtcbiAgbWFyZ2luLWxlZnQ6IGF1dG9cbn1cblxuLndpZGdldC1jb250ZW50IC53aWRnZXQtbnVtYmVycyB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBmb250LXNpemU6IDEuOHJlbTtcbiAgZGlzcGxheTogYmxvY2tcbn1cblxuLndpZGdldC1jb250ZW50IC53aWRnZXQtY29udGVudC1vdXRlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXg6IDE7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW5cbn1cblxuLndpZGdldC1jb250ZW50IC53aWRnZXQtcHJvZ3Jlc3Mtd3JhcHBlciB7XG4gIG1hcmdpbi10b3A6IDFyZW1cbn1cblxuLndpZGdldC1jb250ZW50IC53aWRnZXQtcHJvZ3Jlc3Mtd3JhcHBlciAucHJvZ3Jlc3Mtc3ViLWxhYmVsIHtcbiAgbWFyZ2luLXRvcDogLjMzMzMzcmVtO1xuICBvcGFjaXR5OiAuNTtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyXG59XG5cbi53aWRnZXQtY29udGVudCAud2lkZ2V0LXByb2dyZXNzLXdyYXBwZXIgLnByb2dyZXNzLXN1Yi1sYWJlbCAuc3ViLWxhYmVsLXJpZ2h0IHtcbiAgbWFyZ2luLWxlZnQ6IGF1dG9cbn1cblxuLndpZGdldC1jb250ZW50IC53aWRnZXQtY29udGVudC1yaWdodC53aWRnZXQtY29udGVudC1hY3Rpb25zIHtcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xuICBvcGFjaXR5OiAwO1xuICB0cmFuc2l0aW9uOiBvcGFjaXR5IC4yc1xufVxuXG4ud2lkZ2V0LWNvbnRlbnQ6aG92ZXIgLndpZGdldC1jb250ZW50LXJpZ2h0LndpZGdldC1jb250ZW50LWFjdGlvbnMge1xuICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICBvcGFjaXR5OiAxXG59XG5cblxuLm1vYmlsZS1hcHAtbWVudS1idG4ge1xuICBkaXNwbGF5OiBub25lO1xuICBtYXJnaW46IDNweCAxLjVyZW0gMCAwXG59XG5cbi5zY3JvbGxiYXItc2lkZWJhciwgLnNjcm9sbGJhci1jb250YWluZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGhlaWdodDogMTAwJVxufVxuXG4uc2Nyb2xsLWFyZWEge1xuICBvdmVyZmxvdy14OiBoaWRkZW47XG4gIGhlaWdodDogNDAwcHhcbn1cblxuLnNjcm9sbC1hcmVhLXhzIHtcbiAgaGVpZ2h0OiAxNTBweDtcbiAgb3ZlcmZsb3cteDogaGlkZGVuXG59XG5cbi5zY3JvbGwtYXJlYS1zbSB7XG4gIGhlaWdodDogMjAwcHg7XG4gIG92ZXJmbG93LXg6IGhpZGRlblxufVxuXG4uc2Nyb2xsLWFyZWEtbWQge1xuICBoZWlnaHQ6IDMwMHB4O1xuICBvdmVyZmxvdy14OiBoaWRkZW5cbn1cblxuLnNjcm9sbC1hcmVhLWxnIHtcbiAgaGVpZ2h0OiA0MDBweDtcbiAgb3ZlcmZsb3cteDogaGlkZGVuXG59XG5cbi5zY3JvbGwtYXJlYS14IHtcbiAgb3ZlcmZsb3cteDogYXV0bztcbiAgd2lkdGg6IDEwMCU7XG4gIG1heC13aWR0aDogMTAwJVxufVxuXG5AZm9udC1mYWNlIHtcbiAgZm9udC1mYW1pbHk6IFwiSW9uaWNvbnNcIjtcbiAgc3JjOiB1cmwoc3JjL2Fzc2V0cy9mb250cy9pb25pY29ucy5lb3QpO1xuICBzcmM6IHVybChzcmMvYXNzZXRzL2ZvbnRzL2lvbmljb25zLmVvdCNpZWZpeCkgZm9ybWF0KFwiZW1iZWRkZWQtb3BlbnR5cGVcIiksIHVybChzcmMvYXNzZXRzL2ZvbnRzL2lvbmljb25zLnR0ZikgZm9ybWF0KFwidHJ1ZXR5cGVcIiksIHVybChzcmMvYXNzZXRzL2ZvbnRzL2lvbmljb25zLndvZmYpIGZvcm1hdChcIndvZmZcIiksIHVybChzcmMvYXNzZXRzL2ZvbnRzL2lvbmljb25zLnN2ZyNJb25pY29ucykgZm9ybWF0KFwic3ZnXCIpO1xuICBmb250LXdlaWdodDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWxcbn1cblxuLmlvbiwgLmlvbmljb25zLCAuaW9uLWFsZXJ0OmJlZm9yZSwgLmlvbi1hbGVydC1jaXJjbGVkOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWFkZDpiZWZvcmUsIC5pb24tYW5kcm9pZC1hZGQtY2lyY2xlOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWFsYXJtLWNsb2NrOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWFsZXJ0OmJlZm9yZSwgLmlvbi1hbmRyb2lkLWFwcHM6YmVmb3JlLCAuaW9uLWFuZHJvaWQtYXJjaGl2ZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1hcnJvdy1iYWNrOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWFycm93LWRvd246YmVmb3JlLCAuaW9uLWFuZHJvaWQtYXJyb3ctZHJvcGRvd246YmVmb3JlLCAuaW9uLWFuZHJvaWQtYXJyb3ctZHJvcGRvd24tY2lyY2xlOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWFycm93LWRyb3BsZWZ0OmJlZm9yZSwgLmlvbi1hbmRyb2lkLWFycm93LWRyb3BsZWZ0LWNpcmNsZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1hcnJvdy1kcm9wcmlnaHQ6YmVmb3JlLCAuaW9uLWFuZHJvaWQtYXJyb3ctZHJvcHJpZ2h0LWNpcmNsZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1hcnJvdy1kcm9wdXA6YmVmb3JlLCAuaW9uLWFuZHJvaWQtYXJyb3ctZHJvcHVwLWNpcmNsZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1hcnJvdy1mb3J3YXJkOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWFycm93LXVwOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWF0dGFjaDpiZWZvcmUsIC5pb24tYW5kcm9pZC1iYXI6YmVmb3JlLCAuaW9uLWFuZHJvaWQtYmljeWNsZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1ib2F0OmJlZm9yZSwgLmlvbi1hbmRyb2lkLWJvb2ttYXJrOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWJ1bGI6YmVmb3JlLCAuaW9uLWFuZHJvaWQtYnVzOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWNhbGVuZGFyOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWNhbGw6YmVmb3JlLCAuaW9uLWFuZHJvaWQtY2FtZXJhOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWNhbmNlbDpiZWZvcmUsIC5pb24tYW5kcm9pZC1jYXI6YmVmb3JlLCAuaW9uLWFuZHJvaWQtY2FydDpiZWZvcmUsIC5pb24tYW5kcm9pZC1jaGF0OmJlZm9yZSwgLmlvbi1hbmRyb2lkLWNoZWNrYm94OmJlZm9yZSwgLmlvbi1hbmRyb2lkLWNoZWNrYm94LWJsYW5rOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWNoZWNrYm94LW91dGxpbmU6YmVmb3JlLCAuaW9uLWFuZHJvaWQtY2hlY2tib3gtb3V0bGluZS1ibGFuazpiZWZvcmUsIC5pb24tYW5kcm9pZC1jaGVja21hcmstY2lyY2xlOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWNsaXBib2FyZDpiZWZvcmUsIC5pb24tYW5kcm9pZC1jbG9zZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1jbG91ZDpiZWZvcmUsIC5pb24tYW5kcm9pZC1jbG91ZC1jaXJjbGU6YmVmb3JlLCAuaW9uLWFuZHJvaWQtY2xvdWQtZG9uZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1jbG91ZC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWNvbG9yLXBhbGV0dGU6YmVmb3JlLCAuaW9uLWFuZHJvaWQtY29tcGFzczpiZWZvcmUsIC5pb24tYW5kcm9pZC1jb250YWN0OmJlZm9yZSwgLmlvbi1hbmRyb2lkLWNvbnRhY3RzOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWNvbnRyYWN0OmJlZm9yZSwgLmlvbi1hbmRyb2lkLWNyZWF0ZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1kZWxldGU6YmVmb3JlLCAuaW9uLWFuZHJvaWQtZGVza3RvcDpiZWZvcmUsIC5pb24tYW5kcm9pZC1kb2N1bWVudDpiZWZvcmUsIC5pb24tYW5kcm9pZC1kb25lOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWRvbmUtYWxsOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWRvd25sb2FkOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWRyYWZ0czpiZWZvcmUsIC5pb24tYW5kcm9pZC1leGl0OmJlZm9yZSwgLmlvbi1hbmRyb2lkLWV4cGFuZDpiZWZvcmUsIC5pb24tYW5kcm9pZC1mYXZvcml0ZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1mYXZvcml0ZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWZpbG06YmVmb3JlLCAuaW9uLWFuZHJvaWQtZm9sZGVyOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWZvbGRlci1vcGVuOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWZ1bm5lbDpiZWZvcmUsIC5pb24tYW5kcm9pZC1nbG9iZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1oYW5kOmJlZm9yZSwgLmlvbi1hbmRyb2lkLWhhbmdvdXQ6YmVmb3JlLCAuaW9uLWFuZHJvaWQtaGFwcHk6YmVmb3JlLCAuaW9uLWFuZHJvaWQtaG9tZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1pbWFnZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1sYXB0b3A6YmVmb3JlLCAuaW9uLWFuZHJvaWQtbGlzdDpiZWZvcmUsIC5pb24tYW5kcm9pZC1sb2NhdGU6YmVmb3JlLCAuaW9uLWFuZHJvaWQtbG9jazpiZWZvcmUsIC5pb24tYW5kcm9pZC1tYWlsOmJlZm9yZSwgLmlvbi1hbmRyb2lkLW1hcDpiZWZvcmUsIC5pb24tYW5kcm9pZC1tZW51OmJlZm9yZSwgLmlvbi1hbmRyb2lkLW1pY3JvcGhvbmU6YmVmb3JlLCAuaW9uLWFuZHJvaWQtbWljcm9waG9uZS1vZmY6YmVmb3JlLCAuaW9uLWFuZHJvaWQtbW9yZS1ob3Jpem9udGFsOmJlZm9yZSwgLmlvbi1hbmRyb2lkLW1vcmUtdmVydGljYWw6YmVmb3JlLCAuaW9uLWFuZHJvaWQtbmF2aWdhdGU6YmVmb3JlLCAuaW9uLWFuZHJvaWQtbm90aWZpY2F0aW9uczpiZWZvcmUsIC5pb24tYW5kcm9pZC1ub3RpZmljYXRpb25zLW5vbmU6YmVmb3JlLCAuaW9uLWFuZHJvaWQtbm90aWZpY2F0aW9ucy1vZmY6YmVmb3JlLCAuaW9uLWFuZHJvaWQtb3BlbjpiZWZvcmUsIC5pb24tYW5kcm9pZC1vcHRpb25zOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXBlb3BsZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1wZXJzb246YmVmb3JlLCAuaW9uLWFuZHJvaWQtcGVyc29uLWFkZDpiZWZvcmUsIC5pb24tYW5kcm9pZC1waG9uZS1sYW5kc2NhcGU6YmVmb3JlLCAuaW9uLWFuZHJvaWQtcGhvbmUtcG9ydHJhaXQ6YmVmb3JlLCAuaW9uLWFuZHJvaWQtcGluOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXBsYW5lOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXBsYXlzdG9yZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1wcmludDpiZWZvcmUsIC5pb24tYW5kcm9pZC1yYWRpby1idXR0b24tb2ZmOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXJhZGlvLWJ1dHRvbi1vbjpiZWZvcmUsIC5pb24tYW5kcm9pZC1yZWZyZXNoOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXJlbW92ZTpiZWZvcmUsIC5pb24tYW5kcm9pZC1yZW1vdmUtY2lyY2xlOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXJlc3RhdXJhbnQ6YmVmb3JlLCAuaW9uLWFuZHJvaWQtc2FkOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXNlYXJjaDpiZWZvcmUsIC5pb24tYW5kcm9pZC1zZW5kOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXNldHRpbmdzOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXNoYXJlOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXNoYXJlLWFsdDpiZWZvcmUsIC5pb24tYW5kcm9pZC1zdGFyOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXN0YXItaGFsZjpiZWZvcmUsIC5pb24tYW5kcm9pZC1zdGFyLW91dGxpbmU6YmVmb3JlLCAuaW9uLWFuZHJvaWQtc3RvcHdhdGNoOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXN1YndheTpiZWZvcmUsIC5pb24tYW5kcm9pZC1zdW5ueTpiZWZvcmUsIC5pb24tYW5kcm9pZC1zeW5jOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXRleHRzbXM6YmVmb3JlLCAuaW9uLWFuZHJvaWQtdGltZTpiZWZvcmUsIC5pb24tYW5kcm9pZC10cmFpbjpiZWZvcmUsIC5pb24tYW5kcm9pZC11bmxvY2s6YmVmb3JlLCAuaW9uLWFuZHJvaWQtdXBsb2FkOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXZvbHVtZS1kb3duOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXZvbHVtZS1tdXRlOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXZvbHVtZS1vZmY6YmVmb3JlLCAuaW9uLWFuZHJvaWQtdm9sdW1lLXVwOmJlZm9yZSwgLmlvbi1hbmRyb2lkLXdhbGs6YmVmb3JlLCAuaW9uLWFuZHJvaWQtd2FybmluZzpiZWZvcmUsIC5pb24tYW5kcm9pZC13YXRjaDpiZWZvcmUsIC5pb24tYW5kcm9pZC13aWZpOmJlZm9yZSwgLmlvbi1hcGVydHVyZTpiZWZvcmUsIC5pb24tYXJjaGl2ZTpiZWZvcmUsIC5pb24tYXJyb3ctZG93bi1hOmJlZm9yZSwgLmlvbi1hcnJvdy1kb3duLWI6YmVmb3JlLCAuaW9uLWFycm93LWRvd24tYzpiZWZvcmUsIC5pb24tYXJyb3ctZXhwYW5kOmJlZm9yZSwgLmlvbi1hcnJvdy1ncmFwaC1kb3duLWxlZnQ6YmVmb3JlLCAuaW9uLWFycm93LWdyYXBoLWRvd24tcmlnaHQ6YmVmb3JlLCAuaW9uLWFycm93LWdyYXBoLXVwLWxlZnQ6YmVmb3JlLCAuaW9uLWFycm93LWdyYXBoLXVwLXJpZ2h0OmJlZm9yZSwgLmlvbi1hcnJvdy1sZWZ0LWE6YmVmb3JlLCAuaW9uLWFycm93LWxlZnQtYjpiZWZvcmUsIC5pb24tYXJyb3ctbGVmdC1jOmJlZm9yZSwgLmlvbi1hcnJvdy1tb3ZlOmJlZm9yZSwgLmlvbi1hcnJvdy1yZXNpemU6YmVmb3JlLCAuaW9uLWFycm93LXJldHVybi1sZWZ0OmJlZm9yZSwgLmlvbi1hcnJvdy1yZXR1cm4tcmlnaHQ6YmVmb3JlLCAuaW9uLWFycm93LXJpZ2h0LWE6YmVmb3JlLCAuaW9uLWFycm93LXJpZ2h0LWI6YmVmb3JlLCAuaW9uLWFycm93LXJpZ2h0LWM6YmVmb3JlLCAuaW9uLWFycm93LXNocmluazpiZWZvcmUsIC5pb24tYXJyb3ctc3dhcDpiZWZvcmUsIC5pb24tYXJyb3ctdXAtYTpiZWZvcmUsIC5pb24tYXJyb3ctdXAtYjpiZWZvcmUsIC5pb24tYXJyb3ctdXAtYzpiZWZvcmUsIC5pb24tYXN0ZXJpc2s6YmVmb3JlLCAuaW9uLWF0OmJlZm9yZSwgLmlvbi1iYWNrc3BhY2U6YmVmb3JlLCAuaW9uLWJhY2tzcGFjZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1iYWc6YmVmb3JlLCAuaW9uLWJhdHRlcnktY2hhcmdpbmc6YmVmb3JlLCAuaW9uLWJhdHRlcnktZW1wdHk6YmVmb3JlLCAuaW9uLWJhdHRlcnktZnVsbDpiZWZvcmUsIC5pb24tYmF0dGVyeS1oYWxmOmJlZm9yZSwgLmlvbi1iYXR0ZXJ5LWxvdzpiZWZvcmUsIC5pb24tYmVha2VyOmJlZm9yZSwgLmlvbi1iZWVyOmJlZm9yZSwgLmlvbi1ibHVldG9vdGg6YmVmb3JlLCAuaW9uLWJvbmZpcmU6YmVmb3JlLCAuaW9uLWJvb2ttYXJrOmJlZm9yZSwgLmlvbi1ib3d0aWU6YmVmb3JlLCAuaW9uLWJyaWVmY2FzZTpiZWZvcmUsIC5pb24tYnVnOmJlZm9yZSwgLmlvbi1jYWxjdWxhdG9yOmJlZm9yZSwgLmlvbi1jYWxlbmRhcjpiZWZvcmUsIC5pb24tY2FtZXJhOmJlZm9yZSwgLmlvbi1jYXJkOmJlZm9yZSwgLmlvbi1jYXNoOmJlZm9yZSwgLmlvbi1jaGF0Ym94OmJlZm9yZSwgLmlvbi1jaGF0Ym94LXdvcmtpbmc6YmVmb3JlLCAuaW9uLWNoYXRib3hlczpiZWZvcmUsIC5pb24tY2hhdGJ1YmJsZTpiZWZvcmUsIC5pb24tY2hhdGJ1YmJsZS13b3JraW5nOmJlZm9yZSwgLmlvbi1jaGF0YnViYmxlczpiZWZvcmUsIC5pb24tY2hlY2ttYXJrOmJlZm9yZSwgLmlvbi1jaGVja21hcmstY2lyY2xlZDpiZWZvcmUsIC5pb24tY2hlY2ttYXJrLXJvdW5kOmJlZm9yZSwgLmlvbi1jaGV2cm9uLWRvd246YmVmb3JlLCAuaW9uLWNoZXZyb24tbGVmdDpiZWZvcmUsIC5pb24tY2hldnJvbi1yaWdodDpiZWZvcmUsIC5pb24tY2hldnJvbi11cDpiZWZvcmUsIC5pb24tY2xpcGJvYXJkOmJlZm9yZSwgLmlvbi1jbG9jazpiZWZvcmUsIC5pb24tY2xvc2U6YmVmb3JlLCAuaW9uLWNsb3NlLWNpcmNsZWQ6YmVmb3JlLCAuaW9uLWNsb3NlLXJvdW5kOmJlZm9yZSwgLmlvbi1jbG9zZWQtY2FwdGlvbmluZzpiZWZvcmUsIC5pb24tY2xvdWQ6YmVmb3JlLCAuaW9uLWNvZGU6YmVmb3JlLCAuaW9uLWNvZGUtZG93bmxvYWQ6YmVmb3JlLCAuaW9uLWNvZGUtd29ya2luZzpiZWZvcmUsIC5pb24tY29mZmVlOmJlZm9yZSwgLmlvbi1jb21wYXNzOmJlZm9yZSwgLmlvbi1jb21wb3NlOmJlZm9yZSwgLmlvbi1jb25uZWN0aW9uLWJhcnM6YmVmb3JlLCAuaW9uLWNvbnRyYXN0OmJlZm9yZSwgLmlvbi1jcm9wOmJlZm9yZSwgLmlvbi1jdWJlOmJlZm9yZSwgLmlvbi1kaXNjOmJlZm9yZSwgLmlvbi1kb2N1bWVudDpiZWZvcmUsIC5pb24tZG9jdW1lbnQtdGV4dDpiZWZvcmUsIC5pb24tZHJhZzpiZWZvcmUsIC5pb24tZWFydGg6YmVmb3JlLCAuaW9uLWVhc2VsOmJlZm9yZSwgLmlvbi1lZGl0OmJlZm9yZSwgLmlvbi1lZ2c6YmVmb3JlLCAuaW9uLWVqZWN0OmJlZm9yZSwgLmlvbi1lbWFpbDpiZWZvcmUsIC5pb24tZW1haWwtdW5yZWFkOmJlZm9yZSwgLmlvbi1lcmxlbm1leWVyLWZsYXNrOmJlZm9yZSwgLmlvbi1lcmxlbm1leWVyLWZsYXNrLWJ1YmJsZXM6YmVmb3JlLCAuaW9uLWV5ZTpiZWZvcmUsIC5pb24tZXllLWRpc2FibGVkOmJlZm9yZSwgLmlvbi1mZW1hbGU6YmVmb3JlLCAuaW9uLWZpbGluZzpiZWZvcmUsIC5pb24tZmlsbS1tYXJrZXI6YmVmb3JlLCAuaW9uLWZpcmViYWxsOmJlZm9yZSwgLmlvbi1mbGFnOmJlZm9yZSwgLmlvbi1mbGFtZTpiZWZvcmUsIC5pb24tZmxhc2g6YmVmb3JlLCAuaW9uLWZsYXNoLW9mZjpiZWZvcmUsIC5pb24tZm9sZGVyOmJlZm9yZSwgLmlvbi1mb3JrOmJlZm9yZSwgLmlvbi1mb3JrLXJlcG86YmVmb3JlLCAuaW9uLWZvcndhcmQ6YmVmb3JlLCAuaW9uLWZ1bm5lbDpiZWZvcmUsIC5pb24tZ2Vhci1hOmJlZm9yZSwgLmlvbi1nZWFyLWI6YmVmb3JlLCAuaW9uLWdyaWQ6YmVmb3JlLCAuaW9uLWhhbW1lcjpiZWZvcmUsIC5pb24taGFwcHk6YmVmb3JlLCAuaW9uLWhhcHB5LW91dGxpbmU6YmVmb3JlLCAuaW9uLWhlYWRwaG9uZTpiZWZvcmUsIC5pb24taGVhcnQ6YmVmb3JlLCAuaW9uLWhlYXJ0LWJyb2tlbjpiZWZvcmUsIC5pb24taGVscDpiZWZvcmUsIC5pb24taGVscC1idW95OmJlZm9yZSwgLmlvbi1oZWxwLWNpcmNsZWQ6YmVmb3JlLCAuaW9uLWhvbWU6YmVmb3JlLCAuaW9uLWljZWNyZWFtOmJlZm9yZSwgLmlvbi1pbWFnZTpiZWZvcmUsIC5pb24taW1hZ2VzOmJlZm9yZSwgLmlvbi1pbmZvcm1hdGlvbjpiZWZvcmUsIC5pb24taW5mb3JtYXRpb24tY2lyY2xlZDpiZWZvcmUsIC5pb24taW9uaWM6YmVmb3JlLCAuaW9uLWlvcy1hbGFybTpiZWZvcmUsIC5pb24taW9zLWFsYXJtLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1hbGJ1bXM6YmVmb3JlLCAuaW9uLWlvcy1hbGJ1bXMtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWFtZXJpY2FuZm9vdGJhbGw6YmVmb3JlLCAuaW9uLWlvcy1hbWVyaWNhbmZvb3RiYWxsLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1hbmFseXRpY3M6YmVmb3JlLCAuaW9uLWlvcy1hbmFseXRpY3Mtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWFycm93LWJhY2s6YmVmb3JlLCAuaW9uLWlvcy1hcnJvdy1kb3duOmJlZm9yZSwgLmlvbi1pb3MtYXJyb3ctZm9yd2FyZDpiZWZvcmUsIC5pb24taW9zLWFycm93LWxlZnQ6YmVmb3JlLCAuaW9uLWlvcy1hcnJvdy1yaWdodDpiZWZvcmUsIC5pb24taW9zLWFycm93LXRoaW4tZG93bjpiZWZvcmUsIC5pb24taW9zLWFycm93LXRoaW4tbGVmdDpiZWZvcmUsIC5pb24taW9zLWFycm93LXRoaW4tcmlnaHQ6YmVmb3JlLCAuaW9uLWlvcy1hcnJvdy10aGluLXVwOmJlZm9yZSwgLmlvbi1pb3MtYXJyb3ctdXA6YmVmb3JlLCAuaW9uLWlvcy1hdDpiZWZvcmUsIC5pb24taW9zLWF0LW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1iYXJjb2RlOmJlZm9yZSwgLmlvbi1pb3MtYmFyY29kZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtYmFzZWJhbGw6YmVmb3JlLCAuaW9uLWlvcy1iYXNlYmFsbC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtYmFza2V0YmFsbDpiZWZvcmUsIC5pb24taW9zLWJhc2tldGJhbGwtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWJlbGw6YmVmb3JlLCAuaW9uLWlvcy1iZWxsLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1ib2R5OmJlZm9yZSwgLmlvbi1pb3MtYm9keS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtYm9sdDpiZWZvcmUsIC5pb24taW9zLWJvbHQtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWJvb2s6YmVmb3JlLCAuaW9uLWlvcy1ib29rLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1ib29rbWFya3M6YmVmb3JlLCAuaW9uLWlvcy1ib29rbWFya3Mtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWJveDpiZWZvcmUsIC5pb24taW9zLWJveC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtYnJpZWZjYXNlOmJlZm9yZSwgLmlvbi1pb3MtYnJpZWZjYXNlLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1icm93c2VyczpiZWZvcmUsIC5pb24taW9zLWJyb3dzZXJzLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1jYWxjdWxhdG9yOmJlZm9yZSwgLmlvbi1pb3MtY2FsY3VsYXRvci1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtY2FsZW5kYXI6YmVmb3JlLCAuaW9uLWlvcy1jYWxlbmRhci1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtY2FtZXJhOmJlZm9yZSwgLmlvbi1pb3MtY2FtZXJhLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1jYXJ0OmJlZm9yZSwgLmlvbi1pb3MtY2FydC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtY2hhdGJveGVzOmJlZm9yZSwgLmlvbi1pb3MtY2hhdGJveGVzLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1jaGF0YnViYmxlOmJlZm9yZSwgLmlvbi1pb3MtY2hhdGJ1YmJsZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtY2hlY2ttYXJrOmJlZm9yZSwgLmlvbi1pb3MtY2hlY2ttYXJrLWVtcHR5OmJlZm9yZSwgLmlvbi1pb3MtY2hlY2ttYXJrLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1jaXJjbGUtZmlsbGVkOmJlZm9yZSwgLmlvbi1pb3MtY2lyY2xlLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1jbG9jazpiZWZvcmUsIC5pb24taW9zLWNsb2NrLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1jbG9zZTpiZWZvcmUsIC5pb24taW9zLWNsb3NlLWVtcHR5OmJlZm9yZSwgLmlvbi1pb3MtY2xvc2Utb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWNsb3VkOmJlZm9yZSwgLmlvbi1pb3MtY2xvdWQtZG93bmxvYWQ6YmVmb3JlLCAuaW9uLWlvcy1jbG91ZC1kb3dubG9hZC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtY2xvdWQtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWNsb3VkLXVwbG9hZDpiZWZvcmUsIC5pb24taW9zLWNsb3VkLXVwbG9hZC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtY2xvdWR5OmJlZm9yZSwgLmlvbi1pb3MtY2xvdWR5LW5pZ2h0OmJlZm9yZSwgLmlvbi1pb3MtY2xvdWR5LW5pZ2h0LW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1jbG91ZHktb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWNvZzpiZWZvcmUsIC5pb24taW9zLWNvZy1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtY29sb3ItZmlsdGVyOmJlZm9yZSwgLmlvbi1pb3MtY29sb3ItZmlsdGVyLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1jb2xvci13YW5kOmJlZm9yZSwgLmlvbi1pb3MtY29sb3Itd2FuZC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtY29tcG9zZTpiZWZvcmUsIC5pb24taW9zLWNvbXBvc2Utb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWNvbnRhY3Q6YmVmb3JlLCAuaW9uLWlvcy1jb250YWN0LW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1jb3B5OmJlZm9yZSwgLmlvbi1pb3MtY29weS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtY3JvcDpiZWZvcmUsIC5pb24taW9zLWNyb3Atc3Ryb25nOmJlZm9yZSwgLmlvbi1pb3MtZG93bmxvYWQ6YmVmb3JlLCAuaW9uLWlvcy1kb3dubG9hZC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtZHJhZzpiZWZvcmUsIC5pb24taW9zLWVtYWlsOmJlZm9yZSwgLmlvbi1pb3MtZW1haWwtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWV5ZTpiZWZvcmUsIC5pb24taW9zLWV5ZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtZmFzdGZvcndhcmQ6YmVmb3JlLCAuaW9uLWlvcy1mYXN0Zm9yd2FyZC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtZmlsaW5nOmJlZm9yZSwgLmlvbi1pb3MtZmlsaW5nLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1maWxtOmJlZm9yZSwgLmlvbi1pb3MtZmlsbS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtZmxhZzpiZWZvcmUsIC5pb24taW9zLWZsYWctb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWZsYW1lOmJlZm9yZSwgLmlvbi1pb3MtZmxhbWUtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWZsYXNrOmJlZm9yZSwgLmlvbi1pb3MtZmxhc2stb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWZsb3dlcjpiZWZvcmUsIC5pb24taW9zLWZsb3dlci1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtZm9sZGVyOmJlZm9yZSwgLmlvbi1pb3MtZm9sZGVyLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1mb290YmFsbDpiZWZvcmUsIC5pb24taW9zLWZvb3RiYWxsLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1nYW1lLWNvbnRyb2xsZXItYTpiZWZvcmUsIC5pb24taW9zLWdhbWUtY29udHJvbGxlci1hLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1nYW1lLWNvbnRyb2xsZXItYjpiZWZvcmUsIC5pb24taW9zLWdhbWUtY29udHJvbGxlci1iLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1nZWFyOmJlZm9yZSwgLmlvbi1pb3MtZ2Vhci1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtZ2xhc3NlczpiZWZvcmUsIC5pb24taW9zLWdsYXNzZXMtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWdyaWQtdmlldzpiZWZvcmUsIC5pb24taW9zLWdyaWQtdmlldy1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtaGVhcnQ6YmVmb3JlLCAuaW9uLWlvcy1oZWFydC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtaGVscDpiZWZvcmUsIC5pb24taW9zLWhlbHAtZW1wdHk6YmVmb3JlLCAuaW9uLWlvcy1oZWxwLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1ob21lOmJlZm9yZSwgLmlvbi1pb3MtaG9tZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtaW5maW5pdGU6YmVmb3JlLCAuaW9uLWlvcy1pbmZpbml0ZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtaW5mb3JtYXRpb246YmVmb3JlLCAuaW9uLWlvcy1pbmZvcm1hdGlvbi1lbXB0eTpiZWZvcmUsIC5pb24taW9zLWluZm9ybWF0aW9uLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1pb25pYy1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3Mta2V5cGFkOmJlZm9yZSwgLmlvbi1pb3Mta2V5cGFkLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1saWdodGJ1bGI6YmVmb3JlLCAuaW9uLWlvcy1saWdodGJ1bGItb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWxpc3Q6YmVmb3JlLCAuaW9uLWlvcy1saXN0LW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1sb2NhdGlvbjpiZWZvcmUsIC5pb24taW9zLWxvY2F0aW9uLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1sb2NrZWQ6YmVmb3JlLCAuaW9uLWlvcy1sb2NrZWQtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLWxvb3A6YmVmb3JlLCAuaW9uLWlvcy1sb29wLXN0cm9uZzpiZWZvcmUsIC5pb24taW9zLW1lZGljYWw6YmVmb3JlLCAuaW9uLWlvcy1tZWRpY2FsLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1tZWRraXQ6YmVmb3JlLCAuaW9uLWlvcy1tZWRraXQtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLW1pYzpiZWZvcmUsIC5pb24taW9zLW1pYy1vZmY6YmVmb3JlLCAuaW9uLWlvcy1taWMtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLW1pbnVzOmJlZm9yZSwgLmlvbi1pb3MtbWludXMtZW1wdHk6YmVmb3JlLCAuaW9uLWlvcy1taW51cy1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtbW9uaXRvcjpiZWZvcmUsIC5pb24taW9zLW1vbml0b3Itb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLW1vb246YmVmb3JlLCAuaW9uLWlvcy1tb29uLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1tb3JlOmJlZm9yZSwgLmlvbi1pb3MtbW9yZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtbXVzaWNhbC1ub3RlOmJlZm9yZSwgLmlvbi1pb3MtbXVzaWNhbC1ub3RlczpiZWZvcmUsIC5pb24taW9zLW5hdmlnYXRlOmJlZm9yZSwgLmlvbi1pb3MtbmF2aWdhdGUtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLW51dHJpdGlvbjpiZWZvcmUsIC5pb24taW9zLW51dHJpdGlvbi1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtcGFwZXI6YmVmb3JlLCAuaW9uLWlvcy1wYXBlci1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtcGFwZXJwbGFuZTpiZWZvcmUsIC5pb24taW9zLXBhcGVycGxhbmUtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXBhcnRseXN1bm55OmJlZm9yZSwgLmlvbi1pb3MtcGFydGx5c3Vubnktb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXBhdXNlOmJlZm9yZSwgLmlvbi1pb3MtcGF1c2Utb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXBhdzpiZWZvcmUsIC5pb24taW9zLXBhdy1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtcGVvcGxlOmJlZm9yZSwgLmlvbi1pb3MtcGVvcGxlLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1wZXJzb246YmVmb3JlLCAuaW9uLWlvcy1wZXJzb24tb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXBlcnNvbmFkZDpiZWZvcmUsIC5pb24taW9zLXBlcnNvbmFkZC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtcGhvdG9zOmJlZm9yZSwgLmlvbi1pb3MtcGhvdG9zLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1waWU6YmVmb3JlLCAuaW9uLWlvcy1waWUtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXBpbnQ6YmVmb3JlLCAuaW9uLWlvcy1waW50LW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1wbGF5OmJlZm9yZSwgLmlvbi1pb3MtcGxheS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtcGx1czpiZWZvcmUsIC5pb24taW9zLXBsdXMtZW1wdHk6YmVmb3JlLCAuaW9uLWlvcy1wbHVzLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1wcmljZXRhZzpiZWZvcmUsIC5pb24taW9zLXByaWNldGFnLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1wcmljZXRhZ3M6YmVmb3JlLCAuaW9uLWlvcy1wcmljZXRhZ3Mtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXByaW50ZXI6YmVmb3JlLCAuaW9uLWlvcy1wcmludGVyLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1wdWxzZTpiZWZvcmUsIC5pb24taW9zLXB1bHNlLXN0cm9uZzpiZWZvcmUsIC5pb24taW9zLXJhaW55OmJlZm9yZSwgLmlvbi1pb3MtcmFpbnktb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXJlY29yZGluZzpiZWZvcmUsIC5pb24taW9zLXJlY29yZGluZy1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtcmVkbzpiZWZvcmUsIC5pb24taW9zLXJlZG8tb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXJlZnJlc2g6YmVmb3JlLCAuaW9uLWlvcy1yZWZyZXNoLWVtcHR5OmJlZm9yZSwgLmlvbi1pb3MtcmVmcmVzaC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtcmVsb2FkOmJlZm9yZSwgLmlvbi1pb3MtcmV2ZXJzZS1jYW1lcmE6YmVmb3JlLCAuaW9uLWlvcy1yZXZlcnNlLWNhbWVyYS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtcmV3aW5kOmJlZm9yZSwgLmlvbi1pb3MtcmV3aW5kLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1yb3NlOmJlZm9yZSwgLmlvbi1pb3Mtcm9zZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3Mtc2VhcmNoOmJlZm9yZSwgLmlvbi1pb3Mtc2VhcmNoLXN0cm9uZzpiZWZvcmUsIC5pb24taW9zLXNldHRpbmdzOmJlZm9yZSwgLmlvbi1pb3Mtc2V0dGluZ3Mtc3Ryb25nOmJlZm9yZSwgLmlvbi1pb3Mtc2h1ZmZsZTpiZWZvcmUsIC5pb24taW9zLXNodWZmbGUtc3Ryb25nOmJlZm9yZSwgLmlvbi1pb3Mtc2tpcGJhY2t3YXJkOmJlZm9yZSwgLmlvbi1pb3Mtc2tpcGJhY2t3YXJkLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1za2lwZm9yd2FyZDpiZWZvcmUsIC5pb24taW9zLXNraXBmb3J3YXJkLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1zbm93eTpiZWZvcmUsIC5pb24taW9zLXNwZWVkb21ldGVyOmJlZm9yZSwgLmlvbi1pb3Mtc3BlZWRvbWV0ZXItb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXN0YXI6YmVmb3JlLCAuaW9uLWlvcy1zdGFyLWhhbGY6YmVmb3JlLCAuaW9uLWlvcy1zdGFyLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy1zdG9wd2F0Y2g6YmVmb3JlLCAuaW9uLWlvcy1zdG9wd2F0Y2gtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXN1bm55OmJlZm9yZSwgLmlvbi1pb3Mtc3Vubnktb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXRlbGVwaG9uZTpiZWZvcmUsIC5pb24taW9zLXRlbGVwaG9uZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtdGVubmlzYmFsbDpiZWZvcmUsIC5pb24taW9zLXRlbm5pc2JhbGwtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXRodW5kZXJzdG9ybTpiZWZvcmUsIC5pb24taW9zLXRodW5kZXJzdG9ybS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtdGltZTpiZWZvcmUsIC5pb24taW9zLXRpbWUtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXRpbWVyOmJlZm9yZSwgLmlvbi1pb3MtdGltZXItb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXRvZ2dsZTpiZWZvcmUsIC5pb24taW9zLXRvZ2dsZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtdHJhc2g6YmVmb3JlLCAuaW9uLWlvcy10cmFzaC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtdW5kbzpiZWZvcmUsIC5pb24taW9zLXVuZG8tb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXVubG9ja2VkOmJlZm9yZSwgLmlvbi1pb3MtdW5sb2NrZWQtb3V0bGluZTpiZWZvcmUsIC5pb24taW9zLXVwbG9hZDpiZWZvcmUsIC5pb24taW9zLXVwbG9hZC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3MtdmlkZW9jYW06YmVmb3JlLCAuaW9uLWlvcy12aWRlb2NhbS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1pb3Mtdm9sdW1lLWhpZ2g6YmVmb3JlLCAuaW9uLWlvcy12b2x1bWUtbG93OmJlZm9yZSwgLmlvbi1pb3Mtd2luZWdsYXNzOmJlZm9yZSwgLmlvbi1pb3Mtd2luZWdsYXNzLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlvcy13b3JsZDpiZWZvcmUsIC5pb24taW9zLXdvcmxkLW91dGxpbmU6YmVmb3JlLCAuaW9uLWlwYWQ6YmVmb3JlLCAuaW9uLWlwaG9uZTpiZWZvcmUsIC5pb24taXBvZDpiZWZvcmUsIC5pb24tamV0OmJlZm9yZSwgLmlvbi1rZXk6YmVmb3JlLCAuaW9uLWtuaWZlOmJlZm9yZSwgLmlvbi1sYXB0b3A6YmVmb3JlLCAuaW9uLWxlYWY6YmVmb3JlLCAuaW9uLWxldmVsczpiZWZvcmUsIC5pb24tbGlnaHRidWxiOmJlZm9yZSwgLmlvbi1saW5rOmJlZm9yZSwgLmlvbi1sb2FkLWE6YmVmb3JlLCAuaW9uLWxvYWQtYjpiZWZvcmUsIC5pb24tbG9hZC1jOmJlZm9yZSwgLmlvbi1sb2FkLWQ6YmVmb3JlLCAuaW9uLWxvY2F0aW9uOmJlZm9yZSwgLmlvbi1sb2NrLWNvbWJpbmF0aW9uOmJlZm9yZSwgLmlvbi1sb2NrZWQ6YmVmb3JlLCAuaW9uLWxvZy1pbjpiZWZvcmUsIC5pb24tbG9nLW91dDpiZWZvcmUsIC5pb24tbG9vcDpiZWZvcmUsIC5pb24tbWFnbmV0OmJlZm9yZSwgLmlvbi1tYWxlOmJlZm9yZSwgLmlvbi1tYW46YmVmb3JlLCAuaW9uLW1hcDpiZWZvcmUsIC5pb24tbWVka2l0OmJlZm9yZSwgLmlvbi1tZXJnZTpiZWZvcmUsIC5pb24tbWljLWE6YmVmb3JlLCAuaW9uLW1pYy1iOmJlZm9yZSwgLmlvbi1taWMtYzpiZWZvcmUsIC5pb24tbWludXM6YmVmb3JlLCAuaW9uLW1pbnVzLWNpcmNsZWQ6YmVmb3JlLCAuaW9uLW1pbnVzLXJvdW5kOmJlZm9yZSwgLmlvbi1tb2RlbC1zOmJlZm9yZSwgLmlvbi1tb25pdG9yOmJlZm9yZSwgLmlvbi1tb3JlOmJlZm9yZSwgLmlvbi1tb3VzZTpiZWZvcmUsIC5pb24tbXVzaWMtbm90ZTpiZWZvcmUsIC5pb24tbmF2aWNvbjpiZWZvcmUsIC5pb24tbmF2aWNvbi1yb3VuZDpiZWZvcmUsIC5pb24tbmF2aWdhdGU6YmVmb3JlLCAuaW9uLW5ldHdvcms6YmVmb3JlLCAuaW9uLW5vLXNtb2tpbmc6YmVmb3JlLCAuaW9uLW51Y2xlYXI6YmVmb3JlLCAuaW9uLW91dGxldDpiZWZvcmUsIC5pb24tcGFpbnRicnVzaDpiZWZvcmUsIC5pb24tcGFpbnRidWNrZXQ6YmVmb3JlLCAuaW9uLXBhcGVyLWFpcnBsYW5lOmJlZm9yZSwgLmlvbi1wYXBlcmNsaXA6YmVmb3JlLCAuaW9uLXBhdXNlOmJlZm9yZSwgLmlvbi1wZXJzb246YmVmb3JlLCAuaW9uLXBlcnNvbi1hZGQ6YmVmb3JlLCAuaW9uLXBlcnNvbi1zdGFsa2VyOmJlZm9yZSwgLmlvbi1waWUtZ3JhcGg6YmVmb3JlLCAuaW9uLXBpbjpiZWZvcmUsIC5pb24tcGlucG9pbnQ6YmVmb3JlLCAuaW9uLXBpenphOmJlZm9yZSwgLmlvbi1wbGFuZTpiZWZvcmUsIC5pb24tcGxhbmV0OmJlZm9yZSwgLmlvbi1wbGF5OmJlZm9yZSwgLmlvbi1wbGF5c3RhdGlvbjpiZWZvcmUsIC5pb24tcGx1czpiZWZvcmUsIC5pb24tcGx1cy1jaXJjbGVkOmJlZm9yZSwgLmlvbi1wbHVzLXJvdW5kOmJlZm9yZSwgLmlvbi1wb2RpdW06YmVmb3JlLCAuaW9uLXBvdW5kOmJlZm9yZSwgLmlvbi1wb3dlcjpiZWZvcmUsIC5pb24tcHJpY2V0YWc6YmVmb3JlLCAuaW9uLXByaWNldGFnczpiZWZvcmUsIC5pb24tcHJpbnRlcjpiZWZvcmUsIC5pb24tcHVsbC1yZXF1ZXN0OmJlZm9yZSwgLmlvbi1xci1zY2FubmVyOmJlZm9yZSwgLmlvbi1xdW90ZTpiZWZvcmUsIC5pb24tcmFkaW8td2F2ZXM6YmVmb3JlLCAuaW9uLXJlY29yZDpiZWZvcmUsIC5pb24tcmVmcmVzaDpiZWZvcmUsIC5pb24tcmVwbHk6YmVmb3JlLCAuaW9uLXJlcGx5LWFsbDpiZWZvcmUsIC5pb24tcmliYm9uLWE6YmVmb3JlLCAuaW9uLXJpYmJvbi1iOmJlZm9yZSwgLmlvbi1zYWQ6YmVmb3JlLCAuaW9uLXNhZC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zY2lzc29yczpiZWZvcmUsIC5pb24tc2VhcmNoOmJlZm9yZSwgLmlvbi1zZXR0aW5nczpiZWZvcmUsIC5pb24tc2hhcmU6YmVmb3JlLCAuaW9uLXNodWZmbGU6YmVmb3JlLCAuaW9uLXNraXAtYmFja3dhcmQ6YmVmb3JlLCAuaW9uLXNraXAtZm9yd2FyZDpiZWZvcmUsIC5pb24tc29jaWFsLWFuZHJvaWQ6YmVmb3JlLCAuaW9uLXNvY2lhbC1hbmRyb2lkLW91dGxpbmU6YmVmb3JlLCAuaW9uLXNvY2lhbC1hbmd1bGFyOmJlZm9yZSwgLmlvbi1zb2NpYWwtYW5ndWxhci1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtYXBwbGU6YmVmb3JlLCAuaW9uLXNvY2lhbC1hcHBsZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtYml0Y29pbjpiZWZvcmUsIC5pb24tc29jaWFsLWJpdGNvaW4tb3V0bGluZTpiZWZvcmUsIC5pb24tc29jaWFsLWJ1ZmZlcjpiZWZvcmUsIC5pb24tc29jaWFsLWJ1ZmZlci1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtY2hyb21lOmJlZm9yZSwgLmlvbi1zb2NpYWwtY2hyb21lLW91dGxpbmU6YmVmb3JlLCAuaW9uLXNvY2lhbC1jb2RlcGVuOmJlZm9yZSwgLmlvbi1zb2NpYWwtY29kZXBlbi1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtY3NzMzpiZWZvcmUsIC5pb24tc29jaWFsLWNzczMtb3V0bGluZTpiZWZvcmUsIC5pb24tc29jaWFsLWRlc2lnbmVybmV3czpiZWZvcmUsIC5pb24tc29jaWFsLWRlc2lnbmVybmV3cy1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtZHJpYmJibGU6YmVmb3JlLCAuaW9uLXNvY2lhbC1kcmliYmJsZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtZHJvcGJveDpiZWZvcmUsIC5pb24tc29jaWFsLWRyb3Bib3gtb3V0bGluZTpiZWZvcmUsIC5pb24tc29jaWFsLWV1cm86YmVmb3JlLCAuaW9uLXNvY2lhbC1ldXJvLW91dGxpbmU6YmVmb3JlLCAuaW9uLXNvY2lhbC1mYWNlYm9vazpiZWZvcmUsIC5pb24tc29jaWFsLWZhY2Vib29rLW91dGxpbmU6YmVmb3JlLCAuaW9uLXNvY2lhbC1mb3Vyc3F1YXJlOmJlZm9yZSwgLmlvbi1zb2NpYWwtZm91cnNxdWFyZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtZnJlZWJzZC1kZXZpbDpiZWZvcmUsIC5pb24tc29jaWFsLWdpdGh1YjpiZWZvcmUsIC5pb24tc29jaWFsLWdpdGh1Yi1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtZ29vZ2xlOmJlZm9yZSwgLmlvbi1zb2NpYWwtZ29vZ2xlLW91dGxpbmU6YmVmb3JlLCAuaW9uLXNvY2lhbC1nb29nbGVwbHVzOmJlZm9yZSwgLmlvbi1zb2NpYWwtZ29vZ2xlcGx1cy1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtaGFja2VybmV3czpiZWZvcmUsIC5pb24tc29jaWFsLWhhY2tlcm5ld3Mtb3V0bGluZTpiZWZvcmUsIC5pb24tc29jaWFsLWh0bWw1OmJlZm9yZSwgLmlvbi1zb2NpYWwtaHRtbDUtb3V0bGluZTpiZWZvcmUsIC5pb24tc29jaWFsLWluc3RhZ3JhbTpiZWZvcmUsIC5pb24tc29jaWFsLWluc3RhZ3JhbS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtamF2YXNjcmlwdDpiZWZvcmUsIC5pb24tc29jaWFsLWphdmFzY3JpcHQtb3V0bGluZTpiZWZvcmUsIC5pb24tc29jaWFsLWxpbmtlZGluOmJlZm9yZSwgLmlvbi1zb2NpYWwtbGlua2VkaW4tb3V0bGluZTpiZWZvcmUsIC5pb24tc29jaWFsLW1hcmtkb3duOmJlZm9yZSwgLmlvbi1zb2NpYWwtbm9kZWpzOmJlZm9yZSwgLmlvbi1zb2NpYWwtb2N0b2NhdDpiZWZvcmUsIC5pb24tc29jaWFsLXBpbnRlcmVzdDpiZWZvcmUsIC5pb24tc29jaWFsLXBpbnRlcmVzdC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtcHl0aG9uOmJlZm9yZSwgLmlvbi1zb2NpYWwtcmVkZGl0OmJlZm9yZSwgLmlvbi1zb2NpYWwtcmVkZGl0LW91dGxpbmU6YmVmb3JlLCAuaW9uLXNvY2lhbC1yc3M6YmVmb3JlLCAuaW9uLXNvY2lhbC1yc3Mtb3V0bGluZTpiZWZvcmUsIC5pb24tc29jaWFsLXNhc3M6YmVmb3JlLCAuaW9uLXNvY2lhbC1za3lwZTpiZWZvcmUsIC5pb24tc29jaWFsLXNreXBlLW91dGxpbmU6YmVmb3JlLCAuaW9uLXNvY2lhbC1zbmFwY2hhdDpiZWZvcmUsIC5pb24tc29jaWFsLXNuYXBjaGF0LW91dGxpbmU6YmVmb3JlLCAuaW9uLXNvY2lhbC10dW1ibHI6YmVmb3JlLCAuaW9uLXNvY2lhbC10dW1ibHItb3V0bGluZTpiZWZvcmUsIC5pb24tc29jaWFsLXR1eDpiZWZvcmUsIC5pb24tc29jaWFsLXR3aXRjaDpiZWZvcmUsIC5pb24tc29jaWFsLXR3aXRjaC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtdHdpdHRlcjpiZWZvcmUsIC5pb24tc29jaWFsLXR3aXR0ZXItb3V0bGluZTpiZWZvcmUsIC5pb24tc29jaWFsLXVzZDpiZWZvcmUsIC5pb24tc29jaWFsLXVzZC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtdmltZW86YmVmb3JlLCAuaW9uLXNvY2lhbC12aW1lby1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtd2hhdHNhcHA6YmVmb3JlLCAuaW9uLXNvY2lhbC13aGF0c2FwcC1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwtd2luZG93czpiZWZvcmUsIC5pb24tc29jaWFsLXdpbmRvd3Mtb3V0bGluZTpiZWZvcmUsIC5pb24tc29jaWFsLXdvcmRwcmVzczpiZWZvcmUsIC5pb24tc29jaWFsLXdvcmRwcmVzcy1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwteWFob286YmVmb3JlLCAuaW9uLXNvY2lhbC15YWhvby1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb2NpYWwteWVuOmJlZm9yZSwgLmlvbi1zb2NpYWwteWVuLW91dGxpbmU6YmVmb3JlLCAuaW9uLXNvY2lhbC15b3V0dWJlOmJlZm9yZSwgLmlvbi1zb2NpYWwteW91dHViZS1vdXRsaW5lOmJlZm9yZSwgLmlvbi1zb3VwLWNhbjpiZWZvcmUsIC5pb24tc291cC1jYW4tb3V0bGluZTpiZWZvcmUsIC5pb24tc3BlYWtlcnBob25lOmJlZm9yZSwgLmlvbi1zcGVlZG9tZXRlcjpiZWZvcmUsIC5pb24tc3Bvb246YmVmb3JlLCAuaW9uLXN0YXI6YmVmb3JlLCAuaW9uLXN0YXRzLWJhcnM6YmVmb3JlLCAuaW9uLXN0ZWFtOmJlZm9yZSwgLmlvbi1zdG9wOmJlZm9yZSwgLmlvbi10aGVybW9tZXRlcjpiZWZvcmUsIC5pb24tdGh1bWJzZG93bjpiZWZvcmUsIC5pb24tdGh1bWJzdXA6YmVmb3JlLCAuaW9uLXRvZ2dsZTpiZWZvcmUsIC5pb24tdG9nZ2xlLWZpbGxlZDpiZWZvcmUsIC5pb24tdHJhbnNnZW5kZXI6YmVmb3JlLCAuaW9uLXRyYXNoLWE6YmVmb3JlLCAuaW9uLXRyYXNoLWI6YmVmb3JlLCAuaW9uLXRyb3BoeTpiZWZvcmUsIC5pb24tdHNoaXJ0OmJlZm9yZSwgLmlvbi10c2hpcnQtb3V0bGluZTpiZWZvcmUsIC5pb24tdW1icmVsbGE6YmVmb3JlLCAuaW9uLXVuaXZlcnNpdHk6YmVmb3JlLCAuaW9uLXVubG9ja2VkOmJlZm9yZSwgLmlvbi11cGxvYWQ6YmVmb3JlLCAuaW9uLXVzYjpiZWZvcmUsIC5pb24tdmlkZW9jYW1lcmE6YmVmb3JlLCAuaW9uLXZvbHVtZS1oaWdoOmJlZm9yZSwgLmlvbi12b2x1bWUtbG93OmJlZm9yZSwgLmlvbi12b2x1bWUtbWVkaXVtOmJlZm9yZSwgLmlvbi12b2x1bWUtbXV0ZTpiZWZvcmUsIC5pb24td2FuZDpiZWZvcmUsIC5pb24td2F0ZXJkcm9wOmJlZm9yZSwgLmlvbi13aWZpOmJlZm9yZSwgLmlvbi13aW5lZ2xhc3M6YmVmb3JlLCAuaW9uLXdvbWFuOmJlZm9yZSwgLmlvbi13cmVuY2g6YmVmb3JlLCAuaW9uLXhib3g6YmVmb3JlIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBmb250LWZhbWlseTogXCJJb25pY29uc1wiO1xuICBzcGVhazogbm9uZTtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LXdlaWdodDogbm9ybWFsO1xuICBmb250LXZhcmlhbnQ6IG5vcm1hbDtcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gIHRleHQtcmVuZGVyaW5nOiBhdXRvO1xuICBsaW5lLWhlaWdodDogMTtcbiAgLXdlYmtpdC1mb250LXNtb290aGluZzogYW50aWFsaWFzZWQ7XG4gIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGVcbn1cblxuLmlvbi1hbmRyb2lkLW5vdGlmaWNhdGlvbnM6YmVmb3JlIHtcbiAgY29udGVudDogXCLDr8KOwptcIlxufVxuXG4uaGFtYnVyZ2VyIHtcbiAgcGFkZGluZzogMHB4IDBweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIHRyYW5zaXRpb24tcHJvcGVydHk6IG9wYWNpdHksIGZpbHRlcjtcbiAgdHJhbnNpdGlvbi1kdXJhdGlvbjogMC4xNXM7XG4gIHRyYW5zaXRpb24tdGltaW5nLWZ1bmN0aW9uOiBsaW5lYXI7XG4gIGZvbnQ6IGluaGVyaXQ7XG4gIGNvbG9yOiBpbmhlcml0O1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGJvcmRlcjogMDtcbiAgbWFyZ2luOiAwO1xuICBvdmVyZmxvdzogdmlzaWJsZVxufVxuXG4uaGFtYnVyZ2VyOmhvdmVyIHtcbiAgb3BhY2l0eTogLjdcbn1cblxuLmhhbWJ1cmdlci5pcy1hY3RpdmU6aG92ZXIge1xuICBvcGFjaXR5OiAuN1xufVxuXG4uaGFtYnVyZ2VyLmlzLWFjdGl2ZSAuaGFtYnVyZ2VyLWlubmVyLCAuaGFtYnVyZ2VyLmlzLWFjdGl2ZSAuaGFtYnVyZ2VyLWlubmVyOjpiZWZvcmUsIC5oYW1idXJnZXIuaXMtYWN0aXZlIC5oYW1idXJnZXItaW5uZXI6OmFmdGVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzNmNmFkOFxufVxuXG4uaGFtYnVyZ2VyLWJveCB7XG4gIHdpZHRoOiAyNHB4O1xuICBoZWlnaHQ6IDE0cHg7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcG9zaXRpb246IHJlbGF0aXZlXG59XG5cbi5oYW1idXJnZXItaW5uZXIge1xuICBkaXNwbGF5OiBibG9jaztcbiAgdG9wOiA1MCU7XG4gIG1hcmdpbi10b3A6IC0xcHhcbn1cblxuLmhhbWJ1cmdlci1pbm5lciwgLmhhbWJ1cmdlci1pbm5lcjo6YmVmb3JlLCAuaGFtYnVyZ2VyLWlubmVyOjphZnRlciB7XG4gIHdpZHRoOiAyNHB4O1xuICBoZWlnaHQ6IDJweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzNmNmFkODtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0cmFuc2l0aW9uLXByb3BlcnR5OiB0cmFuc2Zvcm07XG4gIHRyYW5zaXRpb24tZHVyYXRpb246IDAuMTVzO1xuICB0cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZVxufVxuXG4uaGFtYnVyZ2VyLWlubmVyOjpiZWZvcmUsIC5oYW1idXJnZXItaW5uZXI6OmFmdGVyIHtcbiAgY29udGVudDogXCJcIjtcbiAgZGlzcGxheTogYmxvY2tcbn1cblxuLmhhbWJ1cmdlci1pbm5lcjo6YmVmb3JlIHtcbiAgdG9wOiAtNnB4XG59XG5cbi5oYW1idXJnZXItaW5uZXI6OmFmdGVyIHtcbiAgYm90dG9tOiAtNnB4XG59XG5cbi5oYW1idXJnZXItLWVsYXN0aWMgLmhhbWJ1cmdlci1pbm5lciB7XG4gIHRvcDogMXB4O1xuICB0cmFuc2l0aW9uLWR1cmF0aW9uOiAwLjI3NXM7XG4gIHRyYW5zaXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC42OCwgLTAuNTUsIDAuMjY1LCAxLjU1KVxufVxuXG4uaGFtYnVyZ2VyLS1lbGFzdGljIC5oYW1idXJnZXItaW5uZXI6OmJlZm9yZSB7XG4gIHRvcDogNnB4O1xuICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuMTI1cyAwLjI3NXMgZWFzZVxufVxuXG4uaGFtYnVyZ2VyLS1lbGFzdGljIC5oYW1idXJnZXItaW5uZXI6OmFmdGVyIHtcbiAgdG9wOiAxMnB4O1xuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4yNzVzIGN1YmljLWJlemllcigwLjY4LCAtMC41NSwgMC4yNjUsIDEuNTUpXG59XG5cbi5oYW1idXJnZXItLWVsYXN0aWMuaXMtYWN0aXZlIC5oYW1idXJnZXItaW5uZXIge1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDZweCwgMCkgcm90YXRlKDEzNWRlZyk7XG4gIHRyYW5zaXRpb24tZGVsYXk6IDAuMDc1c1xufVxuXG4uaGFtYnVyZ2VyLS1lbGFzdGljLmlzLWFjdGl2ZSAuaGFtYnVyZ2VyLWlubmVyOjpiZWZvcmUge1xuICB0cmFuc2l0aW9uLWRlbGF5OiAwcztcbiAgb3BhY2l0eTogMFxufVxuXG4uaGFtYnVyZ2VyLS1lbGFzdGljLmlzLWFjdGl2ZSAuaGFtYnVyZ2VyLWlubmVyOjphZnRlciB7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTEycHgsIDApIHJvdGF0ZSgtMjcwZGVnKTtcbiAgdHJhbnNpdGlvbi1kZWxheTogMC4wNzVzXG59XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogMTMyMHB4KSB7XG4gIC5oZWFkZXItdXNlci1pbmZvIHtcbiAgICBkaXNwbGF5OiBub25lXG4gIH1cbn1cblxuQG1lZGlhIChtYXgtd2lkdGg6IDk5MS45OHB4KSB7XG4gIC5hcHAtbWFpbiB7XG4gICAgZGlzcGxheTogYmxvY2tcbiAgfVxuXG4gIC5kcm9wZG93bi1tZW51OjpiZWZvcmUsIC5kcm9wZG93bi1tZW51OjphZnRlciB7XG4gICAgZGlzcGxheTogbm9uZVxuICB9XG5cbiAgLmFwcC1zaWRlYmFyIHtcbiAgICBmbGV4OiAwIDAgMjgwcHggIWltcG9ydGFudDtcbiAgICB3aWR0aDogMjgwcHggIWltcG9ydGFudDtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTI4MHB4KTtcbiAgICBwb3NpdGlvbjogZml4ZWRcbiAgfVxuXG4gIC5hcHAtc2lkZWJhciAuYXBwLWhlYWRlcl9fbG9nbyB7XG4gICAgZGlzcGxheTogbm9uZVxuICB9XG5cbiAgLnNpZGViYXItbW9iaWxlLW9wZW4gLmFwcC1zaWRlYmFyIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMClcbiAgfVxuXG4gIC5zaWRlYmFyLW1vYmlsZS1vcGVuIC5hcHAtc2lkZWJhciAuYXBwLXNpZGViYXJfX2lubmVyIC5hcHAtc2lkZWJhcl9faGVhZGluZyB7XG4gICAgdGV4dC1pbmRlbnQ6IGluaXRpYWxcbiAgfVxuXG4gIC5zaWRlYmFyLW1vYmlsZS1vcGVuIC5hcHAtc2lkZWJhciAuYXBwLXNpZGViYXJfX2lubmVyIC5hcHAtc2lkZWJhcl9faGVhZGluZzo6YmVmb3JlIHtcbiAgICBkaXNwbGF5OiBub25lXG4gIH1cblxuICAuc2lkZWJhci1tb2JpbGUtb3BlbiAuYXBwLXNpZGViYXIgLmFwcC1zaWRlYmFyX19pbm5lciB1bCBsaSBhIHtcbiAgICB0ZXh0LWluZGVudDogaW5pdGlhbDtcbiAgICBwYWRkaW5nOiAwIDEuNXJlbSAwIDQ1cHhcbiAgfVxuXG4gIC5zaWRlYmFyLW1vYmlsZS1vcGVuIC5hcHAtc2lkZWJhciAuYXBwLXNpZGViYXJfX2lubmVyIC5tZXRpc21lbnUtaWNvbiB7XG4gICAgdGV4dC1pbmRlbnQ6IGluaXRpYWw7XG4gICAgbGVmdDogNXB4O1xuICAgIG1hcmdpbi1sZWZ0OiAwXG4gIH1cblxuICAuc2lkZWJhci1tb2JpbGUtb3BlbiAuYXBwLXNpZGViYXIgLmFwcC1zaWRlYmFyX19pbm5lciAubWV0aXNtZW51LXN0YXRlLWljb24ge1xuICAgIHZpc2liaWxpdHk6IHZpc2libGVcbiAgfVxuXG4gIC5zaWRlYmFyLW1vYmlsZS1vcGVuIC5hcHAtc2lkZWJhciAuYXBwLXNpZGViYXJfX2lubmVyIHVsOjpiZWZvcmUge1xuICAgIGRpc3BsYXk6IGJsb2NrXG4gIH1cblxuICAuc2lkZWJhci1tb2JpbGUtb3BlbiAuYXBwLXNpZGViYXIgLmFwcC1zaWRlYmFyX19pbm5lciB1bCB1bCBsaSBhIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDFlbVxuICB9XG5cbiAgLnNpZGViYXItbW9iaWxlLW9wZW4gLmFwcC1zaWRlYmFyIC5hcHAtc2lkZWJhcl9faW5uZXIgdWwubW0tc2hvdyB7XG4gICAgcGFkZGluZzogLjVlbSAwIDAgMnJlbVxuICB9XG5cbiAgLnNpZGViYXItbW9iaWxlLW9wZW4gLmFwcC1zaWRlYmFyIC5hcHAtc2lkZWJhcl9faW5uZXIgdWwubW0tc2hvdyA+IGxpID4gYSB7XG4gICAgaGVpZ2h0OiAycmVtO1xuICAgIGxpbmUtaGVpZ2h0OiAycmVtXG4gIH1cblxuICAuc2lkZWJhci1tb2JpbGUtb3BlbiAuYXBwLXNpZGViYXIgLmFwcC1oZWFkZXJfX2xvZ28ge1xuICAgIHdpZHRoOiBhdXRvICFpbXBvcnRhbnRcbiAgfVxuXG4gIC5zaWRlYmFyLW1vYmlsZS1vcGVuIC5hcHAtc2lkZWJhciAuYXBwLWhlYWRlcl9fbG9nbyAubG9nby1zcmMge1xuICAgIHdpZHRoOiA5N3B4ICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gICAgbWFyZ2luLXJpZ2h0OiAwXG4gIH1cblxuICAuc2lkZWJhci1tb2JpbGUtb3BlbiAuZml4ZWQtc2lkZWJhciAuYXBwLXNpZGViYXIge1xuICAgIGhlaWdodDogMTAwJVxuICB9XG5cbiAgLnNpZGViYXItbW9iaWxlLW9wZW4gLnNpZGViYXItbW9iaWxlLW92ZXJsYXkge1xuICAgIGRpc3BsYXk6IGJsb2NrXG4gIH1cblxuICAuYXBwLW1haW4gLmFwcC1tYWluX19vdXRlciB7XG4gICAgcGFkZGluZy1sZWZ0OiAwICFpbXBvcnRhbnRcbiAgfVxuXG4gIC5hcHAtaGVhZGVyIHtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW5cbiAgfVxuXG4gIC5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19sb2dvIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICAgIG9yZGVyOiAyO1xuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gICAgYm9yZGVyOiAwICFpbXBvcnRhbnRcbiAgfVxuXG4gIC5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19jb250ZW50IHtcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XG4gICAgb3BhY2l0eTogMDtcbiAgICBib3gtc2hhZG93OiAwIDAuNDY4NzVyZW0gMi4xODc1cmVtIHJnYmEoNCwgOSwgMjAsIDAuMDMpLCAwIDAuOTM3NXJlbSAxLjQwNjI1cmVtIHJnYmEoNCwgOSwgMjAsIDAuMDMpLCAwIDAuMjVyZW0gMC41MzEyNXJlbSByZ2JhKDQsIDksIDIwLCAwLjA1KSwgMCAwLjEyNXJlbSAwLjE4NzVyZW0gcmdiYSg0LCA5LCAyMCwgMC4wMyk7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDUlO1xuICAgIHdpZHRoOiA5MCU7XG4gICAgdG9wOiAwO1xuICAgIHRyYW5zaXRpb246IGFsbCAuMnM7XG4gICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICAgIHBhZGRpbmc6IDAgMTBweDtcbiAgICBvdmVyZmxvdzogaGlkZGVuXG4gIH1cblxuICAuYXBwLWhlYWRlciAuYXBwLWhlYWRlcl9fY29udGVudCAuaGVhZGVyLWJ0bi1sZyB7XG4gICAgbWFyZ2luLWxlZnQ6IC41cmVtO1xuICAgIHBhZGRpbmc6IDAgLjVyZW1cbiAgfVxuXG4gIC5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19jb250ZW50IC5oZWFkZXItYnRuLWxnIC5oYW1idXJnZXItYm94IHtcbiAgICBtYXJnaW4tdG9wOiA1cHhcbiAgfVxuXG4gIC5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19jb250ZW50IC5oZWFkZXItYnRuLWxnICsgLmhlYWRlci1idG4tbGcge1xuICAgIGRpc3BsYXk6IG5vbmVcbiAgfVxuXG4gIC5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19jb250ZW50IC5hcHAtaGVhZGVyLWxlZnQgLm5hdiB7XG4gICAgZGlzcGxheTogbm9uZVxuICB9XG5cbiAgLmFwcC1oZWFkZXIgLmFwcC1oZWFkZXJfX2NvbnRlbnQuaGVhZGVyLW1vYmlsZS1vcGVuIHtcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICAgIG9wYWNpdHk6IDE7XG4gICAgdG9wOiA4MHB4XG4gIH1cblxuICAuYXBwLWhlYWRlciAuYXBwLWhlYWRlcl9fbW9iaWxlLW1lbnUge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgb3JkZXI6IDFcbiAgfVxuXG4gIC5hcHAtaGVhZGVyIC5hcHAtaGVhZGVyX19tZW51IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIG9yZGVyOiAzXG4gIH1cblxuICAuYXBwLWhlYWRlci5oZWFkZXItdGV4dC1saWdodCAuYXBwLWhlYWRlcl9fbWVudSA+IHNwYW4gLmJ0biwgLmFwcC1oZWFkZXIuaGVhZGVyLXRleHQtbGlnaHQgLmFwcC1oZWFkZXJfX21lbnUgPiAuYnRuIHtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMSk7XG4gICAgYm9yZGVyLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMSlcbiAgfVxuXG4gIC5hcHAtaGVhZGVyLmhlYWRlci10ZXh0LWxpZ2h0IC5oZWFkZXItbW9iaWxlLW9wZW4ge1xuICAgIGJhY2tncm91bmQ6ICMzNDNhNDBcbiAgfVxuXG4gIC5hcHAtcGFnZS10aXRsZSB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyXG4gIH1cblxuICAuYXBwLXBhZ2UtdGl0bGUgLnBhZ2UtdGl0bGUtaGVhZGluZywgLmFwcC1wYWdlLXRpdGxlIC5wYWdlLXRpdGxlLXdyYXBwZXIge1xuICAgIG1hcmdpbjogMCBhdXRvO1xuICAgIGRpc3BsYXk6IGJsb2NrXG4gIH1cblxuICAuYXBwLXBhZ2UtdGl0bGUgLnBhZ2UtdGl0bGUtYWN0aW9ucyB7XG4gICAgbWFyZ2luOiAxNXB4IGF1dG8gMFxuICB9XG5cbiAgLmFwcC1wYWdlLXRpdGxlIC5wYWdlLXRpdGxlLWFjdGlvbnMgLmJyZWFkY3J1bWItaXRlbSwgLmFwcC1wYWdlLXRpdGxlIC5wYWdlLXRpdGxlLWFjdGlvbnMgLmJyZWFkY3J1bWIsIC5hcHAtcGFnZS10aXRsZSAucGFnZS10aXRsZS1zdWJoZWFkaW5nIC5icmVhZGNydW1iLWl0ZW0sIC5hcHAtcGFnZS10aXRsZSAucGFnZS10aXRsZS1zdWJoZWFkaW5nIC5icmVhZGNydW1iIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2tcbiAgfVxuXG4gIC5hcHAtZm9vdGVyIC5hcHAtZm9vdGVyX19pbm5lciAuYXBwLWZvb3Rlci1yaWdodCB7XG4gICAgZGlzcGxheTogbm9uZVxuICB9XG5cbiAgLmFwcC1mb290ZXIgLmFwcC1mb290ZXJfX2lubmVyIC5hcHAtZm9vdGVyLWxlZnQge1xuICAgIHdpZHRoOiAxMDAlXG4gIH1cblxuICAuYXBwLWZvb3RlciAuYXBwLWZvb3Rlcl9faW5uZXIgLmFwcC1mb290ZXItbGVmdCAuZm9vdGVyLWRvdHMge1xuICAgIG1hcmdpbjogMCBhdXRvXG4gIH1cblxuICAud2lkZ2V0LWNvbnRlbnQgLndpZGdldC1udW1iZXJzIHtcbiAgICBmb250LXNpemU6IDEuNnJlbTtcbiAgICBsaW5lLWhlaWdodDogMVxuICB9XG5cbiAgLnNsaWNrLXNsaWRlci1zbSAuc2xpY2stc2xpZGVyIHtcbiAgICBtYXgtd2lkdGg6IDY1MHB4ICFpbXBvcnRhbnRcbiAgfVxuXG4gIC5iZy10cmFuc3BhcmVudC5saXN0LWdyb3VwLWl0ZW0ge1xuICAgIGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnRcbiAgfVxuXG4gIC50YWJzLWxnLWFsdGVybmF0ZS5jYXJkLWhlYWRlciA+IC5uYXYgLm5hdi1pdGVtIC53aWRnZXQtbnVtYmVyIHtcbiAgICBmb250LXNpemU6IDEuNXJlbVxuICB9XG5cbiAgLnBhZ2UtdGl0bGUtaGVhZCB7XG4gICAgZGlzcGxheTogYmxvY2tcbiAgfVxufVxuXG5AbWVkaWEgKG1heC13aWR0aDogOTkxLjk4cHgpIHtcbiAgLmFwcC1wYWdlLXRpdGxlIC5wYWdlLXRpdGxlLWljb24sIC51aS10aGVtZS1zZXR0aW5ncyB7XG4gICAgZGlzcGxheTogbm9uZVxuICB9XG5cbn1cblxuQG1lZGlhIChtYXgtd2lkdGg6IDc2Ny45OHB4KSB7XG4gIC5hcHAtbWFpbiAuYXBwLW1haW5fX2lubmVyIHtcbiAgICBwYWRkaW5nOiAxNXB4IDE1cHggMFxuICB9XG5cbiAgLm1iZy0zLCBib2R5IC5jYXJkLm1iLTMge1xuICAgIG1hcmdpbi1ib3R0b206IDE1cHggIWltcG9ydGFudFxuICB9XG5cbiAgLmFwcC1wYWdlLXRpdGxlIHtcbiAgICBwYWRkaW5nOiAxNXB4O1xuICAgIG1hcmdpbjogLTE1cHggLTE1cHggMTVweFxuICB9XG5cbiAgLmFwcC1wYWdlLXRpdGxlICsgLmJvZHktdGFicy1sYXlvdXQge1xuICAgIG1hcmdpbi10b3A6IC0xNXB4ICFpbXBvcnRhbnRcbiAgfVxufVxuXG5cbi5jbG9zZWQtc2lkZWJhci5maXhlZC1zaWRlYmFyIC5hcHAtbWFpbl9fb3V0ZXIge1xuICBwYWRkaW5nLWxlZnQ6IDgwcHggIWltcG9ydGFudDtcbn1cblxuLmNhcmQge1xuICBib3JkZXItcmFkaXVzOiBjYWxjKC4yNXJlbSAtIDFweCkgY2FsYyguMjVyZW0gLSAxcHgpIDAgMDtcbn1cblxuLmNhcmQtaGVhZGVyIHtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgY29sb3I6IHJnYmEoMTMsIDI3LCA2MiwgMC43KTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtc2l6ZTogLjg4cmVtO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcblxuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAxcHg7XG4gIHBhZGRpbmctdG9wOiAwO1xuICBwYWRkaW5nLWJvdHRvbTogMDtcbiAgcGFkZGluZy1yaWdodDogLjYyNXJlbTtcbiAgaGVpZ2h0OiAzLjVyZW07XG59XG5cbi5jYXJkLWJvZHkge1xuICBmbGV4OiAxIDEgYXV0bztcbiAgcGFkZGluZzogMS4yNXJlbTtcbiAgLW1zLWZsZXg6IDEgMSBhdXRvO1xuICBtaW4taGVpZ2h0OiAxcHg7XG59XG5cbi50YWJsZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xuICBjb2xvcjogIzIxMjUyOTtcbn1cblxuLnRhYmxlLWJvcmRlcmVkIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2FkYWZiMjtcbn1cblxuLmNhcmQtZm9vdGVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG59XG5cbnRib2R5LmN1c3RvbS1ob3ZlciA+IHRyOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0UwRjNGRjtcbiAgdHJhbnNpdGlvbjogLjJzO1xufVxuXG4uYmNrLWltZyB7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCU7XG59XG5cbi5vcGFjaXR5IHtcbiAgb3BhY2l0eTogMSAhaW1wb3J0YW50O1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
    data: {
      animation: [(0,_transitions__WEBPACK_IMPORTED_MODULE_0__.FadeIn)()]
    }
  });
}

/***/ }),

/***/ 47859:
/*!*******************************************!*\
  !*** ./src/app/student/student.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StudentModule": () => (/* binding */ StudentModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _student_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./student.component */ 52667);
/* harmony import */ var _complaints_complaints_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./complaints/complaints.component */ 62687);
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home/home.component */ 93106);
/* harmony import */ var _previous_courses_previous_courses_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./previous-courses/previous-courses.component */ 565);
/* harmony import */ var _teacher_assesment_teacher_assesment_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./teacher-assesment/teacher-assesment.component */ 11125);
/* harmony import */ var _time_table_time_table_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./time-table/time-table.component */ 63014);
/* harmony import */ var _examination_complete_transcript_complete_transcript_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./examination/complete-transcript/complete-transcript.component */ 75393);
/* harmony import */ var _examination_semester_transcript_semester_transcript_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./examination/semester-transcript/semester-transcript.component */ 60855);
/* harmony import */ var _examination_date_sheet_date_sheet_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./examination/date-sheet/date-sheet.component */ 21261);
/* harmony import */ var _student_services_fee_structure_fee_structure_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./student-services/fee-structure/fee-structure.component */ 72689);
/* harmony import */ var _student_services_student_information_student_information_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./student-services/student-information/student-information.component */ 6281);
/* harmony import */ var _student_routing_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./student-routing.module */ 97852);
/* harmony import */ var _auto_close_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./auto.close.directive */ 47144);
/* harmony import */ var _event_emmiter_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./event-emmiter.service */ 8938);
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ng2-charts */ 53808);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./change-password/change-password.component */ 98867);
/* harmony import */ var _shared_order_by_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./shared/order-by.pipe */ 30636);
/* harmony import */ var _attendance_attendance_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./attendance/attendance.component */ 8422);
/* harmony import */ var _progress_report_progress_report_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./progress-report/progress-report.component */ 17975);
/* harmony import */ var _teacher_evaluation_teacher_evaluation_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./teacher-evaluation/teacher-evaluation.component */ 9479);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 22560);























class StudentModule {
  static #_ = this.ɵfac = function StudentModule_Factory(t) {
    return new (t || StudentModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineNgModule"]({
    type: StudentModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineInjector"]({
    providers: [_event_emmiter_service__WEBPACK_IMPORTED_MODULE_13__.AppComponentEventEmitterService],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_20__.CommonModule, _student_routing_module__WEBPACK_IMPORTED_MODULE_11__.StudentRoutingModule, ng2_charts__WEBPACK_IMPORTED_MODULE_21__.ChartsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormsModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵsetNgModuleScope"](StudentModule, {
    declarations: [_student_component__WEBPACK_IMPORTED_MODULE_0__.StudentComponent, _complaints_complaints_component__WEBPACK_IMPORTED_MODULE_1__.ComplaintsComponent, _home_home_component__WEBPACK_IMPORTED_MODULE_2__.HomeComponent, _previous_courses_previous_courses_component__WEBPACK_IMPORTED_MODULE_3__.PreviousCoursesComponent, _teacher_assesment_teacher_assesment_component__WEBPACK_IMPORTED_MODULE_4__.TeacherAssesmentComponent, _time_table_time_table_component__WEBPACK_IMPORTED_MODULE_5__.TimeTableComponent, _student_services_fee_structure_fee_structure_component__WEBPACK_IMPORTED_MODULE_9__.FeeStructureComponent, _student_services_student_information_student_information_component__WEBPACK_IMPORTED_MODULE_10__.StudentInformationComponent, _examination_complete_transcript_complete_transcript_component__WEBPACK_IMPORTED_MODULE_6__.CompleteTranscriptComponent, _examination_semester_transcript_semester_transcript_component__WEBPACK_IMPORTED_MODULE_7__.SemesterTranscriptComponent, _examination_date_sheet_date_sheet_component__WEBPACK_IMPORTED_MODULE_8__.DateSheetComponent, _auto_close_directive__WEBPACK_IMPORTED_MODULE_12__.AutoCloseDirective, _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_14__.ChangePasswordComponent, _shared_order_by_pipe__WEBPACK_IMPORTED_MODULE_15__.OrderByPipe, _attendance_attendance_component__WEBPACK_IMPORTED_MODULE_16__.AttendanceComponent, _progress_report_progress_report_component__WEBPACK_IMPORTED_MODULE_17__.ProgressReportComponent, _teacher_evaluation_teacher_evaluation_component__WEBPACK_IMPORTED_MODULE_18__.TeacherEvaluationComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_20__.CommonModule, _student_routing_module__WEBPACK_IMPORTED_MODULE_11__.StudentRoutingModule, ng2_charts__WEBPACK_IMPORTED_MODULE_21__.ChartsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormsModule]
  });
})();

/***/ }),

/***/ 11125:
/*!**************************************************************************!*\
  !*** ./src/app/student/teacher-assesment/teacher-assesment.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeacherAssesmentComponent": () => (/* binding */ TeacherAssesmentComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class TeacherAssesmentComponent {
  constructor() {}
  ngOnInit() {}
  static #_ = this.ɵfac = function TeacherAssesmentComponent_Factory(t) {
    return new (t || TeacherAssesmentComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: TeacherAssesmentComponent,
    selectors: [["app-teacher-assesment"]],
    decls: 2,
    vars: 0,
    template: function TeacherAssesmentComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "teacher-assesment works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    },
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 9479:
/*!****************************************************************************!*\
  !*** ./src/app/student/teacher-evaluation/teacher-evaluation.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeacherEvaluationComponent": () => (/* binding */ TeacherEvaluationComponent)
/* harmony export */ });
/* harmony import */ var src_app_transitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/transitions */ 71629);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_main_shared_services_Timetable_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/main/shared/services/Timetable.service */ 3651);
/* harmony import */ var _auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../auth/_services/authentication.service */ 7893);
/* harmony import */ var _teacherEvaluation_Services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./teacherEvaluation-Services */ 24082);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-toastr */ 94817);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);








const _c0 = ["f"];
function TeacherEvaluationComponent_li_7_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "button", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function TeacherEvaluationComponent_li_7_button_1_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      const s_r2 = ctx_r6.$implicit;
      const i_r3 = ctx_r6.index;
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r5.navigateToSingleCourse(s_r2.SUB_CODE, i_r3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const s_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](s_r2.SUB_NM);
  }
}
function TeacherEvaluationComponent_li_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "li", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, TeacherEvaluationComponent_li_7_button_1_Template, 2, 1, "button", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const s_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", s_r2.SUB_CODE != "LAW ENG 1101");
  }
}
function TeacherEvaluationComponent_div_9_div_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 29)(1, "a", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "\u00D7");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Dear Students!");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](6, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" You have been allocated Teacher Evaluation Form. Fill it and submit till Date:", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](6, 1, ctx_r9.formQues[0] == null ? null : ctx_r9.formQues[0].SUBMISSION_DT, "medium"), " ");
  }
}
function TeacherEvaluationComponent_div_9_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 31)(1, "p", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "No Evalution form is Allocated yet.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function TeacherEvaluationComponent_div_9_div_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 33)(1, "p", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "Due Date is Over.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function TeacherEvaluationComponent_div_9_div_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 34)(1, "h4", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "Well Done!");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "p", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "You have Successfully Submitted Form.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](5, "hr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
const _c1 = function (a0) {
  return {
    "background-color": a0
  };
};
function TeacherEvaluationComponent_div_9_table_37_td_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "td")(1, "div", 39, 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const p_r20 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](3, _c1, p_r20.PD_ID == 1 ? "#104a8e" : p_r20.PD_ID == 2 ? "#1357a6" : p_r20.PD_ID == 3 ? "#1663be" : p_r20.PD_ID == 4 ? "#1870d5" : p_r20.PD_ID == 5 ? "#1b7ced" : null));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"](" ", p_r20.PD_ID, "-", p_r20.PD_OPT, " ");
  }
}
const _c2 = function (a0) {
  return {
    "clicked": a0
  };
};
function TeacherEvaluationComponent_div_9_table_37_tr_11_td_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "td", 42)(1, "div", 43, 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function TeacherEvaluationComponent_div_9_table_37_tr_11_td_5_Template_div_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r31);
      const j_r27 = restoredCtx.index;
      const i_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().index;
      const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r29.updateSelection(i_r24, j_r27 + 1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const p_r26 = ctx.$implicit;
    const q_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](2, _c2, q_r23.RESPONSE_ID === p_r26.PD_ID));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", p_r26.PD_ID, "");
  }
}
function TeacherEvaluationComponent_div_9_table_37_tr_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, TeacherEvaluationComponent_div_9_table_37_tr_11_td_5_Template, 4, 4, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const q_r23 = ctx.$implicit;
    const i_r24 = ctx.index;
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](i_r24 + 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](q_r23.QUESTION);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r19.pat);
  }
}
function TeacherEvaluationComponent_div_9_table_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "table", 36)(1, "tbody")(2, "td")(3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Sr.No");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "td")(6, "div", 37)(7, "div")(8, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, "Instructor Performance Indicators");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, TeacherEvaluationComponent_div_9_table_37_td_10_Template, 4, 5, "td", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, TeacherEvaluationComponent_div_9_table_37_tr_11_Template, 6, 3, "tr", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r14.pat);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r14.formQues);
  }
}
function TeacherEvaluationComponent_div_9_div_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Comment ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function TeacherEvaluationComponent_div_9_div_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 45)(1, "div", 46)(2, "textarea", 47, 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "            ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
}
function TeacherEvaluationComponent_div_9_button_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "button", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, "Submit");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function TeacherEvaluationComponent_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 12)(1, "div", 13)(2, "div", 0)(3, "div", 14)(4, "h5");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, " Subject Name: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 14)(9, "h5");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10, " Teacher Name: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "div", 15)(14, "div", 16)(15, "h5");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16, " Subject Code: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "div", 16)(20, "h5");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](21, " Semester: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "div", 16)(25, "h5");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26, " Section: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](29, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](30, TeacherEvaluationComponent_div_9_div_30_Template, 7, 4, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "form", 19, 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngSubmit", function TeacherEvaluationComponent_div_9_Template_form_ngSubmit_31_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r35);
      const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r34.onSubmitForm());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](33, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](34, TeacherEvaluationComponent_div_9_div_34_Template, 3, 0, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](35, TeacherEvaluationComponent_div_9_div_35_Template, 3, 0, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](36, TeacherEvaluationComponent_div_9_div_36_Template, 6, 0, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](37, TeacherEvaluationComponent_div_9_table_37_Template, 12, 2, "table", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](38, TeacherEvaluationComponent_div_9_div_38_Template, 2, 0, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](39, TeacherEvaluationComponent_div_9_div_39_Template, 5, 0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](40, TeacherEvaluationComponent_div_9_button_40_Template, 2, 0, "button", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.obj == null ? null : ctx_r1.obj.SUB_NM);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.teacher[0] == null ? null : ctx_r1.teacher[0].nm);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.obj == null ? null : ctx_r1.obj.SUB_CODE);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.obj == null ? null : ctx_r1.obj.T_NO);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.obj == null ? null : ctx_r1.obj.SECTION);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.formQues.length > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.info);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.dueDate);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.submitted);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.formQues.length > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.formQues.length > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.formQues.length > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.hideBtn);
  }
}
class TeacherEvaluationComponent {
  constructor(TimetableService, authenticationService, tchrEvalSer, toaster) {
    this.TimetableService = TimetableService;
    this.authenticationService = authenticationService;
    this.tchrEvalSer = tchrEvalSer;
    this.toaster = toaster;
    this.usr = null;
    this.showDetail = false;
    this.hideBtn = true;
    this.submitted = false;
    this.dueDate = false;
    this.info = false;
    this.showComment = true;
    this.usr = this.authenticationService.getUser();
    this.pat = new Array();
    this.formQues = new Array();
    this.sub = '';
    this.obj = '';
    this.teacher = [];
    this.ans = new Array();
  }
  ngOnInit() {
    this.teams = this.TimetableService.getTeam(this.usr?.C_CODE);
    // this.teams = this.TimetableService.getAllteam(this.usr?.C_CODE);
    this.navigateToSingleCourse(this.teams[0]?.SUB_CODE, 0);
  }
  navigateToSingleCourse(sub_code, i) {
    this.info = false;
    this.submitted = false;
    this.dueDate = false;
    this.sub = sub_code;
    this.obj = '';
    this.pat = [];
    this.formQues = [];
    this.val = sub_code;
    this.showDetail = true;
    this.hideBtn = true;
    this.ans = [];
    this.getTeacherName(this.sub, this.usr.C_CODE, this.usr.SE_ID, this.teams[0].T_NO, this.teams[0].SECTION);
    this.obj = this.teams[i];
    this.tchrEvalSer.getEvaluationForm(this.usr.C_CODE, this.usr.SE_ID, this.teams[0].T_NO, this.usr.RN, this.teams[0].SECTION, sub_code, this.usr.YEAR, this.usr.MAJ_ID).subscribe(res => {
      if (res?.msg === 'Submit') {
        this.hideBtn = false;
        this.submitted = true;
        this.info = false;
        this.dueDate = false;
        return;
      }
      if (res?.msg === '2') {
        this.hideBtn = false;
        this.dueDate = true;
        this.submitted = false;
        this.info = false;
        return;
      }
      res[0]?.forEach(e => {
        this.formQues.push(e);
      });
      res[1]?.forEach(e => {
        this.pat.push(e);
      });
      if (this.formQues.length == 0) {
        this.info = true;
        this.submitted = false;
        this.dueDate = false;
        this.hideBtn = false;
        return;
      } else {
        this.info = false;
        return;
      }
    });
  }
  getTeacherName(sc, cc, seid, tNo, sec) {
    this.teacher = [];
    this.tchrEvalSer.getTeacherName(sc, cc, seid, tNo, sec).subscribe(res => {
      res?.forEach(e => {
        this.teacher.push({
          nm: e.NM,
          id: e.FM_ID
        });
      });
    });
  }
  updateSelection(q_id, pd_id) {
    this.formQues[q_id].RESPONSE_ID = pd_id;
    let objIndex = -1;
    objIndex = this.ans.findIndex(obj => obj.question_id == q_id);
    if (objIndex != -1) {
      this.ans[objIndex].response_id = pd_id;
    } else {
      this.ans.push({
        question_id: q_id,
        response_id: pd_id
      });
    }
  }
  onSubmitForm() {
    if (this.ans.length != this.formQues.length) {
      this.toaster.warning('Fill Form Properly');
      return;
    }
    // this.hideBtn=true;
    this.tchrEvalSer.updateEvalFormSelection({
      year: this.usr.YEAR,
      c_code: this.usr.C_CODE,
      se_id: this.usr.SE_ID,
      maj_id: this.usr.MAJ_ID,
      t_no: this.teams[0].T_NO,
      sub_code: this.sub,
      section: this.teams[0].SECTION,
      rn: this.usr.RN,
      frm_id: this.formQues[0].FRM_ID,
      fm_id: this.teacher[0]?.id,
      array: this.ans
    }).subscribe(res => {
      this.commentSubmit();
      // this.formQues=[];
      this.hideBtn = false;
      this.submitted = true;
      this.toaster.success('Form Submit Successfully.');
      this.ans = [];
    });
  }
  commentSubmit() {
    // if(!this.formRef.value.comment) return;
    let param = {
      year: this.usr?.YEAR,
      c_code: this.usr?.C_CODE,
      se_id: this.usr?.SE_ID,
      maj_id: this.usr?.MAJ_ID,
      t_no: this.teams[0]?.T_NO,
      sub_code: this.sub,
      section: this.teams[0]?.SECTION,
      rn: this.usr?.RN,
      frm_id: this.formQues[0]?.FRM_ID,
      fm_id: this.teacher[0]?.id,
      comment: this.formRef.value.comment,
      cur_year: this.formQues[0]?.CUR_YEAR
    };
    this.tchrEvalSer.EV_F_insertEvaluationFormComment(param).subscribe(res => {
      if (res?.affectedRows != 0) {
        this.formQues = [];
      }
    });
  }
  static #_ = this.ɵfac = function TeacherEvaluationComponent_Factory(t) {
    return new (t || TeacherEvaluationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_main_shared_services_Timetable_service__WEBPACK_IMPORTED_MODULE_1__.TimetableService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_auth_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__.AuthenticationService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_teacherEvaluation_Services__WEBPACK_IMPORTED_MODULE_3__.TeacherEvaluationServices), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](ngx_toastr__WEBPACK_IMPORTED_MODULE_5__.ToastrService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: TeacherEvaluationComponent,
    selectors: [["app-teacher-evaluation"]],
    viewQuery: function TeacherEvaluationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.formRef = _t.first);
      }
    },
    decls: 10,
    vars: 4,
    consts: [[1, "row"], [1, "col-sm-12", "mb-2"], [1, "navbar", "navbar-expand-lg", "navbar-light", "shadow", 2, "background-color", "white", "color", "black"], ["type", "button", "data-toggle", "collapse", "data-target", "#navbarSupportedContent", "aria-controls", "navbarSupportedContent", "aria-expanded", "false", "aria-label", "Toggle navigation", 1, "navbar-toggler", "icon-anim-pulse", "btn-block", "btn-gradient-light"], ["src", "../../assets/icons8-menu.svg", "alt", "none"], ["id", "navbarSupportedContent", 1, "collapse", "navbar-collapse"], [1, "navbar-nav", "mr-auto", "custom-hover-nav"], ["class", "nav-item", 4, "ngFor", "ngForOf"], ["class", "card mb-3", 4, "ngIf"], [1, "nav-item"], ["class", "btn btn-light ml-1", "role", "button", "aria-pressed", "true", 3, "click", 4, "ngIf"], ["role", "button", "aria-pressed", "true", 1, "btn", "btn-light", "ml-1", 3, "click"], [1, "card", "mb-3"], [1, "container", "mt-3"], [1, "col-sm-6"], [1, "row", "mt-1"], [1, "col-sm-4"], [1, "row", "ml-2", "mt-2", "mb-0"], ["class", "alert alert-info alert-dismissible", 4, "ngIf"], [3, "ngSubmit"], ["f", "ngForm"], [1, "card-body", "list-group", 2, "min-height", "10rem", "overflow", "hidden", "overflow-x", "scroll"], ["class", "alert alert-primary", "role", "alert", 4, "ngIf"], ["class", "alert alert-warning", "role", "alert", 4, "ngIf"], ["class", "alert alert-success", "role", "alert", 4, "ngIf"], ["class", "mb-0 table table-bordered", 4, "ngIf"], ["class", "card-header", 4, "ngIf"], ["class", "row my-3", 4, "ngIf"], ["class", "btn btn-outline-primary col-lg-6 col-md-8 col-sm-12 mt-2", "style", "display:flex; margin: auto; text-align: center; justify-content:center", "type", "submit", 4, "ngIf"], [1, "alert", "alert-info", "alert-dismissible"], ["href", "#", "data-dismiss", "alert", "aria-label", "close", 1, "close"], ["role", "alert", 1, "alert", "alert-primary"], [1, "fontSizeOfAlerts"], ["role", "alert", 1, "alert", "alert-warning"], ["role", "alert", 1, "alert", "alert-success"], [1, "alert-heading"], [1, "mb-0", "table", "table-bordered"], [1, "d-flex", "justify-content-around", "w-100"], [4, "ngFor", "ngForOf"], [1, "sectionHead", "fontSection", 3, "ngStyle"], ["section", ""], ["style", "padding: 2px; cursor: pointer;", 4, "ngFor", "ngForOf"], [2, "padding", "2px", "cursor", "pointer"], [1, "section", 3, "ngClass", "click"], [1, "card-header"], [1, "row", "my-3"], [1, "col-lg-12", "col-md-12", "col-sm-12"], ["type", "text", "placeholder", "Enter Your Comment", "name", "comment", "id", "comment", "ngModel", "", "rows", "2", 1, "form-control", "shadow-sm", "mt-1"], ["comment", ""], ["type", "submit", 1, "btn", "btn-outline-primary", "col-lg-6", "col-md-8", "col-sm-12", "mt-2", 2, "display", "flex", "margin", "auto", "text-align", "center", "justify-content", "center"]],
    template: function TeacherEvaluationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "nav", 2)(3, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 5)(6, "ul", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, TeacherEvaluationComponent_li_7_Template, 2, 1, "li", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, TeacherEvaluationComponent_div_9_Template, 41, 13, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.teams);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.showDetail);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgForm, _angular_common__WEBPACK_IMPORTED_MODULE_6__.DatePipe],
    styles: ["tbody.custom-hover[_ngcontent-%COMP%]    > tr[_ngcontent-%COMP%]:hover {\n    background-color: #E0F3FF;\n    transition: .2s;\n  }\n  div.custom-height[_ngcontent-%COMP%]{\n    height: 20rem;\n  }\n  .spinner-border[_ngcontent-%COMP%]{\n    color: blue !important;\n  }\n  \n  .clicked[_ngcontent-%COMP%]{\n    background:#d3d3d3;\n  }\n    .section[_ngcontent-%COMP%]{\n      display: flex;\n      flex: 1;\n      justify-content: center;\n      align-items: center;\n      height: 2rem;\n      border-radius: 5rem;\n    }\n    .fontSection[_ngcontent-%COMP%]{\n      color: white;\n    }\n    .section[_ngcontent-%COMP%]:hover {\n      border: 1px solid rgba(255, 58, 58, 0.3);\n    }\n    .sectionHead[_ngcontent-%COMP%]{\n      display: flex;\n      flex: 1;\n      justify-content: center;\n      align-items: center;\n      height: 2rem;\n      border-radius: 5rem;\n      width: -moz-fit-content;\n      width: fit-content;\n      height:-moz-fit-content;\n      height:fit-content;\n      padding: 8px;\n    }\n\n    .fontSizeOfAlerts[_ngcontent-%COMP%]{\n      font-size: 20px;\n    }\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC90ZWFjaGVyLWV2YWx1YXRpb24vdGVhY2hlci1ldmFsdWF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSx5QkFBeUI7SUFDekIsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsYUFBYTtFQUNmO0VBQ0E7SUFDRSxzQkFBc0I7RUFDeEI7RUFDQTs7Ozs7Ozs7Ozs7Ozs7O0tBZUc7RUFDSDtJQUNFLGtCQUFrQjtFQUNwQjtJQUNFO01BQ0UsYUFBYTtNQUNiLE9BQU87TUFDUCx1QkFBdUI7TUFDdkIsbUJBQW1CO01BQ25CLFlBQVk7TUFDWixtQkFBbUI7SUFDckI7SUFDQTtNQUNFLFlBQVk7SUFDZDtJQUNBO01BQ0Usd0NBQXdDO0lBQzFDO0lBQ0E7TUFDRSxhQUFhO01BQ2IsT0FBTztNQUNQLHVCQUF1QjtNQUN2QixtQkFBbUI7TUFDbkIsWUFBWTtNQUNaLG1CQUFtQjtNQUNuQix1QkFBa0I7TUFBbEIsa0JBQWtCO01BQ2xCLHVCQUFrQjtNQUFsQixrQkFBa0I7TUFDbEIsWUFBWTtJQUNkOztJQUVBO01BQ0UsZUFBZTtJQUNqQiIsInNvdXJjZXNDb250ZW50IjpbInRib2R5LmN1c3RvbS1ob3ZlciA+IHRyOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTBGM0ZGO1xuICAgIHRyYW5zaXRpb246IC4ycztcbiAgfVxuICBkaXYuY3VzdG9tLWhlaWdodHtcbiAgICBoZWlnaHQ6IDIwcmVtO1xuICB9XG4gIC5zcGlubmVyLWJvcmRlcntcbiAgICBjb2xvcjogYmx1ZSAhaW1wb3J0YW50O1xuICB9XG4gIC8qIC50ZWFte1xuICAgIHRyYW5zaXRpb246IDAuNDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTllY2VmO1xuICAgIGJvcmRlci1yYWRpdXM6IC43cmVtO1xuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDAuN3JlbTtcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMC43cmVtO1xuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwLjdyZW07XG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMC43cmVtO1xuICAgIC13ZWJraXQtdHJhbnNpdGlvbjogMC40O1xuICAgIC1tb3otdHJhbnNpdGlvbjogMC40O1xuICAgIC1tcy10cmFuc2l0aW9uOiAwLjQ7XG4gICAgLW8tdHJhbnNpdGlvbjogMC40O1xuICB9XG4gIC50ZWFtIDpob3ZlcntcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2M0YmRiZDtcbiAgfSAqL1xuICAuY2xpY2tlZHtcbiAgICBiYWNrZ3JvdW5kOiNkM2QzZDM7XG4gIH1cbiAgICAuc2VjdGlvbntcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBmbGV4OiAxO1xuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgaGVpZ2h0OiAycmVtO1xuICAgICAgYm9yZGVyLXJhZGl1czogNXJlbTtcbiAgICB9XG4gICAgLmZvbnRTZWN0aW9ue1xuICAgICAgY29sb3I6IHdoaXRlO1xuICAgIH1cbiAgICAuc2VjdGlvbjpob3ZlciB7XG4gICAgICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDI1NSwgNTgsIDU4LCAwLjMpO1xuICAgIH1cbiAgICAuc2VjdGlvbkhlYWR7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgZmxleDogMTtcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgIGhlaWdodDogMnJlbTtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDVyZW07XG4gICAgICB3aWR0aDogZml0LWNvbnRlbnQ7XG4gICAgICBoZWlnaHQ6Zml0LWNvbnRlbnQ7XG4gICAgICBwYWRkaW5nOiA4cHg7XG4gICAgfVxuXG4gICAgLmZvbnRTaXplT2ZBbGVydHN7XG4gICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgfSJdLCJzb3VyY2VSb290IjoiIn0= */", "ul.navbar-nav.custom-hover-nav[_ngcontent-%COMP%] > li[_ngcontent-%COMP%] {\n              border-radius: 10px 10px 10px 10px;\n            }\n\n            @media (min-width: 968px) {\n              ul.navbar-nav.custom-hover-nav[_ngcontent-%COMP%] > li[_ngcontent-%COMP%]:hover {\n                transform: scale(1.05);\n                background-color: #E0F3FF;\n                transition: .2s;\n              }\n            }\n\n            @media (max-width: 968px) {\n              ul.navbar-nav.custom-hover-nav[_ngcontent-%COMP%] > li[_ngcontent-%COMP%] {\n                padding-left: 5px;\n                border-radius: 10px 10px 10px 10px;\n              }\n\n              ul.navbar-nav.custom-hover-nav[_ngcontent-%COMP%] > li[_ngcontent-%COMP%]:hover {\n                transform: scale(1.01);\n                background-color: #E0F3FF;\n                transition: .2s;\n              }\n\n              ul.navbar-nav.custom-hover-nav[_ngcontent-%COMP%] > li.active[_ngcontent-%COMP%] {\n                background-color: #E0F3FF;\n              }\n            }"],
    data: {
      animation: [(0,src_app_transitions__WEBPACK_IMPORTED_MODULE_0__.SlideInFromLeft)()]
    }
  });
}

/***/ }),

/***/ 24082:
/*!**************************************************************************!*\
  !*** ./src/app/student/teacher-evaluation/teacherEvaluation-Services.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeacherEvaluationServices": () => (/* binding */ TeacherEvaluationServices)
/* harmony export */ });
/* harmony import */ var _axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../axios */ 46491);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 58987);



class TeacherEvaluationServices {
  constructor(http) {
    this.http = http;
  }
  getEvaluationForm(c_code, se_id, t_no, rn, section, subCode, year, maj_id) {
    return this.http.get(`${_axios__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/forms/getEvaluationForm/${c_code}/${se_id}/${t_no}/${rn}/${section}/${subCode}/${year}/${maj_id}`);
  }
  updateEvalFormSelection(params) {
    return this.http.post(`${_axios__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/forms/updateEvalFormSelection`, params);
  }
  getTeacherName(sub_code, c_code, se_id, t_no, section) {
    return this.http.get(`${_axios__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/forms/getTeacherName/${sub_code}/${c_code}/${se_id}/${t_no}/${section}`);
  }
  EV_F_insertEvaluationFormComment(params) {
    return this.http.post(`${_axios__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/forms/EV_F_insertEvaluationFormComment`, params);
  }
  static #_ = this.ɵfac = function TeacherEvaluationServices_Factory(t) {
    return new (t || TeacherEvaluationServices)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: TeacherEvaluationServices,
    factory: TeacherEvaluationServices.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 63014:
/*!************************************************************!*\
  !*** ./src/app/student/time-table/time-table.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeTableComponent": () => (/* binding */ TimeTableComponent)
/* harmony export */ });
/* harmony import */ var _home_ali_latest_CMS_frontend_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var _transitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../transitions */ 71629);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jspdf */ 84177);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jspdf-autotable */ 43015);
/* harmony import */ var jspdf_autotable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jspdf_autotable__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ 56908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _main_shared_services_Timetable_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../main/shared/services/Timetable.service */ 3651);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-toastr */ 94817);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var src_app_auth_services__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/auth/_services */ 29792);
/* harmony import */ var src_app_main_shared_services_Major_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/main/shared/services/Major.service */ 3781);
/* harmony import */ var _student_services_student_information_student_information_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../student-services/student-information/student-information.service */ 83271);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/platform-browser */ 34497);















const _c0 = ["convert"];
function TimeTableComponent_button_35_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "button", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function TimeTableComponent_button_35_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r3.CreatePdf());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](1, "i", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](2, " Download Pdf ");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
}
function TimeTableComponent_div_36_hr_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "hr", 15);
  }
}
function TimeTableComponent_div_36_div_2_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const lecture_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"]("", lecture_r8.DAY, " ");
  }
}
function TimeTableComponent_div_36_div_2_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 24)(1, "div", 25)(2, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](4, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](7, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](9, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](10, "div", 28)(11, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](13, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](15, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    const i_r9 = ctx_r13.index;
    const lecture_r8 = ctx_r13.$implicit;
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵclassMap"](i_r9 !== 0 ? "mt-2" : " mt-3");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind2"](4, 9, "1970-01-01 " + lecture_r8.START_TIME, "h:mm a"));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind2"](7, 12, "1970-01-01 " + lecture_r8.END_TIME, "h:mm a"));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleProp"]("background-color", ctx_r11.getColorForSubject(lecture_r8.SUB_CODE));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](lecture_r8.SUB_NM);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](lecture_r8.ROOM_NM);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", lecture_r8.FM_NAME, " ");
  }
}
function TimeTableComponent_div_36_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](1, TimeTableComponent_div_36_div_2_div_1_Template, 2, 1, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](2, TimeTableComponent_div_36_div_2_div_2_Template, 17, 15, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const i_r9 = ctx.index;
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", i_r9 === 0 && ctx_r7.isMobile);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r7.isMobile);
  }
}
function TimeTableComponent_div_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](1, TimeTableComponent_div_36_hr_1_Template, 1, 0, "hr", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](2, TimeTableComponent_div_36_div_2_Template, 3, 2, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const day_r5 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r1.isMobile);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", day_r5);
  }
}
function TimeTableComponent_div_37_hr_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "hr", 15);
  }
}
function TimeTableComponent_div_37_div_2_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 34)(1, "h5", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    const i_r18 = ctx_r21.index;
    const lecture_r17 = ctx_r21.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](i_r18 == 0 ? lecture_r17.DAY : "");
  }
}
function TimeTableComponent_div_37_div_2_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 36)(1, "div", 25)(2, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](4, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](7, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](9, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](10, "div", 28)(11, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](13, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](15, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    const i_r18 = ctx_r22.index;
    const lecture_r17 = ctx_r22.$implicit;
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵclassMap"](i_r18 !== 0 ? "mt-2" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind2"](4, 9, "1970-01-01 " + lecture_r17.START_TIME, "h:mm a"));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind2"](7, 12, "1970-01-01 " + lecture_r17.END_TIME, "h:mm a"));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleProp"]("background-color", ctx_r20.getColorForSubject(lecture_r17.SUB_CODE));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](lecture_r17.SUB_NM);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](lecture_r17.ROOM_NM);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", lecture_r17.FM_NAME, " ");
  }
}
function TimeTableComponent_div_37_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](1, TimeTableComponent_div_37_div_2_div_1_Template, 3, 1, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](2, TimeTableComponent_div_37_div_2_div_2_Template, 17, 15, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", !ctx_r16.isMobile);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", !ctx_r16.isMobile);
  }
}
function TimeTableComponent_div_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](1, TimeTableComponent_div_37_hr_1_Template, 1, 0, "hr", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](2, TimeTableComponent_div_37_div_2_Template, 3, 2, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const day_r14 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", !ctx_r2.isMobile);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", day_r14);
  }
}
class TimeTableComponent {
  constructor(TimetableService, toastr, datePipe, authenticationService, majserve, studentService, router, route, sanitizer) {
    this.TimetableService = TimetableService;
    this.toastr = toastr;
    this.datePipe = datePipe;
    this.authenticationService = authenticationService;
    this.majserve = majserve;
    this.studentService = studentService;
    this.router = router;
    this.route = route;
    this.sanitizer = sanitizer;
    this.isMobile = false;
    this.uniqueSubjects = [];
    // Mapping of subjects to colors
    this.subjectColorMap = {};
    this.imageUrl = null;
    this.stdt_rol = "";
    this.weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    this.calendarDates = [];
    this.calendar = [];
    this.btnHide = false;
    this.usr = this.authenticationService.getUser();
    this.days = new Array();
  }
  ngOnInit() {
    // if (window.innerWidth <= 575) {
    //   this.isMobile = true; // Set to true if screen width is less than or equal to 575 pixels (adjust the value as needed)
    // }
    this.StudentDetail_tm();
    // this.getCalendar();
    // this.AssignmentDetail();
    this.getPicture();
    this.timetable = this.TimetableService.getTimetable();
    this.rolno = this.usr.ROLNO;
    this.stdt_rol = this.rolno;
    this.majserve.std_PDF(this.rolno).subscribe(res => {
      this.usr = {
        ...this.usr,
        F_NM: res[0].f_nm,
        SE_NM: res[0].SE_NM,
        M_ID: res[0].M_ID,
        T_NO: res[0].T_NO,
        SUB_COMB: res[0].SUB_COMB
      };
      this.cls = this.usr.M_ID;
      this.se = this.usr.SE_NM;
      this.sub_comb = this.usr.SUB_COMB;
      this.nm = this.usr.NM;
      this.f_nm = this.usr.F_NM;
    });
    this.sortByStartTimeTable();
    this.getDaysFromTM();
    this.extractUniqueSubjects();
  }
  onWindowResize(event) {
    if (window.innerWidth <= 575) {
      this.isMobile = true; // Set to true if screen width is less than or equal to 575 pixels (adjust the value as needed)
    } else {
      this.isMobile = false;
    }
  }
  StudentDetail_tm() {
    this.studentService.S_getStdtDetail_tm(this.usr.ROLNO).subscribe(res => {
      this.stdentdetails = res[0][0];
    });
  }
  AssignmentDetail() {
    this.studentService.S_StdtAssignmentDetail(this.usr.ROLNO).subscribe(res => {});
  }
  getPicture() {
    // this.stdt_picture = "";
    // this.studentService.S_getStdtPicture(this.usr.C_CODE, this.usr.SE_ID, this.usr.MAJ_ID, this.usr.ROLNO).subscribe((res: any) => {
    //  this.stdt_picture = res.url;
    // });
    this.studentService.S_getStdtPicture(this.usr.C_CODE, this.usr.SE_ID, this.usr.MAJ_ID, this.usr.ROLNO).subscribe(response => {
      const objectURL = URL.createObjectURL(response);
      this.imageUrl = this.sanitizer.bypassSecurityTrustUrl(objectURL);
      console.log("Image", this.imageUrl);
    }, error => {
      console.error('Error retrieving student picture', error);
    });
  }
  getCalendar() {
    const today = new Date();
    this.currentMonthName = this.getMonthName(today.getMonth());
    this.currentYear = today.getFullYear();
    // Create a new date for the first day of the current month
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    // Calculate the day of the week for the first day of the month (0 = Sunday, 1 = Monday, etc.)
    const startDayOfWeek = firstDay.getDay();
    // Initialize the calendar array
    this.calendar = [];
    // Initialize day counter and the week array
    let dayCounter = 1;
    let currentWeek = [];
    // Fill in leading empty slots in the calendar before the first day of the month
    for (let i = 0; i < startDayOfWeek; i++) {
      currentWeek.push({
        date: null,
        isCurrentMonth: false
      });
    }
    // Fill in the days of the current month
    while (dayCounter <= this.getDaysInMonth(today.getMonth(), today.getFullYear())) {
      currentWeek.push({
        date: dayCounter,
        isCurrentMonth: true
      });
      // If we've reached the end of the week (Saturday), push the currentWeek to the calendar
      if (currentWeek.length === 7) {
        this.calendar.push([...currentWeek]);
        currentWeek = [];
      }
      dayCounter++;
    }
    // Fill in any remaining empty slots in the last week
    while (currentWeek.length < 7) {
      currentWeek.push({
        date: null,
        isCurrentMonth: false
      });
    }
    // Push the last week to the calendar
    this.calendar.push([...currentWeek]);
  }
  getMonthName(month) {
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return monthNames[month];
  }
  getDaysInMonth(month, year) {
    return new Date(year, month + 1, 0).getDate();
  }
  OnStudentInformationClicked() {
    this.router.navigate(['../studentInformation'], {
      relativeTo: this.route
    });
    // this.router.navigateByUrl('/studentInformation');
  }

  extractUniqueSubjects() {
    if (this.timetable) {
      this.timetable.forEach(day => {
        day.forEach(lecture => {
          if (!this.uniqueSubjects.includes(lecture.SUB_CODE)) {
            this.uniqueSubjects.push(lecture.SUB_CODE);
          }
        });
      });
      this.ColortoEachSub();
    }
  }
  getColorByIndex(index) {
    const colors = ['red', 'blue', 'green', 'orange', 'purple', 'pink', 'brown', 'teal', 'gray', 'magenta', 'cyan', 'lime', 'indigo'];
    return colors[index % colors.length]; // Cycle through the colors
  }

  ColortoEachSub() {
    this.uniqueSubjects.forEach((subject, index) => {
      // Assign a color based on the index (you can customize this logic)
      const color = this.getColorByIndex(index);
      this.subjectColorMap[subject] = color;
    });
  }
  getColorForSubject(subject) {
    // Use the subjectColorMap to get the color for the subject
    return this.subjectColorMap[subject] || 'gray'; // Default to gray if no color is found
  }

  sortByStartTimeTable() {
    var _this = this;
    return (0,_home_ali_latest_CMS_frontend_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      for (var i = 0; i < _this.timetable.length; i++) {
        _this.timetable[i]?.sort((a, b) => a.START_TIME < b.START_TIME ? -1 : a.START_TIME > b.START_TIME ? 1 : 0);
      }
    })();
  }
  getDaysFromTM() {
    for (var i = 0; i < this.timetable.length; i++) {
      var d = '';
      for (var j = 0; j < this.timetable[i].length; j++) {
        d = this.timetable[i][j]?.DAY.toString();
        if (!this.days.includes(d)) {
          this.days.push(d);
        }
        this.section = this.timetable[i][j]?.SECTION;
        this.semester = this.timetable[i][j]?.T_NO;
      }
    }
    if (this.days.length != 0) {
      this.btnHide = true;
    }
  }
  initCap(words) {
    var separateWord = words.toLowerCase().split(' ');
    for (var i = 0; i < separateWord.length; i++) {
      separateWord[i] = separateWord[i].charAt(0).toUpperCase() + separateWord[i].substring(1);
    }
    return separateWord.join(' ');
  }
  CreatePdf() {
    var body = [];
    var header = [];
    if (this.days.length == 0) {
      this.toastr.warning('Time Table Not Exist.');
      return;
    }
    var pa = this.usr.ROLNO.substr(5, 1);
    var SEMYE;
    if (parseInt(pa) === 1) {
      SEMYE = 'Year';
    } else {
      SEMYE = 'Semester';
    }
    this.toastr.info("Downloading TimeTable");
    var image = new Image();
    image.src = '../../../assets/images/logo3.png';
    const doc = new jspdf__WEBPACK_IMPORTED_MODULE_2__.jsPDF('p', 'mm', [297, 210]);
    doc.addImage(image, 15, 1, 20, 20);
    var exportDate = this.datePipe.transform(new Date(), 'MMM d,y');
    doc.setFontSize(7);
    doc.text(`${exportDate}`, 18, 24);
    doc.setFontSize(13);
    doc.setFont('Arial', 'bold');
    doc.text("GC UNIVERSITY LAHORE", 40, 8);
    doc.text("Time Table", 40, 14);
    doc.setFontSize(11);
    let clas = this.cls;
    let sess = this.se;
    let nam = this.initCap(this.nm);
    let fnam = this.initCap(this.f_nm);
    let rol = this.rolno;
    let t = this.semester;
    let SUB_COMB = this.sub_comb;
    doc.text(clas, 40, 19);
    doc.setFont('Arial', 'normal');
    doc.text('Session: ' + sess, 40, 24);
    doc.text(SEMYE + " : " + t, 80, 24);
    doc.text("Subject Combination: " + SUB_COMB, 40, 29);
    doc.setFont('Arial', 'bold');
    doc.setFontSize(10);
    doc.text("Roll No: " + rol, 135, 8);
    doc.text("Name: " + nam, 135, 13);
    doc.text("Father Name: " + fnam, 135, 18);
    var y_val = 0;
    for (var i = 0; i < this.days.length; i++) {
      //DAYS
      header.push([{
        content: this.days[i],
        colSpan: 7,
        styles: {
          halign: 'left',
          textColor: [0, 0, 0],
          fontSize: 8,
          lineColor: [0, 0, 0],
          fillColor: [256, 256, 256]
        }
      }], ['Time', 'Block', 'Room', 'SubCode', 'Subject Name', 'Teacher Name', 'Sec']);
      y_val = this.timetable[i].length + 2;
      for (var j = 0; j < this.timetable.length; j++) {
        //MAJOR ARRAY
        for (var k = 0; k < this.timetable[j].length; k++) {
          //INNER ARRAY
          if (this.days[i] == this.timetable[j][k]?.DAY) {
            var obj = this.timetable[j][k];
            var tt = moment__WEBPACK_IMPORTED_MODULE_4__(obj?.START_TIME, 'h:mmA').format('hh:mmA') + '-' + moment__WEBPACK_IMPORTED_MODULE_4__(obj?.END_TIME, 'h:mmA').format('hh:mmA');
            body.push([tt, obj?.BLK_NM, obj?.ROOM_NM, obj?.SUB_CODE, obj?.SUB_NM, obj?.FM_NAME, obj?.SECTION]);
          }
        }
      }
      jspdf_autotable__WEBPACK_IMPORTED_MODULE_3___default()(doc, {
        styles: {
          fontSize: 6,
          minCellHeight: 4,
          cellPadding: 1,
          textColor: [0, 0, 0]
        },
        columnStyles: {
          // 0: { fontStyle: 'bold', fontSize: 9 }
        },
        theme: 'grid',
        margin: {
          top: 30,
          bottom: 0
        },
        head: header,
        body: body
      });
      body = [];
      header = [];
    }
    var y_Axis = 265;
    // var y_Axis = (y_val * 9.5) + 35;
    var x_axis = 14;
    doc.text("Note :", x_axis, y_Axis);
    doc.setFontSize(8).setFont('Times-Roman', 'Bold');
    doc.setTextColor(255, 0, 0);
    doc.text("1.Dars-e-Quran/Tutorial Group Meeting on Friday from 10:30 am to 11:00 am. There will be no Theory/Practical Class on Friday from 10:30 am to 11:10 am", x_axis, y_Axis + 4);
    doc.setTextColor(0, 0, 0);
    doc.text("2.The Duration of each class can be different for different subject depending upon their credit hours.", x_axis, y_Axis + 8);
    doc.text("3.Consult Concerned Chairperson if Teacher is not in class room ", x_axis, y_Axis + 12);
    doc.text("4.In case any query, contact Prof. Inam ul Haq(Incharge General Time Table) in Statistics Department PGB-313 from 09:00 am to 10:30 am.", x_axis, y_Axis + 16);
    doc.text("5.Always keep a photocopy of time table in your possession during academic year, as no duplicate time table will be issued.", x_axis, y_Axis + 20);
    doc.text("* University reserves the right to amend Time Table at any time according to availability of faculty,space and combination.", x_axis, y_Axis + 24);
    doc.setFontSize(7).setFont('Times-Roman');
    doc.setFont('Arial', 'normal');
    doc.text("By:Directorate of Information Technology", 15, 295);
    doc.text('Note: Errors and Omissions are Excepted', 155, 295);
    var a = this.toastr;
    setTimeout(function () {
      a.success("Downloaded");
    }, 1000);
    doc.save('Time Table ' + this.rolno);
  }
  static #_ = this.ɵfac = function TimeTableComponent_Factory(t) {
    return new (t || TimeTableComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_main_shared_services_Timetable_service__WEBPACK_IMPORTED_MODULE_5__.TimetableService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](ngx_toastr__WEBPACK_IMPORTED_MODULE_10__.ToastrService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_11__.DatePipe), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_auth_services__WEBPACK_IMPORTED_MODULE_6__.AuthenticationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_main_shared_services_Major_service__WEBPACK_IMPORTED_MODULE_7__.MajorService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_student_services_student_information_student_information_service__WEBPACK_IMPORTED_MODULE_8__.StudentInformationService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_13__.DomSanitizer));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
    type: TimeTableComponent,
    selectors: [["app-time-table"]],
    viewQuery: function TimeTableComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵloadQuery"]()) && (ctx.data = _t.first);
      }
    },
    hostBindings: function TimeTableComponent_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("resize", function TimeTableComponent_resize_HostBindingHandler($event) {
          return ctx.onWindowResize($event);
        }, false, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresolveWindow"]);
      }
    },
    decls: 38,
    vars: 9,
    consts: [[1, "main-card", "mb-3", "card"], [1, "col-12", "mx-0", "px-0"], [1, "col-12"], [1, "container-fluid", "col-12", "mx-0", "px-0", "bg_pic", 2, "background-image", "url('../../../assets/tm_picture.png')", "background-size", "100% auto", "background-position", "center", "height", "130px", "background-repeat", "no-repeat"], ["alt", "Student Picture", 1, "stdt_img", "ml-4", "mt-5", 2, "width", "100%", "height", "auto", "max-width", "135px", "max-height", "130px", "margin-top", "30px", "border-radius", "4.5rem", 3, "src"], [1, "row", "d-flex", "mt-5", "ml-2"], [1, "col-lg-3", "col-md-3", "col-sm-3", "boder_style"], [1, "col-lg-2", "col-md-2", "col-sm-2", "boder_style"], [1, "col-lg-2", "col-md-2", "col-sm-2", 2, "text-align", "center"], [1, "col-lg-2", "col-md-2", "col-sm-2", "mt-2", "d-flex", "justify-content-center"], [1, "custom-link", 3, "click"], [1, "metismenu-icon", "fa", "fa-user", "fa-lg"], [1, "text-lg"], [1, "row", "mt-5"], [1, "col-lg-12", "col-md-12", "col-sm-12", "mt-5"], [1, "ml-3"], ["class", "btn btn-sm btn-danger ri8", "type", "button", 3, "click", 4, "ngIf"], [4, "ngFor", "ngForOf"], ["type", "button", 1, "btn", "btn-sm", "btn-danger", "ri8", 3, "click"], ["for", "", 1, "fa", "fa-file-pdf-o"], ["class", "ml-3", 4, "ngIf"], ["class", "col-12 d-md-none", "style", "font-size: 35px; display: flex; justify-content: center;", 4, "ngIf"], ["class", "col-12 d-flex tm_detail", 3, "class", 4, "ngIf"], [1, "col-12", "d-md-none", 2, "font-size", "35px", "display", "flex", "justify-content", "center"], [1, "col-12", "d-flex", "tm_detail"], [1, "col-3", 2, "border-right", "3px solid maroon"], [1, "col-1"], [1, "circle"], [1, "col-5"], [1, "col-3", "text-right"], ["class", "d-flex", 4, "ngFor", "ngForOf"], [1, "d-flex"], ["scope", "row", "class", "col-2", 4, "ngIf"], ["class", "col-10 d-flex tm_detail", 3, "class", 4, "ngIf"], ["scope", "row", 1, "col-2"], [1, "day_heading"], [1, "col-10", "d-flex", "tm_detail"]],
    template: function TimeTableComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](4, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "div", 5)(6, "div", 6)(7, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](10, "Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](11, "div", 7)(12, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](14, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](15, "Roll #");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](16, "div", 6)(17, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](19, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](20, "Major");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](21, "div", 8)(22, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](23);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](24, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](25, "Semester");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](26, "div", 9)(27, "a", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function TimeTableComponent_Template_a_click_27_listener() {
          return ctx.OnStudentInformationClicked();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](28, "i", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](29, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](30, "View Profile");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](31, "div", 13)(32, "div", 14)(33, "h4", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](34, "Class TimeLine ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](35, TimeTableComponent_button_35_Template, 3, 0, "button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](36, TimeTableComponent_div_36_Template, 3, 2, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](37, TimeTableComponent_div_37_Template, 3, 2, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("@SlideInFromLeft", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("src", ctx.imageUrl, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](ctx.stdentdetails == null ? null : ctx.stdentdetails.nm);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](ctx.stdt_rol);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](ctx.stdentdetails == null ? null : ctx.stdentdetails.class_nm);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](ctx.stdentdetails == null ? null : ctx.stdentdetails.t_no);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.btnHide);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", ctx.timetable);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", ctx.timetable);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_11__.DatePipe],
    styles: [".fix-size[_ngcontent-%COMP%] {\n  width: 7rem;\n  height: 7rem;\n}\n\n.tm_detail[_ngcontent-%COMP%]{\n  font-size: large;\n}\n\n.boder_style[_ngcontent-%COMP%]{\n\n  border-right: 3px solid blue;\n  text-align: center;\n}\n\nth[_ngcontent-%COMP%] {\n  background-color: #e9ecef;\n}\n\ntable.table-bordered[_ngcontent-%COMP%] {\n  font-size: .8rem;\n}\n\ntable.table-bordered[_ngcontent-%COMP%]    > tbody[_ngcontent-%COMP%]    > tr[_ngcontent-%COMP%]    > td[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%] {\n  background-color: #dadada;\n  border-left: 5px solid black;\n  border-radius: 5px 5px 5px 5px\n}\n\ntable.table-bordered[_ngcontent-%COMP%]    > tbody[_ngcontent-%COMP%]    > tr[_ngcontent-%COMP%]{\n  padding: 5px;\n  max-width: 80px;\n  min-width: 80px;\n}\n.ri8[_ngcontent-%COMP%]{\n  float: right;\n  margin-right: 10px;\n}\n\n\n\n@media (max-width: 768px) {\n  table.table-bordered[_ngcontent-%COMP%] {\n    font-size: .7rem;\n  }\n  .day_heading[_ngcontent-%COMP%]{\n    font-size: 15px !important;\n  }\n\n  .tm_detail[_ngcontent-%COMP%]{\n    font-size: small;\n  }\n  .bg_pic[_ngcontent-%COMP%]{\n    background-size: 100vh !important;\n  }\n}\n\n@media (max-width: 575px) {\n  .boder_style[_ngcontent-%COMP%]{\n\n    border: none !important;\n  }\n\n  .custom-link[_ngcontent-%COMP%] {\n    margin-bottom: 0px !important;\n  }\n\n  .stdt_img[_ngcontent-%COMP%] {\n    margin-left: 30% !important;\n    border-radius: 50%;\n    max-width: 100%;\n    margin: 0 auto;\n    margin-top: 50px;\n  }  \n}\n\n.time-table-column[_ngcontent-%COMP%]{\n  padding: 0 0 0 10px;\n  text-align: left;\n  \n}\n\n.max-width-height[_ngcontent-%COMP%] {\n  max-width: 165px;\n  max-height: flex;\n}\n\n.circle[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: 12px;\n  height: 12px;\n  border-radius: 50%;\n  margin-right: 5px;\n  vertical-align: middle;\n}\n\n\n.custom-link[_ngcontent-%COMP%] {\n  text-decoration: none; \n  color: #333; \n  display: flex; \n  align-items: center; \n  margin-bottom: 17px;\n}\n\n.custom-link[_ngcontent-%COMP%]:hover {\n  cursor: pointer;\n  text-decoration: none; \n  color: blue; \n}\n\n.fa-lg[_ngcontent-%COMP%] {\n  font-size: 24px; \n}\n\n.text-lg[_ngcontent-%COMP%] {\n  font-size: 18px; \n  margin-left: 6px; \n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3R1ZGVudC90aW1lLXRhYmxlL3RpbWUtdGFibGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0FBQ2Q7O0FBRUE7RUFDRSxnQkFBZ0I7QUFDbEI7O0FBRUE7O0VBRUUsNEJBQTRCO0VBQzVCLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLHlCQUF5QjtBQUMzQjs7QUFFQTtFQUNFLGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6Qiw0QkFBNEI7RUFDNUI7QUFDRjs7QUFFQTtFQUNFLFlBQVk7RUFDWixlQUFlO0VBQ2YsZUFBZTtBQUNqQjtBQUNBO0VBQ0UsWUFBWTtFQUNaLGtCQUFrQjtBQUNwQjs7OztBQUlBO0VBQ0U7SUFDRSxnQkFBZ0I7RUFDbEI7RUFDQTtJQUNFLDBCQUEwQjtFQUM1Qjs7RUFFQTtJQUNFLGdCQUFnQjtFQUNsQjtFQUNBO0lBQ0UsaUNBQWlDO0VBQ25DO0FBQ0Y7O0FBRUE7RUFDRTs7SUFFRSx1QkFBdUI7RUFDekI7O0VBRUE7SUFDRSw2QkFBNkI7RUFDL0I7O0VBRUE7SUFDRSwyQkFBMkI7SUFDM0Isa0JBQWtCO0lBQ2xCLGVBQWU7SUFDZixjQUFjO0lBQ2QsZ0JBQWdCO0VBQ2xCO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtBQUN0Qjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxxQkFBcUI7RUFDckIsV0FBVztFQUNYLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLHNCQUFzQjtBQUN4Qjs7QUFFQSxvQ0FBb0M7QUFDcEM7RUFDRSxxQkFBcUIsRUFBRSxxQkFBcUI7RUFDNUMsV0FBVyxFQUFFLHNCQUFzQjtFQUNuQyxhQUFhLEVBQUUsZ0RBQWdEO0VBQy9ELG1CQUFtQixFQUFFLDBDQUEwQztFQUMvRCxtQkFBbUI7QUFDckI7O0FBRUE7RUFDRSxlQUFlO0VBQ2YscUJBQXFCLEVBQUUsOEJBQThCO0VBQ3JELFdBQVcsRUFBRSwrQkFBK0I7QUFDOUM7O0FBRUE7RUFDRSxlQUFlLEVBQUUsbUNBQW1DO0FBQ3REOztBQUVBO0VBQ0UsZUFBZSxFQUFFLG1DQUFtQztFQUNwRCxnQkFBZ0IsRUFBRSxzQ0FBc0M7QUFDMUQiLCJzb3VyY2VzQ29udGVudCI6WyIuZml4LXNpemUge1xuICB3aWR0aDogN3JlbTtcbiAgaGVpZ2h0OiA3cmVtO1xufVxuXG4udG1fZGV0YWlse1xuICBmb250LXNpemU6IGxhcmdlO1xufVxuXG4uYm9kZXJfc3R5bGV7XG5cbiAgYm9yZGVyLXJpZ2h0OiAzcHggc29saWQgYmx1ZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG50aCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlOWVjZWY7XG59XG5cbnRhYmxlLnRhYmxlLWJvcmRlcmVkIHtcbiAgZm9udC1zaXplOiAuOHJlbTtcbn1cblxudGFibGUudGFibGUtYm9yZGVyZWQgPiB0Ym9keSA+IHRyID4gdGQgPiBkaXYge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGFkYWRhO1xuICBib3JkZXItbGVmdDogNXB4IHNvbGlkIGJsYWNrO1xuICBib3JkZXItcmFkaXVzOiA1cHggNXB4IDVweCA1cHhcbn1cblxudGFibGUudGFibGUtYm9yZGVyZWQgPiB0Ym9keSA+IHRye1xuICBwYWRkaW5nOiA1cHg7XG4gIG1heC13aWR0aDogODBweDtcbiAgbWluLXdpZHRoOiA4MHB4O1xufVxuLnJpOHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cblxuXG5AbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcbiAgdGFibGUudGFibGUtYm9yZGVyZWQge1xuICAgIGZvbnQtc2l6ZTogLjdyZW07XG4gIH1cbiAgLmRheV9oZWFkaW5ne1xuICAgIGZvbnQtc2l6ZTogMTVweCAhaW1wb3J0YW50O1xuICB9XG5cbiAgLnRtX2RldGFpbHtcbiAgICBmb250LXNpemU6IHNtYWxsO1xuICB9XG4gIC5iZ19waWN7XG4gICAgYmFja2dyb3VuZC1zaXplOiAxMDB2aCAhaW1wb3J0YW50O1xuICB9XG59XG5cbkBtZWRpYSAobWF4LXdpZHRoOiA1NzVweCkge1xuICAuYm9kZXJfc3R5bGV7XG5cbiAgICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jdXN0b20tbGluayB7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4ICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuc3RkdF9pbWcge1xuICAgIG1hcmdpbi1sZWZ0OiAzMCUgIWltcG9ydGFudDtcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbjogMCBhdXRvO1xuICAgIG1hcmdpbi10b3A6IDUwcHg7XG4gIH0gIFxufVxuXG4udGltZS10YWJsZS1jb2x1bW57XG4gIHBhZGRpbmc6IDAgMCAwIDEwcHg7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIC8qbGlzdC1zdHlsZTogbm9uZTsqL1xufVxuXG4ubWF4LXdpZHRoLWhlaWdodCB7XG4gIG1heC13aWR0aDogMTY1cHg7XG4gIG1heC1oZWlnaHQ6IGZsZXg7XG59XG5cbi5jaXJjbGUge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiAxMnB4O1xuICBoZWlnaHQ6IDEycHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG59XG5cbi8qIEFkZCB0aGlzIENTUyB0byB5b3VyIHN0eWxlc2hlZXQgKi9cbi5jdXN0b20tbGluayB7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTsgLyogUmVtb3ZlIHVuZGVybGluZSAqL1xuICBjb2xvcjogIzMzMzsgLyogQ2hhbmdlIGxpbmsgY29sb3IgKi9cbiAgZGlzcGxheTogZmxleDsgLyogTWFrZSB0aGUgaWNvbiBhbmQgdGV4dCBkaXNwbGF5IGhvcml6b250YWxseSAqL1xuICBhbGlnbi1pdGVtczogY2VudGVyOyAvKiBDZW50ZXIgYWxpZ24gaWNvbiBhbmQgdGV4dCB2ZXJ0aWNhbGx5ICovXG4gIG1hcmdpbi1ib3R0b206IDE3cHg7XG59XG5cbi5jdXN0b20tbGluazpob3ZlciB7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lOyAvKiBSZW1vdmUgdW5kZXJsaW5lIG9uIGhvdmVyICovXG4gIGNvbG9yOiBibHVlOyAvKiBDaGFuZ2UgbGluayBjb2xvciBvbiBob3ZlciAqL1xufVxuXG4uZmEtbGcge1xuICBmb250LXNpemU6IDI0cHg7IC8qIEFkanVzdCB0aGUgaWNvbiBzaXplIGFzIG5lZWRlZCAqL1xufVxuXG4udGV4dC1sZyB7XG4gIGZvbnQtc2l6ZTogMThweDsgLyogQWRqdXN0IHRoZSB0ZXh0IHNpemUgYXMgbmVlZGVkICovXG4gIG1hcmdpbi1sZWZ0OiA2cHg7IC8qIEFkZCBzcGFjaW5nIGJldHdlZW4gaWNvbiBhbmQgdGV4dCAqL1xufVxuXG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
    data: {
      animation: [(0,_transitions__WEBPACK_IMPORTED_MODULE_1__.SlideInFromLeft)()]
    }
  });
}

/***/ })

}]);
//# sourceMappingURL=src_app_student_student_module_ts.js.map