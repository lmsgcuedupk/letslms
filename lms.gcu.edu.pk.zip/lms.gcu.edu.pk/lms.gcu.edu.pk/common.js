"use strict";
(self["webpackChunklmsv3"] = self["webpackChunklmsv3"] || []).push([["common"],{

/***/ 61335:
/*!**************************************************************!*\
  !*** ./src/app/main/shared/services/Announcement.service.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AnnouncementService": () => (/* binding */ AnnouncementService)
/* harmony export */ });
/* harmony import */ var src_axios_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/axios.js */ 46491);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 58987);



class AnnouncementService {
  constructor(http) {
    this.http = http;
  }
  getAnnouncements(params) {
    return this.http.post(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/announcement/getAnnoucements`, params);
  }
  // for record add screen
  UploadDailyRecord(params) {
    return this.http.post(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/systemUpdates/uploadDailyRecord`, params);
  }
  getRecord(params) {
    return this.http.post(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/systemUpdates/getRecord`, params);
  }
  static #_ = this.ɵfac = function AnnouncementService_Factory(t) {
    return new (t || AnnouncementService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: AnnouncementService,
    factory: AnnouncementService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 71775:
/*!**********************************************************!*\
  !*** ./src/app/main/shared/services/Repeater.service.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RepeaterService": () => (/* binding */ RepeaterService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var src_axios_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/axios.js */ 46491);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);




class RepeaterService {
  constructor(http) {
    this.http = http;
  }
  getSectionCountandName(grp, se_id, t_no, c_code, sub_code) {
    return this.http.get(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/repeater/getSectionCountandName/${grp}/${se_id}/${t_no}/${c_code}/${sub_code}`);
  }
  getRepeaterAttAssignData(year, c_code, rn, t_no, maj_id, sub_code, se_id, sec) {
    return this.http.get(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/repeater/getRepeaterAttAssignData/${year}/${c_code}/${rn}/${t_no}/${maj_id}/${sub_code}/${se_id}/${sec}`);
  }
  DeleteRepeaterEnrollment(year, c_code, rn, t_no, maj_id, sub_code, se_id, sec) {
    return this.http.post(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/repeater/DeleteRepeaterEnrollment`, {
      year: year,
      c_code: c_code,
      rn: rn,
      t_no: t_no,
      maj_id: maj_id,
      sub_code: sub_code,
      se_id: se_id,
      sec: sec
    });
  }
  RepeaterEnrollment(year, c_code, rn, t_no, maj_id, sub_code, se_id, sec) {
    let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams().set('year', year.valueOf()).set('c_code', c_code.valueOf()).set('rn', rn.valueOf()).set('t_no', t_no.valueOf()).set('maj_id', maj_id.valueOf()).set('sub_code', sub_code.valueOf()).set('se_id', se_id.valueOf()).set('sec', sec.valueOf());
    return this.http.post(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/repeater/RepeaterEnrollment`, params);
  }
  GetSubjectNatureId(c_code, sub_code) {
    return this.http.get(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/repeater/GetSubjectNatureId/${c_code}/${sub_code}`);
  }
  SearchRepeater(c_code, se_id, t_no, rn, year) {
    return this.http.get(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/repeater/SearchRepeater/${c_code}/${se_id}/${t_no}/${rn}/${year}`);
  }
  viewAllRepeater(c_code, maj_id, se_id, t_no, sub_code) {
    return this.http.get(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/repeater/viewAllRepeater/${c_code}/${maj_id || 0}/${se_id || 0}/${t_no || 0}/${sub_code || null}`);
  }
  getSubjectRepeaterStudents(c_code, se_id, t_no) {
    return this.http.get(`${src_axios_js__WEBPACK_IMPORTED_MODULE_0__.baseUrl}/api/repeater/getSubjectRepeaterStudents/${c_code}/${se_id}/${t_no}`);
  }
  static #_ = this.ɵfac = function RepeaterService_Factory(t) {
    return new (t || RepeaterService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: RepeaterService,
    factory: RepeaterService.ɵfac,
    providedIn: 'root'
  });
}

/***/ })

}]);
//# sourceMappingURL=common.js.map